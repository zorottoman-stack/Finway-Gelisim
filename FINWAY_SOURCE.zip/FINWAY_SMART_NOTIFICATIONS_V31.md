# Finway v31 — Akıllı Bildirim Merkezi

- Bildirimler artık kategori, önem seviyesi ve aksiyon bilgisi taşıyor.
- Okunmamış bildirimler rozetle gösteriliyor; tek tek açıldığında okundu olarak işaretleniyor.
- “Tümünü okundu yap” ve günlük bildirim gruplaması eklendi.
- Kart, hedef, harcama ve Finbi bildirimleri için farklı görsel türler eklendi.
- Bildirime dokunulduğunda ilgili Finway bölümüne yönlendirme yapılabiliyor.
- Akıllı bildirim motoru günde en fazla 3 yeni uyarı üretir ve aynı uyarının aynı gün tekrarlanmasını engeller.
- Yaklaşan kredi kartı son ödeme tarihi, yüksek kart limit kullanımı, hedef ilerlemesi ve kategori bazlı harcama artışı izlenir.
- Akıllı bildirimler ayrıca Android bildirim merkezine gönderilir.
- Mevcut Finbi sohbet/klavye, PIN ekranı, kredi kartı-taksit modülü, Harcama ve Anasayfa işlevlerine dokunulmamıştır.
- Dil/localization kapsamı değiştirilmemiştir.
