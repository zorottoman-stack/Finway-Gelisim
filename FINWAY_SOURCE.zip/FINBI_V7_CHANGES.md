# Finbi v7 — Comprehensive Finance Intelligence

- Preserved the existing floating Finbi UI, typing indicator, draggable bubble, X close behavior, and Menu toggle.
- Expanded the local Finbi answer engine without changing transaction/card/goal business logic.
- Added month-over-month comparison and 3-month trend summaries.
- Added category-level expense recognition, including common Turkish category wording and matching existing user categories.
- Added transaction counts and average daily spending answers.
- Expanded credit-card answers with per-card debt, available limit, minimum payment and due-day details.
- Expanded installment answers with active count, estimated monthly load and remaining installment load.
- Expanded savings and goal analysis.
- Added market answers for USD, EUR and gram gold using the app's existing market quote cache.
- Improved intent precedence so specific questions (card count, minimum payment, installments) are not swallowed by generic card/borç matching.
- Expanded quick-question chips.
- No changes to the locked Home or Transactions page logic.
- Source version bumped to 0.2.51 / versionCode 23.

The uploaded APK is treated as behavioral/UI reference; it is v0.2.13 and is not the source baseline.
