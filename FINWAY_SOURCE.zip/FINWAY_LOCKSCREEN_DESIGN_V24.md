# Finway Lock Screen Design v24

- Reworked the app lock screen to match the approved full-screen Finway concept.
- Preserved Finway wordmark and launcher icon.
- Full-screen dialog/window with edge-to-edge layout and transparent system bars.
- Added soft cyan/green wave background rendered natively.
- Added six-digit PIN UI, biometric quick-login card, PIN reset, help center, and bottom sign-in CTA.
- Preserved biometric authentication implementation and PIN verification behavior from v23.
- Finbi remains hidden while locked.
