# Finway v33 — Goal Categories + Credit Card Statement Day

- Goal icon is no longer manually entered as an emoji.
- Goal categories use consistent Finway line icons: Vehicle, Home, Travel, Technology, Education, Wedding/Special Day, Shopping, Savings, Emergency, Debt Payoff, Investment, Other.
- Existing legacy emoji goal icons are mapped to the closest supported category when edited/displayed.
- A Special Goal category remains available for unusual user-defined goals.
- Credit-card statement/closing day is now selected from 1–31 via a spinner instead of manual text entry.
- Existing saved statement days are preserved and selected automatically when editing.
- Credit-card debt, installment, and payment logic are unchanged.
- No localization pass was performed.
