# Finway Build Fix v20

Based on Finway_UI_Fixes_v19.

## Build fix
- Removed an invalid Activity override: `onTaskRemoved(Intent)` is not an Activity method.
- Removed the corresponding `super.onTaskRemoved(...)` call that caused the second compiler error.

## Lock-session behavior
- A new Activity launch (`savedInstanceState == null`) starts locked when App Lock is enabled.
- Activity recreation/configuration changes do not reset an already authenticated in-process session.
- A fresh process still starts with a locked session because the static session flag is reset.
- Backgrounding the existing Activity does not trigger a lock.
- Finbi remains hidden while the lock screen is active.
