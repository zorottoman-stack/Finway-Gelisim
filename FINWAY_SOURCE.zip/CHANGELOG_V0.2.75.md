# Finway v0.2.75 (versionCode 47)

## Düzeltmeler
- **Yedek/dışa aktarma hatası:** Hesaplar `Genel|Maaş` biçiminde saklanırken yedekleme bunları JSON dizisi gibi okumaya çalışıyordu. Kaydedilmiş hesap varsa yedek dosyası boş `{}` çıkıyordu. Artık hesaplar doğru yazılıyor ve geri yüklemede doğru okunuyor.
- Geri yükleme sonrası hesap listesi ve tercihler artık hemen yenileniyor (`loadAccounts()`, `loadPrefs()`).
- Yedek sürümü 2: aylık bütçe, birikim kayıtları ve kayıtlı bankalar da yedekleniyor. Eski (sürüm 1) yedekler hâlâ geri yüklenebilir; eksik alanlar mevcut değerleri silmez.
- Dışa aktarım öncesi önceki dışa aktarım dosyaları önbellekten temizleniyor.

## Güvenlik
- `allowBackup="false"`: PIN doğrulayıcısı ve finansal veriler Android bulut/cihaz yedeğine karışmıyor. Verileri taşımak için uygulamanın kendi yedek/dışa aktarma özelliği kullanılır.
- PIN deneme sınırı: 5 hatalı denemeden sonra 30 sn kilit; her yeni hatada süre ikiye katlanır (en fazla 1 saat). Doğru PIN veya biyometrik giriş sayacı sıfırlar. Kilit süresi cihaz saatine bağlıdır.

## Yeni özellik: Aylık bütçe
- Ana ekrandaki bütçe kartı zaten vardı ama tutar hep 0'dı. Karta dokununca bütçe belirlenir (0 girilirse kaldırılır).
- İlerleme çubuğu %80'de turuncu, %100'de kırmızı olur.
- Akıllı bildirimler: bütçenin %80'ine ve %100'üne ulaşınca ayda bir kez uyarı (uygulama içi bildirim merkezi + sistem bildirimi).
- Finbi'nin bütçe cevapları da bu tutarı kullanır.

## Notlar
- V44'te eklenen bütçe, kategori bütçesi, abonelik ve ilgili bildirim metinleri artık 11 dilde (`tr`, `en`, `fr`, `ru`, `de`, `ja`, `zh`, `ar`, `el`, `es`, `it`) doğrudan yerelleştirilmiştir. Dinamik PIN kilit süresi mesajları da seçili dile göre gösterilir.
- Bu sürüm Android SDK olmadan derlenemedi; yalnızca Java sözdizimi/sembol düzeyinde kontrol edildi. Yayınlamadan önce CI'da derleyip cihazda deneyin.

## V46 Notification Localization Fix
- Smart notifications now use the selected Finway language for credit-card, goal, spending-change, and budget alerts.
- Changing the app language clears only smart notification fingerprints/history and active smart system notifications, then regenerates applicable smart notices in the selected language.
- Credit-card reminder notifications remain independent and retain their existing 11-language localization.
