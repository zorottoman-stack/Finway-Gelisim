package com.example.butcem;

import android.app.*;
import android.os.*;
import android.service.notification.StatusBarNotification;
import android.content.*;
import android.content.res.Configuration;
import android.net.Uri;
import androidx.core.content.FileProvider;
import androidx.core.app.NotificationCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.OnApplyWindowInsetsListener;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.DatePickerDialog;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.Editable;
import org.json.*;
import java.text.*;
import java.util.*;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import android.view.inputmethod.InputMethodManager;
import androidx.biometric.BiometricPrompt;
import androidx.biometric.BiometricManager;
import androidx.fragment.app.FragmentActivity;
import java.util.concurrent.Executor;

public class MainActivity extends FragmentActivity {
    @Override protected void attachBaseContext(Context newBase) {
        String lang = newBase.getSharedPreferences("MainActivity", Context.MODE_PRIVATE).getString("lang", "tr");
        Locale locale = localeForLanguage(lang);
        Locale.setDefault(locale);
        Configuration config = new Configuration(newBase.getResources().getConfiguration());
        config.setLocale(locale);
        super.attachBaseContext(newBase.createConfigurationContext(config));
    }

    private static Locale localeForLanguage(String lang) {
        if ("en".equals(lang)) return Locale.US;
        if ("fr".equals(lang)) return Locale.FRANCE;
        if ("de".equals(lang)) return Locale.GERMANY;
        if ("it".equals(lang)) return Locale.ITALY;
        if ("es".equals(lang)) return new Locale("es", "ES");
        if ("ru".equals(lang)) return new Locale("ru", "RU");
        if ("ja".equals(lang)) return Locale.JAPAN;
        if ("zh".equals(lang)) return Locale.CHINA;
        if ("ar".equals(lang)) return new Locale("ar", "SA");
        if ("el".equals(lang)) return new Locale("el", "GR");
        return new Locale("tr", "TR");
    }

    String s(int resId, Object... args) {
        return args.length == 0 ? getString(resId) : getString(resId, args);
    }

    String money(double value) {
        Locale loc = localeForLanguage(language);
        NumberFormat f = NumberFormat.getCurrencyInstance(loc);
        try { f.setCurrency(Currency.getInstance(currencyCode)); } catch (Exception ignored) {}
        return f.format(value);
    }

    String currencyLabel() {
        if ("USD".equals(currencyCode)) return "$ USD";
        if ("EUR".equals(currencyCode)) return "€ EUR";
        return "₺ TRY";
    }
    private String currencyCode = "TRY";
    private final SimpleDateFormat df = new SimpleDateFormat("dd.MM.yyyy", new Locale("tr","TR"));
    private ArrayList<Tx> txs = new ArrayList<>();
    private ArrayList<Category> categories = new ArrayList<>();
    private ArrayList<Goal> goals = new ArrayList<>();
    private ArrayList<Goal> completedGoals = new ArrayList<>();
    private LinearLayout content;
    private ScrollView activeScrollView;
    // Ana sayfadaki piyasa kartını 2 saniyelik yenilemelerde yeniden oluşturmuyoruz;
    // böylece ScrollView konumu sabit kalır ve ekran sekmez.
    private TextView homeUsdValue, homeEurValue, homeGoldBuyValue, homeGoldSellValue;
    private boolean darkMode = false;
    private int themeMode = 0; // 0 light, 1 dark, 2 system
    private String language = "tr";
    private int currentPage = 0;
    // Finway navigation history: preserves the page we came from when using Back.
    private final Deque<String> screenHistory = new ArrayDeque<>();
    private final HashMap<String,Integer> screenScrollPositions = new HashMap<>();
    private String currentScreen = "home";
    private boolean navigatingBack = false;
    private long lastBackEventAt = 0L;

    private void rememberCurrentScroll() {
        if (activeScrollView != null && currentScreen != null) {
            screenScrollPositions.put(currentScreen, Math.max(0, activeScrollView.getScrollY()));
        }
    }

    private void enterScreen(String screen) {
        if (screen == null) screen = "home";
        if (!screen.equals(currentScreen)) {
            rememberCurrentScroll();
            if (!navigatingBack) screenHistory.push(currentScreen);
        }
        currentScreen = screen;
    }

    private void restoreScreenScroll() {
        if (activeScrollView == null) return;
        final int y = Math.max(0, screenScrollPositions.containsKey(currentScreen) ? screenScrollPositions.get(currentScreen) : 0);
        activeScrollView.post(() -> {
            activeScrollView.scrollTo(0, y);
            activeScrollView.postDelayed(() -> activeScrollView.scrollTo(0, y), 80L);
        });
    }

    private void handleFinwayBack() {
        // Handle a single Android back action at a time. Some Android 13+
        // devices can report the same gesture through more than one route.
        long now = SystemClock.uptimeMillis();
        if (now - lastBackEventAt < 180L) return;
        lastBackEventAt = now;

        // The stack always represents the screen immediately before the current
        // one. Back therefore means "previous Finway screen", never "Home"
        // unless Home was actually the previous screen.
        if (!screenHistory.isEmpty()) {
            String target = screenHistory.pop();
            navigatingBack = true;
            try {
                switch (target) {
                    case "home": showHome(); break;
                    case "credit": showCreditCards(); break;
                    case "savings": showGoals(); break;
                    case "menu": showMenu(); break;
                    case "transactions": showTransactions(); break;
                    case "stats": showStats(); break;
                    case "markets": showMarkets(); break;
                    case "recurring": showRecurringPayments(); break;
                    case "budgets": showBudgets(); break;
                    case "subscriptions": showSubscriptions(); break;
                    case "data": showDataTransfer(); break;
                    case "settings": showSettings(); break;
                    case "about": showAbout(); break;
                    case "guide": showGuide(); break;
                    case "assistant": showDigitalFinanceAssistant(); break;
                    case "accounts": showAccounts(); break;
                    default: showMenu(); break;
                }
            } finally { navigatingBack = false; }
            return;
        }

        // If a screen was opened directly (for example from a notification,
        // a deep link, or a root tab), never throw the user out of Finway.
        // Return to Home first; only Home with an empty history can exit.
        if (!"home".equals(currentScreen)) {
            navigatingBack = true;
            try { showHome(); } finally { navigatingBack = false; }
            return;
        }

        // Home is the root of Finway. Do not finish the Activity here: the
        // Android back action must never unexpectedly send Finway to the background.
        // The user can leave Finway explicitly through the system/app switcher.
        return;
    }

    @Override
    public void onBackPressed() {
        // Legacy Android (< 33) and explicit in-app back buttons.
        handleFinwayBack();
    }
    private final Calendar viewMonth = Calendar.getInstance();
    private static final int REQ_BACKUP=4101, REQ_RESTORE=4102, REQ_TRANSFER_IMPORT=4103;
    private static final int REQ_DEVICE_RESET=4199;
    private boolean pendingDeviceReset=false;

    static class Tx {
        long id; boolean isIncome; double amount; String desc, date, cat, account; boolean creditCard; long cardId; long paymentId; boolean archived; boolean cancelled;
        Tx(long id, boolean isIncome, double amount, String desc, String date, String cat){this(id,isIncome,amount,desc,date,cat,false,0,0);}
        Tx(long id, boolean isIncome, double amount, String desc, String date, String cat, boolean creditCard, long cardId){this(id,isIncome,amount,desc,date,cat,creditCard,cardId,0);}
        Tx(long id, boolean isIncome, double amount, String desc, String date, String cat, boolean creditCard, long cardId, long paymentId){this(id,isIncome,amount,desc,date,cat,creditCard,cardId,paymentId,false);}
        Tx(long id, boolean isIncome, double amount, String desc, String date, String cat, boolean creditCard, long cardId, long paymentId, boolean archived){this.id=id;this.isIncome=isIncome;this.amount=amount;this.desc=desc;this.date=date;this.cat=cat;this.account="Genel";this.creditCard=creditCard;this.cardId=cardId;this.paymentId=paymentId;this.archived=archived;this.cancelled=false;}
    }
    static class Category { String name, icon; Category(String n,String i){name=n;icon=i;} }
    static class Goal { long id; String name, icon, deadline; double target, saved; Goal(long id,String name,String icon,double target,double saved,String deadline){this.id=id;this.name=name;this.icon=icon;this.target=target;this.saved=saved;this.deadline=deadline;} }
    static class SavingEntry { long id; double amount; String unit, date; SavingEntry(long id,double amount,String unit,String date){this.id=id;this.amount=amount;this.unit=unit;this.date=date;} }
    static class CreditCard { long id; String name, bank; double limit, debt, statementDebt, minPayment; int statementDay, dueDay; CreditCard(long id,String name,String bank,double limit,double debt,double statementDebt,double minPayment,int statementDay,int dueDay){this.id=id;this.name=name;this.bank=bank;this.limit=limit;this.debt=debt;this.statementDebt=statementDebt;this.minPayment=minPayment;this.statementDay=statementDay;this.dueDay=dueDay;} }
    static class Installment { long id, cardId; String merchant, firstDate, note; double total; int count, paidCount; boolean debtTracked; Installment(long id,long cardId,String merchant,double total,int count,int paidCount,String firstDate,String note){this(id,cardId,merchant,total,count,paidCount,firstDate,note,false);} Installment(long id,long cardId,String merchant,double total,int count,int paidCount,String firstDate,String note,boolean debtTracked){this.id=id;this.cardId=cardId;this.merchant=merchant;this.total=total;this.count=count;this.paidCount=paidCount;this.firstDate=firstDate;this.note=note;this.debtTracked=debtTracked;} }
    static class CardPayment { long id, cardId, installmentId; double amount; String date, note, account; boolean cancelled; CardPayment(long id,long cardId,double amount,String date,String note){this(id,cardId,0,amount,date,note,"Genel");} CardPayment(long id,long cardId,long installmentId,double amount,String date,String note,String account){this.id=id;this.cardId=cardId;this.installmentId=installmentId;this.amount=amount;this.date=date;this.note=note;this.account=account==null||account.isEmpty()?"Genel":account;this.cancelled=false;} }

    private final ArrayList<CreditCard> creditCards = new ArrayList<>();
    private final ArrayList<String> accounts = new ArrayList<>();
    private boolean appLockEnabled=false, pendingUnlock=false, biometricEnabled=false;
    private static boolean appSessionUnlocked=false;
    private Dialog activeLockDialog;
    private final ArrayList<Installment> installments = new ArrayList<>();
    private final ArrayList<CardPayment> cardPayments = new ArrayList<>();
    private final ArrayList<String> savedBanks = new ArrayList<>();
    static class MarketQuote { String code, name; double buy, sell, change; String updated; MarketQuote(String code,String name,double buy,double sell,double change,String updated){this.code=code;this.name=name;this.buy=buy;this.sell=sell;this.change=change;this.updated=updated;} }
    private final HashMap<String,MarketQuote> marketQuotes = new HashMap<>();
    private String marketBaseUnit = "TRY";
    private final ArrayList<String> watchedMarketCodes = new ArrayList<>(Arrays.asList("USDTRY","EURTRY","GRAMALTIN"));
    private boolean marketLoading = false;
    private boolean marketAutoUpdate = false;
    private int cardReminderDays = 0; // 0 = no selection; 10, 5, 3, 1
    private boolean cardReminderSound = true;
    private boolean cardReminderUseRange = false;
    private int cardReminderStartMinute = 9 * 60;
    private int cardReminderEndMinute = 9 * 60 + 30;
    private static final String REMINDER_CHANNEL = "finway_card_reminders_v2";
    private static final String REMINDER_CHANNEL_SILENT = "finway_card_reminders_silent_v2";
    private static final int REMINDER_REQ_BASE = 41000;
    private boolean marketsVisible = false;
    private TextView notificationBadge;
    private final BroadcastReceiver notificationAddedReceiver = new BroadcastReceiver(){
        @Override public void onReceive(Context context, Intent intent){ updateNotificationBadge(); }
    };
    private final Handler marketHandler = new Handler(Looper.getMainLooper());
    private static final long MARKET_AUTO_UPDATE_MS = 2L*1000L;
    private final Runnable marketAutoRunnable = new Runnable(){ public void run(){ if(marketAutoUpdate){ loadMarketData(null); marketHandler.postDelayed(this, MARKET_AUTO_UPDATE_MS); } } };
    private boolean rebuildingSettings=false;

    // Finbi: app-wide draggable assistant bubble. It is intentionally attached at the Activity
    // level so existing locked screens and their business logic remain untouched.
    private boolean finbiEnabled=true;
    private FrameLayout finbiOverlay;
    private View finbiBubble;
    private Switch finbiMenuSwitch;
    private View finbiChatPanel;
    private float finbiDownX, finbiDownY;
    private int finbiStartLeft, finbiStartTop;
    private boolean finbiDragging=false;

    private Runnable marketDataCallback = null;
    private Runnable savingsMarketCallback = null;

    @Override public void setContentView(View view){
        super.setContentView(view);
        if(finbiEnabled && (!appLockEnabled || appSessionUnlocked)) installFinbiBubble();
    }

    @Override public void setContentView(View view, ViewGroup.LayoutParams params){
        super.setContentView(view,params);
        if(finbiEnabled && (!appLockEnabled || appSessionUnlocked)) installFinbiBubble();
    }

    private String finbiSlogan(){
        if("en".equals(language)) return "Spread your wings toward financial freedom";
        if("fr".equals(language)) return "Déploie tes ailes vers la liberté financière";
        if("de".equals(language)) return "Breite deine Flügel zur finanziellen Freiheit aus";
        if("ru".equals(language)) return "Расправь крылья навстречу финансовой свободе";
        if("ja".equals(language)) return "経済的自由へ、翼を広げよう";
        if("zh".equals(language)) return "张开翅膀，飞向财务自由";
        if("ar".equals(language)) return "حلّق بجناحيك نحو الحرية المالية";
        if("el".equals(language)) return "Άνοιξε τα φτερά σου προς την οικονομική ελευθερία";
        if("es".equals(language)) return "Abre tus alas hacia la libertad financiera";
        if("it".equals(language)) return "Spiega le ali verso la libertà finanziaria";
        return "Finansal özgürlüğe kanat aç";
    }

    private String finbiGreeting(){
        if("en".equals(language)) return "Hi! I’m Finbi. How can I help with your finances?";
        if("fr".equals(language)) return "Bonjour ! Je suis Finbi. Comment puis-je vous aider avec vos finances ?";
        if("de".equals(language)) return "Hallo! Ich bin Finbi. Wie kann ich dir bei deinen Finanzen helfen?";
        if("ru".equals(language)) return "Привет! Я Finbi. Чем помочь с твоими финансами?";
        if("ja".equals(language)) return "こんにちは！Finbiです。お金の管理をお手伝いします。";
        if("zh".equals(language)) return "你好！我是 Finbi。今天想让我帮你看看财务吗？";
        if("ar".equals(language)) return "مرحباً! أنا Finbi. كيف يمكنني مساعدتك في شؤونك المالية؟";
        if("el".equals(language)) return "Γεια! Είμαι ο Finbi. Πώς μπορώ να βοηθήσω με τα οικονομικά σου;";
        if("es".equals(language)) return "¡Hola! Soy Finbi. ¿Cómo puedo ayudarte con tus finanzas?";
        if("it".equals(language)) return "Ciao! Sono Finbi. Come posso aiutarti con le tue finanze?";
        return "Merhaba! Ben Finbi. Finansında nasıl yardımcı olabilirim?";
    }

    private void installFinbiBubble(){
        if(!finbiEnabled) return;
        ViewGroup host=(ViewGroup)findViewById(android.R.id.content);
        if(host==null) return;
        if(finbiOverlay!=null && finbiOverlay.getParent()==host) host.removeView(finbiOverlay);
        finbiOverlay=new FrameLayout(this);
        finbiOverlay.setClipChildren(false); finbiOverlay.setClipToPadding(false);
        host.addView(finbiOverlay,new ViewGroup.LayoutParams(-1,-1));

        final FrameLayout bubbleWrap=new FrameLayout(this);
        bubbleWrap.setClipChildren(false); bubbleWrap.setClipToPadding(false);
        bubbleWrap.setElevation(dp(10));

        ImageView mascot=new ImageView(this);
        mascot.setImageResource(R.drawable.finbi_avatar);
        mascot.setScaleType(ImageView.ScaleType.CENTER_CROP);
        mascot.setPadding(dp(1),dp(1),dp(1),dp(1));
        GradientDrawable mascotCircle=new GradientDrawable();
        mascotCircle.setShape(GradientDrawable.OVAL);
        mascotCircle.setColor(darkMode?Color.rgb(17,48,74):Color.rgb(232,247,255));
        mascotCircle.setStroke(dp(2),darkMode?Color.rgb(48,117,158):Color.rgb(121,211,245));
        mascot.setBackground(mascotCircle);
        if(Build.VERSION.SDK_INT>=21) mascot.setClipToOutline(true);
        mascot.setContentDescription("Finbi");
        FrameLayout.LayoutParams mascotLp=new FrameLayout.LayoutParams(dp(58),dp(58),Gravity.BOTTOM|Gravity.START);
        mascotLp.setMargins(0,0,dp(3),0);
        bubbleWrap.addView(mascot,mascotLp);
        // Very subtle idle animation: Finbi gently breathes instead of occupying attention.
        mascot.postDelayed(new Runnable(){
            @Override public void run(){
                if(mascot.getParent()==null) return;
                mascot.animate().scaleX(1.035f).scaleY(1.035f).setDuration(650).withEndAction(()->
                    mascot.animate().scaleX(1f).scaleY(1f).setDuration(650).withEndAction(this).start()
                ).start();
            }
        },700);

        TextView close=text("×",17,darkMode?Color.WHITE:C().muted);
        close.setGravity(Gravity.CENTER);
        close.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        close.setBackground(bg(darkMode?Color.rgb(31,57,75):Color.WHITE,12));
        close.setElevation(dp(12));
        close.setContentDescription("Finbi kapat");
        FrameLayout.LayoutParams closeLp=new FrameLayout.LayoutParams(dp(20),dp(20),Gravity.TOP|Gravity.END);
        closeLp.setMargins(0,-dp(5),-dp(5),0);
        bubbleWrap.addView(close,closeLp);
        close.setOnClickListener(v->{
            setFinbiEnabled(false);
        });

        finbiBubble=bubbleWrap;
        bubbleWrap.setOnTouchListener((v,event)->{
            switch(event.getActionMasked()){
                case MotionEvent.ACTION_DOWN:
                    finbiDownX=event.getRawX(); finbiDownY=event.getRawY();
                    finbiStartLeft=((FrameLayout.LayoutParams)v.getLayoutParams()).leftMargin;
                    finbiStartTop=((FrameLayout.LayoutParams)v.getLayoutParams()).topMargin;
                    finbiDragging=false; return true;
                case MotionEvent.ACTION_MOVE:
                    float dx=event.getRawX()-finbiDownX, dy=event.getRawY()-finbiDownY;
                    if(Math.abs(dx)>dp(8)||Math.abs(dy)>dp(8)) finbiDragging=true;
                    if(finbiDragging){
                        FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)v.getLayoutParams();
                        int maxX=Math.max(0,finbiOverlay.getWidth()-v.getWidth());
                        int maxY=Math.max(0,finbiOverlay.getHeight()-v.getHeight());
                        lp.leftMargin=Math.max(0,Math.min(maxX,finbiStartLeft+(int)dx));
                        lp.topMargin=Math.max(dp(6),Math.min(maxY,finbiStartTop+(int)dy));
                        v.setLayoutParams(lp);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if(!finbiDragging){ showFinbiChat(); }
                    else snapFinbiToEdge(v);
                    return true;
            }
            return true;
        });

        int wrapW=dp(68), wrapH=dp(68);
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(wrapW,wrapH,Gravity.TOP|Gravity.START);
        int sw=getResources().getDisplayMetrics().widthPixels;
        int sh=getResources().getDisplayMetrics().heightPixels;
        int savedX=getPreferences(0).getInt("finbi_x",Integer.MIN_VALUE);
        int savedY=getPreferences(0).getInt("finbi_y",Integer.MIN_VALUE);
        int maxSavedX=Math.max(dp(4),sw-wrapW-dp(4));
        int maxSavedY=Math.max(dp(6),sh-wrapH-dp(6));
        lp.leftMargin=savedX==Integer.MIN_VALUE?Math.max(dp(8),sw-wrapW-dp(10)):Math.max(dp(4),Math.min(maxSavedX,savedX));
        lp.topMargin=savedY==Integer.MIN_VALUE?Math.max(dp(80),sh-wrapH-dp(120)):Math.max(dp(6),Math.min(maxSavedY,savedY));
        finbiOverlay.addView(bubbleWrap,lp);
    }

    private void snapFinbiToEdge(View v){
        FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)v.getLayoutParams();
        int maxX=Math.max(0,finbiOverlay.getWidth()-v.getWidth());
        int target=lp.leftMargin+v.getWidth()/2<finbiOverlay.getWidth()/2?dp(4):Math.max(dp(4),maxX-dp(4));
        v.animate().x(target).setDuration(180).start();
        lp.leftMargin=target; v.setLayoutParams(lp);
        getPreferences(0).edit().putInt("finbi_x",target).putInt("finbi_y",lp.topMargin).apply();
    }

    private void addFinbiMessage(LinearLayout list,String message,boolean user){
        if(!user) message=finbiLocalizeOutput(message);
        TextView bubble=text(message,14,user?Color.WHITE:C().text);
        bubble.setPadding(dp(14),dp(10),dp(14),dp(10));
        bubble.setBackground(bg(user?C().blue:(darkMode?Color.rgb(25,48,68):Color.WHITE),18));
        bubble.setMaxWidth((int)(getResources().getDisplayMetrics().widthPixels*.76f));
        LinearLayout row=new LinearLayout(this);row.setGravity(user?Gravity.RIGHT:Gravity.LEFT);row.addView(bubble,new LinearLayout.LayoutParams(-2,-2));
        row.setPadding(0,dp(4),0,dp(4)); list.addView(row);
    }

    private String finbiMonthLabel(){
        return new SimpleDateFormat("MMMM yyyy", localeForLanguage(language)).format(viewMonth.getTime());
    }

    private double finbiCardAvailable(){
        double available=0;
        for(CreditCard cc:creditCards) available+=Math.max(0,cc.limit-Math.max(0,cc.debt));
        return available;
    }

    private double finbiCardMinPayments(){
        double total=0;
        for(CreditCard cc:creditCards) total+=Math.max(0,cc.minPayment);
        return total;
    }

    private String finbiTopExpenseCategory(){
        HashMap<String,Double> totals=new HashMap<>();
        String ym=new SimpleDateFormat("MM.yyyy",Locale.US).format(viewMonth.getTime());
        for(Tx t:txs){
            if(t.cancelled||t.isIncome||!t.date.endsWith(ym)) continue;
            String cat=(t.cat==null||t.cat.trim().isEmpty())?"Diğer":t.cat.trim();
            totals.put(cat,totals.containsKey(cat)?totals.get(cat)+t.amount:t.amount);
        }
        String best=""; double max=0;
        for(Map.Entry<String,Double> e:totals.entrySet()) if(e.getValue()>max){best=e.getKey();max=e.getValue();}
        return best.length()==0?"":best+" — "+money(max);
    }

    private String finbiGoalDetails(){
        if(goals.isEmpty()) return trUi("Henüz aktif bir hedefin görünmüyor. İstersen birlikte bir hedef oluşturabiliriz.","You don't have an active goal yet. We can create one together if you want.");
        StringBuilder b=new StringBuilder();
        int shown=0;
        for(Goal g:goals){
            double target=Math.max(0,g.target), saved=Math.max(0,g.saved);
            int pct=target<=0?0:(int)Math.round(Math.min(100,saved*100.0/target));
            if(shown++>0)b.append("\n");
            b.append("• ").append(g.name).append(": ").append(money(saved)).append(" / ").append(money(target)).append(" (%").append(pct).append(")");
            if(shown>=5)break;
        }
        if(goals.size()>5)b.append("\n• +").append(goals.size()-5).append(" hedef daha");
        return b.toString();
    }

    private String finbiMonthKey(Calendar cal){ return new SimpleDateFormat("MM.yyyy",Locale.US).format(cal.getTime()); }
    private Calendar finbiShiftMonth(int delta){ Calendar c=(Calendar)viewMonth.clone(); c.add(Calendar.MONTH,delta); return c; }
    private double finbiMonthSum(Calendar cal, boolean incomeOnly){ double total=0; String ym=finbiMonthKey(cal); for(Tx t:txs) if(!t.cancelled&&t.isIncome==incomeOnly&&t.date.endsWith(ym)) total+=Math.max(0,t.amount); return total; }
    private int finbiMonthCount(Calendar cal, boolean incomeOnly){ int n=0; String ym=finbiMonthKey(cal); for(Tx t:txs) if(!t.cancelled&&t.isIncome==incomeOnly&&t.date.endsWith(ym)) n++; return n; }
    private double finbiCategoryTotal(Calendar cal,String category){ double total=0; String ym=finbiMonthKey(cal); for(Tx t:txs) if(!t.cancelled&&!t.isIncome&&t.date.endsWith(ym)&&category.equalsIgnoreCase(t.cat==null?"":t.cat)) total+=Math.max(0,t.amount); return total; }
    private String finbiTopCategories(Calendar cal,int limit){
        HashMap<String,Double> totals=new HashMap<>(); String ym=finbiMonthKey(cal);
        for(Tx t:txs){ if(t.cancelled||t.isIncome||!t.date.endsWith(ym))continue; String cat=(t.cat==null||t.cat.trim().isEmpty())?"Diğer":t.cat.trim(); totals.put(cat,totals.containsKey(cat)?totals.get(cat)+t.amount:t.amount); }
        ArrayList<Map.Entry<String,Double>> list=new ArrayList<>(totals.entrySet()); Collections.sort(list,(a,b)->Double.compare(b.getValue(),a.getValue()));
        StringBuilder out=new StringBuilder(); for(int i=0;i<Math.min(limit,list.size());i++){if(i>0)out.append("\n");out.append(i+1).append(". ").append(categoryLabel(list.get(i).getKey())).append(" — ").append(money(list.get(i).getValue()));} return out.toString();
    }
    private String finbiFindCategoryFromQuestion(String q,Calendar cal){
        String x=q.toLowerCase(Locale.ROOT); String ym=finbiMonthKey(cal); HashSet<String> cats=new HashSet<>();
        for(Tx t:txs)if(!t.cancelled&&!t.isIncome&&t.date.endsWith(ym)&&t.cat!=null&&!t.cat.trim().isEmpty())cats.add(t.cat.trim());
        String[] common={"market","alışveriş","alisveris","yeme","yemek","restoran","restaurant","ulaşım","ulasim","akaryakıt","akaryakit","fatura","eğitim","egitim","sağlık","saglik","giyim","eğlence","eglence","kira","yakıt","yakit","benzin"};
        for(String key:common)if(x.contains(key)){for(String cat:cats)if(cat.toLowerCase(Locale.ROOT).contains(key))return cat;if(x.contains("market"))return "Market";if(x.contains("yem"))return "Yeme-İçme";if(x.contains("ulaş")||x.contains("ulas"))return "Ulaşım";}
        for(String cat:cats)if(x.contains(cat.toLowerCase(Locale.ROOT)))return cat; return "";
    }
    private String finbiCardDetails(){
        if(creditCards.isEmpty())return trUi("Henüz kayıtlı kredi kartın görünmüyor.","No registered credit card is visible yet."); StringBuilder b=new StringBuilder(trUi("Kredi kartı durumun:\n","Your credit card status:\n")); int i=0;
        for(CreditCard cc:creditCards){if(i++>0)b.append("\n");double used=Math.max(0,cc.debt),available=Math.max(0,cc.limit-used);b.append("• ").append(cc.name==null||cc.name.isEmpty()?"Kart":cc.name).append(": borç ").append(money(used)).append(", kullanılabilir ").append(money(available));if(cc.minPayment>0)b.append(", asgari ").append(money(cc.minPayment));if(cc.dueDay>0)b.append(", son ödeme günü ").append(cc.dueDay).append(".");} return b.toString();
    }
    private String finbiInstallmentDetails(){
        int active=0;double monthly=0,remaining=0;StringBuilder b=new StringBuilder();
        for(Installment in:installments){int rem=Math.max(0,in.count-in.paidCount);if(rem<=0)continue;active++;double per=in.total/Math.max(1,in.count);monthly+=per;remaining+=per*rem;if(b.length()<700){if(b.length()>0)b.append("\n");b.append("• ").append(in.merchant==null||in.merchant.isEmpty()?"Taksit":in.merchant).append(": ").append(rem).append(" taksit × ").append(money(per));}}
        if(active==0)return trUi("Aktif taksit görünmüyor.","No active installments are visible.");return active+" aktif taksidin var. Aylık yaklaşık yük: "+money(monthly)+". Kalan toplam tahmini yük: "+money(remaining)+".\n"+b;
    }
    private String finbiGoalAnalysis(){
        if(goals.isEmpty())return trUi("Henüz aktif bir hedefin görünmüyor. İstersen birlikte bir hedef oluşturabiliriz.","You don't have an active goal yet. We can create one together if you want.");StringBuilder b=new StringBuilder();int shown=0;
        for(Goal g:goals){double target=Math.max(0,g.target),saved=Math.max(0,g.saved);int pct=target<=0?0:(int)Math.round(Math.min(100,saved*100.0/target));double left=Math.max(0,target-saved);if(shown++>0)b.append("\n");b.append("• ").append(g.name).append(": %").append(pct).append(" tamamlandı, ").append(money(left)).append(" kaldı");if(g.deadline!=null&&!g.deadline.isEmpty())b.append(" — hedef tarihi ").append(g.deadline);if(shown>=6)break;}return b.toString();
    }
    private String finbiSavingsAnalysis(){
        ArrayList<SavingEntry> entries=getSavingEntries();if(entries.isEmpty())return trUi("Henüz kayıtlı birikim hareketi görünmüyor.","No saved savings activity is visible yet.");HashMap<String,Double> totals=new HashMap<>();for(SavingEntry e:entries)totals.put(e.unit,totals.containsKey(e.unit)?totals.get(e.unit)+e.amount:e.amount);StringBuilder b=new StringBuilder(trUi("Birikimlerin:\n","Your savings:\n"));int i=0;for(Map.Entry<String,Double> e:totals.entrySet()){if(i++>0)b.append("\n");b.append("• ").append(e.getKey()).append(": ").append(money(e.getValue()));}return b.toString();
    }
    private String finbiComparison(){
        Calendar prev=finbiShiftMonth(-1);double inc=finbiMonthSum(viewMonth,true),exp=finbiMonthSum(viewMonth,false),pinc=finbiMonthSum(prev,true),pexp=finbiMonthSum(prev,false);StringBuilder b=new StringBuilder();b.append(trUi("Bu ay: gelir ","This month: income ")).append(money(inc)).append(", gider ").append(money(exp)).append(".\nGeçen ay: gelir ").append(money(pinc)).append(", gider ").append(money(pexp)).append(".");if(pexp>0)b.append("\nHarcama değişimi: ").append(String.format(Locale.US,"%+.1f%%",(exp-pexp)*100.0/pexp)).append(".");if(pinc>0)b.append(" Gelir değişimi: ").append(String.format(Locale.US,"%+.1f%%",(inc-pinc)*100.0/pinc)).append(".");return b.toString();
    }
    private String finbiThreeMonthTrend(){
        StringBuilder b=new StringBuilder(trUi("Son 3 ayın özeti:","Summary of the last 3 months:"));double totalExp=0,totalInc=0;for(int i=0;i<3;i++){Calendar c=finbiShiftMonth(-i);double inc=finbiMonthSum(c,true),exp=finbiMonthSum(c,false);totalInc+=inc;totalExp+=exp;b.append("\n• ").append(new SimpleDateFormat("MM.yyyy",Locale.US).format(c.getTime())).append(": gelir ").append(money(inc)).append(" / gider ").append(money(exp));}b.append("\nToplam: gelir ").append(money(totalInc)).append(", gider ").append(money(totalExp)).append(", net ").append(money(totalInc-totalExp));return b.toString();
    }
    private String finbiMarketAnswer(String x){
        String code=x.contains("dolar")||x.contains("usd")?"USDTRY":x.contains("euro")||x.contains("eur")?"EURTRY":(x.contains("altın")||x.contains("altin")||x.contains("gram"))?"GRAMALTIN":"";if(code.isEmpty())return trUi("Piyasa tarafında dolar, euro veya gram altın için de bilgi verebilirim.","I can also provide information about the dollar, euro, or gram gold market.");MarketQuote q=marketQuotes.get(code);if(q==null)return trUi("Bu piyasa verisi şu anda yüklenmemiş. Piyasa ekranını açıp güncel veriyi yenileyebilirsin.","This market data is not loaded right now. Open the Markets screen and refresh the latest data.");return q.name+": alış "+money(q.buy)+", satış "+money(q.sell)+". Değişim: "+String.format(Locale.US,"%+.2f%%",q.change)+".";
    }

    private String finbiLastTopic="";
    private String finbiLastCategory="";
    private Calendar finbiLastMonth=null;

    private boolean finbiHas(String x,String... words){
        for(String w:words) if(x.contains(w)) return true;
        return false;
    }
    private String finbiPercent(double a,double b){
        if(Math.abs(b)<0.0001) return "—";
        return String.format(Locale.US,"%.1f%%",(a/b)*100.0);
    }
    private String finbiSignedChange(double current,double previous){
        if(Math.abs(previous)<0.0001) return current>0?trUi("arttı","increased"):trUi("değişmedi","did not change");
        double pct=(current-previous)*100.0/previous;
        return String.format(Locale.US,"%+.1f%%",pct);
    }
    private String finbiContextHint(String x){
        if(finbiHas(x,"peki","bunu","aynı","aynisi","yüzde kaç","yuzde kac","ne kadar arttı","ne kadar artti") && !finbiLastTopic.isEmpty()){
            if("category".equals(finbiLastTopic) && !finbiLastCategory.isEmpty()) return "category_followup";
            if("comparison".equals(finbiLastTopic)) return "comparison_followup";
        }
        return "";
    }
    private String finbiCategoryComparison(String category){
        Calendar prev=finbiShiftMonth(-1);
        double cur=finbiCategoryTotal(viewMonth,category), old=finbiCategoryTotal(prev,category);
        StringBuilder b=new StringBuilder();
        b.append(category).append(" harcaman bu ay ").append(money(cur)).append(".");
        b.append(" Geçen ay ").append(money(old)).append(".");
        if(old>0) b.append(" Değişim: ").append(finbiSignedChange(cur,old)).append(".");
        else if(cur>0) b.append(" Geçen ay bu kategoride kayıtlı harcama görünmüyor.");
        return b.toString();
    }
    private String finbiFinancialHealth(){
        double income=finbiMonthSum(viewMonth,true), expense=finbiMonthSum(viewMonth,false), net=income-expense;
        double budget=monthlyBudget();
        StringBuilder b=new StringBuilder(trUi("Bu ayki finansal görünümün:\n","Your financial picture this month:\n"));
        b.append("• Gelir: ").append(money(income)).append("\n");
        b.append("• Gider: ").append(money(expense)).append("\n");
        b.append("• Net: ").append(money(net));
        if(budget>0) b.append("\n• Bütçe kullanımı: ").append(finbiPercent(expense,budget)).append(" — kalan ").append(money(Math.max(0,budget-expense)));
        String top=finbiTopCategories(viewMonth,3);
        if(!top.isEmpty()) b.append("\n\nEn yüksek harcamaların:\n").append(top);
        Calendar prev=finbiShiftMonth(-1);
        double prevExp=finbiMonthSum(prev,false);
        if(prevExp>0) b.append("\n\nGeçen aya göre gider değişimi: ").append(finbiSignedChange(expense,prevExp)).append(".");
        if(net<0) b.append("\n\nBu ay giderlerin gelirlerini aşmış görünüyor; önce en yüksek harcama kategorilerini incelemek faydalı olabilir.");
        else if(budget>0 && expense>budget) b.append("\n\nBu ay bütçeni aşmış görünüyorsun.");
        else b.append("\n\nŞu an gelir-gider farkın pozitif görünüyor.");
        return b.toString();
    }
    private String finbiForecast(){
        Calendar now=Calendar.getInstance();
        int daysInMonth=now.getActualMaximum(Calendar.DAY_OF_MONTH), day=now.get(Calendar.DAY_OF_MONTH);
        double expense=finbiMonthSum(viewMonth,false), income=finbiMonthSum(viewMonth,true);
        if(!finbiMonthKey(now).equals(finbiMonthKey(viewMonth))) return "Tahmin için mevcut aya geçmen gerekiyor.";
        double projected=day>0?expense*((double)daysInMonth/day):expense;
        double projectedNet=income-projected;
        StringBuilder b=new StringBuilder(trUi("Mevcut harcama hızına göre ay sonu tahminin:\n","Your month-end estimate based on your current spending pace:\n"));
        b.append(trUi("• Tahmini gider: ","• Estimated spending: ")).append(money(projected)).append("\n");
        b.append(trUi("• Kayıtlı gelir: ","• Recorded income: ")).append(money(income)).append("\n");
        b.append(trUi("• Tahmini net: ","• Estimated net: ")).append(money(projectedNet));
        double budget=monthlyBudget();
        if(budget>0) b.append("\n• Bütçe: ").append(money(budget)).append(" — tahmini ").append(projected>budget?"aşım":"sınır içinde");
        b.append("\n\nBu yalnızca mevcut günlük harcama hızına dayalı bir tahmindir; yeni gelir veya giderler sonucu değiştirebilir.");
        return b.toString();
    }
    private String finbiDetailedSummary(){
        double income=finbiMonthSum(viewMonth,true),expense=finbiMonthSum(viewMonth,false),balance=totalBalance(),net=income-expense,cardDebt=0;
        for(CreditCard cc:creditCards) cardDebt+=Math.max(0,cc.debt);
        StringBuilder b=new StringBuilder(trUi("Finansal özetin:\n","Your financial summary:\n"));
        b.append(trUi("• Toplam bakiye: ","• Total balance: ")).append(money(balance)).append("\n");
        b.append(trUi("• Bu ay gelir: ","• Income this month: ")).append(money(income)).append(" ("+finbiMonthCount(viewMonth,true)+" işlem)\n");
        b.append(trUi("• Bu ay gider: ","• Spending this month: ")).append(money(expense)).append(" ("+finbiMonthCount(viewMonth,false)+" işlem)\n");
        b.append(trUi("• Ay neti: ","• Monthly net: ")).append(money(net)).append("\n");
        b.append(trUi("• Kart borcu: ","• Card debt: ")).append(money(cardDebt));
        String goals=finbiGoalAnalysis();
        if(!goals.startsWith("Henüz")) b.append("\n\nHedeflerin:\n").append(goals);
        String top=finbiTopCategories(viewMonth,3);
        if(!top.isEmpty()) b.append("\n\nEn yüksek harcamaların:\n").append(top);
        return b.toString();
    }
    /**
     * Expands questions written in the selected app language with canonical
     * Turkish intent tokens. Finbi's financial calculations stay unchanged;
     * this only makes the existing intent rules multilingual/offline.
     */
    private String finbiCanonicalQuery(String q){
        if(q==null) return "";
        String raw=q.toLowerCase(Locale.ROOT).trim();
        StringBuilder x=new StringBuilder(raw);
        if("en".equals(language)){
            if(finbiHas(raw,"how am i doing","how are things","how is my month","how's my month")) x.append(" bu ay durumum finansal durum");
            if(finbiHas(raw,"compared with last month","compared to last month","than last month","last month")) x.append(" geçen ay karşılaştır");
            if(finbiHas(raw,"what did i spend the most on","where did i spend","highest spending","most on")) x.append(" en çok harcama kategori");
            if(finbiHas(raw,"card debt","credit card debt","how much do i owe")) x.append(" kart borç kredi kart");
            if(finbiHas(raw,"my goals","goals doing","goal progress")) x.append(" hedeflerim hedef");
            if(finbiHas(raw,"last 3 months","last three months","three month summary")) x.append(" son 3 ay özet");
            if(finbiHas(raw,"balance","account balance","how much money")) x.append(" bakiye");
            if(finbiHas(raw,"income","salary","earnings")) x.append(" gelir kazanç maaş");
            if(finbiHas(raw,"spending","expenses","expense","spent")) x.append(" harcama gider");
            if(finbiHas(raw,"remaining","left after expenses","how much will i have left")) x.append(" kalan");
            if(finbiHas(raw,"installment","installments","payment plan")) x.append(" taksit");
            if(finbiHas(raw,"minimum payment","minimum due")) x.append(" asgari ödeme");
            if(finbiHas(raw,"budget")) x.append(" bütçe");
            if(finbiHas(raw,"savings","saved money")) x.append(" birikim");
            if(finbiHas(raw,"forecast","end of month","month end")) x.append(" tahmin ay sonu");
            if(finbiHas(raw,"dollar","usd")) x.append(" dolar usd");
            if(finbiHas(raw,"euro","eur")) x.append(" euro eur");
            if(finbiHas(raw,"gold","gram gold")) x.append(" altın gram altın");
            if(finbiHas(raw,"what can you do","what can finbi do","capabilities")) x.append(" ne yapabiliyorsun özelliklerin");
        } else if("fr".equals(language)){
            if(finbiHas(raw,"comment ça va ce mois","comment je vais ce mois","comment ça se passe ce mois")) x.append(" bu ay durumum finansal durum");
            if(finbiHas(raw,"par rapport au mois dernier","comparé au mois dernier","mois dernier")) x.append(" geçen ay karşılaştır");
            if(finbiHas(raw,"dans quoi ai-je le plus dépensé","où ai-je le plus dépensé","plus dépensé")) x.append(" en çok harcama kategori");
            if(finbiHas(raw,"dette de carte","dette carte","dois-je")) x.append(" kart borç kredi kart");
            if(finbiHas(raw,"mes objectifs","progression de mes objectifs")) x.append(" hedeflerim hedef");
            if(finbiHas(raw,"trois derniers mois","3 derniers mois")) x.append(" son 3 ay özet");
            if(finbiHas(raw,"solde","combien d'argent")) x.append(" bakiye");
            if(finbiHas(raw,"revenus","salaire")) x.append(" gelir kazanç maaş");
            if(finbiHas(raw,"dépenses","dépense","dépenser")) x.append(" harcama gider");
            if(finbiHas(raw,"reste","combien me reste")) x.append(" kalan");
            if(finbiHas(raw,"échéance","échelonnement","paiement en plusieurs fois")) x.append(" taksit");
            if(finbiHas(raw,"paiement minimum")) x.append(" asgari ödeme");
            if(finbiHas(raw,"budget")) x.append(" bütçe");
            if(finbiHas(raw,"épargne","économies")) x.append(" birikim");
            if(finbiHas(raw,"prévision","fin du mois")) x.append(" tahmin ay sonu");
            if(finbiHas(raw,"dollar","usd")) x.append(" dolar usd"); if(finbiHas(raw,"euro","eur")) x.append(" euro eur"); if(finbiHas(raw,"or","or gramme")) x.append(" altın gram altın");
            if(finbiHas(raw,"que peux-tu faire","capacités","que peut faire finbi")) x.append(" ne yapabiliyorsun özelliklerin");
        } else if("de".equals(language)){
            if(finbiHas(raw,"wie geht es mir diesen monat","wie läuft mein monat","wie sieht es diesen monat aus")) x.append(" bu ay durumum finansal durum");
            if(finbiHas(raw,"im vergleich zum letzten monat","gegenüber dem letzten monat","letzten monat")) x.append(" geçen ay karşılaştır");
            if(finbiHas(raw,"wofür habe ich am meisten ausgegeben","wo habe ich am meisten ausgegeben","meisten ausgegeben")) x.append(" en çok harcama kategori");
            if(finbiHas(raw,"kreditkartenschulden","kartenschulden","wie viel schulde ich")) x.append(" kart borç kredi kart");
            if(finbiHas(raw,"meine ziele","wie stehen meine ziele","ziel fortschritt")) x.append(" hedeflerim hedef");
            if(finbiHas(raw,"letzte 3 monate","letzten drei monate")) x.append(" son 3 ay özet");
            if(finbiHas(raw,"kontostand","saldo","wie viel geld")) x.append(" bakiye");
            if(finbiHas(raw,"einkommen","gehalt","einnahmen")) x.append(" gelir kazanç maaş");
            if(finbiHas(raw,"ausgaben","ausgabe","ausgegeben")) x.append(" harcama gider");
            if(finbiHas(raw,"übrig","wie viel bleibt")) x.append(" kalan");
            if(finbiHas(raw,"ratenzahlung","raten","teilzahlung")) x.append(" taksit");
            if(finbiHas(raw,"mindestzahlung")) x.append(" asgari ödeme");
            if(finbiHas(raw,"budget")) x.append(" bütçe");
            if(finbiHas(raw,"ersparnisse","sparen")) x.append(" birikim");
            if(finbiHas(raw,"prognose","monatsende")) x.append(" tahmin ay sonu");
            if(finbiHas(raw,"dollar","usd")) x.append(" dolar usd"); if(finbiHas(raw,"euro","eur")) x.append(" euro eur"); if(finbiHas(raw,"gold","gramm gold")) x.append(" altın gram altın");
            if(finbiHas(raw,"was kannst du","fähigkeiten","was kann finbi")) x.append(" ne yapabiliyorsun özelliklerin");
        } else if("ru".equals(language)){
            if(finbiHas(raw,"как у меня дела в этом месяце","как дела в этом месяце","как мой месяц")) x.append(" bu ay durumum finansal durum");
            if(finbiHas(raw,"по сравнению с прошлым месяцем","чем в прошлом месяце","прошлый месяц")) x.append(" geçen ay karşılaştır");
            if(finbiHas(raw,"на что я потратил больше всего","где я потратил больше всего","больше всего потратил")) x.append(" en çok harcama kategori");
            if(finbiHas(raw,"долг по карте","долг по кредитной карте","сколько я должен")) x.append(" kart borç kredi kart");
            if(finbiHas(raw,"мои цели","как мои цели","прогресс целей")) x.append(" hedeflerim hedef");
            if(finbiHas(raw,"последние 3 месяца","последние три месяца")) x.append(" son 3 ay özet");
            if(finbiHas(raw,"баланс","остаток","сколько денег")) x.append(" bakiye");
            if(finbiHas(raw,"доход","зарплата","доходы")) x.append(" gelir kazanç maaş");
            if(finbiHas(raw,"расходы","расход","потратил")) x.append(" harcama gider");
            if(finbiHas(raw,"сколько осталось","остаток после расходов")) x.append(" kalan");
            if(finbiHas(raw,"рассрочка","рассрочки","план платежей")) x.append(" taksit");
            if(finbiHas(raw,"минимальный платеж")) x.append(" asgari ödeme");
            if(finbiHas(raw,"бюджет")) x.append(" bütçe");
            if(finbiHas(raw,"сбережения","накопления")) x.append(" birikim");
            if(finbiHas(raw,"прогноз","конец месяца")) x.append(" tahmin ay sonu");
            if(finbiHas(raw,"доллар","usd")) x.append(" dolar usd"); if(finbiHas(raw,"евро","eur")) x.append(" euro eur"); if(finbiHas(raw,"золото","грамм золота")) x.append(" altın gram altın");
            if(finbiHas(raw,"что ты умеешь","возможности","что умеет finbi")) x.append(" ne yapabiliyorsun özelliklerin");
        } else if("es".equals(language)){
            if(finbiHas(raw,"cómo voy este mes","cómo me va este mes","cómo estoy este mes")) x.append(" bu ay durumum finansal durum");
            if(finbiHas(raw,"comparado con el mes pasado","respecto al mes pasado","mes pasado")) x.append(" geçen ay karşılaştır");
            if(finbiHas(raw,"en qué gasté más","dónde gasté más","gasté más")) x.append(" en çok harcama kategori");
            if(finbiHas(raw,"deuda de mi tarjeta","deuda de tarjeta","cuánto debo")) x.append(" kart borç kredi kart");
            if(finbiHas(raw,"mis objetivos","cómo van mis objetivos","progreso de objetivos")) x.append(" hedeflerim hedef");
            if(finbiHas(raw,"últimos 3 meses","últimos tres meses")) x.append(" son 3 ay özet");
            if(finbiHas(raw,"saldo","cuánto dinero")) x.append(" bakiye");
            if(finbiHas(raw,"ingresos","sueldo","salario")) x.append(" gelir kazanç maaş");
            if(finbiHas(raw,"gastos","gastado","gasto")) x.append(" harcama gider");
            if(finbiHas(raw,"cuánto me queda","restante")) x.append(" kalan");
            if(finbiHas(raw,"cuotas","pago a plazos")) x.append(" taksit");
            if(finbiHas(raw,"pago mínimo")) x.append(" asgari ödeme");
            if(finbiHas(raw,"presupuesto")) x.append(" bütçe");
            if(finbiHas(raw,"ahorros","ahorro")) x.append(" birikim");
            if(finbiHas(raw,"previsión","fin de mes")) x.append(" tahmin ay sonu");
            if(finbiHas(raw,"dólar","usd")) x.append(" dolar usd"); if(finbiHas(raw,"euro","eur")) x.append(" euro eur"); if(finbiHas(raw,"oro","oro en gramos")) x.append(" altın gram altın");
            if(finbiHas(raw,"qué puedes hacer","capacidades","qué puede hacer finbi")) x.append(" ne yapabiliyorsun özelliklerin");
        } else if("it".equals(language)){
            if(finbiHas(raw,"come sto questo mese","come va questo mese","come me la cavo questo mese")) x.append(" bu ay durumum finansal durum");
            if(finbiHas(raw,"rispetto al mese scorso","confronto con il mese scorso","mese scorso")) x.append(" geçen ay karşılaştır");
            if(finbiHas(raw,"per cosa ho speso di più","dove ho speso di più","speso di più")) x.append(" en çok harcama kategori");
            if(finbiHas(raw,"debito della carta","debito carta di credito","quanto devo")) x.append(" kart borç kredi kart");
            if(finbiHas(raw,"i miei obiettivi","come vanno i miei obiettivi","progresso obiettivi")) x.append(" hedeflerim hedef");
            if(finbiHas(raw,"ultimi 3 mesi","ultimi tre mesi")) x.append(" son 3 ay özet");
            if(finbiHas(raw,"saldo","quanti soldi")) x.append(" bakiye");
            if(finbiHas(raw,"entrate","stipendio","reddito")) x.append(" gelir kazanç maaş");
            if(finbiHas(raw,"spese","spesa","speso")) x.append(" harcama gider");
            if(finbiHas(raw,"quanto mi rimane","restante")) x.append(" kalan");
            if(finbiHas(raw,"rate","pagamento a rate")) x.append(" taksit");
            if(finbiHas(raw,"pagamento minimo")) x.append(" asgari ödeme");
            if(finbiHas(raw,"budget")) x.append(" bütçe");
            if(finbiHas(raw,"risparmi","risparmio")) x.append(" birikim");
            if(finbiHas(raw,"previsione","fine mese")) x.append(" tahmin ay sonu");
            if(finbiHas(raw,"dollaro","usd")) x.append(" dolar usd"); if(finbiHas(raw,"euro","eur")) x.append(" euro eur"); if(finbiHas(raw,"oro","oro in grammi")) x.append(" altın gram altın");
            if(finbiHas(raw,"cosa puoi fare","funzionalità","cosa sa fare finbi")) x.append(" ne yapabiliyorsun özelliklerin");
        } else if("el".equals(language)){
            if(finbiHas(raw,"πώς τα πάω αυτόν τον μήνα","πώς πάει ο μήνας","πώς είμαι αυτόν τον μήνα")) x.append(" bu ay durumum finansal durum");
            if(finbiHas(raw,"σε σύγκριση με τον προηγούμενο μήνα","σε σχέση με τον προηγούμενο μήνα","προηγούμενος μήνας")) x.append(" geçen ay karşılaştır");
            if(finbiHas(raw,"πού ξόδεψα τα περισσότερα","σε τι ξόδεψα περισσότερο")) x.append(" en çok harcama kategori");
            if(finbiHas(raw,"χρέος κάρτας","χρέος πιστωτικής κάρτας","πόσα χρωστάω")) x.append(" kart borç kredi kart");
            if(finbiHas(raw,"οι στόχοι μου","πώς πάνε οι στόχοι μου")) x.append(" hedeflerim hedef");
            if(finbiHas(raw,"τελευταίους 3 μήνες","τελευταίους τρεις μήνες")) x.append(" son 3 ay özet");
            if(finbiHas(raw,"υπόλοιπο","πόσα χρήματα")) x.append(" bakiye");
            if(finbiHas(raw,"εισόδημα","μισθός","έσοδα")) x.append(" gelir kazanç maaş");
            if(finbiHas(raw,"έξοδα","δαπάνες","ξόδεψα")) x.append(" harcama gider");
            if(finbiHas(raw,"πόσα μου μένουν","υπόλοιπο μετά τα έξοδα")) x.append(" kalan");
            if(finbiHas(raw,"δόσεις","δόση","πληρωμή σε δόσεις")) x.append(" taksit");
            if(finbiHas(raw,"ελάχιστη πληρωμή")) x.append(" asgari ödeme");
            if(finbiHas(raw,"προϋπολογισμός")) x.append(" bütçe");
            if(finbiHas(raw,"αποταμίευση","αποταμιεύσεις")) x.append(" birikim");
            if(finbiHas(raw,"πρόβλεψη","τέλος του μήνα")) x.append(" tahmin ay sonu");
            if(finbiHas(raw,"δολάριο","usd")) x.append(" dolar usd"); if(finbiHas(raw,"ευρώ","eur")) x.append(" euro eur"); if(finbiHas(raw,"χρυσός","χρυσός σε γραμμάρια")) x.append(" altın gram altın");
            if(finbiHas(raw,"τι μπορείς να κάνεις","δυνατότητες","τι μπορεί να κάνει ο finbi")) x.append(" ne yapabiliyorsun özelliklerin");
        } else if("ar".equals(language)){
            if(finbiHas(raw,"كيف حالي هذا الشهر","كيف تسير أموري هذا الشهر","وضعي هذا الشهر")) x.append(" bu ay durumum finansal durum");
            if(finbiHas(raw,"مقارنة بالشهر الماضي","مقارنة مع الشهر الماضي","الشهر الماضي")) x.append(" geçen ay karşılaştır");
            if(finbiHas(raw,"على ماذا أنفقت أكثر","أين أنفقت أكثر","أنفقت أكثر")) x.append(" en çok harcama kategori");
            if(finbiHas(raw,"دين البطاقة","دين بطاقة الائتمان","كم أدين")) x.append(" kart borç kredi kart");
            if(finbiHas(raw,"أهدافي","كيف حال أهدافي","تقدم الأهداف")) x.append(" hedeflerim hedef");
            if(finbiHas(raw,"آخر 3 أشهر","آخر ثلاثة أشهر")) x.append(" son 3 ay özet");
            if(finbiHas(raw,"الرصيد","كم من المال")) x.append(" bakiye");
            if(finbiHas(raw,"الدخل","الراتب","إيرادات")) x.append(" gelir kazanç maaş");
            if(finbiHas(raw,"المصروفات","الإنفاق","أنفقت")) x.append(" harcama gider");
            if(finbiHas(raw,"كم يتبقى","المتبقي")) x.append(" kalan");
            if(finbiHas(raw,"التقسيط","الأقساط","الدفع بالتقسيط")) x.append(" taksit");
            if(finbiHas(raw,"الحد الأدنى للدفع")) x.append(" asgari ödeme");
            if(finbiHas(raw,"الميزانية")) x.append(" bütçe");
            if(finbiHas(raw,"المدخرات","التوفير")) x.append(" birikim");
            if(finbiHas(raw,"التوقع","نهاية الشهر")) x.append(" tahmin ay sonu");
            if(finbiHas(raw,"الدولار","usd")) x.append(" dolar usd"); if(finbiHas(raw,"اليورو","eur")) x.append(" euro eur"); if(finbiHas(raw,"الذهب","ذهب بالجرام")) x.append(" altın gram altın");
            if(finbiHas(raw,"ماذا يمكنك أن تفعل","إمكاناتك","ماذا يستطيع finbi")) x.append(" ne yapabiliyorsun özelliklerin");
        } else if("ja".equals(language)){
            if(finbiHas(raw,"今月の調子","今月どう","今月の状況")) x.append(" bu ay durumum finansal durum");
            if(finbiHas(raw,"先月と比べて","先月との比較","先月")) x.append(" geçen ay karşılaştır");
            if(finbiHas(raw,"何に一番お金を使った","最も使った","一番使った")) x.append(" en çok harcama kategori");
            if(finbiHas(raw,"カードの借金","クレジットカードの借金","いくら借りている")) x.append(" kart borç kredi kart");
            if(finbiHas(raw,"目標","目標の進捗")) x.append(" hedeflerim hedef");
            if(finbiHas(raw,"過去3か月","過去3ヶ月")) x.append(" son 3 ay özet");
            if(finbiHas(raw,"残高","いくらお金")) x.append(" bakiye");
            if(finbiHas(raw,"収入","給料")) x.append(" gelir kazanç maaş");
            if(finbiHas(raw,"支出","出費","使った")) x.append(" harcama gider");
            if(finbiHas(raw,"いくら残っている","残り")) x.append(" kalan");
            if(finbiHas(raw,"分割払い","分割")) x.append(" taksit");
            if(finbiHas(raw,"最低支払額")) x.append(" asgari ödeme");
            if(finbiHas(raw,"予算")) x.append(" bütçe");
            if(finbiHas(raw,"貯蓄","貯金")) x.append(" birikim");
            if(finbiHas(raw,"予測","月末")) x.append(" tahmin ay sonu");
            if(finbiHas(raw,"ドル","usd")) x.append(" dolar usd"); if(finbiHas(raw,"ユーロ","eur")) x.append(" euro eur"); if(finbiHas(raw,"金","金価格","グラム金")) x.append(" altın gram altın");
            if(finbiHas(raw,"何ができる","機能","finbiに何ができる")) x.append(" ne yapabiliyorsun özelliklerin");
        } else if("zh".equals(language)){
            if(finbiHas(raw,"这个月我的情况怎么样","这个月过得怎么样","本月情况")) x.append(" bu ay durumum finansal durum");
            if(finbiHas(raw,"和上个月相比","与上个月相比","上个月")) x.append(" geçen ay karşılaştır");
            if(finbiHas(raw,"我花钱最多的是什么","哪里花得最多","花得最多")) x.append(" en çok harcama kategori");
            if(finbiHas(raw,"信用卡欠款","卡债","我欠多少钱")) x.append(" kart borç kredi kart");
            if(finbiHas(raw,"我的目标","目标进度")) x.append(" hedeflerim hedef");
            if(finbiHas(raw,"最近3个月","过去三个月")) x.append(" son 3 ay özet");
            if(finbiHas(raw,"余额","有多少钱")) x.append(" bakiye");
            if(finbiHas(raw,"收入","工资")) x.append(" gelir kazanç maaş");
            if(finbiHas(raw,"支出","花费","花了")) x.append(" harcama gider");
            if(finbiHas(raw,"还剩多少钱","剩余")) x.append(" kalan");
            if(finbiHas(raw,"分期","分期付款")) x.append(" taksit");
            if(finbiHas(raw,"最低还款")) x.append(" asgari ödeme");
            if(finbiHas(raw,"预算")) x.append(" bütçe");
            if(finbiHas(raw,"储蓄","存款")) x.append(" birikim");
            if(finbiHas(raw,"预测","月底")) x.append(" tahmin ay sonu");
            if(finbiHas(raw,"美元","usd")) x.append(" dolar usd"); if(finbiHas(raw,"欧元","eur")) x.append(" euro eur"); if(finbiHas(raw,"黄金","克黄金")) x.append(" altın gram altın");
            if(finbiHas(raw,"你能做什么","功能","finbi能做什么")) x.append(" ne yapabiliyorsun özelliklerin");
        }
        // Broader multilingual keyword families so natural questions do not fall into the generic reply.
        if("en".equals(language)){if(finbiHas(raw,"subscription","subscriptions","membership","streaming"))x.append(" abonelik");if(finbiHas(raw,"budget","limit","spending limit"))x.append(" bütçe");if(finbiHas(raw,"financial health","financial analysis","financial situation","overall finances"))x.append(" finansal durum");}
        if("fr".equals(language)){if(finbiHas(raw,"abonnement","abonnements","mensuel","streaming"))x.append(" abonelik");if(finbiHas(raw,"budget","limite de dépenses"))x.append(" bütçe");if(finbiHas(raw,"santé financière","analyse financière","situation financière"))x.append(" finansal durum");}
        if("de".equals(language)){if(finbiHas(raw,"abo","abonnement","abonnements","monatlich","streaming"))x.append(" abonelik");if(finbiHas(raw,"budget","ausgabenlimit"))x.append(" bütçe");if(finbiHas(raw,"finanzielle gesundheit","finanzanalyse","finanzielle situation"))x.append(" finansal durum");}
        if("ru".equals(language)){if(finbiHas(raw,"подписка","подписки","ежемесячно","стриминг"))x.append(" abonelik");if(finbiHas(raw,"бюджет","лимит расходов"))x.append(" bütçe");if(finbiHas(raw,"финансовое здоровье","финансовый анализ","финансовая ситуация"))x.append(" finansal durum");}
        if("es".equals(language)){if(finbiHas(raw,"suscripción","suscripciones","mensual","streaming"))x.append(" abonelik");if(finbiHas(raw,"presupuesto","límite de gasto"))x.append(" bütçe");if(finbiHas(raw,"salud financiera","análisis financiero","situación financiera"))x.append(" finansal durum");}
        if("it".equals(language)){if(finbiHas(raw,"abbonamento","abbonamenti","mensile","streaming"))x.append(" abonelik");if(finbiHas(raw,"budget","limite di spesa"))x.append(" bütçe");if(finbiHas(raw,"salute finanziaria","analisi finanziaria","situazione finanziaria"))x.append(" finansal durum");}
        if("el".equals(language)){if(finbiHas(raw,"συνδρομή","συνδρομές","μηνιαία","streaming"))x.append(" abonelik");if(finbiHas(raw,"προϋπολογισμός","όριο δαπανών"))x.append(" bütçe");if(finbiHas(raw,"οικονομική υγεία","οικονομική ανάλυση","οικονομική κατάσταση"))x.append(" finansal durum");}
        if("ar".equals(language)){if(finbiHas(raw,"اشتراك","الاشتراكات","شهري","بث"))x.append(" abonelik");if(finbiHas(raw,"الميزانية","حد الإنفاق"))x.append(" bütçe");if(finbiHas(raw,"الصحة المالية","التحليل المالي","الوضع المالي"))x.append(" finansal durum");}
        if("ja".equals(language)){if(finbiHas(raw,"サブスク","サブスクリプション","毎月","ストリーミング"))x.append(" abonelik");if(finbiHas(raw,"予算","支出上限"))x.append(" bütçe");if(finbiHas(raw,"財務状況","金融分析","お金の健康状態"))x.append(" finansal durum");}
        if("zh".equals(language)){if(finbiHas(raw,"订阅","订阅服务","每月","流媒体"))x.append(" abonelik");if(finbiHas(raw,"预算","消费上限"))x.append(" bütçe");if(finbiHas(raw,"财务状况","财务分析","财务健康"))x.append(" finansal durum");}
        return x.toString();
    }

    private String finbiBudgetAnalysis(){
        double budget=monthlyBudget(),expense=finbiMonthSum(viewMonth,false);StringBuilder b=new StringBuilder(trUi("Bütçe durumun:\n","Your budget status:\n"));
        if(budget<=0)b.append(trUi("Genel aylık bütçen tanımlı değil. ","Your overall monthly budget is not set. "));else b.append(trUi("Genel bütçe: ","Overall budget: ")).append(money(budget)).append(" — ").append(trUi("kullanılan ","used ")).append(finbiPercent(expense,budget)).append("\n").append(trUi("Kalan: ","Remaining: ")).append(money(Math.max(0,budget-expense)));
        JSONObject cb=categoryBudgetsJson();int shown=0;for(String cat:budgetCategories()){double lim=cb.optDouble(cat,0);if(lim<=0)continue;double spent=finbiCategoryTotal(viewMonth,cat);if(shown++<6)b.append("\n• ").append(budgetCategoryLabel(cat)).append(": ").append(money(spent)).append(" / ").append(money(lim));}
        if(shown==0)b.append("\n").append(trUi("Kategori bütçesi tanımlanmamış.","No category budgets are set."));
        return b.toString();
    }

    private String finbiAnswer(String q){
        String x=finbiCanonicalQuery(q);
        double income=finbiMonthSum(viewMonth,true),expense=finbiMonthSum(viewMonth,false),balance=totalBalance(),net=income-expense,cardDebt=0,saved=0,target=0;
        for(CreditCard cc:creditCards) cardDebt+=Math.max(0,cc.debt);
        for(Goal g:goals){saved+=Math.min(Math.max(0,g.saved),Math.max(0,g.target));target+=Math.max(0,g.target);}

        if(x.isEmpty()) return trUi("Buradayım. Bakiye, harcamalar, gelirler, kartlar, taksitler, birikimler veya hedeflerin hakkında sorabilirsin.","I'm here. You can ask about your balance, spending, income, cards, installments, savings, or goals.");
        if(isGuideQuestion(q)){ finbiLastTopic="guide"; return finbiGuideAnswer(q); }
        boolean greeting=finbiHas(x,"merhaba","selam","hello")||x.equals("hi")||x.equals("hey");
        if(greeting){finbiLastTopic="greeting";return finbiGreeting();}

        String context=finbiContextHint(x);
        if("category_followup".equals(context)){
            String r=finbiCategoryComparison(finbiLastCategory); finbiLastTopic="comparison";return r;
        }
        if("comparison_followup".equals(context)){
            finbiLastTopic="comparison";return finbiComparison();
        }

        if(finbiHas(x,"ne yapabiliyorsun","neler yapabiliyorsun","yapabileceklerin","özelliklerin","ozelliklerin","sen ne yaparsın","sen ne yaparsin","finbi ne yapıyor","finbi ne yapiyor")){finbiLastTopic="capabilities";return finbiCapabilities();}
        String navTarget=finbiNavigationTarget(x);
        if(navTarget!=null && (finbiHas(x,"aç","ac","götür","gotur","git","yönlendir","yonlendir","göster","goster","etkinleştir","etkinlestir","aktif","ayar") || "market_auto".equals(navTarget))){
            finbiLastTopic="navigation";
            return finbiNavigationAnswer(x,navTarget);
        }
        if(finbiHas(x,"dolar","usd","euro","eur","altın","altin","gram altın","gram altin")) {finbiLastTopic="market";return finbiMarketAnswer(x);}
        if(finbiHas(x,"tahmin","ay sonunda","ay sonu","gelecek günlerde","gelecek ay ne olur")){finbiLastTopic="forecast";return finbiForecast();}
        if(finbiHas(x,"son 3 ay","son üç ay","3 ayı","3 ayi","üç aylık","uc aylik")){finbiLastTopic="trend";return finbiThreeMonthTrend();}
        if(finbiHas(x,"geçen ay","gecen ay","önceki ay","onceki ay","karşılaştır","karsilastir")){finbiLastTopic="comparison";return finbiComparison();}
        if(finbiHas(x,"kaç işlem","kac islem","işlem say","islem say")){finbiLastTopic="transactions";return "Bu ay "+finbiMonthCount(viewMonth,false)+" gider ve "+finbiMonthCount(viewMonth,true)+" gelir işlemin var.";}
        if(finbiHas(x,"ortalama","günlük harcama","gunluk harcama")){Calendar now=Calendar.getInstance();int days=now.get(Calendar.DAY_OF_MONTH);if(!finbiMonthKey(now).equals(finbiMonthKey(viewMonth)))days=30;finbiLastTopic="average";return "Bu ay günlük ortalama harcaman yaklaşık "+money(expense/Math.max(1,days))+".";}

        String matchedCat=finbiFindCategoryFromQuestion(x,viewMonth);
        if(!matchedCat.isEmpty() && finbiHas(x,"harca","gider","para","ne kadar","harcama","masraf")){
            finbiLastTopic="category";finbiLastCategory=matchedCat;finbiLastMonth=(Calendar)viewMonth.clone();
            double v=finbiCategoryTotal(viewMonth,matchedCat);
            Calendar prev=finbiShiftMonth(-1);double old=finbiCategoryTotal(prev,matchedCat);
            StringBuilder b=new StringBuilder(matchedCat+" kategorisinde bu ay "+money(v)+" harcadın.");
            if(old>0) b.append(" Geçen ay ").append(money(old)).append(" harcamıştın (değişim ").append(finbiSignedChange(v,old)).append(").");
            return b.toString();
        }
        if(finbiHas(x,"kategori","harcama dağılım","harcama dagilim","nereye gidiyor","en çok","en fazla")){finbiLastTopic="category";String top=finbiTopCategories(viewMonth,5);return top.isEmpty()?trUi("Bu ay henüz gider kaydın yok.","You have no spending recorded this month yet."):trUi("Bu ay en yüksek harcama kategorilerin:\n","Your highest spending categories this month:\n")+top;}
        if(finbiHas(x,"bakiye","balance","param ne kadar","ne kadar param")){finbiLastTopic="balance";return trUi("Güncel toplam bakiyen ","Your current total balance is ")+money(balance)+". Bu ay gelirlerin "+money(income)+", giderlerin "+money(expense)+" ve net farkın "+money(net)+".";}
        if(finbiHas(x,"gelir","kazanç","kazanc","maaş","maas","income","salary")){finbiLastTopic="income";return finbiMonthLabel()+trUi(" döneminde kayıtlı gelirlerin toplamı "," recorded income for the period is ")+money(income)+". "+finbiMonthCount(viewMonth,true)+trUi(" gelir işlemi bulunuyor."," income transactions found.");}
        if(finbiHas(x,"harcama","gider","spent","expense","neye para")){finbiLastTopic="expense";return finbiMonthLabel()+trUi(" döneminde toplam harcaman "," total spending for the period is ")+money(expense)+". En yüksek kategoriler:\n"+finbiTopCategories(viewMonth,3);}
        if(finbiHas(x,"kalan","remaining","ne kadar kaldı","ne kadar kaldi")){finbiLastTopic="remaining";return trUi("Bu ay gelirlerinden giderlerini çıkardığımda ","After subtracting your spending from your income this month, you have ")+money(net)+" kalıyor.";}
        if(finbiHas(x,"kaç kart","kac kart","how many card")){finbiLastTopic="cards";return "Finway'de "+creditCards.size()+trUi(" kredi kartı kayıtlı."," registered credit cards.");}
        if(finbiHas(x,"minimum","asgari","min ödeme","min odeme")){finbiLastTopic="minimum";return creditCards.isEmpty()?trUi("Henüz kayıtlı kredi kartın görünmüyor.","No registered credit card is visible yet."):trUi("Kayıtlı kartlarının toplam asgari ödeme tutarı ","The total minimum payment for your registered cards is ")+money(finbiCardMinPayments())+".";}
        if(finbiHas(x,"taksit","installment")){finbiLastTopic="installment";return finbiInstallmentDetails();}
        if(finbiHas(x,"kart ödemesi","kart odemesi","kart borcumu öde","kart borcumu ode")){finbiLastTopic="card_payment";return "Kredi kartı ödeme ekranına yönlendirebilirim. Genel kart ödemesi yaptığında kart borcun azalır; taksit planların ise ayrı şekilde korunur. İstersen ödeme ekranını açabilirim.";}
        if(finbiHas(x,"kart","borç","borc","card","kredi kart")){finbiLastTopic="cards";return finbiCardDetails();}
        if(finbiHas(x,"bütçe","butce","budget")){finbiLastTopic="budget";return finbiBudgetAnalysis();}
        if(finbiHas(x,"abonelik","subscription","subscriptions","netflix","spotify","prime")){finbiLastTopic="subscriptions";return finbiSubscriptionAnalysis();}
        if(finbiHas(x,"birik","saving")){finbiLastTopic="savings";return finbiSavingsAnalysis();}
        if(finbiHas(x,"hedef","goal","amaç","amac")){finbiLastTopic="goal";return finbiGoalAnalysis();}
        if(finbiHas(x,"özet","ozet","summary","genel durum")){finbiLastTopic="summary";return finbiDetailedSummary();}
        if(finbiHas(x,"nasılım","nasilim","durumum","financial health","finansal durum","iyi gidiyor muyum","nasıl gidiyor","nasil gidiyor")){finbiLastTopic="health";return finbiFinancialHealth();}
        if(finbiHas(x,"öner","oner","tavsiye","advice","ne yapmalıyım","ne yapmaliyim","tasarruf","paramı nasıl yönet","parami nasil yonet")){
            finbiLastTopic="advice";
            String top=finbiTopCategories(viewMonth,1);
            if(net<0)return trUi("Bu ay giderlerin gelirlerinden ","This month your spending is ")+money(Math.abs(net))+trUi(" daha yüksek. Öncelikle "," higher than your income. First, it may help to review ")+(top.length()>0?top.split(" — ")[0]+" kategorisini":"en yüksek harcama kategorini")+" incelemek mantıklı olabilir.";
            if(target>saved&&target>0)return "Hedeflerinde toplam "+money(target-saved)+" açık var. Düzenli birikimle ilerlemek için aylık sabit bir tutar belirleyebilirsin.";
            return "Bu ay gelir-gider farkın "+money(net)+". İstersen önce en yüksek harcama kategorini, sonra kart ve hedeflerini birlikte inceleyebiliriz.";
        }
        finbiLastTopic="unknown";
        return "Bunu Finway verilerinden yorumlayabilmem için biraz daha açık sorabilirsin. Örneğin “Bu ay durumum nasıl?”, “Geçen aya göre market harcamam nasıl değişti?”, “Ay sonunda ne kadar param kalabilir?”, “Kart taksitlerim ne durumda?” veya “Hedeflerim ne durumda?” diyebilirsin.";
    }

    private TextView addFinbiTyping(LinearLayout list){
        TextView bubble=text("•••",15,C().muted);
        bubble.setGravity(Gravity.CENTER);
        bubble.setPadding(dp(16),dp(7),dp(16),dp(7));
        bubble.setBackground(bg(darkMode?Color.rgb(25,48,68):Color.WHITE,18));
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.LEFT); row.addView(bubble,new LinearLayout.LayoutParams(dp(58),dp(38)));
        row.setPadding(0,dp(4),0,dp(4)); list.addView(row);
        bubble.animate().alpha(.35f).setDuration(450).withEndAction(()->bubble.animate().alpha(1f).setDuration(450).start()).start();
        return bubble;
    }

    private String finbiNavigationIntro(String target){
        if("market_auto".equals(target)) return trUi("Piyasa verilerinin otomatik güncelleme ayarını açmak istiyorsun. Seni Piyasa Güncellemeleri bölümüne götürüyorum; oradan otomatik güncellemeyi tek dokunuşla açabilirsin.","You want to open automatic market update settings. I’m taking you to Market Updates, where you can enable automatic updates with one tap.");
        if("markets".equals(target)) return trUi("Piyasa ekranını açıyorum. Burada dolar, euro ve gram altın değerlerini ve güncel değişimleri görebilirsin.","I’m opening the Markets screen. You can see dollar, euro, and gram gold values and current changes here.");
        if("accounts".equals(target)) return trUi("Hesaplarını açıyorum. Bakiyelerini, hesaplarını düzenleme seçeneklerini ve yeni hesap ekleme alanını buradan yönetebilirsin.","I’m opening your accounts. You can manage balances, edit accounts, and add new accounts here.");
        if("credit".equals(target)) return trUi("Kredi kartları bölümünü açıyorum. Kart borçlarını, limitlerini ve taksit planlarını buradan takip edebilirsin.","I’m opening the credit cards section. You can track card debt, limits, and installment plans here.");
        if("savings".equals(target)) return trUi("Birikim ve hedefler bölümünü açıyorum. Hedeflerini, birikmiş tutarlarını ve ilerlemeni buradan görebilirsin.","I’m opening Savings & Goals. You can see your goals, saved amounts, and progress here.");
        if("transactions".equals(target)) return trUi("İşlemler ekranını açıyorum. Gelir ve harcamalarını burada arayabilir, filtreleyebilir ve ayrıntılarını inceleyebilirsin.","I’m opening Transactions. You can search, filter, and review your income and spending here.");
        if("security".equals(target)) return trUi("Güvenlik ayarlarını açıyorum. PIN, uygulama kilidi ve biyometrik giriş seçeneklerini buradan yönetebilirsin.","I’m opening Security settings. You can manage PIN, app lock, and biometric login here.");
        if("settings".equals(target)) return trUi("Ayarlar ekranını açıyorum. Uygulamanın genel tercihlerini buradan yönetebilirsin.","I’m opening Settings. You can manage the app’s general preferences here.");
        return trUi("Seni ilgili bölüme yönlendiriyorum.","I’m taking you to the relevant section.");
    }

    private String finbiCapabilities(){
        return "Ben Finbi. Finansal durumunu birlikte takip edebiliriz.\n\n"+
                "• Bakiye, gelir ve harcamalarını analiz edebilirim.\n"+
                "• Kategorilerini ve aylık değişimleri karşılaştırabilirim.\n"+
                "• Kredi kartı borcu, asgari ödeme ve taksitlerini özetleyebilirim.\n"+
                "• Birikim ve hedeflerini takip edebilirim.\n"+
                "• Dolar, euro ve gram altın gibi piyasa verilerini gösterebilirim.\n"+
                "• İstediğin Finway ekranına seni yönlendirebilirim.\n\n"+
                "Örneğin “Piyasa otomatik güncellemeyi aç”, “Bu ay en çok nereye harcadım?” veya “Kaç taksidim kaldı?” diyebilirsin.";
    }

    private String finbiNavigationAnswer(String x,String target){
        if(target==null) return null;
        return finbiNavigationIntro(target);
    }

    private String finbiNavigationTarget(String q){
        String x=q.toLowerCase(Locale.ROOT);
        if(finbiHas(x,"otomatik güncelle","otomatik guncelle","otomatik yenile","otomatik yenileme") && finbiHas(x,"piyasa","piyasalar","döviz","doviz","kur","altın","altin")) return "market_auto";
        if(finbiHas(x,"piyasa ayar","piyasa ekran","piyasalar","döviz ekran","doviz ekran","kur ekran","altın fiyat")) return "markets";
        if(finbiHas(x,"hesaplar","hesabım","hesabim","banka hesab","cüzdan","cuzdan","bakiye ekran")) return "accounts";
        if(finbiHas(x,"kredi kartlarım","kredi kartlarim","kartlarım","kartlarim","kart ekran","kartlar")) return "credit";
        if(finbiHas(x,"taksitlerim","taksit planı","taksit plani")) return "credit";
        if(finbiHas(x,"birikimlerim","birikim ekran","hedeflerim","hedef ekran")) return "savings";
        if(finbiHas(x,"işlemler","islemler","işlem ekran","islem ekran")) return "transactions";
        if(finbiHas(x,"ayarlar","ayar ekranı","ayar ekrani","uygulama ayar")) return "settings";
        if(finbiHas(x,"güvenlik","guvenlik","biyometrik","uygulama kilidi","pin ayar")) return "security";
        return null;
    }

    private void finbiNavigateTo(String target){
        closeFinbiChat();
        switch(target){
            case "market_auto":
                showSettings();
                if(activeScrollView!=null){
                    activeScrollView.postDelayed(()->{
                        View v=activeScrollView.findViewWithTag("finbi_market_auto");
                        if(v!=null) v.getParent().requestChildFocus(v,v);
                        if(v!=null) activeScrollView.smoothScrollTo(0,Math.max(0,v.getTop()-dp(24)));
                    },120L);
                }
                break;
            case "markets": showMarkets(); break;
            case "accounts": showAccounts(); break;
            case "credit": showCreditCards(); break;
            case "savings": showGoals(); break;
            case "transactions": showTransactions(); break;
            case "security":
            case "settings": showSettings(); break;
            default: showMenu(); break;
        }
    }

    private void addFinbiNavigationAction(final LinearLayout messages, final ScrollView sv, final String target){
        if(target==null) return;
        Colors c=C();
        String label="market_auto".equals(target)?"Piyasa ayarlarını aç  ›":
                "markets".equals(target)?"Piyasaları aç  ›":
                "accounts".equals(target)?"Hesapları aç  ›":
                "credit".equals(target)?"Kredi kartlarını aç  ›":
                "savings".equals(target)?"Birikimleri aç  ›":
                "transactions".equals(target)?"İşlemleri aç  ›":
                "security".equals(target)?"Güvenlik ayarlarını aç  ›":"Ayarları aç  ›";
        Button action=dialogButton(label,Color.WHITE,c.blue);
        action.setAllCaps(false);
        action.setTextSize(13);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(48));
        lp.setMargins(dp(4),dp(6),dp(4),dp(4));
        messages.addView(action,lp);
        action.setOnClickListener(v->{
            String progress="market_auto".equals(target)?"Tamam. Piyasa Güncellemeleri bölümüne geçiyorum; otomatik güncelleme seçeneğini görünür hale getireceğim.":
                    "markets".equals(target)?"Tamam. Piyasalar ekranını açıyorum.":
                    "accounts".equals(target)?"Tamam. Hesaplarını yönetebileceğin bölümü açıyorum.":
                    "credit".equals(target)?"Tamam. Kredi kartları ve taksitler bölümünü açıyorum.":
                    "savings".equals(target)?"Tamam. Birikim ve hedefler bölümünü açıyorum.":
                    "transactions".equals(target)?"Tamam. İşlemler ekranını açıyorum.":
                    "security".equals(target)?"Tamam. Güvenlik ayarlarını açıyorum.":"Tamam. Ayarlar ekranını açıyorum.";
            addFinbiMessage(messages,progress,false);
            sv.post(()->sv.fullScroll(View.FOCUS_DOWN));
            v.setEnabled(false);
            v.setAlpha(.65f);
            new Handler(Looper.getMainLooper()).postDelayed(()->finbiNavigateTo(target),520L);
        });
    }

    private void finbiAskWithTyping(final String q, final LinearLayout messages, final ScrollView sv){
        addFinbiMessage(messages,q,true);
        final TextView typing=addFinbiTyping(messages);
        sv.post(()->sv.fullScroll(View.FOCUS_DOWN));
        new Handler(Looper.getMainLooper()).postDelayed(()->{
            if(typing.getParent() instanceof ViewGroup) ((ViewGroup)typing.getParent()).removeView(typing);
            addFinbiMessage(messages,finbiAnswer(q),false);
            addFinbiNavigationAction(messages,sv,finbiNavigationTarget(q));
            sv.post(()->sv.fullScroll(View.FOCUS_DOWN));
        },2000L);
    }


    /**
     * Keeps dialog content clear of the on-screen keyboard on modern Android.
     * The window may be resized or the IME may be overlaid depending on the
     * device/target SDK, so we explicitly consume the IME inset as bottom space.
     */
    private void installImeAwareDialog(final Dialog dlg, final View root, final int baseBottomPadding, final int maxHeightDp, final Runnable revealFocused) {
        final Window window = dlg.getWindow();
        View decor = window == null ? root : window.getDecorView();
        ViewCompat.setOnApplyWindowInsetsListener(decor, (v, insets) -> {
            int imeBottom = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom;
            int barsBottom = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom;
            int bottomInset = Math.max(imeBottom, barsBottom);
            int screenH = getResources().getDisplayMetrics().heightPixels;
            int normalHeight = Math.min(dp(maxHeightDp), (int)(screenH * 0.88f));
            int availableHeight = Math.max(dp(280), screenH - bottomInset - dp(24));
            int targetHeight = Math.min(normalHeight, availableHeight);
            if (window != null) {
                WindowManager.LayoutParams lp = window.getAttributes();
                if (lp.height != targetHeight) { lp.height = targetHeight; window.setAttributes(lp); }
            }
            root.setPadding(root.getPaddingLeft(), root.getPaddingTop(), root.getPaddingRight(), baseBottomPadding);
            if (imeBottom > 0 && revealFocused != null) root.postDelayed(revealFocused, 120L);
            return insets;
        });
        ViewCompat.requestApplyInsets(decor);
    }

    private void installExpenseKeyboardHandling(final Dialog dlg, final View root, final ScrollView scroll, final EditText desc, final int maxSheetH) {
        final Window window = dlg.getWindow();
        if (window == null) return;

        // Do not rely on a fixed dialog height alone. Some Android 15/16 devices
        // keep the dialog window at its explicit height while the IME is visible.
        // We therefore observe both WindowInsets and the real visible display frame.
        final Runnable[] sync = new Runnable[]{() -> {
            Rect visible = new Rect();
            window.getDecorView().getWindowVisibleDisplayFrame(visible);
            int screenH = getResources().getDisplayMetrics().heightPixels;
            int keyboardH = Math.max(0, screenH - visible.bottom);
            int normalH = Math.min(maxSheetH, (int)(screenH * 0.86f));
            int targetH = keyboardH > dp(120)
                    ? Math.max(dp(300), Math.min(normalH, screenH - keyboardH - dp(8)))
                    : normalH;
            WindowManager.LayoutParams lp = window.getAttributes();
            if (lp.height != targetH) {
                lp.height = targetH;
                window.setAttributes(lp);
            }
            if (keyboardH > dp(120) && desc.hasFocus()) {
                scroll.postDelayed(() -> {
                    desc.requestRectangleOnScreen(new Rect(0, 0, desc.getWidth(), desc.getHeight()), true);
                    revealViewInScroll(scroll, desc);
                }, 60L);
            }
        }};

        View decor = window.getDecorView();
        ViewCompat.setOnApplyWindowInsetsListener(decor, (v, insets) -> {
            int ime = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom;
            int bars = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom;
            if (ime > dp(120) || bars > 0) sync[0].run();
            return insets;
        });

        ViewTreeObserver.OnGlobalLayoutListener global = () -> {
            if (decor.getWindowToken() != null) sync[0].run();
        };
        decor.getViewTreeObserver().addOnGlobalLayoutListener(global);

        desc.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                decor.postDelayed(() -> {
                    sync[0].run();
                    desc.requestRectangleOnScreen(new Rect(0, 0, desc.getWidth(), desc.getHeight()), true);
                    revealViewInScroll(scroll, desc);
                }, 120L);
            }
        });

        ViewCompat.requestApplyInsets(decor);
        decor.postDelayed(sync[0], 100L);
    }

    private void revealViewInScroll(ScrollView scroll, View target) {
        if (scroll == null || target == null) return;
        target.post(() -> {
            int[] loc = new int[2];
            target.getLocationOnScreen(loc);
            int[] scrollLoc = new int[2];
            scroll.getLocationOnScreen(scrollLoc);
            int top = loc[1] - scrollLoc[1] + scroll.getScrollY();
            int bottom = top + target.getHeight();
            int visibleBottom = scroll.getHeight() - dp(16);
            if (bottom > scroll.getScrollY() + visibleBottom) {
                scroll.smoothScrollTo(0, Math.max(0, bottom - visibleBottom));
            } else if (top < scroll.getScrollY() + dp(8)) {
                scroll.smoothScrollTo(0, Math.max(0, top - dp(8)));
            }
        });
    }

    private void showFinbiChat(){
        Colors c=C();
        final ViewGroup host=finbiOverlay;
        if(host==null) return;

        // Finbi chat is a true Activity-level overlay rather than a Dialog.
        // This avoids dialog/window IME conflicts and lets us position the chat
        // panel directly above the on-screen keyboard.
        if(finbiChatPanel!=null && finbiChatPanel.getParent()==host) host.removeView(finbiChatPanel);

        final FrameLayout panel=new FrameLayout(this);
        panel.setClipChildren(false);
        panel.setClipToPadding(false);
        panel.setElevation(dp(18));
        panel.setBackground(bg(c.surface,26));
        finbiChatPanel=panel;

        LinearLayout outer=new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dp(14),dp(12),dp(14),dp(10));
        outer.setBackground(bg(c.surface,26));
        panel.addView(outer,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout head=row();
        ImageView mini=new ImageView(this);
        mini.setImageResource(R.drawable.finbi_avatar);
        mini.setScaleType(ImageView.ScaleType.CENTER_CROP);
        mini.setBackground(bg(darkMode?Color.rgb(17,48,74):Color.rgb(232,247,255),27));
        mini.setPadding(dp(2),dp(2),dp(2),dp(2));
        head.addView(mini,new LinearLayout.LayoutParams(dp(54),dp(54)));

        LinearLayout titles=new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(10),0,dp(4),0);
        TextView name=text("Finbi",20,c.text); name.setTypeface(null,Typeface.BOLD); titles.addView(name);
        TextView slogan=text(finbiSlogan(),11,c.muted); titles.addView(slogan);
        head.addView(titles,new LinearLayout.LayoutParams(0,-2,1));

        TextView close=text("×",28,c.muted);
        close.setGravity(Gravity.CENTER);
        close.setBackground(bg(darkMode?Color.rgb(24,48,69):Color.rgb(242,247,251),18));
        head.addView(close,new LinearLayout.LayoutParams(dp(44),dp(44)));
        outer.addView(head);

        ScrollView sv=new ScrollView(this);
        sv.setFillViewport(true);
        sv.setClipToPadding(false);
        LinearLayout messages=new LinearLayout(this);
        messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(dp(4),dp(10),dp(4),dp(8));
        sv.addView(messages,new ScrollView.LayoutParams(-1,-2));
        outer.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        addFinbiMessage(messages,finbiGreeting(),false);

        LinearLayout bottomPanel=new LinearLayout(this);
        bottomPanel.setOrientation(LinearLayout.VERTICAL);
        bottomPanel.setPadding(0,dp(4),0,0);

        LinearLayout inputRow=row();
        EditText input=modernEdit(trUi("Finbi'ye bir şey sor...","Ask Finbi something..."),c);
        input.setSingleLine(true);
        input.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEND);
        input.setPrivateImeOptions("finway_finbi");
        inputRow.addView(input,new LinearLayout.LayoutParams(0,dp(52),1));
        Button send=dialogButton("➤",Color.WHITE,c.blue);
        send.setTextSize(18);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(54),dp(52));
        sp.setMargins(dp(8),0,0,0);
        inputRow.addView(send,sp);
        bottomPanel.addView(inputRow);

        HorizontalScrollView quickScroll=new HorizontalScrollView(this);
        quickScroll.setHorizontalScrollBarEnabled(false);
        quickScroll.setClipToPadding(false);
        LinearLayout quick=row();
        quick.setPadding(dp(1),dp(8),dp(1),dp(3));
        String[] qs={trUi("Bu ay durumum nasıl?","How am I doing this month?"),trUi("Geçen aya göre nasılım?","How am I doing compared with last month?"),trUi("En çok neye harcadım?","What did I spend the most on?"),trUi("Kart borcum ne kadar?","How much is my card debt?"),trUi("Hedeflerim ne durumda?","How are my goals doing?"),trUi("Son 3 ayımı özetle?","Summarize my last 3 months?")};
        for(String q:qs){
            TextView chip=text(q,11,c.blue);
            chip.setGravity(Gravity.CENTER);
            chip.setSingleLine(true);
            chip.setPadding(dp(12),dp(7),dp(12),dp(7));
            chip.setBackground(strokeBg(darkMode?Color.rgb(19,48,73):Color.rgb(237,247,255),c.border,18));
            LinearLayout.LayoutParams qp=new LinearLayout.LayoutParams(-2,dp(38));
            qp.setMargins(dp(3),0,dp(5),0);
            quick.addView(chip,qp);
            chip.setOnClickListener(v->finbiAskWithTyping(q,messages,sv));
        }
        quickScroll.addView(quick,new HorizontalScrollView.LayoutParams(-2,dp(46)));
        bottomPanel.addView(quickScroll);

        TextView dashboard=text(trUi("Finans merkezini aç  ›","Open financial center  ›"),12,c.blue);
        dashboard.setGravity(Gravity.CENTER);
        dashboard.setPadding(0,dp(4),0,dp(2));
        bottomPanel.addView(dashboard,new LinearLayout.LayoutParams(-1,dp(30)));
        outer.addView(bottomPanel,new LinearLayout.LayoutParams(-1,-2));

        close.setOnClickListener(v->closeFinbiChat());
        dashboard.setOnClickListener(v->{closeFinbiChat();showDigitalFinanceAssistant();});
        send.setOnClickListener(v->{
            String q=input.getText().toString().trim();
            if(q.length()==0)return;
            finbiAskWithTyping(q,messages,sv);
            input.setText("");
        });
        input.setOnEditorActionListener((v,a,e)->{ if(a==android.view.inputmethod.EditorInfo.IME_ACTION_SEND){send.performClick();return true;} return false; });

        final int maxHeight=Math.min(dp(700),(int)(getResources().getDisplayMetrics().heightPixels*.78f));
        final int panelWidth=Math.min(getResources().getDisplayMetrics().widthPixels-dp(20),dp(460));
        FrameLayout.LayoutParams plp=new FrameLayout.LayoutParams(panelWidth,maxHeight,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
        plp.setMargins(dp(10),dp(18),dp(10),dp(14));
        host.addView(panel,plp);

        final OnApplyWindowInsetsListener[] listenerRef=new OnApplyWindowInsetsListener[1];
        listenerRef[0]=(v,insets)->{
            int imeBottom=insets.getInsets(WindowInsetsCompat.Type.ime()).bottom;
            int barsBottom=insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom;
            int bottom=Math.max(imeBottom,barsBottom);
            FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)panel.getLayoutParams();
            int screenH=getResources().getDisplayMetrics().heightPixels;
            int available=Math.max(dp(320),screenH-bottom-dp(18));
            int targetH=Math.min(maxHeight,available);
            lp.height=targetH;
            lp.bottomMargin=bottom+dp(10);
            panel.setLayoutParams(lp);
            if(imeBottom>0){
                input.postDelayed(()->{
                    sv.post(()->sv.fullScroll(View.FOCUS_DOWN));
                    input.requestFocus();
                },80L);
            }
            return insets;
        };
        ViewCompat.setOnApplyWindowInsetsListener(host,listenerRef[0]);
        ViewCompat.requestApplyInsets(host);

        input.setOnFocusChangeListener((v,hasFocus)->{
            if(hasFocus) {
                input.postDelayed(()->{
                    ViewCompat.requestApplyInsets(host);
                    sv.post(()->sv.fullScroll(View.FOCUS_DOWN));
                },90L);
            }
        });
    }

    private void closeFinbiChat(){
        if(finbiChatPanel!=null){
            EditText focused=null;
            if(finbiChatPanel instanceof ViewGroup){
                ArrayDeque<View> q=new ArrayDeque<>(); q.add(finbiChatPanel);
                while(!q.isEmpty()){
                    View v=q.removeFirst();
                    if(v instanceof EditText && v.hasFocus()){ focused=(EditText)v; break; }
                    if(v instanceof ViewGroup){ for(int i=0;i<((ViewGroup)v).getChildCount();i++) q.add(((ViewGroup)v).getChildAt(i)); }
                }
            }
            if(focused!=null) ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(focused.getWindowToken(),0);
            ViewParent p=finbiChatPanel.getParent(); if(p instanceof ViewGroup)((ViewGroup)p).removeView(finbiChatPanel);
            finbiChatPanel=null;
        }
        if(finbiOverlay!=null) ViewCompat.setOnApplyWindowInsetsListener(finbiOverlay,null);
    }

    private class FinbiMascotView extends View{
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        FinbiMascotView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas canvas){
            super.onDraw(canvas);
            float w=getWidth(),h=getHeight();
            p.setShadowLayer(dp(4),0,dp(2),0x35000000);
            p.setColor(darkMode?Color.rgb(17,48,74):Color.rgb(232,247,255));
            canvas.drawCircle(w/2f,h/2f,w*.46f,p);
            p.clearShadowLayer();
            // Friendly Finbi-inspired bionic bird face: bright eyes, beak and blue feather crest.
            p.setColor(Color.rgb(20,75,120));
            Path wing=new Path();
            wing.moveTo(w*.17f,h*.45f); wing.cubicTo(w*.02f,h*.26f,w*.12f,h*.08f,w*.30f,h*.27f);
            wing.lineTo(w*.27f,h*.55f); wing.close(); canvas.drawPath(wing,p);
            p.setColor(Color.rgb(0,191,255));
            Path crest=new Path();
            crest.moveTo(w*.35f,h*.23f); crest.cubicTo(w*.42f,h*.02f,w*.63f,h*.08f,w*.68f,h*.24f);
            crest.cubicTo(w*.55f,h*.19f,w*.45f,h*.22f,w*.35f,h*.23f); crest.close(); canvas.drawPath(crest,p);
            p.setColor(Color.WHITE); canvas.drawCircle(w*.50f,h*.49f,w*.31f,p);
            p.setColor(Color.rgb(15,38,58)); canvas.drawOval(w*.36f,h*.37f,w*.48f,h*.51f,p); canvas.drawOval(w*.52f,h*.37f,w*.64f,h*.51f,p);
            p.setColor(Color.rgb(0,213,255)); canvas.drawCircle(w*.43f,h*.43f,w*.035f,p); canvas.drawCircle(w*.57f,h*.43f,w*.035f,p);
            p.setColor(Color.rgb(30,100,175));
            Path beak=new Path(); beak.moveTo(w*.50f,h*.49f); beak.lineTo(w*.63f,h*.54f); beak.lineTo(w*.50f,h*.59f); beak.close(); canvas.drawPath(beak,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(Color.rgb(0,150,225)); Path smile=new Path(); smile.moveTo(w*.43f,h*.62f); smile.quadTo(w*.50f,h*.69f,w*.57f,h*.62f); canvas.drawPath(smile,p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(20,100,190)); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(w*.16f); p.setTextAlign(Paint.Align.CENTER); canvas.drawText("F",w*.50f,h*.86f,p);
        }
    }

    private String guideText(String key){
        if("en".equals(language)){
            if("guide_title".equals(key)) return "User Guide";
            if("guide_intro".equals(key)) return "A quick guide to using Finway.";
            if("accounts".equals(key)) return "Accounts|Add your bank, cash and other accounts from My Accounts. Enter the current balance and keep it updated when money moves.";
            if("transactions".equals(key)) return "Transactions|Use Transactions to record income and spending. Select the amount, date, category and account so Finway can analyze your activity.";
            if("budget".equals(key)) return "Budget|Open Budgets from the menu, enter your monthly limit and optionally set category limits. Finway can alert you as you approach the limit.";
            if("cards".equals(key)) return "Credit Cards|Add your card with its limit, statement day and due day. You can then track debt, installments and payments.";
            if("subscriptions".equals(key)) return "Subscriptions|Add recurring services with their amount and payment day so you can see recurring costs in one place.";
            if("finbi".equals(key)) return "Finbi|Open Finbi from the menu or the floating assistant. Ask about your balance, spending, budget, cards, goals or how to use Finway.";
            if("analysis".equals(key)) return "Analysis|Finway uses the transactions you record to show spending categories, trends, budget usage and financial summaries.";
            if("security".equals(key)) return "Security & Backup|Use Settings for PIN/app lock, biometric access, language and appearance. Use Data Transfer for backup and restore.";
            if("on_welcome".equals(key)) return "Welcome to Finway|Let's take a short tour so you know where everything is.";
            if("on_home".equals(key)) return "Home|Your balance, income, spending, budget and market information are summarized here.";
            if("on_accounts".equals(key)) return "Accounts & Transactions|Keep your accounts and income/expense records up to date. Accurate records make Finway's analysis more useful.";
            if("on_budget".equals(key)) return "Budget & Cards|Set a monthly budget and track your credit cards, limits, payments and installments.";
            if("on_finbi".equals(key)) return "Finbi & Guide|Finbi can answer questions about your finances and explain how to use Finway. The User Guide is always available from the menu.";
            if("on_done".equals(key)) return "You're ready|Start by adding an account and your first transaction. You can replay this tour from the User Guide.";
            if("next".equals(key)) return "Next";
            if("skip".equals(key)) return "Skip";
            if("start".equals(key)) return "Get Started";
            if("replay".equals(key)) return "Replay introduction";
        }
        if("fr".equals(language)){
            if("guide_title".equals(key)) return "Guide d’utilisation"; if("guide_intro".equals(key)) return "Un guide rapide pour utiliser Finway.";
            if("accounts".equals(key)) return "Comptes|Ajoutez vos comptes bancaires, espèces et autres comptes dans Mes comptes. Saisissez le solde actuel et mettez-le à jour lorsque l’argent bouge.";
            if("transactions".equals(key)) return "Transactions|Enregistrez vos revenus et dépenses dans Transactions. Indiquez le montant, la date, la catégorie et le compte pour améliorer l’analyse.";
            if("budget".equals(key)) return "Budget|Ouvrez Budgets dans le menu, indiquez votre limite mensuelle et, si besoin, des limites par catégorie. Finway peut vous avertir à l’approche de la limite.";
            if("cards".equals(key)) return "Cartes bancaires|Ajoutez votre carte avec sa limite, son jour de relevé et sa date d’échéance. Suivez ensuite dettes, paiements et échéances.";
            if("subscriptions".equals(key)) return "Abonnements|Ajoutez les services récurrents avec leur montant et leur jour de paiement pour suivre les coûts réguliers.";
            if("finbi".equals(key)) return "Finbi|Ouvrez Finbi depuis le menu ou l’assistant flottant. Demandez votre solde, vos dépenses, votre budget, vos cartes, vos objectifs ou comment utiliser Finway.";
            if("analysis".equals(key)) return "Analyse|Finway utilise vos transactions pour afficher les catégories de dépenses, tendances, utilisation du budget et résumés financiers.";
            if("security".equals(key)) return "Sécurité et sauvegarde|Les réglages permettent le PIN, le verrouillage, la biométrie, la langue et l’apparence. Utilisez Transfert de données pour la sauvegarde et la restauration.";
            if("on_welcome".equals(key)) return "Bienvenue dans Finway|Faisons une courte visite pour découvrir où se trouvent les fonctions.";
            if("on_home".equals(key)) return "Accueil|Votre solde, vos revenus, vos dépenses, votre budget et les marchés sont résumés ici.";
            if("on_accounts".equals(key)) return "Comptes et transactions|Gardez vos comptes et vos revenus/dépenses à jour. Des données précises améliorent l’analyse.";
            if("on_budget".equals(key)) return "Budget et cartes|Définissez un budget mensuel et suivez vos cartes, limites, paiements et échéances.";
            if("on_finbi".equals(key)) return "Finbi et guide|Finbi répond à vos questions financières et explique comment utiliser Finway. Le guide reste accessible depuis le menu.";
            if("on_done".equals(key)) return "Vous êtes prêt|Commencez par ajouter un compte et votre première transaction. Vous pourrez revoir cette visite depuis le guide.";
            if("next".equals(key)) return "Suivant"; if("skip".equals(key)) return "Passer"; if("start".equals(key)) return "Commencer"; if("replay".equals(key)) return "Rejouer l’introduction";
        }
        if("de".equals(language)){
            if("guide_title".equals(key)) return "Benutzerhandbuch"; if("guide_intro".equals(key)) return "Eine kurze Anleitung für Finway.";
            if("accounts".equals(key)) return "Konten|Füge Bank-, Bargeld- und andere Konten unter Meine Konten hinzu. Trage den aktuellen Saldo ein und aktualisiere ihn bei Bewegungen.";
            if("transactions".equals(key)) return "Transaktionen|Erfasse Einnahmen und Ausgaben. Betrag, Datum, Kategorie und Konto helfen Finway bei der Analyse.";
            if("budget".equals(key)) return "Budget|Öffne Budgets im Menü, lege dein Monatslimit und optional Kategorienlimits fest. Finway kann dich vor dem Limit warnen.";
            if("cards".equals(key)) return "Kreditkarten|Füge deine Karte mit Limit, Abrechnungstag und Fälligkeit hinzu. Verfolge danach Schulden, Raten und Zahlungen.";
            if("subscriptions".equals(key)) return "Abonnements|Füge wiederkehrende Dienste mit Betrag und Zahlungstag hinzu, um laufende Kosten zu verfolgen.";
            if("finbi".equals(key)) return "Finbi|Öffne Finbi über das Menü oder den schwebenden Assistenten. Frage nach Kontostand, Ausgaben, Budget, Karten, Zielen oder der Nutzung von Finway.";
            if("analysis".equals(key)) return "Analyse|Finway nutzt deine Transaktionen für Ausgabenkategorien, Trends, Budgetnutzung und Finanzübersichten.";
            if("security".equals(key)) return "Sicherheit und Backup|In den Einstellungen findest du PIN, App-Sperre, Biometrie, Sprache und Darstellung. Für Backup und Wiederherstellung nutze Datenübertragung.";
            if("on_welcome".equals(key)) return "Willkommen bei Finway|Machen wir einen kurzen Rundgang durch die wichtigsten Bereiche.";
            if("on_home".equals(key)) return "Startseite|Hier siehst du eine Zusammenfassung von Saldo, Einnahmen, Ausgaben, Budget und Marktdaten.";
            if("on_accounts".equals(key)) return "Konten und Transaktionen|Halte Konten sowie Einnahmen und Ausgaben aktuell. Genaue Daten verbessern die Analyse.";
            if("on_budget".equals(key)) return "Budget und Karten|Lege ein Monatsbudget fest und verfolge Karten, Limits, Zahlungen und Raten.";
            if("on_finbi".equals(key)) return "Finbi und Handbuch|Finbi beantwortet Finanzfragen und erklärt die Nutzung von Finway. Das Handbuch bleibt im Menü verfügbar.";
            if("on_done".equals(key)) return "Du bist bereit|Füge zuerst ein Konto und deine erste Transaktion hinzu. Die Einführung kannst du im Handbuch erneut starten.";
            if("next".equals(key)) return "Weiter"; if("skip".equals(key)) return "Überspringen"; if("start".equals(key)) return "Loslegen"; if("replay".equals(key)) return "Einführung wiederholen";
        }
        if("ru".equals(language)){
            if("guide_title".equals(key)) return "Руководство"; if("guide_intro".equals(key)) return "Краткое руководство по Finway.";
            if("accounts".equals(key)) return "Счета|Добавьте банковские, наличные и другие счета в Мои счета. Укажите текущий баланс и обновляйте его при движении денег.";
            if("transactions".equals(key)) return "Операции|Записывайте доходы и расходы. Сумма, дата, категория и счёт помогают Finway анализировать данные.";
            if("budget".equals(key)) return "Бюджет|Откройте Бюджеты в меню, задайте месячный лимит и при необходимости лимиты категорий. Finway может предупреждать о приближении к лимиту.";
            if("cards".equals(key)) return "Кредитные карты|Добавьте карту с лимитом, датой выписки и сроком платежа. Отслеживайте долг, рассрочки и платежи.";
            if("subscriptions".equals(key)) return "Подписки|Добавьте регулярные сервисы с суммой и днём оплаты, чтобы видеть постоянные расходы.";
            if("finbi".equals(key)) return "Finbi|Откройте Finbi из меню или плавающего помощника. Спрашивайте о балансе, расходах, бюджете, картах, целях и использовании Finway.";
            if("analysis".equals(key)) return "Анализ|Finway использует ваши операции для категорий расходов, тенденций, бюджета и финансовых сводок.";
            if("security".equals(key)) return "Безопасность и резервная копия|В настройках доступны PIN, блокировка, биометрия, язык и оформление. Для резервной копии используйте передачу данных.";
            if("on_welcome".equals(key)) return "Добро пожаловать в Finway|Давайте быстро познакомимся с основными разделами.";
            if("on_home".equals(key)) return "Главная|Здесь собраны баланс, доходы, расходы, бюджет и рыночная информация.";
            if("on_accounts".equals(key)) return "Счета и операции|Поддерживайте счета и записи доходов/расходов актуальными. Точные данные улучшают анализ.";
            if("on_budget".equals(key)) return "Бюджет и карты|Задайте месячный бюджет и отслеживайте карты, лимиты, платежи и рассрочки.";
            if("on_finbi".equals(key)) return "Finbi и руководство|Finbi отвечает на финансовые вопросы и объясняет, как пользоваться Finway. Руководство всегда доступно в меню.";
            if("on_done".equals(key)) return "Всё готово|Начните с добавления счёта и первой операции. Введение можно повторить из руководства.";
            if("next".equals(key)) return "Далее"; if("skip".equals(key)) return "Пропустить"; if("start".equals(key)) return "Начать"; if("replay".equals(key)) return "Повторить введение";
        }
        if("ja".equals(language)){
            if("guide_title".equals(key)) return "利用ガイド"; if("guide_intro".equals(key)) return "Finwayの使い方を簡単に説明します。";
            if("accounts".equals(key)) return "口座|マイアカウントから銀行・現金などの口座を追加します。現在残高を入力し、お金が動いたら更新してください。";
            if("transactions".equals(key)) return "取引|収入と支出を記録します。金額、日付、カテゴリ、口座を入力すると分析が正確になります。";
            if("budget".equals(key)) return "予算|メニューの予算から月間上限を設定し、必要ならカテゴリ別上限も設定できます。上限に近づくと通知できます。";
            if("cards".equals(key)) return "クレジットカード|限度額、締め日、支払日を登録すると、残高、分割払い、支払いを管理できます。";
            if("subscriptions".equals(key)) return "サブスクリプション|定期サービスの金額と支払日を登録して、継続費用をまとめて確認できます。";
            if("finbi".equals(key)) return "Finbi|メニューまたはフローティングアシスタントから開けます。残高、支出、予算、カード、目標、Finwayの使い方を質問できます。";
            if("analysis".equals(key)) return "分析|登録した取引から支出カテゴリ、傾向、予算使用状況、財務サマリーを表示します。";
            if("security".equals(key)) return "セキュリティとバックアップ|設定からPIN、アプリロック、生体認証、言語、表示を管理できます。バックアップはデータ転送から行います。";
            if("on_welcome".equals(key)) return "Finwayへようこそ|主要な機能を短いツアーで確認しましょう。";
            if("on_home".equals(key)) return "ホーム|残高、収入、支出、予算、市場情報をここでまとめて確認できます。";
            if("on_accounts".equals(key)) return "口座と取引|口座と収入・支出を最新に保ちましょう。正確な記録ほど分析が便利になります。";
            if("on_budget".equals(key)) return "予算とカード|月間予算を設定し、カード、限度額、支払い、分割払いを管理できます。";
            if("on_finbi".equals(key)) return "Finbiとガイド|Finbiは財務に関する質問とFinwayの使い方を案内します。利用ガイドはメニューからいつでも開けます。";
            if("on_done".equals(key)) return "準備完了|まず口座と最初の取引を追加しましょう。ツアーは利用ガイドから再表示できます。";
            if("next".equals(key)) return "次へ"; if("skip".equals(key)) return "スキップ"; if("start".equals(key)) return "始める"; if("replay".equals(key)) return "紹介をもう一度見る";
        }
        if("zh".equals(language)){
            if("guide_title".equals(key)) return "使用指南"; if("guide_intro".equals(key)) return "快速了解如何使用 Finway。";
            if("accounts".equals(key)) return "账户|在我的账户中添加银行、现金等账户，输入当前余额，并在资金变化后更新。";
            if("transactions".equals(key)) return "交易|记录收入和支出。填写金额、日期、分类和账户，可帮助 Finway 更准确地分析。";
            if("budget".equals(key)) return "预算|从菜单进入预算，设置月度上限，也可以设置分类上限。接近上限时可获得提醒。";
            if("cards".equals(key)) return "信用卡|添加额度、账单日和还款日，即可跟踪欠款、分期和还款。";
            if("subscriptions".equals(key)) return "订阅|添加定期服务、金额和付款日，集中查看持续性支出。";
            if("finbi".equals(key)) return "Finbi|从菜单或悬浮助手打开。可以询问余额、支出、预算、信用卡、目标以及 Finway 的使用方法。";
            if("analysis".equals(key)) return "分析|Finway 根据记录的交易展示支出分类、趋势、预算使用情况和财务摘要。";
            if("security".equals(key)) return "安全与备份|在设置中管理 PIN、应用锁、生物识别、语言和外观。备份与恢复可从数据传输进入。";
            if("on_welcome".equals(key)) return "欢迎使用 Finway|让我们用一个简短的导览了解主要功能。";
            if("on_home".equals(key)) return "首页|这里汇总显示余额、收入、支出、预算和市场信息。";
            if("on_accounts".equals(key)) return "账户与交易|保持账户以及收入、支出记录最新。准确的数据会让分析更有用。";
            if("on_budget".equals(key)) return "预算与信用卡|设置月度预算并跟踪信用卡、额度、还款和分期。";
            if("on_finbi".equals(key)) return "Finbi 与指南|Finbi 可以回答财务问题并说明如何使用 Finway。使用指南始终可以从菜单打开。";
            if("on_done".equals(key)) return "准备好了|先添加一个账户和第一笔交易。你可以从使用指南重新查看导览。";
            if("next".equals(key)) return "下一步"; if("skip".equals(key)) return "跳过"; if("start".equals(key)) return "开始"; if("replay".equals(key)) return "重新查看介绍";
        }
        if("ar".equals(language)){
            if("guide_title".equals(key)) return "دليل الاستخدام"; if("guide_intro".equals(key)) return "دليل سريع لاستخدام Finway.";
            if("accounts".equals(key)) return "الحسابات|أضف الحسابات البنكية والنقدية وغيرها من قسم حساباتي. أدخل الرصيد الحالي وحدّثه عند حركة الأموال.";
            if("transactions".equals(key)) return "المعاملات|سجل الدخل والمصروفات. أدخل المبلغ والتاريخ والفئة والحساب لتحسين التحليل.";
            if("budget".equals(key)) return "الميزانية|افتح الميزانيات من القائمة وحدد الحد الشهري ويمكنك إضافة حدود للفئات. يمكن لـ Finway تنبيهك عند الاقتراب من الحد.";
            if("cards".equals(key)) return "البطاقات الائتمانية|أضف الحد وتاريخ كشف الحساب وتاريخ الاستحقاق لمتابعة الديون والأقساط والمدفوعات.";
            if("subscriptions".equals(key)) return "الاشتراكات|أضف الخدمات المتكررة مع المبلغ ويوم الدفع لمتابعة التكاليف المستمرة.";
            if("finbi".equals(key)) return "Finbi|افتح Finbi من القائمة أو المساعد العائم. اسأل عن الرصيد والمصروفات والميزانية والبطاقات والأهداف أو كيفية استخدام Finway.";
            if("analysis".equals(key)) return "التحليل|يستخدم Finway معاملاتك لعرض فئات الإنفاق والاتجاهات واستخدام الميزانية والملخصات المالية.";
            if("security".equals(key)) return "الأمان والنسخ الاحتياطي|من الإعدادات يمكنك إدارة PIN وقفل التطبيق والقياسات الحيوية واللغة والمظهر. استخدم نقل البيانات للنسخ والاستعادة.";
            if("on_welcome".equals(key)) return "مرحباً بك في Finway|لنأخذ جولة قصيرة للتعرف على أهم الأقسام.";
            if("on_home".equals(key)) return "الرئيسية|هنا سترى ملخص الرصيد والدخل والمصروفات والميزانية وبيانات السوق.";
            if("on_accounts".equals(key)) return "الحسابات والمعاملات|حافظ على تحديث الحسابات والدخل والمصروفات. البيانات الدقيقة تجعل التحليل أفضل.";
            if("on_budget".equals(key)) return "الميزانية والبطاقات|حدد ميزانية شهرية وتابع البطاقات والحدود والمدفوعات والأقساط.";
            if("on_finbi".equals(key)) return "Finbi والدليل|يجيب Finbi عن الأسئلة المالية ويشرح استخدام Finway. دليل الاستخدام متاح دائماً من القائمة.";
            if("on_done".equals(key)) return "أنت جاهز|ابدأ بإضافة حساب وأول معاملة. يمكنك إعادة الجولة من دليل الاستخدام.";
            if("next".equals(key)) return "التالي"; if("skip".equals(key)) return "تخطي"; if("start".equals(key)) return "ابدأ"; if("replay".equals(key)) return "إعادة المقدمة";
        }
        if("el".equals(language)){
            if("guide_title".equals(key)) return "Οδηγός χρήσης"; if("guide_intro".equals(key)) return "Γρήγορος οδηγός για το Finway.";
            if("accounts".equals(key)) return "Λογαριασμοί|Πρόσθεσε τραπεζικούς, μετρητά και άλλους λογαριασμούς από τους Λογαριασμούς μου. Ενημέρωνε το υπόλοιπο όταν αλλάζουν τα χρήματα.";
            if("transactions".equals(key)) return "Συναλλαγές|Κατέγραψε έσοδα και έξοδα. Ποσό, ημερομηνία, κατηγορία και λογαριασμός βοηθούν την ανάλυση.";
            if("budget".equals(key)) return "Προϋπολογισμός|Άνοιξε Προϋπολογισμούς από το μενού, βάλε μηνιαίο όριο και προαιρετικά όρια κατηγοριών. Το Finway μπορεί να σε ειδοποιεί.";
            if("cards".equals(key)) return "Πιστωτικές κάρτες|Πρόσθεσε όριο, ημέρα έκδοσης και ημερομηνία πληρωμής για να παρακολουθείς χρέη, δόσεις και πληρωμές.";
            if("subscriptions".equals(key)) return "Συνδρομές|Πρόσθεσε επαναλαμβανόμενες υπηρεσίες με ποσό και ημέρα πληρωμής για να βλέπεις τα σταθερά έξοδα.";
            if("finbi".equals(key)) return "Finbi|Άνοιξε το Finbi από το μενού ή τον αιωρούμενο βοηθό. Ρώτησε για υπόλοιπο, έξοδα, προϋπολογισμό, κάρτες, στόχους ή χρήση του Finway.";
            if("analysis".equals(key)) return "Ανάλυση|Το Finway χρησιμοποιεί τις συναλλαγές σου για κατηγορίες εξόδων, τάσεις, χρήση προϋπολογισμού και οικονομικές περιλήψεις.";
            if("security".equals(key)) return "Ασφάλεια και αντίγραφο|Από τις Ρυθμίσεις διαχειρίζεσαι PIN, κλείδωμα, βιομετρικά, γλώσσα και εμφάνιση. Για αντίγραφο και επαναφορά χρησιμοποίησε Μεταφορά δεδομένων.";
            if("on_welcome".equals(key)) return "Καλώς ήρθες στο Finway|Ας κάνουμε μια σύντομη ξενάγηση στις βασικές λειτουργίες.";
            if("on_home".equals(key)) return "Αρχική|Εδώ συνοψίζονται υπόλοιπο, έσοδα, έξοδα, προϋπολογισμός και αγορές.";
            if("on_accounts".equals(key)) return "Λογαριασμοί και συναλλαγές|Κράτα ενημερωμένους τους λογαριασμούς και τις εγγραφές εσόδων/εξόδων. Τα ακριβή δεδομένα βελτιώνουν την ανάλυση.";
            if("on_budget".equals(key)) return "Προϋπολογισμός και κάρτες|Ρύθμισε μηνιαίο προϋπολογισμό και παρακολούθησε κάρτες, όρια, πληρωμές και δόσεις.";
            if("on_finbi".equals(key)) return "Finbi και οδηγός|Το Finbi απαντά σε οικονομικές ερωτήσεις και εξηγεί πώς χρησιμοποιείται το Finway. Ο οδηγός είναι πάντα στο μενού.";
            if("on_done".equals(key)) return "Είσαι έτοιμος|Πρόσθεσε πρώτα έναν λογαριασμό και την πρώτη συναλλαγή. Μπορείς να ξαναδείς την ξενάγηση από τον οδηγό.";
            if("next".equals(key)) return "Επόμενο"; if("skip".equals(key)) return "Παράλειψη"; if("start".equals(key)) return "Ξεκίνα"; if("replay".equals(key)) return "Επανάληψη εισαγωγής";
        }
        if("es".equals(language)){
            if("guide_title".equals(key)) return "Guía de uso"; if("guide_intro".equals(key)) return "Guía rápida para usar Finway.";
            if("accounts".equals(key)) return "Cuentas|Añade cuentas bancarias, efectivo y otras cuentas desde Mis cuentas. Introduce el saldo actual y actualízalo cuando se mueva el dinero.";
            if("transactions".equals(key)) return "Transacciones|Registra ingresos y gastos. Importe, fecha, categoría y cuenta ayudan a Finway a analizar tu actividad.";
            if("budget".equals(key)) return "Presupuesto|Abre Presupuestos desde el menú, define tu límite mensual y, si quieres, límites por categoría. Finway puede avisarte al acercarte al límite.";
            if("cards".equals(key)) return "Tarjetas de crédito|Añade límite, día de extracto y fecha de pago para seguir deuda, cuotas y pagos.";
            if("subscriptions".equals(key)) return "Suscripciones|Añade servicios recurrentes con importe y día de pago para controlar los costes periódicos.";
            if("finbi".equals(key)) return "Finbi|Abre Finbi desde el menú o el asistente flotante. Pregunta por saldo, gastos, presupuesto, tarjetas, objetivos o cómo usar Finway.";
            if("analysis".equals(key)) return "Análisis|Finway usa tus transacciones para mostrar categorías de gasto, tendencias, uso del presupuesto y resúmenes financieros.";
            if("security".equals(key)) return "Seguridad y copia|En Ajustes puedes gestionar PIN, bloqueo, biometría, idioma y apariencia. Usa Transferencia de datos para copias y restauración.";
            if("on_welcome".equals(key)) return "Bienvenido a Finway|Hagamos un recorrido breve por las funciones principales.";
            if("on_home".equals(key)) return "Inicio|Aquí se resumen saldo, ingresos, gastos, presupuesto y mercados.";
            if("on_accounts".equals(key)) return "Cuentas y transacciones|Mantén actualizadas tus cuentas y registros. Los datos precisos mejoran el análisis.";
            if("on_budget".equals(key)) return "Presupuesto y tarjetas|Define un presupuesto mensual y controla tarjetas, límites, pagos y cuotas.";
            if("on_finbi".equals(key)) return "Finbi y guía|Finbi responde preguntas financieras y explica cómo usar Finway. La guía está siempre disponible en el menú.";
            if("on_done".equals(key)) return "Ya estás listo|Empieza añadiendo una cuenta y tu primera transacción. Puedes repetir el recorrido desde la guía.";
            if("next".equals(key)) return "Siguiente"; if("skip".equals(key)) return "Omitir"; if("start".equals(key)) return "Empezar"; if("replay".equals(key)) return "Repetir introducción";
        }
        if("it".equals(language)){
            if("guide_title".equals(key)) return "Guida all’uso"; if("guide_intro".equals(key)) return "Guida rapida per usare Finway.";
            if("accounts".equals(key)) return "Conti|Aggiungi conti bancari, contanti e altri conti da I miei conti. Inserisci il saldo attuale e aggiornalo quando il denaro cambia.";
            if("transactions".equals(key)) return "Transazioni|Registra entrate e spese. Importo, data, categoria e conto aiutano Finway nell’analisi.";
            if("budget".equals(key)) return "Budget|Apri Budget dal menu, imposta il limite mensile e, se vuoi, limiti per categoria. Finway può avvisarti quando ti avvicini al limite.";
            if("cards".equals(key)) return "Carte di credito|Aggiungi limite, giorno dell’estratto e scadenza per seguire debiti, rate e pagamenti.";
            if("subscriptions".equals(key)) return "Abbonamenti|Aggiungi servizi ricorrenti con importo e giorno di pagamento per controllare i costi periodici.";
            if("finbi".equals(key)) return "Finbi|Apri Finbi dal menu o dall’assistente flottante. Chiedi di saldo, spese, budget, carte, obiettivi o uso di Finway.";
            if("analysis".equals(key)) return "Analisi|Finway usa le transazioni per mostrare categorie di spesa, tendenze, uso del budget e riepiloghi finanziari.";
            if("security".equals(key)) return "Sicurezza e backup|Da Impostazioni gestisci PIN, blocco app, biometria, lingua e aspetto. Usa Trasferimento dati per backup e ripristino.";
            if("on_welcome".equals(key)) return "Benvenuto in Finway|Facciamo un breve tour delle funzioni principali.";
            if("on_home".equals(key)) return "Home|Qui trovi un riepilogo di saldo, entrate, spese, budget e mercati.";
            if("on_accounts".equals(key)) return "Conti e transazioni|Mantieni aggiornati conti, entrate e spese. Dati accurati rendono l’analisi più utile.";
            if("on_budget".equals(key)) return "Budget e carte|Imposta un budget mensile e controlla carte, limiti, pagamenti e rate.";
            if("on_finbi".equals(key)) return "Finbi e guida|Finbi risponde alle domande finanziarie e spiega come usare Finway. La guida è sempre nel menu.";
            if("on_done".equals(key)) return "Sei pronto|Inizia aggiungendo un conto e la prima transazione. Puoi ripetere il tour dalla guida.";
            if("next".equals(key)) return "Avanti"; if("skip".equals(key)) return "Salta"; if("start".equals(key)) return "Inizia"; if("replay".equals(key)) return "Ripeti introduzione";
        }
        // Turkish fallback
        if("guide_title".equals(key)) return "Kullanım Kılavuzu";
        if("guide_intro".equals(key)) return "Finway'i kullanmak için hızlı rehber.";
        if("accounts".equals(key)) return "Hesaplar|Hesaplarım bölümünden banka, nakit ve diğer hesaplarını ekle. Güncel bakiyeni gir ve para hareketlerinde güncelle.";
        if("transactions".equals(key)) return "İşlemler|Gelir ve giderlerini İşlemler ekranından kaydet. Tutar, tarih, kategori ve hesap bilgilerini girerek analizlerin daha doğru olmasını sağla.";
        if("budget".equals(key)) return "Bütçe|Menüden Bütçeler bölümünü aç, aylık limitini gir ve istersen kategori limitleri belirle. Finway limite yaklaşınca seni uyarabilir.";
        if("cards".equals(key)) return "Kredi Kartları|Kartını limit, ekstre günü ve son ödeme tarihiyle ekle. Borç, taksit ve ödemelerini buradan takip et.";
        if("subscriptions".equals(key)) return "Abonelikler|Düzenli hizmetlerini tutar ve ödeme günüyle ekle. Böylece tekrarlayan giderlerini tek yerde görebilirsin.";
        if("finbi".equals(key)) return "Finbi|Menüden veya yüzen Finbi asistanından aç. Bakiye, harcama, bütçe, kart, hedef veya Finway'i nasıl kullanacağını sorabilirsin.";
        if("analysis".equals(key)) return "Analiz|Finway, kaydettiğin işlemlerden harcama kategorileri, trendler, bütçe kullanımı ve finansal özetler oluşturur.";
        if("security".equals(key)) return "Güvenlik ve Yedekleme|Ayarlar'dan PIN, uygulama kilidi, biyometrik giriş, dil ve görünümü yönet. Yedekleme ve geri yükleme için Veri Aktarımı'nı kullan.";
        if("on_welcome".equals(key)) return "Finway'e hoş geldin|Uygulamanın temel bölümlerini kısa bir turla tanıyalım.";
        if("on_home".equals(key)) return "Ana Sayfa|Bakiye, gelir, gider, bütçe ve piyasa bilgilerini burada özet olarak görebilirsin.";
        if("on_accounts".equals(key)) return "Hesaplar ve İşlemler|Hesaplarını ve gelir-gider kayıtlarını güncel tut. Doğru kayıtlar Finway analizlerini daha faydalı hale getirir.";
        if("on_budget".equals(key)) return "Bütçe ve Kartlar|Aylık bütçeni belirle; kredi kartlarını, limitlerini, ödemelerini ve taksitlerini takip et.";
        if("on_finbi".equals(key)) return "Finbi ve Kılavuz|Finbi finans sorularını yanıtlayabilir ve Finway'in nasıl kullanılacağını anlatabilir. Kılavuza menüden her zaman ulaşabilirsin.";
        if("on_done".equals(key)) return "Hazırsın|Önce bir hesap ve ilk işlemini ekleyerek başlayabilirsin. Bu turu Kılavuz üzerinden tekrar açabilirsin.";
        if("next".equals(key)) return "İleri"; if("skip".equals(key)) return "Atla"; if("start".equals(key)) return "Başla"; if("replay".equals(key)) return "Tanıtımı tekrar göster";
        return key;
    }

    private void showGuide(){
        enterScreen("guide");
        currentPage=3;
        base(guideText("guide_title"));
        Colors c=C();
        TextView intro=text(guideText("guide_intro"),13,c.muted);margins(intro,2,0,2,14);content.addView(intro);
        String[] keys={"accounts","transactions","budget","cards","subscriptions","finbi","analysis","security"};
        for(String key:keys){
            String[] parts=guideText(key).split("\\|",2);
            LinearLayout item=card(c.surface,18);item.setPadding(dp(15),dp(14),dp(15),dp(14));
            TextView title=text(parts[0],16,c.text);title.setTypeface(null,Typeface.BOLD);item.addView(title);
            if(parts.length>1){TextView body=text(parts[1],12,c.muted);margins(body,0,6,0,0);item.addView(body);}
            margins(item,0,0,0,9);content.addView(item);
        }
        Button replay=dialogButton(guideText("replay"),Color.WHITE,c.blue);replay.setTextSize(13);margins(replay,0,6,0,0);content.addView(replay);replay.setOnClickListener(v->showOnboarding(false));
    }

    private FrameLayout visualTourOverlay;
    private ImageView visualTourBlur;
    private ImageView visualTourFocus;
    private GuidedTourView visualTourCanvas;
    private int visualTourStep=0;
    private boolean visualTourFirstLaunch=false;

    private String tourText(String key){
        String l=language==null?"tr":language;
        if("en".equals(l)){
            if("welcome".equals(key))return "Welcome to Finway";
            if("welcome_body".equals(key))return "A short visual tour will show you where the important actions live. Everything else stays softly out of the way.";
            if("home".equals(key))return "Your financial home";
            if("home_body".equals(key))return "Your balance, income, spending and budget are summarized here. Start from this screen whenever you open Finway.";
            if("accounts".equals(key))return "Add your accounts";
            if("accounts_body".equals(key))return "Tap here to add a bank, cash or other account. Finway uses these accounts to keep your balances and transactions connected.";
            if("transactions".equals(key))return "Record a transaction";
            if("transactions_body".equals(key))return "Add income or spending here. The more accurately you record your activity, the better your analysis becomes.";
            if("budget".equals(key))return "Set your budget";
            if("budget_body".equals(key))return "Define your monthly limit and keep an eye on how much is left. You can also set category limits.";
            if("cards".equals(key))return "Track your credit cards";
            if("cards_body".equals(key))return "Add a card here to follow its limit, statement, due date, debt and installments in one place.";
            if("finbi".equals(key))return "Meet Finbi";
            if("finbi_body".equals(key))return "Ask Finbi about your finances or simply ask how to use Finway. The assistant can guide you to the right feature.";
            if("guide".equals(key))return "Your visual guide";
            if("guide_body".equals(key))return "The User Guide is always available from the menu. You can replay this tour whenever you want.";
            if("done".equals(key))return "You're ready";
            if("done_body".equals(key))return "Start by adding an account and your first transaction. Finway will take it from there.";
            if("next".equals(key))return "Next";
            if("skip".equals(key))return "Skip tour";
            if("start".equals(key))return "Start using Finway";
        }
        if("fr".equals(l)){
            if("welcome".equals(key))return "Bienvenue sur Finway"; if("welcome_body".equals(key))return "Une courte visite visuelle vous montre où se trouvent les actions importantes. Le reste reste discrètement en arrière-plan.";
            if("home".equals(key))return "Votre espace financier"; if("home_body".equals(key))return "Votre solde, vos revenus, vos dépenses et votre budget sont réunis ici. C’est votre point de départ dans Finway.";
            if("accounts".equals(key))return "Ajoutez vos comptes"; if("accounts_body".equals(key))return "Touchez ici pour ajouter un compte bancaire, liquide ou autre. Finway relie ensuite soldes et transactions.";
            if("transactions".equals(key))return "Enregistrez une transaction"; if("transactions_body".equals(key))return "Ajoutez ici un revenu ou une dépense. Des données précises améliorent vos analyses.";
            if("budget".equals(key))return "Définissez votre budget"; if("budget_body".equals(key))return "Définissez votre limite mensuelle et suivez ce qu’il vous reste. Vous pouvez aussi créer des limites par catégorie.";
            if("cards".equals(key))return "Suivez vos cartes"; if("cards_body".equals(key))return "Ajoutez une carte ici pour suivre limite, relevé, échéance, dette et paiements en un seul endroit.";
            if("finbi".equals(key))return "Découvrez Finbi"; if("finbi_body".equals(key))return "Posez vos questions financières à Finbi ou demandez simplement comment utiliser Finway.";
            if("guide".equals(key))return "Votre guide visuel"; if("guide_body".equals(key))return "Le guide d’utilisation est toujours disponible dans le menu. Vous pouvez rejouer cette visite à tout moment.";
            if("done".equals(key))return "Vous êtes prêt"; if("done_body".equals(key))return "Commencez par ajouter un compte et votre première transaction. Finway vous accompagne ensuite.";
            if("next".equals(key))return "Suivant"; if("skip".equals(key))return "Passer"; if("start".equals(key))return "Commencer avec Finway";
        }
        if("de".equals(l)){
            if("welcome".equals(key))return "Willkommen bei Finway"; if("welcome_body".equals(key))return "Eine kurze visuelle Tour zeigt dir die wichtigsten Aktionen. Alles andere tritt dezent in den Hintergrund.";
            if("home".equals(key))return "Deine Finanzzentrale"; if("home_body".equals(key))return "Saldo, Einnahmen, Ausgaben und Budget werden hier zusammengefasst. Von hier aus startest du in Finway.";
            if("accounts".equals(key))return "Konten hinzufügen"; if("accounts_body".equals(key))return "Tippe hier, um Bank-, Bargeld- oder andere Konten hinzuzufügen. Finway verbindet Salden und Transaktionen.";
            if("transactions".equals(key))return "Transaktion erfassen"; if("transactions_body".equals(key))return "Füge hier Einnahmen oder Ausgaben hinzu. Genaue Daten verbessern deine Analyse.";
            if("budget".equals(key))return "Budget festlegen"; if("budget_body".equals(key))return "Lege dein Monatslimit fest und behalte den verbleibenden Betrag im Blick. Kategorienlimits sind ebenfalls möglich.";
            if("cards".equals(key))return "Kreditkarten verfolgen"; if("cards_body".equals(key))return "Füge hier eine Karte hinzu, um Limit, Abrechnung, Fälligkeit, Schulden und Raten zentral zu verfolgen.";
            if("finbi".equals(key))return "Finbi kennenlernen"; if("finbi_body".equals(key))return "Frage Finbi zu deinen Finanzen oder einfach, wie Finway funktioniert.";
            if("guide".equals(key))return "Dein visueller Leitfaden"; if("guide_body".equals(key))return "Das Benutzerhandbuch ist jederzeit im Menü verfügbar. Du kannst diese Tour jederzeit wiederholen.";
            if("done".equals(key))return "Du bist bereit"; if("done_body".equals(key))return "Füge zuerst ein Konto und deine erste Transaktion hinzu. Finway übernimmt den Rest.";
            if("next".equals(key))return "Weiter"; if("skip".equals(key))return "Überspringen"; if("start".equals(key))return "Finway starten";
        }
        if("ru".equals(l)){
            if("welcome".equals(key))return "Добро пожаловать в Finway"; if("welcome_body".equals(key))return "Короткий визуальный тур покажет основные действия, а всё остальное мягко уйдёт на второй план.";
            if("home".equals(key))return "Ваш финансовый центр"; if("home_body".equals(key))return "Здесь собраны баланс, доходы, расходы и бюджет. Это главный экран Finway.";
            if("accounts".equals(key))return "Добавьте счета"; if("accounts_body".equals(key))return "Нажмите здесь, чтобы добавить банковский, наличный или другой счёт. Finway свяжет остатки и операции.";
            if("transactions".equals(key))return "Добавьте операцию"; if("transactions_body".equals(key))return "Здесь добавляются доходы и расходы. Точные записи делают анализ полезнее.";
            if("budget".equals(key))return "Настройте бюджет"; if("budget_body".equals(key))return "Задайте месячный лимит и следите за остатком. Можно также установить лимиты категорий.";
            if("cards".equals(key))return "Следите за картами"; if("cards_body".equals(key))return "Добавьте карту, чтобы видеть лимит, выписку, срок оплаты, долг и рассрочки в одном месте.";
            if("finbi".equals(key))return "Познакомьтесь с Finbi"; if("finbi_body".equals(key))return "Спросите Finbi о финансах или о том, как пользоваться Finway.";
            if("guide".equals(key))return "Ваш визуальный гид"; if("guide_body".equals(key))return "Руководство пользователя всегда доступно в меню. Тур можно повторить в любое время.";
            if("done".equals(key))return "Всё готово"; if("done_body".equals(key))return "Начните с добавления счёта и первой операции. Дальше Finway поможет вам.";
            if("next".equals(key))return "Далее"; if("skip".equals(key))return "Пропустить"; if("start".equals(key))return "Начать работу с Finway";
        }
        if("ja".equals(l)){
            if("welcome".equals(key))return "Finwayへようこそ"; if("welcome_body".equals(key))return "重要な操作を実際の画面上で案内します。その他の部分はガラスのように控えめにします。";
            if("home".equals(key))return "あなたの金融ホーム"; if("home_body".equals(key))return "残高、収入、支出、予算をここでまとめて確認できます。";
            if("accounts".equals(key))return "口座を追加"; if("accounts_body".equals(key))return "ここから銀行口座、現金などを追加します。残高と取引をFinwayでつなげられます。";
            if("transactions".equals(key))return "取引を記録"; if("transactions_body".equals(key))return "ここから収入や支出を追加します。正確な記録ほど分析が便利になります。";
            if("budget".equals(key))return "予算を設定"; if("budget_body".equals(key))return "月間上限を設定し、残りを確認できます。カテゴリ別の上限も設定できます。";
            if("cards".equals(key))return "カードを管理"; if("cards_body".equals(key))return "カードの上限、締め日、支払日、残高、分割払いをここで管理できます。";
            if("finbi".equals(key))return "Finbiを使ってみる"; if("finbi_body".equals(key))return "Finbiにお金のことやFinwayの使い方を質問できます。";
            if("guide".equals(key))return "ビジュアルガイド"; if("guide_body".equals(key))return "利用ガイドはメニューからいつでも開けます。このツアーも再生できます。";
            if("done".equals(key))return "準備完了"; if("done_body".equals(key))return "まず口座と最初の取引を追加してみましょう。";
            if("next".equals(key))return "次へ"; if("skip".equals(key))return "スキップ"; if("start".equals(key))return "Finwayを始める";
        }
        if("zh".equals(l)){
            if("welcome".equals(key))return "欢迎使用 Finway"; if("welcome_body".equals(key))return "通过真实页面上的视觉引导了解重要操作，其余区域会柔和地退到背景。";
            if("home".equals(key))return "你的财务首页"; if("home_body".equals(key))return "余额、收入、支出和预算都在这里汇总。";
            if("accounts".equals(key))return "添加账户"; if("accounts_body".equals(key))return "点击这里添加银行、现金或其他账户，让余额与交易保持关联。";
            if("transactions".equals(key))return "记录一笔交易"; if("transactions_body".equals(key))return "在这里添加收入或支出。记录越准确，分析越有用。";
            if("budget".equals(key))return "设置预算"; if("budget_body".equals(key))return "设置月度上限并查看剩余金额，也可以设置分类预算。";
            if("cards".equals(key))return "管理信用卡"; if("cards_body".equals(key))return "添加信用卡后，可集中查看额度、账单日、还款日、欠款和分期。";
            if("finbi".equals(key))return "认识 Finbi"; if("finbi_body".equals(key))return "向 Finbi 询问财务问题，也可以直接询问如何使用 Finway。";
            if("guide".equals(key))return "可视化使用指南"; if("guide_body".equals(key))return "使用指南始终可以从菜单打开，也可以随时重新播放本次导览。";
            if("done".equals(key))return "准备好了"; if("done_body".equals(key))return "先添加一个账户和第一笔交易，Finway会继续帮助你。";
            if("next".equals(key))return "下一步"; if("skip".equals(key))return "跳过"; if("start".equals(key))return "开始使用 Finway";
        }
        if("ar".equals(l)){
            if("welcome".equals(key))return "مرحبًا بك في Finway"; if("welcome_body".equals(key))return "جولة مرئية قصيرة ستوضح لك أماكن أهم الإجراءات، بينما تتراجع بقية الشاشة بلطف إلى الخلفية.";
            if("home".equals(key))return "مركزك المالي"; if("home_body".equals(key))return "ستجد هنا ملخص الرصيد والدخل والمصروفات والميزانية.";
            if("accounts".equals(key))return "أضف حساباتك"; if("accounts_body".equals(key))return "اضغط هنا لإضافة حساب بنكي أو نقدي أو غيره وربط الأرصدة بالعمليات.";
            if("transactions".equals(key))return "سجّل عملية"; if("transactions_body".equals(key))return "أضف الدخل أو المصروفات هنا. التسجيل الدقيق يجعل التحليل أفضل.";
            if("budget".equals(key))return "حدّد ميزانيتك"; if("budget_body".equals(key))return "حدد الحد الشهري وتابع المبلغ المتبقي، ويمكنك أيضًا تحديد حدود للفئات.";
            if("cards".equals(key))return "تابع بطاقاتك"; if("cards_body".equals(key))return "أضف البطاقة لمتابعة الحد والفاتورة والاستحقاق والديون والأقساط في مكان واحد.";
            if("finbi".equals(key))return "تعرّف على Finbi"; if("finbi_body".equals(key))return "اسأل Finbi عن أموالك أو عن طريقة استخدام Finway.";
            if("guide".equals(key))return "دليلك المرئي"; if("guide_body".equals(key))return "دليل الاستخدام متاح دائمًا من القائمة ويمكنك إعادة الجولة متى شئت.";
            if("done".equals(key))return "أنت جاهز"; if("done_body".equals(key))return "ابدأ بإضافة حساب وأول عملية لك، ثم دع Finway يساعدك.";
            if("next".equals(key))return "التالي"; if("skip".equals(key))return "تخطي"; if("start".equals(key))return "ابدأ استخدام Finway";
        }
        if("el".equals(l)){
            if("welcome".equals(key))return "Καλώς ήρθατε στο Finway"; if("welcome_body".equals(key))return "Μια σύντομη οπτική περιήγηση δείχνει τις βασικές ενέργειες, ενώ το υπόλοιπο περιβάλλον υποχωρεί διακριτικά.";
            if("home".equals(key))return "Η οικονομική σας αρχική"; if("home_body".equals(key))return "Υπόλοιπο, έσοδα, έξοδα και προϋπολογισμός συγκεντρώνονται εδώ.";
            if("accounts".equals(key))return "Προσθέστε λογαριασμούς"; if("accounts_body".equals(key))return "Πατήστε εδώ για να προσθέσετε τραπεζικό, μετρητά ή άλλο λογαριασμό και να συνδέσετε υπόλοιπα και συναλλαγές.";
            if("transactions".equals(key))return "Καταγράψτε μια συναλλαγή"; if("transactions_body".equals(key))return "Προσθέστε έσοδα ή έξοδα εδώ. Οι ακριβείς καταγραφές κάνουν την ανάλυση καλύτερη.";
            if("budget".equals(key))return "Ορίστε προϋπολογισμό"; if("budget_body".equals(key))return "Ορίστε το μηνιαίο όριο και παρακολουθήστε το υπόλοιπο. Μπορείτε επίσης να ορίσετε όρια ανά κατηγορία.";
            if("cards".equals(key))return "Παρακολουθήστε κάρτες"; if("cards_body".equals(key))return "Προσθέστε μια κάρτα για να βλέπετε όριο, έκδοση λογαριασμού, προθεσμία, χρέος και δόσεις.";
            if("finbi".equals(key))return "Γνωρίστε το Finbi"; if("finbi_body".equals(key))return "Ρωτήστε το Finbi για τα οικονομικά σας ή για το πώς χρησιμοποιείται το Finway.";
            if("guide".equals(key))return "Ο οπτικός οδηγός σας"; if("guide_body".equals(key))return "Ο οδηγός χρήσης είναι πάντα διαθέσιμος από το μενού και η περιήγηση μπορεί να επαναληφθεί.";
            if("done".equals(key))return "Είστε έτοιμοι"; if("done_body".equals(key))return "Ξεκινήστε προσθέτοντας έναν λογαριασμό και την πρώτη σας συναλλαγή.";
            if("next".equals(key))return "Επόμενο"; if("skip".equals(key))return "Παράλειψη"; if("start".equals(key))return "Ξεκινήστε με το Finway";
        }
        if("es".equals(l)){
            if("welcome".equals(key))return "Bienvenido a Finway"; if("welcome_body".equals(key))return "Un breve recorrido visual te mostrará dónde están las acciones importantes y desenfocará suavemente el resto.";
            if("home".equals(key))return "Tu centro financiero"; if("home_body".equals(key))return "Aquí se resumen saldo, ingresos, gastos y presupuesto. Es tu punto de partida en Finway.";
            if("accounts".equals(key))return "Añade tus cuentas"; if("accounts_body".equals(key))return "Pulsa aquí para añadir una cuenta bancaria, efectivo u otra cuenta y conectar saldos y movimientos.";
            if("transactions".equals(key))return "Registra una operación"; if("transactions_body".equals(key))return "Añade ingresos o gastos aquí. Cuanto más precisos sean los registros, mejor será el análisis.";
            if("budget".equals(key))return "Configura tu presupuesto"; if("budget_body".equals(key))return "Define tu límite mensual y controla lo que queda. También puedes establecer límites por categoría.";
            if("cards".equals(key))return "Controla tus tarjetas"; if("cards_body".equals(key))return "Añade una tarjeta para seguir límite, extracto, vencimiento, deuda y cuotas en un solo lugar.";
            if("finbi".equals(key))return "Conoce Finbi"; if("finbi_body".equals(key))return "Pregunta a Finbi por tus finanzas o simplemente cómo usar Finway.";
            if("guide".equals(key))return "Tu guía visual"; if("guide_body".equals(key))return "La guía de uso está siempre disponible en el menú y puedes repetir este recorrido cuando quieras.";
            if("done".equals(key))return "Ya estás listo"; if("done_body".equals(key))return "Empieza añadiendo una cuenta y tu primera operación. Finway hará el resto.";
            if("next".equals(key))return "Siguiente"; if("skip".equals(key))return "Omitir"; if("start".equals(key))return "Empezar con Finway";
        }
        if("it".equals(l)){
            if("welcome".equals(key))return "Benvenuto in Finway"; if("welcome_body".equals(key))return "Un breve tour visivo mostra le azioni importanti mentre il resto della schermata resta sfocato e discreto.";
            if("home".equals(key))return "Il tuo centro finanziario"; if("home_body".equals(key))return "Saldo, entrate, spese e budget sono riassunti qui. È il tuo punto di partenza in Finway.";
            if("accounts".equals(key))return "Aggiungi i tuoi conti"; if("accounts_body".equals(key))return "Tocca qui per aggiungere conto bancario, contanti o altro e collegare saldi e movimenti.";
            if("transactions".equals(key))return "Registra una transazione"; if("transactions_body".equals(key))return "Aggiungi entrate o spese qui. Registrazioni accurate rendono l’analisi più utile.";
            if("budget".equals(key))return "Imposta il budget"; if("budget_body".equals(key))return "Definisci il limite mensile e controlla quanto resta. Puoi anche impostare limiti per categoria.";
            if("cards".equals(key))return "Tieni sotto controllo le carte"; if("cards_body".equals(key))return "Aggiungi una carta per seguire limite, estratto, scadenza, debito e rate in un unico posto.";
            if("finbi".equals(key))return "Conosci Finbi"; if("finbi_body".equals(key))return "Chiedi a Finbi delle tue finanze o semplicemente come usare Finway.";
            if("guide".equals(key))return "La tua guida visiva"; if("guide_body".equals(key))return "La guida è sempre disponibile dal menu e puoi ripetere questo tour quando vuoi.";
            if("done".equals(key))return "Sei pronto"; if("done_body".equals(key))return "Inizia aggiungendo un conto e la prima transazione. Finway farà il resto.";
            if("next".equals(key))return "Avanti"; if("skip".equals(key))return "Salta"; if("start".equals(key))return "Inizia con Finway";
        }
        if("welcome".equals(key))return "Finway'e Hoş Geldin";
        if("welcome_body".equals(key))return "Uygulamanın önemli noktalarını gerçek ekranların üzerinde göstereceğim. Seçilen alan parlayacak, geri kalan ekran cam gibi yumuşak biçimde geri çekilecek.";
        if("home".equals(key))return "Finans merkezini keşfet";
        if("home_body".equals(key))return "Bakiyen, gelirlerin, harcamaların ve bütçen burada özetlenir. Finway'i açtığında başlangıç noktan burası.";
        if("accounts".equals(key))return "Hesaplarını ekle";
        if("accounts_body".equals(key))return "Banka, nakit veya diğer hesaplarını buradan ekle. Finway bakiye ve işlemlerini birbiriyle ilişkilendirir.";
        if("transactions".equals(key))return "Bir işlem ekle";
        if("transactions_body".equals(key))return "Gelir veya harcamalarını buradan kaydet. Kayıtların ne kadar doğruysa Finway analizleri de o kadar faydalı olur.";
        if("budget".equals(key))return "Bütçeni belirle";
        if("budget_body".equals(key))return "Aylık limitini belirle ve ne kadar kaldığını takip et. İstersen kategori bazında da limit koyabilirsin.";
        if("cards".equals(key))return "Kredi kartlarını takip et";
        if("cards_body".equals(key))return "Kartını buradan ekleyerek limitini, ekstre ve son ödeme tarihini, borcunu ve taksitlerini tek yerde takip edebilirsin.";
        if("finbi".equals(key))return "Finbi ile tanış";
        if("finbi_body".equals(key))return "Finbi'ye finansını sorabilir veya doğrudan “Finway'i nasıl kullanırım?” diyebilirsin. Seni doğru özelliğe yönlendirir.";
        if("guide".equals(key))return "Görsel kullanım kılavuzun";
        if("guide_body".equals(key))return "Kullanım Kılavuzu menüden her zaman ulaşılabilir. Bu görsel turu istediğin zaman tekrar oynatabilirsin.";
        if("done".equals(key))return "Hazırsın";
        if("done_body".equals(key))return "Önce bir hesap ve ilk işlemini ekle. Finway bundan sonrasında sana eşlik edecek.";
        if("next".equals(key))return "İleri";
        if("back".equals(key))return "Geri";
        if("skip".equals(key))return "Turu geç";
        if("start".equals(key))return "Finway'i keşfet";
        return key;
    }

    private View findTourTextView(String value){
        if(value==null)return null;
        ViewGroup root=content;
        if(root==null)return null;
        ArrayDeque<View> q=new ArrayDeque<>(); q.add(root);
        while(!q.isEmpty()){
            View v=q.removeFirst();
            if(v instanceof TextView){
                String t=((TextView)v).getText()==null?"":((TextView)v).getText().toString();
                if(t.equals(value) || t.contains(value)) return v;
            }
            if(v instanceof ViewGroup){ for(int i=0;i<((ViewGroup)v).getChildCount();i++) q.add(((ViewGroup)v).getChildAt(i)); }
        }
        return null;
    }

    private void finishVisualTour(boolean completed){
        if(completed)getPreferences(0).edit().putBoolean("onboarding_completed_v48",true).apply();
        if(visualTourOverlay!=null){
            ViewParent p=visualTourOverlay.getParent(); if(p instanceof ViewGroup)((ViewGroup)p).removeView(visualTourOverlay);
        }
        visualTourOverlay=null;visualTourBlur=null;visualTourFocus=null;visualTourCanvas=null;
        showHome();
    }

    private void showOnboarding(boolean firstLaunch){
        visualTourFirstLaunch=firstLaunch;
        visualTourStep=0;
        renderVisualTourStep();
    }

    private void renderVisualTourStep(){
        if(visualTourStep>=8){finishVisualTour(true);return;}
        if(visualTourOverlay!=null){
            final View oldOverlay=visualTourOverlay;
            oldOverlay.animate().alpha(0f).setDuration(180L)
                .setInterpolator(new android.view.animation.DecelerateInterpolator())
                .withEndAction(()->{
                    ViewParent p=oldOverlay.getParent();
                    if(p instanceof ViewGroup)((ViewGroup)p).removeView(oldOverlay);
                    if(visualTourOverlay==oldOverlay)visualTourOverlay=null;
                    renderVisualTourStepNow();
                }).start();
            return;
        }
        renderVisualTourStepNow();
    }

    private void renderVisualTourStepNow(){
        if(visualTourStep>=8){finishVisualTour(true);return;}
        switch(visualTourStep){
            case 0: showHome(); break;
            case 1: showAccounts(); break;
            case 2: showTransactions(); break;
            case 3: showBudgets(); break;
            case 4: showCreditCards(); break;
            case 5: showHome(); break;
            case 6: showMenu(); break;
            case 7: showHome(); break;
        }
        View host=findViewById(android.R.id.content);
        host.postDelayed(()->{
            View target=null;
            switch(visualTourStep){
                case 0: target=content!=null&&content.getChildCount()>1?content.getChildAt(1):content; break;
                case 1: target=findTourTextView(trUi("Hesap Ekle","Add Account")); break;
                case 2: target=findTourTextView(s(R.string.ui_56f0e02301)); break;
                case 3: target=findTourTextView(trUi("Genel bütçeyi düzenle","Edit overall budget")); break;
                case 4: target=findTourTextView(s(R.string.ui_fef3cdd767)); break;
                case 5: target=finbiBubble; break;
                case 6: target=findTourTextView(guideText("guide_title")); break;
                case 7: target=content!=null&&content.getChildCount()>0?content.getChildAt(0):content; break;
            }
            if(target==null)target=content;
            final View tourTarget=target;
            tourTarget.postDelayed(()->installVisualTour(tourTarget),80);
        },160);
    }

    private void installVisualTour(View target){
        ViewGroup host=(ViewGroup)findViewById(android.R.id.content);
        if(host==null||target==null)return;
        int hw=host.getWidth(),hh=host.getHeight();
        if(hw<=0||hh<=0){final View retryTarget=target;host.postDelayed(()->installVisualTour(retryTarget),120);return;}
        Bitmap snapshot=Bitmap.createBitmap(hw,hh,Bitmap.Config.ARGB_8888);
        Canvas sc=new Canvas(snapshot);host.draw(sc);
        int[] hp=new int[2],tp=new int[2];host.getLocationOnScreen(hp);target.getLocationOnScreen(tp);
        RectF rect=new RectF(tp[0]-hp[0],tp[1]-hp[1],tp[0]-hp[0]+target.getWidth(),tp[1]-hp[1]+target.getHeight());
        float pad=dp(10);rect.inset(-pad,-pad);
        rect.left=Math.max(dp(6),rect.left);rect.top=Math.max(dp(6),rect.top);rect.right=Math.min(hw-dp(6),rect.right);rect.bottom=Math.min(hh-dp(6),rect.bottom);

        visualTourOverlay=new FrameLayout(this);visualTourOverlay.setClipChildren(false);visualTourOverlay.setClipToPadding(false);visualTourOverlay.setLayerType(View.LAYER_TYPE_SOFTWARE,null);
        visualTourBlur=new ImageView(this);visualTourBlur.setImageBitmap(snapshot);visualTourBlur.setScaleType(ImageView.ScaleType.FIT_XY);
        if(Build.VERSION.SDK_INT>=31)visualTourBlur.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(dp(6),dp(6),android.graphics.Shader.TileMode.CLAMP));
        visualTourOverlay.addView(visualTourBlur,new FrameLayout.LayoutParams(-1,-1));
        int sx=Math.max(0,(int)rect.left),sy=Math.max(0,(int)rect.top),sw=Math.min(hw-sx,(int)rect.width()),sh=Math.min(hh-sy,(int)rect.height());
        if(sw>0&&sh>0){
            Bitmap focus=Bitmap.createBitmap(snapshot,sx,sy,sw,sh);
            visualTourFocus=new ImageView(this);visualTourFocus.setImageBitmap(focus);visualTourFocus.setScaleType(ImageView.ScaleType.FIT_XY);FrameLayout.LayoutParams flp=new FrameLayout.LayoutParams(sw,sh);flp.leftMargin=sx;flp.topMargin=sy;visualTourOverlay.addView(visualTourFocus,flp);
        }
        visualTourCanvas=new GuidedTourView(this,rect,visualTourStep,8);
        visualTourOverlay.addView(visualTourCanvas,new FrameLayout.LayoutParams(-1,-1));
        visualTourOverlay.setAlpha(0f);
        host.addView(visualTourOverlay,new ViewGroup.LayoutParams(-1,-1));
        visualTourOverlay.animate().alpha(1f).setDuration(260L)
            .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
    }

    private class GuidedTourView extends View{
        final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); final RectF target; final int step,total;
        GuidedTourView(Context c,RectF r,int st,int count){super(c);target=r;step=st;total=count;setLayerType(View.LAYER_TYPE_SOFTWARE,null);setFocusable(true);}
        String title(){switch(step){case 0:return tourText("welcome");case 1:return tourText("accounts");case 2:return tourText("transactions");case 3:return tourText("budget");case 4:return tourText("cards");case 5:return tourText("finbi");case 6:return tourText("guide");default:return tourText("done");}}
        String body(){switch(step){case 0:return tourText("welcome_body");case 1:return tourText("accounts_body");case 2:return tourText("transactions_body");case 3:return tourText("budget_body");case 4:return tourText("cards_body");case 5:return tourText("finbi_body");case 6:return tourText("guide_body");default:return tourText("done_body");}}
        protected void onDraw(Canvas c){
            super.onDraw(c); int w=getWidth(),h=getHeight();
            p.setStyle(Paint.Style.FILL);p.setColor(Color.argb(darkMode?194:176,2,8,18));c.drawRect(0,0,w,h,p);
            p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));c.drawRoundRect(target,dp(18),dp(18),p);p.setXfermode(null);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2.2f));p.setColor(C().blue);p.setShadowLayer(dp(18),0,0,Color.argb(210,70,225,255));c.drawRoundRect(target,dp(18),dp(18),p);p.clearShadowLayer();
            float dotsW=dp(8*total+7*(total-1)),dx=(w-dotsW)/2f;
            for(int i=0;i<total;i++){p.setStyle(Paint.Style.FILL);p.setColor(i==step?C().blue:Color.argb(80,150,190,215));p.setShadowLayer(i==step?dp(7):0,0,0,Color.argb(180,70,225,255));c.drawCircle(dx+dp(4)+i*dp(15),dp(28),dp(i==step?4:3),p);p.clearShadowLayer();}
            p.setColor(Color.WHITE);p.setTextSize(dp(12));p.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));String skipText=tourText("skip");c.drawText(skipText,w-dp(18)-p.measureText(skipText),dp(33),p);
            float cardW=Math.min(w-dp(28),dp(400)),cardH=dp(step==7?214:204),left=(w-cardW)/2f;boolean below=target.bottom+cardH+dp(34)<h-dp(18);float top=below?target.bottom+dp(18):target.top-cardH-dp(18);top=Math.max(dp(96),Math.min(top,h-cardH-dp(12)));
            p.setStyle(Paint.Style.FILL);p.setColor(darkMode?Color.rgb(10,25,40):Color.rgb(249,253,255));p.setShadowLayer(dp(28),0,dp(8),Color.argb(145,0,0,0));c.drawRoundRect(left,top,left+cardW,top+cardH,dp(24),dp(24),p);p.clearShadowLayer();
            p.setColor(C().blue);p.setShadowLayer(dp(10),0,0,Color.argb(160,70,225,255));c.drawRoundRect(left+dp(18),top+dp(15),left+dp(74),top+dp(18),dp(2),dp(2),p);p.clearShadowLayer();
            p.setColor(C().text);p.setTextSize(dp(19));p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));drawWrapped(c,title(),left+dp(18),top+dp(50),cardW-dp(36),dp(22),3);
            p.setColor(C().muted);p.setTextSize(dp(12.5f));p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));drawWrapped(c,body(),left+dp(18),top+dp(84),cardW-dp(36),dp(18),5);
            float navY=top+cardH-dp(62);
            if(step>0){p.setColor(C().muted);p.setTextSize(dp(12));p.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));c.drawText(tourText("back"),left+dp(18),navY+dp(30),p);}
            p.setStyle(Paint.Style.FILL);p.setColor(C().blue);c.drawRoundRect(left+cardW-dp(122),navY,left+cardW-dp(16),navY+dp(44),dp(15),dp(15),p);
            p.setColor(Color.WHITE);p.setTextSize(dp(12));p.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));String next=step==7?tourText("start"):tourText("next");c.drawText(next,left+cardW-dp(69)-p.measureText(next)/2,navY+dp(28),p);
            float hx=target.right+dp(9),hy=target.bottom+dp(8);if(hx>w-dp(30))hx=target.left-dp(9);if(hy>h-dp(32))hy=target.top-dp(9);
            p.setColor(Color.WHITE);p.setStyle(Paint.Style.FILL);p.setShadowLayer(dp(9),0,dp(3),Color.argb(190,70,225,255));Path hand=new Path();hand.moveTo(hx,hy);hand.lineTo(hx+dp(5),hy+dp(20));hand.lineTo(hx+dp(10),hy+dp(14));hand.lineTo(hx+dp(18),hy+dp(18));hand.lineTo(hx+dp(21),hy+dp(14));hand.lineTo(hx+dp(14),hy+dp(8));hand.lineTo(hx+dp(21),hy+dp(8));hand.close();c.drawPath(hand,p);p.clearShadowLayer();
        }
        private void drawWrapped(Canvas c,String value,float x,float y,float maxW,float lineH,int maxLines){
            if(value==null)value="";String[] words=value.split("\\s+");String line="";int n=0;
            for(String word:words){String test=line.length()==0?word:line+" "+word;if(p.measureText(test)>maxW&&line.length()>0){c.drawText(line,x,y+n*lineH,p);n++;line=word;if(n>=maxLines-1){line=line+"…";break;}}else line=test;}
            if(n<maxLines&&line.length()>0)c.drawText(line,x,y+n*lineH,p);
        }
        public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX(),y=e.getY();int w=getWidth(),h=getHeight();
            float cardW=Math.min(w-dp(28),dp(400)),cardH=dp(step==7?214:204),left=(w-cardW)/2f;boolean below=target.bottom+cardH+dp(34)<h-dp(18);float top=below?target.bottom+dp(18):target.top-cardH-dp(18);top=Math.max(dp(96),Math.min(top,h-cardH-dp(12)));float navY=top+cardH-dp(62);
            RectF next=new RectF(left+cardW-dp(138),navY-dp(8),left+cardW-dp(5),navY+dp(52));RectF back=new RectF(left,navY-dp(8),left+dp(108),navY+dp(52));RectF skipTop=new RectF(w-dp(150),0,w,dp(58));
            if(skipTop.contains(x,y)){finishVisualTour(true);return true;}
            if(next.contains(x,y)){if(step>=7)finishVisualTour(true);else{visualTourStep++;renderVisualTourStep();}return true;}
            if(step>0&&back.contains(x,y)){visualTourStep--;renderVisualTourStep();return true;}
            if(target.contains(x,y)){if(step>=7)finishVisualTour(true);else{visualTourStep++;renderVisualTourStep();}return true;}
            return true;
        }
    }

    private boolean isGuideQuestion(String q){
        String x=q==null?"":q.toLowerCase(Locale.ROOT);
        return finbiHas(x,"nasıl kullan","nasil kullan","kullanım kılavuzu","kullanim kilavuzu","rehber","bütçe nasıl","butce nasil","hesap nasıl","hesap nasil","kart nasıl","kart nasil","abonelik nasıl","abonelik nasil","what can i do","how do i use","user guide","guide","how to use","how can i use","comment utiliser","benutzerhandbuch","利用ガイド","使用指南","دليل الاستخدام","guía de uso","guida all’uso");
    }

    private String finbiGuideAnswer(String q){
        String x=q==null?"":q.toLowerCase(Locale.ROOT);
        if(finbiHas(x,"bütçe nasıl","butce nasil","budget","presupuesto","budget")) return guideText("budget").replace("|","\n\n");
        if(finbiHas(x,"hesap nasıl","hesap nasil","account","accounts","compte","konto","口座","账户","حساب")) return guideText("accounts").replace("|","\n\n");
        if(finbiHas(x,"kart nasıl","kart nasil","credit card","card","carte","kreditkarte","カード","信用卡","بطاقة")) return guideText("cards").replace("|","\n\n");
        if(finbiHas(x,"abonelik nasıl","abonelik nasil","subscription","abonnement","abo","サブスクリプション","订阅","اشتراك")) return guideText("subscriptions").replace("|","\n\n");
        if(finbiHas(x,"işlem nasıl","islem nasil","transaction","transaction","transaktion","取引","交易","معاملة")) return guideText("transactions").replace("|","\n\n");
        if(finbiHas(x,"finbi nasıl","finbi nasil","finbi","assistant","asistan")) return guideText("finbi").replace("|","\n\n");
        StringBuilder b=new StringBuilder(guideText("guide_title")).append("\n\n").append(guideText("guide_intro"));
        for(String key:new String[]{"accounts","transactions","budget","cards","subscriptions","finbi"}) b.append("\n\n• ").append(guideText(key).replace("|",": "));
        return b.toString();
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);

        // Android 13+ / 14+ / 15+ / 16: consume the platform back callback
        // directly so the Activity cannot fall through to the system task
        // navigation. Older Android versions continue through onBackPressed().
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                () -> handleFinwayBack()
            );
        }
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        loadPrefs();
        appLockEnabled=getPreferences(0).getBoolean("app_lock_enabled",false);
        biometricEnabled=getPreferences(0).getBoolean("app_lock_biometric",false);
        // When App Lock is enabled for the first time, offer biometric sign-in
        // automatically if the device has an enrolled biometric. The user can
        // still turn it off from Settings.
        if(appLockEnabled && !getPreferences(0).contains("app_lock_biometric")){
            try{
                if(biometricAvailable()){
                    biometricEnabled=true;
                    getPreferences(0).edit().putBoolean("app_lock_biometric",true).apply();
                }
            }catch(Throwable ignored){
                biometricEnabled=false;
            }
        }
        pendingUnlock=false;
        pendingDeviceReset=false;
        // Lock only on a genuinely new activity launch (including a relaunch after
        // the task was removed). Configuration/activity recreation must not re-lock
        // an already authenticated session. A new process starts with the static
        // session flag false, so it will still require authentication.
        if(b==null) appSessionUnlocked=!appLockEnabled;
        else if(!appLockEnabled) appSessionUnlocked=true;
        finbiEnabled=getPreferences(0).getBoolean("finbi_enabled",true);
        initFixedCategories(); loadAccounts(); load(); loadGoals(); loadCreditCards(); loadCardPayments(); loadReminderPrefs(); createReminderChannel(); requestNotificationPermissionIfNeeded(); scheduleAllCardReminders(); runSmartNotificationEngine();
        IntentFilter nf=new IntentFilter("com.example.butcem.NOTIFICATION_ADDED");
        if(Build.VERSION.SDK_INT>=33) registerReceiver(notificationAddedReceiver,nf,Context.RECEIVER_NOT_EXPORTED); else registerReceiver(notificationAddedReceiver,nf);
        // Keep the launch frame independent from the user's app theme. The original
        // Finway light branded splash renders first; the System/Light/Dark UI is
        // applied only after the splash animation has completely finished.
        getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.rgb(248,252,255)));
        showFinwaySplash();
    }

    @Override protected void onDestroy(){
        try{unregisterReceiver(notificationAddedReceiver);}catch(Exception ignored){}
        super.onDestroy();
    }

    void applySystemUi(){
        getWindow().setNavigationBarColor(C().nav);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    static class Colors {
        int bg, surface, surface2, text, muted, blue, blue2, green, green2, red, red2, gold, border, nav;
        Colors(boolean dark){
            if(dark){
                bg=Color.rgb(4,10,20); surface=Color.rgb(11,23,38); surface2=Color.rgb(15,31,50);
                text=Color.rgb(242,249,255); muted=Color.rgb(153,178,201); blue=Color.rgb(74,218,255); blue2=Color.rgb(19,83,112);
                green=Color.rgb(73,232,177); green2=Color.rgb(20,75,67); red=Color.rgb(255,105,125); red2=Color.rgb(72,28,42);
                gold=Color.rgb(255,211,88); border=Color.rgb(28,79,105); nav=Color.rgb(3,9,17);
            } else {
                bg=Color.rgb(241,248,253); surface=Color.rgb(250,253,255); surface2=Color.rgb(235,248,255);
                text=Color.rgb(20,42,62); muted=Color.rgb(92,119,141); blue=Color.rgb(20,181,229); blue2=Color.rgb(216,247,255);
                green=Color.rgb(28,184,143); green2=Color.rgb(221,249,242); red=Color.rgb(230,78,105); red2=Color.rgb(255,235,241);
                gold=Color.rgb(231,175,48); border=Color.rgb(190,229,241); nav=Color.WHITE;
            }
        }
    }
    Colors C(){ return new Colors(darkMode); }

    /** Finway Design System: single source of truth for UI rhythm and typography. */
    static final class FinwayDS {
        static final float TEXT_CAPTION=12f, TEXT_SECONDARY=13f, TEXT_BODY=14f, TEXT_BODY_LARGE=15f, TEXT_CARD_TITLE=16f, TEXT_SECTION=20f, TEXT_SCREEN=24f;
        static final float SPACE_XS=4f, SPACE_SM=8f, SPACE_MD=12f, SPACE_LG=16f, SPACE_XL=20f, SPACE_XXL=24f;
        static final float R_CARD=18f, R_BUTTON=16f, R_FIELD=14f, R_PILL=22f;
        static float text(float requested){ if(requested<=11f)return TEXT_CAPTION; if(requested<=13f)return TEXT_SECONDARY; if(requested<=15f)return TEXT_BODY_LARGE; if(requested<=17f)return TEXT_CARD_TITLE; if(requested<=21f)return TEXT_SECTION; return TEXT_SCREEN; }
        static int grid(float v){ return Math.round(v/4f)*4; }
    }

    String localizedMarketLabel(String code){
        if("TRY".equals(code))return "₺ "+s(R.string.ui_4e6ce94a03);
        if("USD".equals(code))return "$ "+s(R.string.ui_eaf03afec0);
        if("EUR".equals(code))return "€ "+s(R.string.ui_b3da56fa8d);
        if("GRAMALTIN".equals(code))return s(R.string.ui_e13744a751);
        if("GBPTRY".equals(code))return "£ "+s(R.string.ui_16abc36b89);
        if("CHFTRY".equals(code))return "CHF "+s(R.string.ui_edd79b57ac);
        if("RUBTRY".equals(code))return "₽ "+s(R.string.ui_cbda73e549);
        if("AEDTRY".equals(code))return "د.إ "+s(R.string.ui_30e9262b7e);
        if("CADTRY".equals(code))return "CA$ "+s(R.string.ui_60efecad53);
        if("AUDTRY".equals(code))return "A$ "+s(R.string.ui_fb28f9b536);
        return code;
    }

    TextView text(String s,float size,int color){TextView t=new TextView(this);float token=FinwayDS.text(size);s=legacyTranslate(s);t.setText(s);t.setTextSize(token);t.setTextColor(color);t.setTypeface(Typeface.create("sans-serif",token>=FinwayDS.TEXT_CARD_TITLE?Typeface.BOLD:Typeface.NORMAL));t.setFontFeatureSettings("kern");return t;}
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(r));return g;}
    GradientDrawable strokeBg(int fill,int stroke,float r){GradientDrawable g=bg(fill,r);g.setStroke(dp(1),stroke);return g;}
    GradientDrawable roundGradient(int start,int end,float r){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{start,end});g.setCornerRadius(dp(r));return g;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void margins(View v,int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(dp(FinwayDS.grid(l)),dp(FinwayDS.grid(t)),dp(FinwayDS.grid(r)),dp(FinwayDS.grid(b)));v.setLayoutParams(p);}

    View brandMark(){
        ImageView iv=new ImageView(this);
        // Keep the same bright Finway wordmark in both light and dark themes.
        // The source artwork has transparency, so it blends into the existing background.
        iv.setImageResource(R.drawable.finway_home_wordmark_transparent);
        iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        iv.setAdjustViewBounds(true);
        iv.setPadding(0,dp(2),0,dp(2));
        iv.setContentDescription("Finway");
        return iv;
    }

    void base(String title){
        Colors c=C();
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        if(!darkMode){
            GradientDrawable lightGradient=new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Color.rgb(231,246,246),Color.rgb(236,243,252),Color.rgb(239,248,242)});
            root.setBackground(lightGradient);
        }else{root.setBackgroundColor(c.bg);}
        root.setPadding(0,dp(6),0,0);

        LinearLayout top=row();top.setPadding(dp(20),dp(6),dp(20),dp(6));
        // The main brand is centered; the app icon is intentionally not repeated here.
        SimpleIconView aboutIcon=new SimpleIconView(this,title==null?"info":"back",c.blue);top.addView(aboutIcon,new LinearLayout.LayoutParams(dp(48),dp(52)));
        aboutIcon.setContentDescription(title==null?s(R.string.ui_6e7a9e67fa):s(R.string.ui_09223f7d2e));
        aboutIcon.setOnClickListener(v->{ if(title==null) showAbout(); else onBackPressed(); });
        Space left=new Space(this);top.addView(left,new LinearLayout.LayoutParams(0,1,1));
        View brand=brandMark();
        brand.setTranslationY(dp(2));
        top.addView(brand,new LinearLayout.LayoutParams(dp(162),dp(45)));
        Space right=new Space(this);top.addView(right,new LinearLayout.LayoutParams(0,1,1));
        FrameLayout bellWrap=new FrameLayout(this);bellWrap.setPadding(0,0,0,0);
        SimpleIconView bell=new SimpleIconView(this,"bell",c.gold);bell.setBackground(bg(darkMode?Color.rgb(17,35,52):Color.rgb(248,251,253),22));
        bellWrap.addView(bell,new FrameLayout.LayoutParams(dp(52),dp(52)));
        notificationBadge=text("",10,Color.WHITE);
        notificationBadge.setGravity(Gravity.CENTER);
        notificationBadge.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        notificationBadge.setBackground(bg(c.red,20));
        FrameLayout.LayoutParams blp=new FrameLayout.LayoutParams(dp(22),dp(22),Gravity.TOP|Gravity.END);
        blp.setMargins(0,dp(-3),dp(-3),0);
        bellWrap.addView(notificationBadge,blp);
        updateNotificationBadge();
        top.addView(bellWrap,new LinearLayout.LayoutParams(dp(52),dp(52)));bellWrap.setOnClickListener(v->showNotifications());
        root.addView(top);

        if(title!=null){TextView h=text(title,24,c.text);h.setTypeface(null,1);margins(h,24,10,24,10);root.addView(h);}
        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.setClipToPadding(false);activeScrollView=sv;content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(18),dp(4),dp(18),dp(24));sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(nav(),new LinearLayout.LayoutParams(-1,dp(82)));setContentView(root);applySystemUi();
        restoreScreenScroll();
    }

    View nav(){
        Colors c=C();LinearLayout n=row();n.setBackgroundColor(c.nav);n.setPadding(dp(8),dp(5),dp(8),dp(4));
        String[] labels={s(R.string.ui_53a4c5a8dc),s(R.string.ui_746777096c),s(R.string.ui_844419a6be),s(R.string.ui_a6cc92d718)};
        String[] icons={"home","card","savings","menu"};
        for(int i=0;i<labels.length;i++){final int k=i;boolean selected=currentPage==i;LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setGravity(Gravity.CENTER);item.setPadding(dp(3),dp(2),dp(3),dp(2));
            SimpleIconView ic=new SimpleIconView(this,icons[i],selected?c.blue:c.muted);ic.setAlpha(selected?1f:0.82f);
            LinearLayout.LayoutParams iconLp=new LinearLayout.LayoutParams(dp(40),dp(38));
            item.addView(ic,iconLp);
            TextView tx=text(labels[i],10,selected?c.blue:c.muted);tx.setGravity(Gravity.CENTER);tx.setTypeface(null,Typeface.BOLD);
            LinearLayout.LayoutParams labelLp=new LinearLayout.LayoutParams(-1,dp(18));
            if(selected){
                tx.setVisibility(View.VISIBLE);
                tx.setAlpha(1f);
                item.addView(tx,labelLp);
                item.setBackground(bg(darkMode?Color.rgb(17,48,73):Color.rgb(232,244,255),18));
            } else {
                tx.setVisibility(View.GONE);
            }
            LinearLayout.LayoutParams itemLp=new LinearLayout.LayoutParams(0,-1,1);itemLp.setMargins(dp(4),0,dp(4),0);n.addView(item,itemLp);item.setOnClickListener(v->{if(k==0)goToRootScreen(()->showHome());else if(k==1)goToRootScreen(()->showCreditCards());else if(k==2)goToRootScreen(()->showGoals());else goToRootScreen(()->showMenu());});}
        return n;
    }


    private void goToRootScreen(Runnable destination) {
        // Keep the page the user came from in history. This makes Back return to
        // the previous Finway section instead of minimizing/closing the app.
        rememberCurrentScroll();
        navigatingBack = false;
        destination.run();
    }

    class SimpleIconView extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);String type;int color;
        SimpleIconView(Context x,String t,int col){super(x);type=t;color=col;setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),cx=w/2f,cy=h/2f; p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2.4f));p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);
            if(type.equals("calendar")){c.drawRoundRect(cx-dp(10),cy-dp(9),cx+dp(10),cy+dp(10),dp(2),dp(2),p);c.drawLine(cx-dp(10),cy-dp(2),cx+dp(10),cy-dp(2),p);c.drawLine(cx-dp(5),cy-dp(12),cx-dp(5),cy-dp(6),p);c.drawLine(cx+dp(5),cy-dp(12),cx+dp(5),cy-dp(6),p);}
            else if(type.equals("info")){c.drawCircle(cx,cy,dp(10),p);c.drawLine(cx,cy-dp(1),cx,cy+dp(7),p);p.setStyle(Paint.Style.FILL);c.drawCircle(cx,cy-dp(5),dp(1.5f),p);p.setStyle(Paint.Style.STROKE);}
            else if(type.equals("bell")){Path q=new Path();q.moveTo(cx-dp(9),cy+dp(7));q.lineTo(cx+dp(9),cy+dp(7));q.moveTo(cx-dp(7),cy+dp(7));q.cubicTo(cx-dp(7),cy+dp(1),cx-dp(6),cy-dp(9),cx,cy-dp(9));q.cubicTo(cx+dp(6),cy-dp(9),cx+dp(7),cy+dp(1),cx+dp(7),cy+dp(7));c.drawPath(q,p);c.drawCircle(cx,cy+dp(10),dp(2),p);}
            else if(type.equals("home")){Path q=new Path();q.moveTo(cx-dp(10),cy-dp(1));q.lineTo(cx,cy-dp(10));q.lineTo(cx+dp(10),cy-dp(1));q.lineTo(cx+dp(10),cy+dp(10));q.lineTo(cx+dp(3),cy+dp(10));q.lineTo(cx+dp(3),cy+dp(2));q.lineTo(cx-dp(3),cy+dp(2));q.lineTo(cx-dp(3),cy+dp(10));q.lineTo(cx-dp(10),cy+dp(10));q.close();c.drawPath(q,p);}
            else if(type.equals("list")){for(int i=-1;i<=1;i++){float y=cy+i*dp(8);c.drawCircle(cx-dp(9),y,dp(1.6f),p);c.drawLine(cx-dp(3),y,cx+dp(10),y,p);}}
            else if(type.equals("stats")){for(int i=0;i<3;i++){float x=cx-dp(9)+i*dp(9);float top=cy+dp(9)-dp(8+i*5);c.drawRoundRect(x,top,x+dp(5),cy+dp(9),dp(2),dp(2),p);}}
            else if(type.equals("laptop")){c.drawRoundRect(cx-dp(10),cy-dp(8),cx+dp(10),cy+dp(6),dp(2),dp(2),p);c.drawLine(cx-dp(13),cy+dp(9),cx+dp(13),cy+dp(9),p);c.drawLine(cx-dp(5),cy+dp(6),cx+dp(5),cy+dp(6),p);}
            else if(type.equals("heart")){Path q=new Path();q.moveTo(cx,cy+dp(10));q.cubicTo(cx-dp(4),cy+dp(6),cx-dp(11),cy+dp(1),cx-dp(11),cy-dp(5));q.cubicTo(cx-dp(11),cy-dp(12),cx-dp(2),cy-dp(13),cx,cy-dp(6));q.cubicTo(cx+dp(2),cy-dp(13),cx+dp(11),cy-dp(12),cx+dp(11),cy-dp(5));q.cubicTo(cx+dp(11),cy+dp(1),cx+dp(4),cy+dp(6),cx,cy+dp(10));q.close();c.drawPath(q,p);}
            else if(type.equals("shield")){Path q=new Path();q.moveTo(cx,cy-dp(11));q.lineTo(cx+dp(9),cy-dp(7));q.lineTo(cx+dp(7),cy+dp(4));q.cubicTo(cx+dp(6),cy+dp(8),cx+dp(2),cy+dp(11),cx,cy+dp(12));q.cubicTo(cx-dp(2),cy+dp(11),cx-dp(6),cy+dp(8),cx-dp(7),cy+dp(4));q.lineTo(cx-dp(9),cy-dp(7));q.close();c.drawPath(q,p);}
            else if(type.equals("debt")){c.drawRoundRect(cx-dp(10),cy-dp(8),cx+dp(10),cy+dp(8),dp(2),dp(2),p);c.drawLine(cx-dp(6),cy, cx+dp(6),cy,p);c.drawLine(cx+dp(3),cy-dp(3),cx+dp(6),cy,p);c.drawLine(cx+dp(3),cy+dp(3),cx+dp(6),cy,p);}
            else if(type.equals("investment")){Path q=new Path();q.moveTo(cx-dp(10),cy+dp(7));q.lineTo(cx-dp(3),cy);q.lineTo(cx+dp(2),cy+dp(4));q.lineTo(cx+dp(10),cy-dp(7));c.drawPath(q,p);c.drawLine(cx+dp(5),cy-dp(7),cx+dp(10),cy-dp(7),p);c.drawLine(cx+dp(10),cy-dp(7),cx+dp(10),cy-dp(2),p);}
            else if(type.equals("target")){c.drawCircle(cx,cy,dp(9),p);c.drawCircle(cx,cy,dp(4),p);c.drawCircle(cx,cy,dp(1.5f),p);}
            else if(type.equals("savings")){c.drawCircle(cx,cy,dp(9),p);c.drawLine(cx-dp(6),cy-dp(9),cx-dp(9),cy-dp(13),p);c.drawLine(cx+dp(6),cy-dp(9),cx+dp(9),cy-dp(13),p);c.drawLine(cx-dp(9),cy+dp(1),cx+dp(9),cy+dp(1),p);c.drawCircle(cx+dp(4),cy-dp(4),dp(1.2f),p);}
            else if(type.equals("menu")){for(int i=-1;i<=1;i++)c.drawLine(cx-dp(9),cy+i*dp(7),cx+dp(9),cy+i*dp(7),p);}
            else if(type.equals("refresh")){RectF rr=new RectF(cx-dp(9),cy-dp(9),cx+dp(9),cy+dp(9));c.drawArc(rr,-50,280,false,p);Path q=new Path();q.moveTo(cx+dp(8),cy-dp(8));q.lineTo(cx+dp(11),cy-dp(2));q.lineTo(cx+dp(4),cy-dp(3));c.drawPath(q,p);}
            else if(type.equals("trend")){Path q=new Path();q.moveTo(cx-dp(10),cy+dp(7));q.lineTo(cx-dp(3),cy);q.lineTo(cx+dp(2),cy+dp(4));q.lineTo(cx+dp(10),cy-dp(7));c.drawPath(q,p);c.drawLine(cx+dp(5),cy-dp(7),cx+dp(10),cy-dp(7),p);c.drawLine(cx+dp(10),cy-dp(7),cx+dp(10),cy-dp(2),p);}
            else if(type.equals("cart")){c.drawRoundRect(cx-dp(9),cy-dp(6),cx+dp(8),cy+dp(5),dp(2),dp(2),p);c.drawLine(cx-dp(11),cy-dp(9),cx-dp(8),cy-dp(6),p);c.drawLine(cx-dp(6),cy+dp(8),cx-dp(3),cy+dp(8),p);c.drawLine(cx+dp(4),cy+dp(8),cx+dp(7),cy+dp(8),p);c.drawCircle(cx-dp(4),cy+dp(8),dp(2),p);c.drawCircle(cx+dp(6),cy+dp(8),dp(2),p);}
            else if(type.equals("card")){c.drawRoundRect(cx-dp(11),cy-dp(7),cx+dp(11),cy+dp(7),dp(2),dp(2),p);c.drawLine(cx-dp(10),cy-dp(2),cx+dp(10),cy-dp(2),p);c.drawLine(cx-dp(7),cy+dp(3),cx-dp(2),cy+dp(3),p);}
            else if(type.equals("food")){c.drawArc(new RectF(cx-dp(8),cy-dp(5),cx+dp(8),cy+dp(10)),0,180,false,p);c.drawLine(cx-dp(8),cy+dp(3),cx+dp(8),cy+dp(3),p);c.drawLine(cx+dp(5),cy-dp(9),cx+dp(5),cy+dp(3),p);c.drawLine(cx+dp(8),cy-dp(9),cx+dp(8),cy+dp(3),p);}
            else if(type.equals("bill")){c.drawRect(cx-dp(8),cy-dp(10),cx+dp(8),cy+dp(10),p);c.drawLine(cx-dp(4),cy-dp(4),cx+dp(4),cy-dp(4),p);c.drawLine(cx-dp(4),cy, cx+dp(4),cy,p);c.drawLine(cx-dp(4),cy+dp(4),cx+dp(2),cy+dp(4),p);}
            else if(type.equals("fun")){c.drawCircle(cx,cy,dp(9),p);c.drawLine(cx-dp(5),cy+dp(4),cx+dp(5),cy+dp(4),p);c.drawCircle(cx-dp(4),cy-dp(2),dp(1),p);c.drawCircle(cx+dp(4),cy-dp(2),dp(1),p);}
            else if(type.equals("car")){Path q=new Path();q.moveTo(cx-dp(10),cy+dp(4));q.lineTo(cx-dp(7),cy-dp(4));q.lineTo(cx+dp(7),cy-dp(4));q.lineTo(cx+dp(10),cy+dp(4));q.close();c.drawPath(q,p);c.drawLine(cx-dp(10),cy+dp(4),cx+dp(10),cy+dp(4),p);c.drawCircle(cx-dp(6),cy+dp(6),dp(2),p);c.drawCircle(cx+dp(6),cy+dp(6),dp(2),p);}
            else if(type.equals("home")){Path q=new Path();q.moveTo(cx-dp(10),cy);q.lineTo(cx,cy-dp(9));q.lineTo(cx+dp(10),cy);q.lineTo(cx+dp(10),cy+dp(9));q.lineTo(cx-dp(10),cy+dp(9));q.close();c.drawPath(q,p);c.drawRect(cx-dp(3),cy+dp(3),cx+dp(3),cy+dp(9),p);}
            else if(type.equals("fingerprint")){Path q=new Path();q.moveTo(cx,cy+dp(10));q.cubicTo(cx-dp(11),cy+dp(4),cx-dp(9),cy-dp(8),cx,cy-dp(10));q.cubicTo(cx+dp(9),cy-dp(8),cx+dp(11),cy+dp(4),cx,cy+dp(10));c.drawPath(q,p);Path q2=new Path();q2.moveTo(cx-dp(5),cy+dp(8));q2.cubicTo(cx-dp(8),cy+dp(1),cx-dp(6),cy-dp(5),cx,cy-dp(6));q2.cubicTo(cx+dp(6),cy-dp(5),cx+dp(8),cy+dp(1),cx+dp(5),cy+dp(8));c.drawPath(q2,p);c.drawLine(cx,cy-dp(1),cx,cy+dp(8),p);}
            else if(type.equals("health")){Path q=new Path();q.moveTo(cx-dp(9),cy-dp(5));q.lineTo(cx-dp(3),cy-dp(5));q.lineTo(cx-dp(3),cy-dp(10));q.lineTo(cx+dp(3),cy-dp(10));q.lineTo(cx+dp(3),cy-dp(5));q.lineTo(cx+dp(9),cy-dp(5));q.lineTo(cx+dp(9),cy+dp(5));q.lineTo(cx+dp(3),cy+dp(5));q.lineTo(cx+dp(3),cy+dp(10));q.lineTo(cx-dp(3),cy+dp(10));q.lineTo(cx-dp(3),cy+dp(5));q.lineTo(cx-dp(9),cy+dp(5));q.close();c.drawPath(q,p);}
            else if(type.equals("school")){Path q=new Path();q.moveTo(cx-dp(10),cy-dp(4));q.lineTo(cx,cy-dp(10));q.lineTo(cx+dp(10),cy-dp(4));q.lineTo(cx,cy+dp(2));q.close();c.drawPath(q,p);c.drawLine(cx-dp(6),cy, cx+dp(6),cy,p);c.drawLine(cx+dp(6),cy, cx+dp(6),cy+dp(7),p);}
            else if(type.equals("shirt")){Path q=new Path();q.moveTo(cx-dp(6),cy-dp(9));q.lineTo(cx-dp(10),cy-dp(5));q.lineTo(cx-dp(7),cy+dp(1));q.lineTo(cx-dp(4),cy-dp(1));q.lineTo(cx-dp(4),cy+dp(9));q.lineTo(cx+dp(4),cy+dp(9));q.lineTo(cx+dp(4),cy-dp(1));q.lineTo(cx+dp(7),cy+dp(1));q.lineTo(cx+dp(10),cy-dp(5));q.lineTo(cx+dp(6),cy-dp(9));q.close();c.drawPath(q,p);}
            else if(type.equals("travel")){c.drawCircle(cx,cy,dp(9),p);c.drawLine(cx-dp(6),cy-dp(4),cx+dp(6),cy+dp(4),p);c.drawLine(cx+dp(6),cy-dp(4),cx-dp(6),cy+dp(4),p);c.drawLine(cx,cy-dp(9),cx,cy+dp(9),p);}
            else if(type.equals("fuel")){c.drawRect(cx-dp(8),cy-dp(9),cx+dp(3),cy+dp(9),p);c.drawLine(cx-dp(5),cy-dp(4),cx,cy-dp(4),p);c.drawLine(cx+dp(3),cy-dp(6),cx+dp(9),cy-dp(1),p);c.drawLine(cx+dp(9),cy-dp(1),cx+dp(9),cy+dp(7),p);c.drawCircle(cx+dp(7),cy+dp(8),dp(1.5f),p);}
            else if(type.equals("other")){c.drawCircle(cx,cy,dp(10),p);p.setStyle(Paint.Style.FILL);c.drawCircle(cx-dp(5),cy,dp(1.7f),p);c.drawCircle(cx,cy,dp(1.7f),p);c.drawCircle(cx+dp(5),cy,dp(1.7f),p);p.setStyle(Paint.Style.STROKE);}
            else if(type.equals("gold")){Path q=new Path();q.moveTo(cx,cy-dp(11));q.lineTo(cx+dp(10),cy-dp(2));q.lineTo(cx+dp(6),cy+dp(10));q.lineTo(cx-dp(6),cy+dp(10));q.lineTo(cx-dp(10),cy-dp(2));q.close();c.drawPath(q,p);}
            else if(type.equals("dollar")){c.drawCircle(cx,cy,dp(10),p);p.setStyle(Paint.Style.FILL);p.setTextSize(dp(13));p.setTextAlign(Paint.Align.CENTER);c.drawText("$",cx,cy+dp(5),p);p.setTextAlign(Paint.Align.LEFT);p.setStyle(Paint.Style.STROKE);}
            else if(type.equals("euro")){c.drawCircle(cx,cy,dp(10),p);p.setStyle(Paint.Style.FILL);p.setTextSize(dp(13));p.setTextAlign(Paint.Align.CENTER);c.drawText("€",cx,cy+dp(5),p);p.setTextAlign(Paint.Align.LEFT);p.setStyle(Paint.Style.STROKE);}
            else if(type.equals("currency")){c.drawCircle(cx,cy,dp(10),p);p.setStyle(Paint.Style.FILL);p.setTextSize(dp(13));p.setTextAlign(Paint.Align.CENTER);c.drawText("¤",cx,cy+dp(5),p);p.setTextAlign(Paint.Align.LEFT);p.setStyle(Paint.Style.STROKE);}
            else if(type.equals("wallet")){Path q=new Path();q.moveTo(cx-dp(9),cy-dp(5));q.lineTo(cx-dp(7),cy-dp(10));q.lineTo(cx+dp(6),cy-dp(10));q.lineTo(cx+dp(10),cy-dp(6));q.lineTo(cx+dp(10),cy+dp(8));q.quadTo(cx+dp(10),cy+dp(10),cx+dp(8),cy+dp(10));q.lineTo(cx-dp(8),cy+dp(10));q.quadTo(cx-dp(10),cy+dp(10),cx-dp(10),cy+dp(8));q.close();c.drawPath(q,p);c.drawLine(cx-dp(8),cy-dp(5),cx+dp(8),cy-dp(5),p);c.drawCircle(cx+dp(5),cy+dp(2),dp(1.5f),p);}
            else if(type.equals("arrow_left")){c.drawLine(cx+dp(7),cy,cx-dp(7),cy,p);c.drawLine(cx-dp(2),cy-dp(6),cx-dp(8),cy,p);c.drawLine(cx-dp(2),cy+dp(6),cx-dp(8),cy,p);}
            else if(type.equals("arrow")){c.drawLine(cx-dp(7),cy,cx+dp(7),cy,p);c.drawLine(cx+dp(2),cy-dp(6),cx+dp(8),cy,p);c.drawLine(cx+dp(2),cy+dp(6),cx+dp(8),cy,p);}
            p.setStyle(Paint.Style.FILL);
        }
    }

    void showCurrencyPicker(){
        Colors c=C(); Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(18),dp(16),dp(18),dp(12));outer.setBackground(bg(c.surface,24));
        LinearLayout head=row();
        TextView badge=text("¤",24,Color.WHITE);badge.setGravity(Gravity.CENTER);badge.setTypeface(null,Typeface.BOLD);badge.setBackground(bg(c.gold,22));head.addView(badge,new LinearLayout.LayoutParams(dp(50),dp(50)));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(12),0,0,0);
        TextView title=text(s(R.string.ui_baf4efda08),19,c.text);title.setTypeface(null,Typeface.BOLD);copy.addView(title);
        TextView sub=text(s(R.string.ui_a26a802a77),12,c.muted);copy.addView(sub);head.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        TextView close=text("×",30,c.muted);close.setGravity(Gravity.CENTER);close.setBackground(bg(darkMode?Color.rgb(24,48,69):Color.rgb(242,247,251),18));head.addView(close,new LinearLayout.LayoutParams(dp(44),dp(46)));outer.addView(head);
        String[] codes={"TRY","USD","EUR"};String[] labels={"₺  "+s(R.string.ui_4e6ce94a03)+" (TRY)","$  "+s(R.string.ui_eaf03afec0)+" (USD)","€  "+s(R.string.ui_b3da56fa8d)+" (EUR)"};
        for(int i=0;i<codes.length;i++){final String code=codes[i];TextView choice=text((code.equals(currencyCode)?"●  ":"○  ")+labels[i],15,code.equals(currencyCode)?c.blue:c.text);choice.setPadding(dp(12),dp(15),dp(12),dp(15));choice.setBackground(strokeBg(c.bg,c.border,14));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(52));cp.setMargins(0,dp(6),0,0);outer.addView(choice,cp);attachPressFeedback(choice);choice.setOnClickListener(v->{currencyCode=code;savePrefs();dlg.dismiss();showHome();});}
        close.setOnClickListener(v->dlg.dismiss());
        dlg.setContentView(outer);Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}dlg.show();w=dlg.getWindow();if(w!=null){WindowManager.LayoutParams lp=w.getAttributes();lp.width=Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430));lp.height=WindowManager.LayoutParams.WRAP_CONTENT;lp.dimAmount=.55f;w.setAttributes(lp);}
    }

    void showHome(){
        enterScreen("home");
        marketsVisible=false;
        currentPage=0;
        Colors c=C();
        base(null);

        // HOME REDESIGN ONLY
        // The existing calculations, navigation and data actions remain unchanged.
        // This section changes the presentation of the home screen without touching other pages.
        TextView welcome=text(s(R.string.ui_57fa172b61),13,c.muted);
        welcome.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        margins(welcome,2,2,2,3);
        content.addView(welcome);

        LinearLayout hero=new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable heroBg=new GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            darkMode
                ? new int[]{Color.rgb(17,64,91),Color.rgb(20,104,105),Color.rgb(24,55,93)}
                : new int[]{Color.rgb(17,67,117),Color.rgb(15,128,137),Color.rgb(42,82,156)}
        );
        hero.setBackground(heroBg);
        hero.setPadding(dp(19),dp(17),dp(19),dp(17));

        LinearLayout heroTop=row();
        LinearLayout heroCopy=new LinearLayout(this);heroCopy.setOrientation(LinearLayout.VERTICAL);
        TextView heroTitle=text(s(R.string.ui_30ae0060cf),13,Color.WHITE);
        heroTitle.setAlpha(.80f);heroCopy.addView(heroTitle);
        TextView heroSub=text(s(R.string.ui_2d1f11b3e6),10,Color.WHITE);
        heroSub.setAlpha(.60f);margins(heroSub,0,2,0,0);heroCopy.addView(heroSub);
        heroTop.addView(heroCopy,new LinearLayout.LayoutParams(0,-2,1));
        SimpleIconView heroChart=new SimpleIconView(this,"stats",Color.WHITE);heroChart.setAlpha(.92f);
        heroTop.addView(heroChart,new LinearLayout.LayoutParams(dp(42),dp(42)));
        hero.addView(heroTop);

        TextView balanceValue=text(money(totalBalance()),34,Color.WHITE);
        balanceValue.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        margins(balanceValue,0,7,0,12);hero.addView(balanceValue);

        LinearLayout heroStats=row();
        homeHeroStat(heroStats,s(R.string.ui_6c41c144f4),sum(true),Color.rgb(205,255,232),"↑");
        homeHeroStat(heroStats,s(R.string.ui_47e07dfbe1),sum(false),Color.rgb(255,220,220),"↓");
        homeHeroStat(heroStats,s(R.string.ui_cef3b68516),totalBalance(),Color.rgb(255,239,188),"◔");
        hero.addView(heroStats);

        LinearLayout heroBottom=row();
        TextView freedom=text(s(R.string.ui_799bd065fa),10,Color.WHITE);
        freedom.setAlpha(.68f);heroBottom.addView(freedom,new LinearLayout.LayoutParams(0,-2,1));
        Button heroPeriod=button(monthName(),Color.WHITE);heroPeriod.setAllCaps(false);heroPeriod.setTextSize(10);
        heroPeriod.setTextColor(Color.WHITE);heroPeriod.setBackground(bg(Color.argb(42,255,255,255),20));
        heroPeriod.setPadding(dp(10),0,dp(10),0);heroBottom.addView(heroPeriod,new LinearLayout.LayoutParams(dp(92),dp(34)));
        heroPeriod.setOnClickListener(v->showDatePicker());
        margins(heroBottom,0,12,0,0);hero.addView(heroBottom);
        attachPressFeedback(hero);hero.setOnClickListener(v->showStats());
        margins(hero,0,0,0,14);content.addView(hero);



        // Compact month navigation remains available, but is visually secondary.
        LinearLayout period=card(c.surface,16);period.setPadding(dp(10),dp(8),dp(10),dp(8));
        LinearLayout pr=row();
        SimpleIconView cal=new SimpleIconView(this,"calendar",c.blue);pr.addView(cal,new LinearLayout.LayoutParams(dp(36),dp(36)));attachPressFeedback(cal);cal.setOnClickListener(v->showDatePicker());
        SimpleIconView prev=new SimpleIconView(this,"arrow_left",c.muted);pr.addView(prev,new LinearLayout.LayoutParams(dp(34),dp(36)));attachPressFeedback(prev);prev.setOnClickListener(v->{viewMonth.add(Calendar.MONTH,-1);showHome();});
        TextView mt=text(monthName(),14,c.text);mt.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));mt.setGravity(Gravity.CENTER);pr.addView(mt,new LinearLayout.LayoutParams(0,dp(36),1));attachPressFeedback(mt);mt.setOnClickListener(v->showDatePicker());
        SimpleIconView next=new SimpleIconView(this,"arrow",c.muted);pr.addView(next,new LinearLayout.LayoutParams(dp(34),dp(36)));attachPressFeedback(next);next.setOnClickListener(v->{viewMonth.add(Calendar.MONTH,1);showHome();});
        Button currency=button(currencyLabel(),c.blue);currency.setAllCaps(false);currency.setTextSize(10);currency.setTextColor(c.blue);currency.setBackground(bg(c.blue2,FinwayDS.R_PILL));currency.setPadding(dp(8),0,dp(8),0);pr.addView(currency,new LinearLayout.LayoutParams(dp(68),dp(36)));currency.setOnClickListener(v->showCurrencyPicker());
        period.addView(pr);margins(period,0,0,0,14);content.addView(period);

        TextView quickTitle=text(s(R.string.ui_2609b73aed),19,c.text);quickTitle.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));margins(quickTitle,2,0,2,8);content.addView(quickTitle);
        LinearLayout actions=row();
        LinearLayout inc=modernQuickAction("＋",s(R.string.ui_732d0cf46d),trUi("Kazancını kaydet","Record income"),c.green);
        LinearLayout exp=modernQuickAction("−",s(R.string.ui_227e02a0f2),trUi("Harcamayı kaydet","Record expense"),c.red);
        LinearLayout save=modernQuickAction("◈",s(R.string.ui_749ef1856d),trUi("Birikimini takip et","Track savings"),c.blue);
        actions.addView(inc,new LinearLayout.LayoutParams(0,dp(86),1));
        LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(0,dp(86),1);ep.setMargins(dp(8),0,0,0);actions.addView(exp,ep);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(86),1);sp.setMargins(dp(8),0,0,0);actions.addView(save,sp);
        margins(actions,0,0,0,16);content.addView(actions);
        inc.setOnClickListener(v->dialog(true,null));exp.setOnClickListener(v->dialog(false,null));save.setOnClickListener(v->savingsDialog());

        // Monthly financial pulse: same calculations, cleaner dashboard presentation.
        LinearLayout pulse=card(c.surface,18);pulse.setPadding(dp(16),dp(14),dp(16),dp(14));
        LinearLayout ph=row();TextView pt=text(s(R.string.ui_6b53f4bc5f),16,c.text);pt.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));ph.addView(pt,new LinearLayout.LayoutParams(0,-2,1));
        double income=sum(true), expense=sum(false), net=income-expense;
        double ratio=income>0?Math.min(100,expense*100.0/income):0;
        TextView ratioTv=text("%"+(int)Math.round(ratio),13,ratio>90?c.red:c.blue);ratioTv.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));ph.addView(ratioTv);pulse.addView(ph);
        LinearLayout totals=row();homeMetric(totals,s(R.string.ui_6c41c144f4),money(income),c.green);homeMetric(totals,s(R.string.ui_2dcbf4a0f5),money(expense),c.red);homeMetric(totals,s(R.string.ui_9dd0ab3d89),money(net),net>=0?c.green:c.red);margins(totals,0,12,0,10);pulse.addView(totals);
        ProgressBar pulseBar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);pulseBar.setMax(100);pulseBar.setProgress((int)Math.round(ratio));pulseBar.setProgressTintList(android.content.res.ColorStateList.valueOf(ratio>90?c.red:c.blue));pulseBar.setBackgroundTintList(android.content.res.ColorStateList.valueOf(c.border));pulseBar.setPadding(0,0,0,0);pulse.addView(pulseBar,new LinearLayout.LayoutParams(-1,dp(5)));
        TextView pulseHint=text(income<=0?s(R.string.ui_ccb089d800):s(R.string.ui_expense_ratio, (int)Math.round(ratio)),11,c.muted);margins(pulseHint,0,8,0,0);pulse.addView(pulseHint);
        margins(pulse,0,0,0,14);content.addView(pulse);

        // V46: Make the new budget feature a first-class home dashboard card.
        // Existing budget calculations and navigation are unchanged; only visibility/presentation is improved.
        LinearLayout budget=homeBudgetCard(c);
        margins(budget,0,0,0,14);
        content.addView(budget);

        sectionHeader(content,s(R.string.ui_6ab857cf0f),true,()->showTransactions());
        addRecentCards(content,3);
        sectionHeader(content,s(R.string.ui_64f4695852),true,()->showStats());
        addCategorySummaryCard(content);
        addHomeMarketPreview();
    }

    LinearLayout homeBudgetCard(Colors c){
        final double budgetValue=monthlyBudget();
        final double spent=sum(false);
        final int pct=budgetPercent();
        final double remaining=Math.max(0,budgetValue-spent);

        LinearLayout card=card(c.surface,18);
        card.setPadding(dp(16),dp(14),dp(16),dp(14));

        LinearLayout header=row();
        FrameLayout iconWrap=new FrameLayout(this);
        iconWrap.setBackground(bg(darkMode?Color.rgb(20,58,75):Color.rgb(231,246,239),16));
        TextView icon=text("₺",18,c.green);
        icon.setGravity(Gravity.CENTER);
        icon.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        iconWrap.addView(icon,new FrameLayout.LayoutParams(dp(42),dp(42)));
        header.addView(iconWrap,new LinearLayout.LayoutParams(dp(42),dp(42)));

        LinearLayout copy=new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setPadding(dp(12),0,0,0);
        TextView title=text(s(R.string.ui_v46_budget_title),15,c.text);
        title.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        copy.addView(title);
        TextView subtitle=text(budgetValue<=0?s(R.string.ui_v46_budget_setup):s(R.string.ui_v46_budget_spent),11,c.muted);
        margins(subtitle,0,2,0,0);
        copy.addView(subtitle);
        header.addView(copy,new LinearLayout.LayoutParams(0,-2,1));

        TextView percent=text(budgetValue<=0?"—":"%"+pct,14,budgetValue>0&&pct>=100?c.red:(budgetValue>0&&pct>=80?Color.rgb(245,158,11):c.green));
        percent.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        percent.setGravity(Gravity.CENTER);
        header.addView(percent,new LinearLayout.LayoutParams(dp(54),dp(42)));
        card.addView(header);

        if(budgetValue>0){
            ProgressBar pb=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
            pb.setMax(100);
            pb.setProgress(pct);
            int barColor=pct>=100?c.red:(pct>=80?Color.rgb(245,158,11):c.green);
            pb.setProgressTintList(android.content.res.ColorStateList.valueOf(barColor));
            pb.setBackgroundTintList(android.content.res.ColorStateList.valueOf(c.border));
            margins(pb,0,10,0,8);
            card.addView(pb);

            LinearLayout metrics=row();
            TextView spentTv=text(s(R.string.ui_v46_budget_spent)+" "+money(spent),11,c.muted);
            metrics.addView(spentTv,new LinearLayout.LayoutParams(0,-2,1));
            TextView remTv=text(s(R.string.ui_v46_budget_remaining)+" "+money(remaining),11,pct>=100?c.red:c.muted);
            remTv.setGravity(Gravity.RIGHT);
            metrics.addView(remTv,new LinearLayout.LayoutParams(0,-2,1));
            card.addView(metrics);

            if(pct>=100){
                TextView status=text(s(R.string.ui_v46_budget_over),11,c.red);
                status.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
                margins(status,0,8,0,0);
                card.addView(status);
            }else if(pct>=80){
                TextView status=text(s(R.string.ui_v46_budget_near),11,Color.rgb(245,158,11));
                status.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
                margins(status,0,8,0,0);
                card.addView(status);
            }
        }

        TextView manage=text("›  "+s(R.string.ui_v46_budget_manage),12,c.blue);
        manage.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        manage.setGravity(Gravity.RIGHT);
        margins(manage,0,8,0,0);
        card.addView(manage);

        card.setClickable(true);
        attachPressFeedback(card);
        card.setOnClickListener(v->budgetDialog());
        return card;
    }

    void homeHeroStat(LinearLayout parent,String label,double value,int valueColor,String icon){
        LinearLayout x=new LinearLayout(this);
        x.setOrientation(LinearLayout.VERTICAL);
        x.setPadding(dp(4),0,dp(4),0);
        TextView l=text(icon+"  "+label,10,Color.WHITE);
        l.setAlpha(.76f);
        x.addView(l);
        TextView v=text(money(value),13,valueColor);
        v.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        margins(v,0,2,0,0);
        x.addView(v);
        parent.addView(x,new LinearLayout.LayoutParams(0,-2,1));
    }

    void homeMetric(LinearLayout parent,String label,String value,int color){
        LinearLayout x=new LinearLayout(this);
        x.setOrientation(LinearLayout.VERTICAL);
        TextView l=text(label,10,C().muted);
        x.addView(l);
        TextView v=text(value,14,color);
        v.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        margins(v,0,2,0,0);
        x.addView(v);
        parent.addView(x,new LinearLayout.LayoutParams(0,-2,1));
    }

    void addHomeMarketPreview(){
        Colors c=C();
        LinearLayout box=card(c.surface,18);box.setPadding(dp(14),dp(12),dp(14),dp(12));
        LinearLayout head=row();
        TextView title=text(s(R.string.ui_c89739552b),18,c.text);title.setTypeface(null,Typeface.BOLD);head.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        Button refresh=button("↻",c.blue);refresh.setTextSize(18);refresh.setPadding(0,0,0,0);refresh.setContentDescription(s(R.string.ui_4e81758724));
        head.addView(refresh,new LinearLayout.LayoutParams(dp(44),dp(40)));
        TextView see=text(s(R.string.ui_3c7d51990d),12,c.blue);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(82),dp(40));sp.setMargins(dp(6),0,0,0);head.addView(see,sp);box.addView(head);
        LinearLayout quotes=row();
        addPreviewQuote(quotes,"USDTRY","$",c.blue);addPreviewQuote(quotes,"EURTRY","€",c.green);addPreviewQuote(quotes,"GRAMALTIN","GRAM",c.gold);
        box.addView(quotes,new LinearLayout.LayoutParams(-1,dp(76)));margins(box,0,0,0,12);content.addView(box);
        see.setOnClickListener(v->showMarkets()); box.setOnClickListener(v->showMarkets());
        refresh.setOnClickListener(v->loadMarketData(null));
        if(marketQuotes.isEmpty()&&!marketLoading&&marketAutoUpdate) loadMarketData(null);
    }

    void addPreviewQuote(LinearLayout parent,String code,String symbol,int accent){
        Colors c=C();LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setGravity(Gravity.CENTER);x.setPadding(dp(3),dp(4),dp(3),dp(4));
        TextView top=text(symbol+"  "+(code.equals("USDTRY")?"USD":code.equals("EURTRY")?"EUR":"ALTIN"),11,accent);top.setTypeface(null,Typeface.BOLD);top.setGravity(Gravity.CENTER);x.addView(top);
        MarketQuote q=marketQuotes.get(code);
        if("GRAMALTIN".equals(code)){
            TextView buy=text(q!=null&&q.buy>0?s(R.string.ui_e6ad46674a)+formatMarket(q.buy):s(R.string.ui_d15060f53d),10,c.muted);buy.setGravity(Gravity.CENTER);x.addView(buy);homeGoldBuyValue=buy;
            TextView sell=text(q!=null&&q.sell>0?s(R.string.ui_50f21481fb)+formatMarket(q.sell):s(R.string.ui_73af078ea8),10,accent);sell.setGravity(Gravity.CENTER);x.addView(sell);homeGoldSellValue=sell;
        }else{
            TextView v=text(q!=null&&q.sell>0?formatMarket(q.sell):s(R.string.ui_44d9f0dc96),11,c.text);v.setTypeface(null,Typeface.BOLD);v.setGravity(Gravity.CENTER);x.addView(v);
            if("USDTRY".equals(code))homeUsdValue=v; else if("EURTRY".equals(code))homeEurValue=v;
        }
        parent.addView(x,new LinearLayout.LayoutParams(0,-1,1));
    }

    void updateHomeMarketValues(){
        if(currentPage!=0)return;
        runOnUiThread(()->{
            MarketQuote u=marketQuotes.get("USDTRY"), e=marketQuotes.get("EURTRY"), g=marketQuotes.get("GRAMALTIN");
            if(homeUsdValue!=null)homeUsdValue.setText(u!=null&&u.sell>0?formatMarket(u.sell):s(R.string.ui_44d9f0dc96));
            if(homeEurValue!=null)homeEurValue.setText(e!=null&&e.sell>0?formatMarket(e.sell):s(R.string.ui_44d9f0dc96));
            if(homeGoldBuyValue!=null)homeGoldBuyValue.setText(g!=null&&g.buy>0?s(R.string.ui_e6ad46674a)+formatMarket(g.buy):s(R.string.ui_d15060f53d));
            if(homeGoldSellValue!=null)homeGoldSellValue.setText(g!=null&&g.sell>0?s(R.string.ui_50f21481fb)+formatMarket(g.sell):s(R.string.ui_73af078ea8));
        });
    }

    String formatMarket(double v){return NumberFormat.getNumberInstance(new Locale("tr","TR")).format(v)+" ₺";}
    String formatChange(double v){String sign=v>0?"+":"";return sign+NumberFormat.getNumberInstance(new Locale("tr","TR")).format(v)+"%";}

    void showMarkets(){
        enterScreen("markets");
        marketsVisible=true; currentPage=3;base(s(R.string.ui_c89739552b));Colors c=C();
        LinearLayout marketSummary=card(c.surface,18);marketSummary.setPadding(dp(14),dp(12),dp(14),dp(12));LinearLayout msr=row();SimpleIconView msi=new SimpleIconView(this,"trend",c.blue);msr.addView(msi,new LinearLayout.LayoutParams(dp(40),dp(40)));LinearLayout msc=new LinearLayout(this);msc.setOrientation(LinearLayout.VERTICAL);msc.setPadding(dp(10),0,0,0);TextView mst=text(s(R.string.ui_56f99afa02),16,c.text);mst.setTypeface(null,Typeface.BOLD);msc.addView(mst);TextView mss=text(s(R.string.ui_d561f970c1),11,c.muted);msc.addView(mss);msr.addView(msc,new LinearLayout.LayoutParams(0,-2,1));marketSummary.addView(msr);margins(marketSummary,0,0,0,10);content.addView(marketSummary);
        LinearLayout intro=card(darkMode?Color.rgb(14,43,61):Color.rgb(235,247,255),20);intro.setPadding(dp(16),dp(14),dp(16),dp(14));
        LinearLayout ir=row();SimpleIconView trend=new SimpleIconView(this,"trend",c.blue);ir.addView(trend,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(12),0,0,0);TextView t=text(s(R.string.ui_bb75ceb15b),16,c.text);t.setTypeface(null,Typeface.BOLD);copy.addView(t);TextView st=text(s(R.string.ui_69063d199e),12,c.muted);margins(st,0,3,0,0);copy.addView(st);ir.addView(copy,new LinearLayout.LayoutParams(0,-2,1));intro.addView(ir);margins(intro,0,0,0,12);content.addView(intro);

        LinearLayout baseBox=card(c.surface,18);baseBox.setPadding(dp(14),dp(12),dp(14),dp(12));
        LinearLayout bh=row();
        LinearLayout btitle=new LinearLayout(this);btitle.setOrientation(LinearLayout.VERTICAL);
        TextView bl=text(s(R.string.ui_47451c31b1),13,c.text);bl.setTypeface(null,Typeface.BOLD);btitle.addView(bl);
        TextView bsub=text(s(R.string.ui_d1a6cdaf13),11,c.muted);margins(bsub,0,2,0,0);btitle.addView(bsub);
        bh.addView(btitle,new LinearLayout.LayoutParams(0,-2,1));
        Button changeBase=dialogButton(marketUnitLabel(marketBaseUnit),Color.WHITE,c.blue);changeBase.setTextSize(12);changeBase.setPadding(dp(14),0,dp(14),0);bh.addView(changeBase,new LinearLayout.LayoutParams(dp(112),dp(42)));baseBox.addView(bh);
        margins(baseBox,0,0,0,10);content.addView(baseBox);
        changeBase.setOnClickListener(v->showMarketBasePicker());

        LinearLayout refreshRow=row();String upd=marketQuotes.isEmpty()?s(R.string.ui_a5cb68a1ef):(marketQuotes.get("USDTRY")!=null?s(R.string.ui_last_update, marketQuotes.get("USDTRY").updated):s(R.string.ui_04a0c463c8));TextView updated=text(upd,11,c.muted);refreshRow.addView(updated,new LinearLayout.LayoutParams(0,dp(42),1));
        Button refresh=button(s(R.string.ui_41a1111ec0),c.blue);refresh.setTextSize(12);refreshRow.addView(refresh,new LinearLayout.LayoutParams(dp(110),dp(42)));refresh.setOnClickListener(v->{v.animate().scaleX(1.06f).scaleY(1.06f).alpha(0.55f).setDuration(90).withEndAction(()->v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(180).start()).start();loadMarketData(updated);});content.addView(refreshRow);

        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);margins(list,0,4,0,8);content.addView(list);
        for(String code:watchedMarketCodes) addMarketEquivalentCard(list,code,c);

        Button add=button(s(R.string.ui_9e3fdeb202),c.blue);add.setTextSize(12);margins(add,0,2,0,4);content.addView(add);add.setOnClickListener(v->showMarketCurrencyPicker());
        TextView note=text(s(R.string.ui_6dfb2e2a43),11,c.muted);note.setLineSpacing(0,1.12f);margins(note,4,10,4,12);content.addView(note);
        if(marketQuotes.isEmpty()&&!marketLoading&&marketAutoUpdate) loadMarketData(updated);
    }

    String[] marketCodes(){return new String[]{"TRY","USD","EUR","GRAMALTIN","GBPTRY","CHFTRY","RUBTRY","AEDTRY","CADTRY","AUDTRY"};}
    String[] marketLabels(){return new String[]{localizedMarketLabel("TRY"),localizedMarketLabel("USD"),localizedMarketLabel("EUR"),localizedMarketLabel("GRAMALTIN"),localizedMarketLabel("GBPTRY"),localizedMarketLabel("CHFTRY"),localizedMarketLabel("RUBTRY"),localizedMarketLabel("AEDTRY"),localizedMarketLabel("CADTRY"),localizedMarketLabel("AUDTRY")};}
    String marketCodeLabel(String code){String[] cs=marketCodes(),ls=marketLabels();for(int i=0;i<cs.length;i++)if(cs[i].equals(code))return ls[i];return code;}
    String marketUnitLabel(String u){return marketCodeLabel(u);}
    String marketQuoteKey(String unit){return "TRY".equals(unit)?"TRY":("GRAMALTIN".equals(unit)?"GRAMALTIN":(unit.endsWith("TRY")?unit:unit+"TRY"));}
    double marketTryValue(String code){MarketQuote q=marketQuotes.get(code);return q==null?0:q.sell;}
    double marketBaseTry(String unit){if("TRY".equals(unit))return 1;return marketTryValue(marketQuoteKey(unit));}
    String marketSymbol(String unit){if("TRY".equals(unit))return "₺";if("USD".equals(unit))return "$";if("EUR".equals(unit))return "€";if("GRAMALTIN".equals(unit))return "g";if("GBPTRY".equals(unit))return "£";if("CHFTRY".equals(unit))return "CHF";if("JPYTRY".equals(unit))return "¥";if("CNYTRY".equals(unit))return "¥";if("RUBTRY".equals(unit))return "₽";if("AEDTRY".equals(unit))return "د.إ";if("CADTRY".equals(unit))return "CA$";if("AUDTRY".equals(unit))return "A$";return unit.replace("TRY","");}
    String formatMarketBase(double v,String unit){if("GRAMALTIN".equals(unit))return fmtGold(v);return NumberFormat.getNumberInstance(new Locale("tr","TR")).format(v)+" "+marketSymbol(unit);}
    String marketIconType(String code){if("GRAMALTIN".equals(code))return "gold";if("EURTRY".equals(code))return "euro";if("USDTRY".equals(code))return "dollar";return "currency";}
    int marketAccent(String code,Colors c){if("EURTRY".equals(code))return c.green;if("GRAMALTIN".equals(code))return c.gold;if("USDTRY".equals(code))return c.blue;return c.blue;}
    String marketDisplayName(String code){if("USDTRY".equals(code))return s(R.string.ui_eaf03afec0);if("EURTRY".equals(code))return s(R.string.ui_b3da56fa8d);if("GRAMALTIN".equals(code))return s(R.string.ui_e13744a751);MarketQuote q=marketQuotes.get(code);return q==null?code:q.name;}

    void addMarketEquivalentCard(LinearLayout parent,String code,Colors c){
        MarketQuote q=marketQuotes.get(code); if(q==null||q.sell<=0)return;
        double baseTry=marketBaseTry(marketBaseUnit); if(baseTry<=0)return;
        double value=q.sell/baseTry;
        LinearLayout box=card(c.surface,18);box.setPadding(dp(12),dp(10),dp(10),dp(10));LinearLayout r=row();
        SimpleIconView ic=new SimpleIconView(this,marketIconType(code),marketAccent(code,c));ic.setBackground(bg(darkMode?Color.rgb(25,49,68):Color.rgb(239,247,253),20));r.addView(ic,new LinearLayout.LayoutParams(dp(46),dp(46)));
        LinearLayout mid=new LinearLayout(this);mid.setOrientation(LinearLayout.VERTICAL);mid.setPadding(dp(12),0,dp(6),0);TextView n=text(marketDisplayName(code),15,c.text);n.setTypeface(null,Typeface.BOLD);mid.addView(n);
        if("GRAMALTIN".equals(code)){
            double buyValue=q.buy/baseTry;
            TextView sub=text(s(R.string.ui_e6ad46674a)+formatMarketBase(buyValue,marketBaseUnit),11,c.muted);margins(sub,2,1,0,0);mid.addView(sub);
            TextView sub2=text(s(R.string.ui_50f21481fb)+formatMarketBase(value,marketBaseUnit),11,c.muted);mid.addView(sub2);
        }else{
            TextView sub=text(formatMarketBase(value,marketBaseUnit),12,c.muted);margins(sub,2,1,0,0);mid.addView(sub);
        }
        r.addView(mid,new LinearLayout.LayoutParams(0,-2,1));
        TextView val=text(formatMarketBase(value,marketBaseUnit),14,marketAccent(code,c));val.setTypeface(null,Typeface.BOLD);val.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);r.addView(val,new LinearLayout.LayoutParams(dp(105),dp(52)));
        box.addView(r);margins(box,0,0,0,8);parent.addView(box);
        if(isAddedMarketCurrency(code)){
            box.setOnLongClickListener(v->{showRemoveMarketCurrencyDialog(code);return true;});
        }
    }

    boolean isAddedMarketCurrency(String code){
        return !("USDTRY".equals(code)||"EURTRY".equals(code)||"GRAMALTIN".equals(code));
    }

    void showRemoveMarketCurrencyDialog(String code){
        Colors c=C();
        final Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(22),dp(20),dp(22),dp(18));root.setBackground(bg(c.surface,26));
        LinearLayout head=row();
        SimpleIconView icon=new SimpleIconView(this,"currency",c.blue);icon.setBackground(bg(darkMode?Color.rgb(25,49,68):Color.rgb(239,247,253),18));head.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(12),0,0,0);
        TextView title=text(s(R.string.ui_192f9d6120),18,c.text);title.setTypeface(null,Typeface.BOLD);copy.addView(title);
        TextView name=text(marketCodeLabel(code),12,c.muted);margins(name,2,0,0,0);copy.addView(name);head.addView(copy,new LinearLayout.LayoutParams(0,-2,1));root.addView(head);
        TextView msg=text(s(R.string.ui_c91c91fdaf),12,c.muted);msg.setLineSpacing(0,1.12f);margins(msg,0,16,0,0);root.addView(msg);
        LinearLayout actions=row();
        Button cancel=dialogButton(s(R.string.ui_9dc74649ac),c.muted,c.surface);actions.addView(cancel,new LinearLayout.LayoutParams(0,dp(48),1));
        Button remove=dialogButton(s(R.string.ui_90bfcb8918),Color.WHITE,c.red);margins(remove,10,0,0,0);actions.addView(remove,new LinearLayout.LayoutParams(0,dp(48),1));root.addView(actions);
        cancel.setOnClickListener(v->dlg.dismiss());remove.setOnClickListener(v->{watchedMarketCodes.remove(code);savePrefs();dlg.dismiss();showMarkets();});
        dlg.setContentView(root);Window w=dlg.getWindow();if(w!=null)w.setBackgroundDrawableResource(android.R.color.transparent);dlg.show();w=dlg.getWindow();if(w!=null){WindowManager.LayoutParams lp=w.getAttributes();lp.width=Math.min(getResources().getDisplayMetrics().widthPixels-dp(32),dp(420));lp.height=WindowManager.LayoutParams.WRAP_CONTENT;lp.dimAmount=.55f;w.setAttributes(lp);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}
    }

    void showMarketCurrencyPicker(){
        final String[] codes={"GBPTRY","CHFTRY","RUBTRY","AEDTRY","CADTRY","AUDTRY"};
        final String[] labels={"£ GBP","CHF "+s(R.string.ui_edd79b57ac),"₽ RUB "+s(R.string.ui_cbda73e549),"د.إ AED "+s(R.string.ui_30e9262b7e),"CA$ CAD "+s(R.string.ui_60efecad53),"A$ AUD "+s(R.string.ui_fb28f9b536)};
        ArrayList<String> avail=new ArrayList<>();for(int i=0;i<codes.length;i++)if(!watchedMarketCodes.contains(codes[i]))avail.add(codes[i]+"|"+labels[i]);
        if(avail.isEmpty()){Toast.makeText(this,s(R.string.ui_1d186ecefc),Toast.LENGTH_SHORT).show();return;}
        showMarketChoiceDialog(s(R.string.ui_42ceb99193),s(R.string.ui_d16469e404),avail,(selected)->{if(!watchedMarketCodes.contains(selected))watchedMarketCodes.add(selected);savePrefs();showMarkets();});
    }

    void showMarketBasePicker(){
        ArrayList<String> options=new ArrayList<>();for(String code:marketCodes())options.add(code+"|"+marketCodeLabel(code));
        showMarketChoiceDialog(s(R.string.ui_47451c31b1),s(R.string.ui_f1c4701b31),options,(selected)->{marketBaseUnit=selected;savePrefs();showMarkets();});
    }

    interface MarketChoiceListener { void onSelected(String code); }
    void showMarketChoiceDialog(String title,String subtitle,ArrayList<String> options,MarketChoiceListener listener){
        Colors c=C();final Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(18),dp(18),dp(14));root.setBackground(bg(c.surface,26));
        LinearLayout header=row();LinearLayout tb=new LinearLayout(this);tb.setOrientation(LinearLayout.VERTICAL);TextView h=text(title,20,c.text);h.setTypeface(null,Typeface.BOLD);tb.addView(h);TextView st=text(subtitle,12,c.muted);margins(st,2,0,0,0);tb.addView(st);header.addView(tb,new LinearLayout.LayoutParams(0,-2,1));
        TextView close=text("×",28,c.muted);close.setGravity(Gravity.CENTER);close.setBackground(bg(darkMode?Color.rgb(24,48,69):Color.rgb(242,247,251),18));header.addView(close,new LinearLayout.LayoutParams(dp(44),dp(44)));root.addView(header);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);margins(list,0,14,0,6);
        for(String item:options){String[] parts=item.split("\\|",2);String code=parts[0],label=parts.length>1?parts[1]:parts[0];LinearLayout row=marketChoiceRow(code,label,c,code.equals(marketBaseUnit));list.addView(row,new LinearLayout.LayoutParams(-1,dp(54)));attachPressFeedback(row);row.setOnClickListener(v->{dlg.dismiss();listener.onSelected(code);});}
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.addView(list);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        Button cancel=dialogButton(s(R.string.ui_989f51ec41),c.muted,c.surface);margins(cancel,0,10,0,0);root.addView(cancel,new LinearLayout.LayoutParams(-1,dp(48)));cancel.setOnClickListener(v->dlg.dismiss());close.setOnClickListener(v->dlg.dismiss());
        dlg.setContentView(root);Window w=dlg.getWindow();if(w!=null)w.setBackgroundDrawableResource(android.R.color.transparent);dlg.show();w=dlg.getWindow();if(w!=null){WindowManager.LayoutParams lp=w.getAttributes();lp.width=Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430));lp.height=Math.min(getResources().getDisplayMetrics().heightPixels-dp(80),dp(620));lp.dimAmount=.55f;w.setAttributes(lp);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}
    }

    LinearLayout marketChoiceRow(String code,String label,Colors c,boolean selected){
        LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(12),dp(6),dp(10),dp(6));r.setBackground(strokeBg(selected?c.blue2:c.bg,c.border,15));
        TextView symbol=text(marketSymbol(code),16,selected?c.blue:c.text);symbol.setGravity(Gravity.CENTER);symbol.setTypeface(null,Typeface.BOLD);r.addView(symbol,new LinearLayout.LayoutParams(dp(46),dp(40)));
        LinearLayout mid=new LinearLayout(this);mid.setOrientation(LinearLayout.VERTICAL);TextView name=text(label,14,c.text);name.setTypeface(null,Typeface.BOLD);mid.addView(name);TextView hint=text(code.equals("GRAMALTIN")?s(R.string.ui_4d0eb9936b):s(R.string.ui_54a7bacb2f),10,c.muted);margins(hint,0,1,0,0);mid.addView(hint);r.addView(mid,new LinearLayout.LayoutParams(0,-2,1));
        if(selected){TextView tick=text("✓",18,c.blue);tick.setGravity(Gravity.CENTER);r.addView(tick,new LinearLayout.LayoutParams(dp(34),dp(40)));}
        margins(r,0,0,0,6);return r;
    }

    void addMarketCard(LinearLayout parent,String code,String symbol,String name,String iconType,int accent){
        Colors c=C();LinearLayout box=card(c.surface,18);box.setPadding(dp(14),dp(12),dp(14),dp(12));LinearLayout r=row();
        SimpleIconView ic=new SimpleIconView(this,iconType,accent);ic.setBackground(bg(darkMode?Color.rgb(25,49,68):Color.rgb(239,247,253),20));r.addView(ic,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout mid=new LinearLayout(this);mid.setOrientation(LinearLayout.VERTICAL);mid.setPadding(dp(12),0,dp(8),0);TextView n=text(name,16,c.text);n.setTypeface(null,Typeface.BOLD);mid.addView(n);TextView s=text(symbol,11,c.muted);margins(s,0,2,0,0);mid.addView(s);r.addView(mid,new LinearLayout.LayoutParams(0,-2,1));
        MarketQuote q=marketQuotes.get(code);String sell=q==null?"—":formatMarket(q.sell);String buy=q==null?"—":formatMarket(q.buy);String ch=q==null?"—":formatChange(q.change);int chColor=q!=null&&q.change<0?c.red:c.green;
        LinearLayout vals=new LinearLayout(this);vals.setOrientation(LinearLayout.VERTICAL);vals.setGravity(Gravity.RIGHT);
        if("GRAMALTIN".equals(code)){
            TextView buyTv=text(s(R.string.ui_368a72a7fc)+buy,12,c.muted);buyTv.setGravity(Gravity.RIGHT);vals.addView(buyTv);
            TextView sellTv=text(s(R.string.ui_ecc07b3479)+sell,17,c.text);sellTv.setTypeface(null,Typeface.BOLD);sellTv.setGravity(Gravity.RIGHT);vals.addView(sellTv);
        }else{
            TextView rateTv=text(sell,17,c.text);rateTv.setTypeface(null,Typeface.BOLD);rateTv.setGravity(Gravity.RIGHT);vals.addView(rateTv);
        }
        TextView changeTv=text(ch,10,chColor);changeTv.setGravity(Gravity.RIGHT);vals.addView(changeTv);
        r.addView(vals,new LinearLayout.LayoutParams(dp(150),-2));box.addView(r);margins(box,0,4,0,4);parent.addView(box);
    }

    // Piyasa verisi kaynakları:
    // - Döviz: TCMB'nin resmi günlük XML dosyası. TCMB bu dosyanın otomatik
    //   olarak uygulamalarda kullanılabileceğini ve formatının sabit olduğunu belirtir.
    // - Gram altın: API üzerinden JSON. HTML kazıması kullanılmaz.
    private static final String TCMB_DAILY_RATES_URL = "https://www.tcmb.gov.tr/kurlar/today.xml";
    private static final String GOLD_API_URL = "https://api.apinoktam.erenozdemir.com.tr/public/v1/altin";
    private static final String MARKET_CACHE_PREFIX = "market_cache_";

    String fetchMarketUrl(String url,int connectTimeout,int readTimeout){
        HttpURLConnection con=null;try{
            URL u=new URL(url);con=(HttpURLConnection)u.openConnection();
            con.setRequestMethod("GET");con.setConnectTimeout(connectTimeout);con.setReadTimeout(readTimeout);
            con.setRequestProperty("Accept","application/xml,application/json,text/plain;q=0.9,*/*;q=0.8");
            con.setRequestProperty("User-Agent","Finway/45 (Android)");
            con.setRequestProperty("Accept-Encoding","identity");
            int code=con.getResponseCode();
            if(code<200||code>=300)return "__ERROR__";
            InputStream in=new BufferedInputStream(con.getInputStream());
            BufferedReader br=new BufferedReader(new InputStreamReader(in,"UTF-8"));
            StringBuilder sb=new StringBuilder();String line;
            while((line=br.readLine())!=null)sb.append(line).append('\n');
            br.close();return sb.toString();
        }catch(Exception e){return "__ERROR__";}finally{if(con!=null)con.disconnect();}
    }

    String marketNow(){
        return new SimpleDateFormat("dd.MM.yyyy HH:mm",new Locale("tr","TR")).format(new Date());
    }

    void saveMarketQuote(MarketQuote q){
        if(q==null||q.sell<=0)return;
        getPreferences(0).edit()
            .putLong(MARKET_CACHE_PREFIX+q.code+"_time",System.currentTimeMillis())
            .putFloat(MARKET_CACHE_PREFIX+q.code+"_buy",(float)q.buy)
            .putFloat(MARKET_CACHE_PREFIX+q.code+"_sell",(float)q.sell)
            .putFloat(MARKET_CACHE_PREFIX+q.code+"_change",(float)q.change)
            .apply();
    }

    boolean loadCachedMarketData(){
        android.content.SharedPreferences p=getPreferences(0);
        boolean any=false;
        String[] codes={"USDTRY","EURTRY","GBPTRY","CHFTRY","RUBTRY","AEDTRY","CADTRY","AUDTRY","GRAMALTIN"};
        for(String code:codes){
            long t=p.getLong(MARKET_CACHE_PREFIX+code+"_time",0);
            double buy=p.getFloat(MARKET_CACHE_PREFIX+code+"_buy",0);
            double sell=p.getFloat(MARKET_CACHE_PREFIX+code+"_sell",0);
            double change=p.getFloat(MARKET_CACHE_PREFIX+code+"_change",0);
            if(t<=0||sell<=0)continue;
            String name=localizedMarketLabel(code);
            marketQuotes.put(code,new MarketQuote(code,name,buy,sell,change,
                new SimpleDateFormat("dd.MM.yyyy HH:mm",new Locale("tr","TR")).format(new Date(t))));
            any=true;
        }
        return any;
    }

    String tcmbXmlValue(String block,String tag){
        if(block==null)return "";
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("<"+tag+">\\s*([^<]*)\\s*</"+tag+">",java.util.regex.Pattern.CASE_INSENSITIVE).matcher(block);
        return m.find()?m.group(1).trim():"";
    }

    boolean parseTcmbDailyRates(String xml){
        if(xml==null||xml.length()<100)return false;
        boolean any=false;
        String[] codes={"USD","EUR","GBP","CHF","RUB","AED","CAD","AUD"};
        String[] names={"USD","EUR","GBP","CHF","RUB","AED","CAD","AUD"};
        for(int i=0;i<codes.length;i++){
            String code=codes[i];
            java.util.regex.Matcher cm=java.util.regex.Pattern.compile(
                "<Currency\\b[^>]*CurrencyCode=\\\""+code+"\\\"[^>]*>(.*?)</Currency>",
                java.util.regex.Pattern.CASE_INSENSITIVE|java.util.regex.Pattern.DOTALL).matcher(xml);
            if(!cm.find())continue;
            String block=cm.group(1);
            double buy=parseApiNumber(tcmbXmlValue(block,"ForexBuying"));
            double sell=parseApiNumber(tcmbXmlValue(block,"ForexSelling"));
            double unit=parseApiNumber(tcmbXmlValue(block,"Unit"));
            if(unit<=0)unit=1;
            if(buy<=0&&sell<=0)continue;
            if(sell<=0)sell=buy;
            if(buy<=0)buy=sell;
            // TCMB bazı para birimlerini 100 birim üzerinden yayımlar (ör. JPY).
            // Bu sürümde yalnızca 1 birimlik kurlar kullanıldığı için Unit'e göre normalize ediyoruz.
            buy/=unit;sell/=unit;
            String key=code+"TRY";
            MarketQuote q=new MarketQuote(key,localizedMarketLabel(key),buy,sell,0,marketNow());
            marketQuotes.put(key,q);saveMarketQuote(q);any=true;
        }
        return any;
    }

    JSONObject findGoldObject(Object node){
        try{
            if(node instanceof JSONObject){
                JSONObject o=(JSONObject)node;
                String symbol=o.optString("sembol",o.optString("symbol","")).toUpperCase(Locale.US);
                String name=o.optString("isim",o.optString("name","")).toLowerCase(Locale.US);
                if("GRA".equals(symbol)||name.contains("gram alt"))return o;
                Iterator<String> it=o.keys();
                while(it.hasNext()){
                    Object child=o.opt(it.next());
                    JSONObject found=findGoldObject(child);
                    if(found!=null)return found;
                }
            }else if(node instanceof JSONArray){
                JSONArray a=(JSONArray)node;
                for(int i=0;i<a.length();i++){
                    JSONObject found=findGoldObject(a.opt(i));
                    if(found!=null)return found;
                }
            }
        }catch(Exception ignored){}
        return null;
    }

    boolean parseGoldApi(String json){
        try{
            JSONObject root=new JSONObject(json);
            JSONObject gold=findGoldObject(root);
            if(gold==null)return false;
            double buy=jsonNumber(gold,"alis");
            if(buy<=0)buy=jsonNumber(gold,"buy");
            double sell=jsonNumber(gold,"satis");
            if(sell<=0)sell=jsonNumber(gold,"sell");
            if(sell<=0)sell=buy;
            if(buy<=0)buy=sell;
            if(sell<=0)return false;
            double ch=jsonNumber(gold,"degisim");
            if(ch==0)ch=jsonNumber(gold,"change");
            if(ch==0)ch=jsonNumber(gold,"change_pct");
            MarketQuote q=new MarketQuote("GRAMALTIN",localizedMarketLabel("GRAMALTIN"),buy,sell,ch,marketNow());
            marketQuotes.put("GRAMALTIN",q);saveMarketQuote(q);return true;
        }catch(Exception e){return false;}
    }

    void loadMarketData(final TextView updatedView){
        if(marketLoading)return;
        marketLoading=true;
        // Ağ geçici olarak kapalıysa bile son başarılı değerleri gösterebiliriz.
        final AtomicBoolean anySuccess=new AtomicBoolean(loadCachedMarketData());
        final ExecutorService pool=Executors.newFixedThreadPool(2);
        final AtomicBoolean currencyDone=new AtomicBoolean(false), goldDone=new AtomicBoolean(false);
        Runnable finishIfReady=()->{
            if(!currencyDone.get()||!goldDone.get())return;
            pool.shutdownNow();
            runOnUiThread(()->{
                marketLoading=false;
                if(isFinishing())return;
                if(!anySuccess.get()){
                    Toast.makeText(MainActivity.this,s(R.string.ui_f0c2bfa92a),Toast.LENGTH_LONG).show();
                    return;
                }
                if(updatedView!=null){
                    MarketQuote uq=marketQuotes.get("USDTRY");
                    if(uq!=null)updatedView.setText(s(R.string.ui_last_update, uq.updated));
                }
                if(rebuildingSettings)return;
                if(marketDataCallback!=null&&currentPage==3)marketDataCallback.run();
                if(marketsVisible) showMarkets();
                else if(currentPage==0) updateHomeMarketValues();
            });
        };

        // Döviz: TCMB resmi günlük XML.
        pool.execute(()->{
            String raw=fetchMarketUrl(TCMB_DAILY_RATES_URL,10000,12000);
            boolean parsed=false;
            if(!"__ERROR__".equals(raw)){
                try{parsed=parseTcmbDailyRates(raw);}catch(Exception ignored){}
            }
            if(parsed)anySuccess.set(true);
            currencyDone.set(true);finishIfReady.run();
        });

        // Gram altın: JSON API; HTML kazıması yok.
        pool.execute(()->{
            String raw=fetchMarketUrl(GOLD_API_URL,10000,12000);
            boolean parsed=false;
            if(!"__ERROR__".equals(raw)){
                try{parsed=parseGoldApi(raw);}catch(Exception ignored){}
            }
            if(parsed)anySuccess.set(true);
            goldDone.set(true);finishIfReady.run();
        });
    }

    double parseApiNumber(String s){
        if(s==null)return 0;
        String x=s.trim();
        try{
            if(x.contains(",") && x.contains(".")){
                if(x.lastIndexOf(",")>x.lastIndexOf(".")) x=x.replace(".","").replace(",", ".");
                else x=x.replace(",", "");
            }else if(x.contains(",")){x=x.replace(",", ".");}
            return Double.parseDouble(x);
        }catch(Exception e){return 0;}
    }

    double jsonNumber(JSONObject o,String key){
        try{
            Object v=o.opt(key);
            if(v instanceof Number)return ((Number)v).doubleValue();
            if(v instanceof String)return parseApiNumber((String)v);
        }catch(Exception ignored){}
        return 0;
    }

    void parseMarketObject(JSONObject o){
        if(o==null)return;
        String code=o.optString("code",o.optString("symbol","")).toUpperCase(Locale.US);
        if(code.equals("GA")||code.equals("ALTIN"))code="GRAMALTIN";
        String name=o.optString("name",code);
        if(code.length()==0 && name.toLowerCase(Locale.US).contains("gram alt"))code="GRAMALTIN";
        if(!(code.equals("USD")||code.equals("USDTRY")||code.equals("EUR")||code.equals("EURTRY")||code.equals("GRAMALTIN")||code.equals("GBP")||code.equals("CHF")||code.equals("JPY")||code.equals("CNY")||code.equals("RUB")||code.equals("AED")||code.equals("CAD")||code.equals("AUD")))return;
        String key=code.equals("GRAMALTIN")?code:(code.endsWith("TRY")?code:code+"TRY");
        double buy=jsonNumber(o,"buy");
        if(buy<=0)buy=jsonNumber(o,"alis");
        double sell=jsonNumber(o,"sell");
        if(sell<=0)sell=jsonNumber(o,"satis");
        if(sell<=0)sell=buy;
        double ch=jsonNumber(o,"change_pct");
        if(ch==0)ch=jsonNumber(o,"change");
        if(sell<=0)return;
        marketQuotes.put(key,new MarketQuote(key,name,buy,sell,ch,""));
    }

    void parseNamedObject(JSONObject o){
        if(o==null)return;
        Iterator<String> it=o.keys();
        while(it.hasNext()){
            String k=it.next();
            try{
                JSONObject v=o.optJSONObject(k);
                if(v!=null){v.put("symbol",k);parseMarketObject(v);}
            }catch(Exception ignored){}
        }
    }

    void showFinwaySplash(){
        final FrameLayout root=new FrameLayout(this);
        // The branded launch animation is intentionally theme-independent and
        // preserves Finway's original light launch artwork. The actual app theme
        // is applied only after this animation finishes.
        GradientDrawable splashBg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(248,252,255),Color.rgb(232,249,246)});
        root.setBackground(splashBg);
        ImageView logo=new ImageView(this);
        logo.setImageResource(R.drawable.finway_splash_wordmark);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        logo.setAlpha(0f);
        logo.setScaleX(.86f);logo.setScaleY(.86f);
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,dp(300),Gravity.CENTER);
        lp.setMargins(dp(22),0,dp(22),0);root.addView(logo,lp);
        setContentView(root);
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(850).setInterpolator(new android.view.animation.DecelerateInterpolator()).withEndAction(()->{
            logo.animate().alpha(1f).setDuration(500).withEndAction(()->{
                root.animate().alpha(0f).setDuration(450).withEndAction(()->{
                // The splash itself is always brand-styled. Only now do we apply
                // the user's System/Light/Dark choice to the actual Finway UI.
                applySystemUi();
                boolean completed=getPreferences(0).getBoolean("onboarding_completed_v48",false);
                boolean languageSelected=getPreferences(0).getBoolean("onboarding_language_selected_v49",false);
                if(!completed){
                    if(languageSelected) showOnboarding(true); else showOnboardingLanguagePicker();
                } else showHome();
                if(appLockEnabled){
                    new Handler(Looper.getMainLooper()).postDelayed(()->showUnlockDialog(),180L);
                }
            }).start();
            }).start();
        }).start();
    }

    private void showOnboardingLanguagePicker(){
        final FrameLayout root=new FrameLayout(this);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(4,10,20),Color.rgb(7,22,35),Color.rgb(12,8,30)}));
        LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(22),dp(34),dp(22),dp(22));
        TextView brand=text("FINWAY",13,Color.rgb(91,225,255));brand.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));brand.setLetterSpacing(.22f);outer.addView(brand,new LinearLayout.LayoutParams(-1,dp(28)));
        TextView title=text(languagePickerText("title"),28,Color.WHITE);title.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));title.setPadding(0,dp(12),0,0);outer.addView(title,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView body=text(languagePickerText("body"),14,Color.rgb(178,201,220));body.setLineSpacing(dp(4),1f);outer.addView(body,new LinearLayout.LayoutParams(-1,dp(54)));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);LinearLayout grid=new LinearLayout(this);grid.setOrientation(LinearLayout.VERTICAL);grid.setPadding(0,dp(8),0,dp(12));
        String[][] langs={{"tr","🇹🇷","Türkçe"},{"en","🇬🇧","English"},{"de","🇩🇪","Deutsch"},{"fr","🇫🇷","Français"},{"es","🇪🇸","Español"},{"it","🇮🇹","Italiano"},{"ru","🇷🇺","Русский"},{"ja","🇯🇵","日本語"},{"zh","🇨🇳","中文"},{"ar","🇸🇦","العربية"},{"el","🇬🇷","Ελληνικά"}};
        for(String[] l:langs){
            TextView item=text(l[1]+"   "+l[2],16,Color.WHITE);item.setGravity(Gravity.CENTER_VERTICAL);item.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));item.setPadding(dp(18),0,dp(18),0);
            GradientDrawable normal=new GradientDrawable();normal.setColor(Color.argb(38,80,205,255));normal.setCornerRadius(dp(18));normal.setStroke(dp(1),Color.argb(85,91,225,255));item.setBackground(normal);
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(56));ip.setMargins(0,dp(5),0,dp(5));grid.addView(item,ip);
            item.setOnClickListener(v->{getPreferences(0).edit().putBoolean("onboarding_language_selected_v49",true).putString("lang",l[0]).apply();language=l[0];recreate();});
        }
        scroll.addView(grid,new ScrollView.LayoutParams(-1,-2));outer.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        TextView hint=text(languagePickerText("hint"),12,Color.rgb(126,157,180));hint.setGravity(Gravity.CENTER);hint.setPadding(0,dp(10),0,0);outer.addView(hint,new LinearLayout.LayoutParams(-1,dp(38)));
        root.addView(outer,new FrameLayout.LayoutParams(-1,-1));setContentView(root);
    }

    private String languagePickerText(String key){
        if("en".equals(language)){if("title".equals(key))return "Choose your language";if("body".equals(key))return "Select the language you want to use in Finway. Your visual tour will continue in this language.";return "You can change this later from Settings.";}
        if("de".equals(language)){if("title".equals(key))return "Sprache auswählen";if("body".equals(key))return "Wähle die Sprache für Finway. Die Einführung wird in dieser Sprache fortgesetzt.";return "Du kannst die Sprache später in den Einstellungen ändern.";}
        if("fr".equals(language)){if("title".equals(key))return "Choisissez votre langue";if("body".equals(key))return "Sélectionnez la langue de Finway. La visite guidée continuera dans cette langue.";return "Vous pourrez la modifier plus tard dans les réglages.";}
        if("es".equals(language)){if("title".equals(key))return "Elige tu idioma";if("body".equals(key))return "Selecciona el idioma de Finway. El recorrido continuará en este idioma.";return "Puedes cambiarlo más tarde desde Ajustes.";}
        if("it".equals(language)){if("title".equals(key))return "Scegli la lingua";if("body".equals(key))return "Seleziona la lingua di Finway. La visita guidata continuerà in questa lingua.";return "Puoi cambiarla in seguito dalle Impostazioni.";}
        if("ru".equals(language)){if("title".equals(key))return "Выберите язык";if("body".equals(key))return "Выберите язык Finway. Обучение продолжится на выбранном языке.";return "Язык можно изменить позже в настройках.";}
        if("ja".equals(language)){if("title".equals(key))return "言語を選択";if("body".equals(key))return "Finwayで使用する言語を選択してください。ガイドもこの言語で表示されます。";return "言語は後から設定で変更できます。";}
        if("zh".equals(language)){if("title".equals(key))return "选择语言";if("body".equals(key))return "选择 Finway 的使用语言，接下来的引导也会使用该语言。";return "之后可以在设置中更改语言。";}
        if("ar".equals(language)){if("title".equals(key))return "اختر لغتك";if("body".equals(key))return "اختر اللغة التي تريد استخدامها في Finway. سيستمر الدليل بهذه اللغة.";return "يمكنك تغيير اللغة لاحقًا من الإعدادات.";}
        if("el".equals(language)){if("title".equals(key))return "Επίλεξε γλώσσα";if("body".equals(key))return "Επίλεξε τη γλώσσα του Finway. Η ξενάγηση θα συνεχιστεί σε αυτή τη γλώσσα.";return "Μπορείς να την αλλάξεις αργότερα από τις Ρυθμίσεις.";}
        if("title".equals(key))return "Dilini seç";if("body".equals(key))return "Finway'de kullanmak istediğin dili seç. Görsel tanıtım da seçtiğin dilde devam edecek.";return "Dili daha sonra Ayarlar bölümünden değiştirebilirsin.";
    }

    void showDatePicker(){
        final Calendar picked=(Calendar)viewMonth.clone();
        DatePickerDialog d=new DatePickerDialog(this,(view,y,m,day)->{viewMonth.set(y,m,day);showHome();},picked.get(Calendar.YEAR),picked.get(Calendar.MONTH),picked.get(Calendar.DAY_OF_MONTH));
        d.setOnShowListener(x->{int accent=C().blue;d.getButton(DatePickerDialog.BUTTON_POSITIVE).setTextColor(accent);d.getButton(DatePickerDialog.BUTTON_NEGATIVE).setTextColor(C().muted);});
        d.show();
    }

    String monthName(){Locale ml=language.equals("en")?Locale.ENGLISH:language.equals("fr")?Locale.FRENCH:language.equals("de")?Locale.GERMAN:language.equals("es")?new Locale("es","ES"):language.equals("it")?Locale.ITALIAN:language.equals("ru")?new Locale("ru","RU"):language.equals("ja")?Locale.JAPANESE:language.equals("zh")?Locale.CHINESE:language.equals("ar")?new Locale("ar","SA"):language.equals("el")?new Locale("el","GR"):new Locale("tr","TR");String s=new SimpleDateFormat("MMMM yyyy",ml).format(viewMonth.getTime());return Character.toUpperCase(s.charAt(0))+s.substring(1);}
    void budgetDialog(){
        Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(18),dp(16),dp(18),dp(12));outer.setBackground(bg(c.surface,24));
        TextView h=text(trUi("Aylık bütçe","Monthly budget"),20,c.text);h.setTypeface(null,Typeface.BOLD);outer.addView(h);
        TextView sub=text(trUi("Bu ay harcayabileceğiniz üst tutarı girin. %80 ve %100'e ulaşınca uyarı alırsınız. Bütçeyi kaldırmak için 0 girin.","Enter the most you plan to spend each month. You will be alerted at 80% and 100%. Enter 0 to remove the budget."),12,c.muted);margins(sub,0,6,0,0);outer.addView(sub);
        EditText amount=modernEdit(trUi("Bütçe tutarı","Budget amount"),c);amount.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);attachNumberFormatter(amount);margins(amount,0,12,0,10);outer.addView(amount,new LinearLayout.LayoutParams(-1,dp(54)));
        if(monthlyBudget()>0)setMoneyInput(amount,monthlyBudget());
        LinearLayout actions=row();Button cancel=dialogButton(trUi("Vazgeç","Cancel"),c.muted,c.surface);Button save=dialogButton(trUi("Kaydet","Save"),Color.WHITE,c.green);actions.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(52),1);sp.setMargins(dp(8),0,0,0);actions.addView(save,sp);margins(actions,0,8,0,0);outer.addView(actions);
        cancel.setOnClickListener(v->dlg.dismiss());
        save.setOnClickListener(v->{try{String raw=amount.getText().toString().trim();double a=raw.isEmpty()?0:parseMoneyText(raw);if(a<0||a>1e12||Double.isNaN(a))throw new Exception();SharedPreferences.Editor ed=getPreferences(0).edit();if(a<=0)ed.remove("monthlyBudget");else ed.putString("monthlyBudget",Double.toString(a));ed.apply();dlg.dismiss();showHome();}catch(Exception e){amount.setError(trUi("Geçerli bir tutar girin","Enter a valid amount"));}});
        dlg.setContentView(outer);dlg.show();Window w=dlg.getWindow();if(w!=null)w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);
    }
    int budgetPercent(){if(monthlyBudget()<=0)return 0;return Math.min(100,(int)Math.round(sum(false)*100.0/monthlyBudget()));}
    double monthlyBudget(){try{return Math.max(0,Double.parseDouble(getPreferences(0).getString("monthlyBudget","0")));}catch(Exception e){return 0;}}

    LinearLayout card(int color,float r){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setBackground(strokeBg(color,C().border,FinwayDS.R_CARD));l.setPadding(dp(FinwayDS.SPACE_LG),dp(FinwayDS.SPACE_LG),dp(FinwayDS.SPACE_LG),dp(FinwayDS.SPACE_LG));return l;}
    void miniStat(LinearLayout p,String label,double v,int color,String icon){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(dp(4),0,dp(4),0);TextView a=text(icon+"  "+label,12,C().muted);TextView b=text(money(v),16,color);b.setTypeface(null,1);x.addView(a);x.addView(b);p.addView(x,new LinearLayout.LayoutParams(0,-2,1));}
    Button actionButton(String icon,String label,int accent,int fill){Button b=new Button(this);b.setAllCaps(false);b.setText(icon+"  "+legacyTranslate(label));b.setTextSize(FinwayDS.TEXT_CARD_TITLE);b.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));b.setTextColor(accent);b.setMinHeight(0);b.setMinimumHeight(0);b.setBackground(strokeBg(darkMode?Color.rgb(20,43,62):Color.WHITE,C().border,FinwayDS.R_BUTTON));b.setPadding(dp(FinwayDS.SPACE_SM),0,dp(FinwayDS.SPACE_SM),0);attachPressFeedback(b);return b;}
    LinearLayout modernQuickAction(String icon,String titleText,String subText,int accent){
        Colors c=C();
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setPadding(dp(8),dp(8),dp(8),dp(7));
        card.setBackground(strokeBg(darkMode?Color.rgb(20,43,62):Color.WHITE,c.border,18));
        TextView badge=text(icon,20,Color.WHITE);
        badge.setGravity(Gravity.CENTER);
        badge.setTypeface(null,Typeface.BOLD);
        badge.setBackground(bg(accent,18));
        card.addView(badge,new LinearLayout.LayoutParams(dp(34),dp(34)));
        TextView title=text(titleText,13,accent);
        title.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        title.setGravity(Gravity.CENTER);
        title.setMaxLines(2);
        margins(title,0,5,0,0);
        card.addView(title);
        TextView sub=text(subText,9,c.muted);
        sub.setGravity(Gravity.CENTER);
        sub.setMaxLines(1);
        sub.setEllipsize(android.text.TextUtils.TruncateAt.END);
        card.addView(sub);
        attachPressFeedback(card);
        return card;
    }

    void sectionHeader(LinearLayout target,String title,boolean see,final Runnable r){LinearLayout h=row();TextView t=text(title,20,C().text);t.setTypeface(null,1);h.addView(t,new LinearLayout.LayoutParams(0,-2,1));if(see){TextView s=text(s(R.string.ui_3c7d51990d),12,C().blue);h.addView(s);h.setOnClickListener(v->r.run());}margins(h,2,4,2,8);target.addView(h);}

    void addRecentCards(LinearLayout target,int limit){
        ArrayList<Tx> list=new ArrayList<>();String ym=new SimpleDateFormat("MM.yyyy",Locale.US).format(viewMonth.getTime());for(Tx t:txs)if(!t.cancelled&&!t.isIncome&&t.date.endsWith(ym))list.add(t);Collections.sort(list,(a,b)->Long.compare(b.id,a.id));
        if(list.isEmpty()){LinearLayout empty=card(C().surface,16);empty.setPadding(dp(16),dp(16),dp(16),dp(16));TextView a=text(s(R.string.ui_1d9954dd16),14,C().text);a.setTypeface(null,1);empty.addView(a);TextView b=text(s(R.string.ui_1b6e53f78f),12,C().muted);margins(b,0,4,0,0);empty.addView(b);margins(empty,0,0,0,14);target.addView(empty);return;}
        LinearLayout r=row();for(int i=0;i<Math.min(limit,list.size());i++){Tx t=list.get(i);LinearLayout box=card(C().surface,15);box.setPadding(dp(10),dp(10),dp(10),dp(8));LinearLayout top=row();if(t.isIncome){TextView ic=text("↑",22,C().green);ic.setGravity(Gravity.CENTER);top.addView(ic,new LinearLayout.LayoutParams(dp(34),dp(34)));}else{SimpleIconView ic=new SimpleIconView(this,iconFor(t.cat),C().blue);top.addView(ic,new LinearLayout.LayoutParams(dp(34),dp(34)));}box.addView(top);TextView d=text(t.desc.length()>0?t.desc:s(R.string.ui_5e6806f6e3),12,C().text);d.setTypeface(null,1);d.setGravity(Gravity.CENTER);d.setMaxLines(1);d.setEllipsize(android.text.TextUtils.TruncateAt.END);margins(d,0,4,0,0);box.addView(d);TextView a=text("-"+money(t.amount),12,C().red);a.setTypeface(null,1);a.setGravity(Gravity.CENTER);box.addView(a);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(132),1);if(i>0)p.setMargins(dp(6),0,0,0);r.addView(box,p);}margins(r,0,0,0,12);target.addView(r);
    }

    View insightCard(){Colors c=C();LinearLayout box=card(darkMode?Color.rgb(15,50,48):Color.rgb(235,251,245),16);box.setPadding(dp(16),dp(12),dp(16),dp(12));LinearLayout r=row();TextView ic=text("▮▮▮",22,c.green);r.addView(ic,new LinearLayout.LayoutParams(dp(54),dp(42)));TextView t=text(s(R.string.ui_513a52722f),13,c.text);r.addView(t,new LinearLayout.LayoutParams(0,-2,1));box.addView(r);margins(box,0,0,0,12);return box;}

    void addCategorySummaryCard(LinearLayout target){
        Colors c=C();
        LinearLayout box=card(c.surface,20);
        box.setPadding(dp(16),dp(16),dp(16),dp(16));

        TextView hint=text(s(R.string.ui_c76421d430),11,c.muted);
        margins(hint,2,0,2,10);box.addView(hint);

        LinearLayout chartRow=row();
        FrameLayout chartWrap=new FrameLayout(this);
        chartWrap.setBackground(bg(darkMode?Color.rgb(20,45,62):Color.rgb(246,250,253),80));
        DonutView donut=new DonutView(this);
        FrameLayout.LayoutParams dlp=new FrameLayout.LayoutParams(dp(148),dp(148),Gravity.CENTER);
        chartWrap.addView(donut,dlp);
        LinearLayout.LayoutParams cwp=new LinearLayout.LayoutParams(dp(158),dp(158));
        chartRow.addView(chartWrap,cwp);

        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(dp(14),0,0,0);
        double total=0;for(Category cat:categories)total+=catSum(cat.name);
        int[] cols={c.blue,c.green,c.gold,Color.rgb(151,104,219),Color.rgb(255,140,86)};
        int idx=0;
        for(Category cat:categories){
            double s=catSum(cat.name);if(s<=0)continue;
            LinearLayout item=row();item.setGravity(Gravity.CENTER_VERTICAL);
            TextView dot=text("●",13,cols[idx%cols.length]);dot.setGravity(Gravity.CENTER);item.addView(dot,new LinearLayout.LayoutParams(dp(20),dp(26)));
            LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);
            TextView name=text(categoryLabel(cat.name),12,c.text);name.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));copy.addView(name);
            double pct=total<=0?0:s*100.0/total;
            TextView value=text(money(s)+"  •  "+String.format(Locale.US,"%.0f%%",pct),10,c.muted);margins(value,0,1,0,0);copy.addView(value);
            item.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
            margins(item,0,1,0,3);list.addView(item);idx++;
        }
        if(list.getChildCount()==0){TextView empty=text(s(R.string.ui_59ee57dabb),12,c.muted);list.addView(empty);}
        chartRow.addView(list,new LinearLayout.LayoutParams(0,-2,1));
        box.addView(chartRow);
        margins(box,0,0,0,18);target.addView(box);
    }

    class DonutView extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        DonutView(Context x){super(x);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        protected void onDraw(Canvas cv){
            super.onDraw(cv);float cx=getWidth()/2f,cy=getHeight()/2f;float rad=Math.min(getWidth(),getHeight())/2f-dp(13);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(17));p.setStrokeCap(Paint.Cap.BUTT);
            int[] cols={C().blue,C().green,C().gold,Color.rgb(151,104,219),Color.rgb(255,140,86)};
            double total=0;for(Category cat:categories)total+=catSum(cat.name);
            if(total<=0){p.setColor(C().border);cv.drawCircle(cx,cy,rad,p);}
            else{float start=-90;int idx=0;for(Category cat:categories){double s=catSum(cat.name);if(s<=0)continue;p.setColor(cols[idx%cols.length]);float sweep=(float)(s/total*360);cv.drawArc(cx-rad,cy-rad,cx+rad,cy+rad,start,sweep,false,p);start+=sweep;idx++;}}
            p.setStyle(Paint.Style.FILL);p.setColor(C().text);p.setTextSize(dp(12));p.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));p.setTextAlign(Paint.Align.CENTER);cv.drawText(money(total),cx,cy+dp(4),p);
            p.setColor(C().muted);p.setTextSize(dp(8));cv.drawText(s(R.string.ui_fe236856dd),cx,cy+dp(17),p);
        }
    }

    String iconFor(String c){for(Category cat:categories)if(cat.name.equals(c))return cat.icon;return "•";}

    void showTransactions(){
        enterScreen("transactions");
        marketsVisible=false;
        currentPage = 3;
        base(s(R.string.ui_5115cef58b));
        Colors c=C();

        // Üst özet: işlemler ekranını daha profesyonel ve taranabilir hale getirir.
        double income=sum(true), expense=sum(false);
        LinearLayout summary=card(c.surface,20);
        summary.setPadding(dp(16),dp(15),dp(16),dp(15));
        LinearLayout summaryHead=row();
        LinearLayout copy=new LinearLayout(this); copy.setOrientation(LinearLayout.VERTICAL);
        TextView st=text(s(R.string.ui_c2c0d3442c),13,c.muted);
        TextView net=text(money(income-expense),24,(income-expense)>=0?c.green:c.red);
        net.setTypeface(null,Typeface.BOLD);
        margins(net,0,2,0,0); copy.addView(st); copy.addView(net);
        summaryHead.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        int visibleCount=0; for(Tx tx:txs) if(!tx.archived) visibleCount++;
        TextView count=text(String.valueOf(visibleCount),22,c.blue); count.setTypeface(null,Typeface.BOLD); count.setGravity(Gravity.CENTER);
        TextView countLabel=text(s(R.string.ui_2965ea265b),10,c.muted); countLabel.setGravity(Gravity.CENTER);
        LinearLayout countBox=new LinearLayout(this); countBox.setOrientation(LinearLayout.VERTICAL); countBox.setGravity(Gravity.CENTER);
        countBox.setPadding(dp(12),dp(7),dp(12),dp(7)); countBox.setBackground(bg(darkMode?Color.rgb(24,49,70):Color.rgb(237,246,255),16));
        countBox.addView(count); countBox.addView(countLabel);
        summaryHead.addView(countBox,new LinearLayout.LayoutParams(dp(76),dp(62)));
        summary.addView(summaryHead);
        LinearLayout totals=row();
        TextView inc=text("↑  "+money(income),12,c.green); inc.setTypeface(null,Typeface.BOLD);
        TextView out=text("↓  "+money(expense),12,c.red); out.setTypeface(null,Typeface.BOLD);
        totals.addView(inc,new LinearLayout.LayoutParams(0,dp(28),1)); totals.addView(out,new LinearLayout.LayoutParams(0,dp(28),1));
        margins(totals,0,7,0,0); summary.addView(totals); margins(summary,0,0,0,14); content.addView(summary);

        TextView note=text(s(R.string.ui_5bbbc4f277),11,c.muted);
        note.setLineSpacing(0,1.12f); margins(note,0,0,0,10); content.addView(note);

        LinearLayout filterBar=row();
        EditText search=modernEdit(trUi("İşlem ara...","Search transactions..."),c);
        search.setSingleLine(true); search.setTextSize(14);
        filterBar.addView(search,new LinearLayout.LayoutParams(0,dp(50),1));
        Button filterBtn=button(trUi("Filtre","Filter"),c.blue); filterBtn.setTextSize(12);
        LinearLayout.LayoutParams fbp=new LinearLayout.LayoutParams(dp(88),dp(50)); fbp.setMargins(dp(8),0,0,0); filterBar.addView(filterBtn,fbp);
        margins(filterBar,0,0,0,10); content.addView(filterBar);
        final String[] typeFilter={"all"}; final String[] catFilter={"all"};
        LinearLayout listHost=new LinearLayout(this); listHost.setOrientation(LinearLayout.VERTICAL); content.addView(listHost);
        Runnable renderFiltered=()->{ listHost.removeAllViews(); ArrayList<Tx> list=new ArrayList<>(); String q=search.getText().toString().trim().toLowerCase(Locale.ROOT); for(Tx t:txs){ if(t.archived)continue; if(!"all".equals(typeFilter[0]) && (("income".equals(typeFilter[0]))!=t.isIncome))continue; if(!"all".equals(catFilter[0]) && !catFilter[0].equals(t.cat))continue; if(q.length()>0 && !(t.desc+" "+t.cat+" "+t.account+" "+t.date).toLowerCase(Locale.ROOT).contains(q))continue; list.add(t);} Collections.sort(list,(a,b)->Long.compare(b.id,a.id)); if(list.isEmpty()) listHost.addView(emptyText(trUi("Filtreye uyan işlem yok","No matching transactions"))); else { TextView sec=text(s(R.string.ui_aa816f12f3),18,c.text); sec.setTypeface(null,Typeface.BOLD); margins(sec,0,2,0,8); listHost.addView(sec); for(Tx t:list){ TextView accountTag=text((t.account==null||t.account.isEmpty()?"Genel":t.account),10,c.muted); LinearLayout wrap=new LinearLayout(this); wrap.setOrientation(LinearLayout.VERTICAL); wrap.addView(txRow(t)); listHost.addView(wrap); } } };
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){renderFiltered.run();}public void afterTextChanged(Editable e){}});
        filterBtn.setOnClickListener(v->showTransactionFilterDialog(typeFilter,catFilter,renderFiltered));
        renderFiltered.run();
        // Yeni işlem butonu özellikle listenin altında tutuluyor.
        LinearLayout addCard=card(darkMode?Color.rgb(16,47,70):Color.rgb(239,247,255),18);
        addCard.setPadding(dp(14),dp(12),dp(14),dp(12));
        LinearLayout ar=row();
        SimpleIconView plus=new SimpleIconView(this,"arrow",c.blue); ar.addView(plus,new LinearLayout.LayoutParams(dp(38),dp(38)));
        LinearLayout ac=new LinearLayout(this); ac.setOrientation(LinearLayout.VERTICAL); ac.setPadding(dp(10),0,dp(8),0);
        TextView at=text(s(R.string.ui_56f0e02301),15,c.blue); at.setTypeface(null,Typeface.BOLD);
        TextView as=text(s(R.string.ui_7d9982b054),11,c.muted); margins(as,0,2,0,0);
        ac.addView(at); ac.addView(as); ar.addView(ac,new LinearLayout.LayoutParams(0,-2,1));
        TextView aa=text("＋",28,c.blue); aa.setGravity(Gravity.CENTER); ar.addView(aa,new LinearLayout.LayoutParams(dp(38),dp(38)));
        addCard.addView(ar); margins(addCard,0,14,0,4); content.addView(addCard);
        addCard.setOnClickListener(v->chooseType()); attachPressFeedback(addCard);
    }
    TextView emptyText(String s){TextView e=text(s,14,C().muted);e.setGravity(Gravity.CENTER);margins(e,4,20,4,4);return e;}
    void chooseType(){
        Colors c=C();
        Dialog dlg=new Dialog(this);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20),dp(18),dp(20),dp(18));
        root.setBackground(bg(c.surface,26));

        LinearLayout header=row();
        LinearLayout titleBox=new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        TextView title=text(s(R.string.ui_4f8e7a2510),22,c.text);
        title.setTypeface(null,1);
        titleBox.addView(title);
        TextView sub=text(s(R.string.ui_2d9219ec07),12,c.muted);
        margins(sub,0,3,0,0);
        titleBox.addView(sub);
        header.addView(titleBox,new LinearLayout.LayoutParams(0,-2,1));

        TextView close=text("×",30,c.muted);
        close.setGravity(Gravity.CENTER);
        close.setBackground(bg(darkMode?Color.rgb(24,48,69):Color.rgb(242,247,251),18));
        header.addView(close,new LinearLayout.LayoutParams(dp(46),dp(46)));
        root.addView(header);

        LinearLayout choices=new LinearLayout(this);
        choices.setOrientation(LinearLayout.VERTICAL);
        margins(choices,0,18,0,8);

        LinearLayout income=choiceCard("+$",s(R.string.ui_732d0cf46d),s(R.string.ui_58c052ae86),c.green);
        LinearLayout expense=choiceCard("-$",s(R.string.ui_227e02a0f2),s(R.string.ui_75a479f0b8),c.red);
        choices.addView(income,new LinearLayout.LayoutParams(-1,dp(92)));
        LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,dp(92));ep.setMargins(0,dp(10),0,0);choices.addView(expense,ep);
        root.addView(choices);

        TextView tip=text(s(R.string.ui_3da2c1edfe),11,c.muted);
        tip.setLineSpacing(0,1.1f);
        margins(tip,4,4,4,12);
        root.addView(tip);

        Button cancel=dialogButton(s(R.string.ui_989f51ec41),c.muted,c.surface);
        cancel.setOnClickListener(v->dlg.dismiss());
        root.addView(cancel,new LinearLayout.LayoutParams(-1,dp(50)));

        income.setOnClickListener(v->{dlg.dismiss();dialog(true,null);});
        expense.setOnClickListener(v->{dlg.dismiss();dialog(false,null);});
        close.setOnClickListener(v->dlg.dismiss());

        dlg.setContentView(root);
        Window w=dlg.getWindow();
        if(w!=null){
            w.setBackgroundDrawableResource(android.R.color.transparent);
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams lp=w.getAttributes();
            lp.width=Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430));
            lp.height=WindowManager.LayoutParams.WRAP_CONTENT;
            lp.dimAmount=0.55f;
            w.setAttributes(lp);
        }
        dlg.show();
        w=dlg.getWindow();
        if(w!=null){
            WindowManager.LayoutParams lp=w.getAttributes();
            lp.width=Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430));
            lp.height=WindowManager.LayoutParams.WRAP_CONTENT;
            w.setAttributes(lp);
        }
    }

    LinearLayout choiceCard(String icon,String titleText,String subText,int accent){
        Colors c=C();
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(12),dp(10),dp(12),dp(10));
        card.setBackground(strokeBg(c.surface2,c.border,18));

        TextView badge=text(icon,21,Color.WHITE);
        badge.setGravity(Gravity.CENTER);
        badge.setTypeface(null,1);
        badge.setBackground(bg(accent,22));
        card.addView(badge,new LinearLayout.LayoutParams(dp(58),dp(58)));

        LinearLayout copy=new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setPadding(dp(13),0,dp(8),0);
        TextView t=text(titleText,17,accent);t.setTypeface(null,1);copy.addView(t);
        TextView s=text(subText,11,c.muted);s.setMaxLines(2);margins(s,0,3,0,0);copy.addView(s);
        card.addView(copy,new LinearLayout.LayoutParams(0,-2,1));

        TextView arrow=text("›",30,accent);arrow.setGravity(Gravity.CENTER);
        card.addView(arrow,new LinearLayout.LayoutParams(dp(28),dp(54)));
        return card;
    }

    View txRow(final Tx t){
        Colors c=C();
        LinearLayout r=row();
        r.setPadding(dp(12),dp(10),dp(8),dp(10));
        r.setBackground(strokeBg(c.surface,c.border,15));
        if(t.isIncome){
            TextView icon=text("↑",22,c.green);icon.setGravity(Gravity.CENTER);
            r.addView(icon,new LinearLayout.LayoutParams(dp(44),dp(44)));
        }else{
            SimpleIconView icon=new SimpleIconView(this,iconFor(t.cat),c.blue);
            icon.setContentDescription(categoryLabel(t.cat));
            r.addView(icon,new LinearLayout.LayoutParams(dp(44),dp(44)));
        }
        LinearLayout mid=new LinearLayout(this);mid.setOrientation(LinearLayout.VERTICAL);
        String rowTitle=(t.isIncome && ("Harcama".equalsIgnoreCase(t.desc.trim()) || t.desc.trim().isEmpty()))?trUi("Gelir","Income"):(t.desc.length()>0?t.desc:s(R.string.ui_5e6806f6e3));
        TextView d=text(rowTitle,14,t.cancelled?c.muted:c.text);
        d.setTypeface(null,1);d.setMaxLines(1);d.setEllipsize(android.text.TextUtils.TruncateAt.END);
        TextView sub=text("•  "+t.date+(t.cancelled?"  •  "+s(R.string.ui_117a549663):""),11,t.cancelled?c.red:c.muted);
        sub.setMaxLines(1);sub.setEllipsize(android.text.TextUtils.TruncateAt.END);
        mid.addView(d);mid.addView(sub);
        r.addView(mid,new LinearLayout.LayoutParams(0,-2,1));
        TextView a=text((t.isIncome?"+ ":"- ")+money(t.amount),14,t.cancelled?c.muted:(t.isIncome?c.green:c.red));
        a.setTypeface(null,1);a.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        r.addView(a,new LinearLayout.LayoutParams(dp(82),dp(44)));

        if(!t.cancelled){
            Button editBtn=button("✎",c.blue);
            editBtn.setTextSize(14);editBtn.setPadding(0,0,0,0);
            editBtn.setContentDescription(s(R.string.ui_3fe215d38e));
            r.addView(editBtn,new LinearLayout.LayoutParams(dp(32),dp(34)));
            editBtn.setOnClickListener(v->dialog(t.isIncome,t));
            r.setOnClickListener(v->dialog(t.isIncome,t));
        }else{
            // İptal edilmiş işlemler satırında ayrıca kırmızı bir buton/badge gösterilmez.
            // Durum bilgisi tarih satırındaki "İptal edildi" metninde tutulur.
        }

        margins(r,0,3,0,3);
        attachPressFeedback(r);
        r.setOnLongClickListener(v->{confirmArchive(t);return true;});
        return r;
    }
    void showStats(){
        enterScreen("stats");
        marketsVisible=false; currentPage=3; base(s(R.string.ui_ea7c2aa969)); Colors c=C(); double in=sum(true),out=sum(false),net=in-out;
        LinearLayout hero=card(darkMode?Color.rgb(18,32,45):Color.rgb(238,247,255),22);hero.setPadding(dp(18),dp(16),dp(18),dp(16));LinearLayout hr=row();SimpleIconView hv=new SimpleIconView(this,"trend",c.blue);hr.addView(hv,new LinearLayout.LayoutParams(dp(48),dp(48)));LinearLayout hc=new LinearLayout(this);hc.setOrientation(LinearLayout.VERTICAL);hc.setPadding(dp(12),0,0,0);TextView ht=text(s(R.string.ui_ad3f7716c4),19,c.text);ht.setTypeface(null,Typeface.BOLD);hc.addView(ht);TextView hs=text(s(R.string.ui_59a6c7f23c),12,c.muted);margins(hs,0,3,0,0);hc.addView(hs);hr.addView(hc,new LinearLayout.LayoutParams(0,-2,1));hero.addView(hr);margins(hero,0,0,0,12);content.addView(hero);
        LinearLayout metrics=row();LinearLayout ic=card(c.surface,16);ic.setPadding(dp(12),dp(12),dp(12),dp(12));ic.addView(text(s(R.string.ui_6c41c144f4),11,c.muted));TextView iv=text(money(in),17,c.green);iv.setTypeface(null,Typeface.BOLD);ic.addView(iv);LinearLayout ec=card(c.surface,16);ec.setPadding(dp(12),dp(12),dp(12),dp(12));ec.addView(text(s(R.string.ui_2dcbf4a0f5),11,c.muted));TextView ev=text(money(out),17,c.red);ev.setTypeface(null,Typeface.BOLD);ec.addView(ev);LinearLayout nc=card(c.surface,16);nc.setPadding(dp(12),dp(12),dp(12),dp(12));nc.addView(text(s(R.string.ui_9dd0ab3d89),11,c.muted));TextView nv=text(money(net),17,net>=0?c.green:c.red);nv.setTypeface(null,Typeface.BOLD);nc.addView(nv);metrics.addView(ic,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(0,-2,1);ep.setMargins(dp(6),0,0,0);metrics.addView(ec,ep);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,-2,1);np.setMargins(dp(6),0,0,0);metrics.addView(nc,np);margins(metrics,0,0,0,16);content.addView(metrics);
        sectionHeader(content,s(R.string.ui_1356541b4e),false,null);addCategorySummaryCard(content);sectionHeader(content,s(R.string.ui_ea1151932c),false,null);content.addView(insightCard());
    }
    void showGoals(){
        enterScreen("savings");
        marketsVisible=false;
        currentPage = 2;
        marketDataCallback = null;
        savingsMarketCallback = null;
        base(s(R.string.ui_844419a6be));
        // Requested order on the My Savings page:
        // Birikimim -> savings entries -> Hedefler -> goal actions -> goals -> Currency Calculator.
        addSavingsSection();

        TextView goalsSectionTitle=text(s(R.string.ui_f79d757d87),20,C().text);
        goalsSectionTitle.setTypeface(null,Typeface.BOLD);
        margins(goalsSectionTitle,2,4,2,8);
        content.addView(goalsSectionTitle);

        // Keep the goal action controls at the top of the Goals section. If there is more than one
        // active goal, the user can choose which goal to add money to or delete.
        if(!goals.isEmpty()) addGoalActionsTop();

        Button addGoalTop=button(s(R.string.ui_d120f74c03),C().blue);
        margins(addGoalTop,0,0,0,12);content.addView(addGoalTop);
        addGoalTop.setOnClickListener(v->goalDialog(null));

        double targetTotal=0,savedTotal=0;
        for(Goal g:goals){targetTotal+=g.target;savedTotal+=Math.min(g.saved,g.target);}
        LinearLayout summary=card(darkMode?Color.rgb(18,47,67):Color.rgb(235,246,255),20);summary.setPadding(dp(18),dp(16),dp(18),dp(16));
        LinearLayout sh=row();TextView icon=text("🎯",28,C().blue);sh.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout st=new LinearLayout(this);st.setOrientation(LinearLayout.VERTICAL);st.setPadding(dp(10),0,0,0);
        TextView title=text(s(R.string.ui_8d675e1c53),18,C().text);title.setTypeface(null,1);st.addView(title);
        TextView sub=text(goals.size()+" "+s(R.string.ui_28ed312975)+"  •  "+completedGoals.size()+" "+s(R.string.ui_da8d090aeb),12,C().muted);margins(sub,0,2,0,0);st.addView(sub);sh.addView(st,new LinearLayout.LayoutParams(0,-2,1));summary.addView(sh);
        TextView totals=text(money(savedTotal)+" / "+money(targetTotal),24,C().blue);totals.setTypeface(null,1);margins(totals,0,12,0,6);summary.addView(totals);
        int pct=targetTotal<=0?0:(int)Math.round(savedTotal*100/targetTotal);TextView pctText=text("%"+pct+"  "+s(R.string.ui_da8d090aeb),12,C().muted);summary.addView(pctText);addProgressBar(summary,pct,C().blue);margins(summary,0,0,0,12);content.addView(summary);

        if(goals.isEmpty() && completedGoals.isEmpty()){
            LinearLayout empty=card(C().surface,18);empty.setPadding(dp(18),dp(20),dp(18),dp(20));
            TextView eh=text(s(R.string.ui_c451c37ad5),17,C().text);eh.setTypeface(null,1);empty.addView(eh);
            TextView es=text(s(R.string.ui_5bd0f7b468),13,C().muted);margins(es,0,5,0,0);empty.addView(es);margins(empty,0,0,0,14);content.addView(empty);
        } else {
            if(!goals.isEmpty()){
                TextView activeTitle=text(s(R.string.ui_d2722fa039),20,C().text);activeTitle.setTypeface(null,1);margins(activeTitle,2,4,2,8);content.addView(activeTitle);
                for(Goal g:goals) addGoalCard(g);
            }
            if(!completedGoals.isEmpty()){
                TextView doneTitle=text(s(R.string.ui_557d2845b7),20,C().text);doneTitle.setTypeface(null,1);margins(doneTitle,2,12,2,8);content.addView(doneTitle);
                for(Goal g:completedGoals) addCompletedGoalCard(g);
            }
        }

        // Final order: Birikimim -> savings entries -> Hedefler -> goal actions/goals -> Currency Calculator.
        addCurrencyCalculator();
    }

    void addGoalActionsTop(){
        final Colors c=C();
        final LinearLayout box=card(darkMode?Color.rgb(24,48,69):Color.rgb(242,247,251),18);
        box.setPadding(dp(14),dp(12),dp(14),dp(12));
        LinearLayout head=row();
        SimpleIconView icon=new SimpleIconView(this,"target",c.blue);
        icon.setBackground(bg(darkMode?Color.rgb(30,66,91):Color.rgb(229,242,255),18));
        head.addView(icon,new LinearLayout.LayoutParams(dp(44),dp(44)));
        LinearLayout titles=new LinearLayout(this);titles.setOrientation(LinearLayout.VERTICAL);titles.setPadding(dp(10),0,0,0);
        TextView h=text(s(R.string.ui_e71f67ca9f),15,c.text);h.setTypeface(null,Typeface.BOLD);titles.addView(h);
        TextView sub=text(s(R.string.ui_76e893672f),10,c.muted);margins(sub,0,2,0,0);titles.addView(sub);
        head.addView(titles,new LinearLayout.LayoutParams(0,-2,1));box.addView(head);

        final int[] selectedGoalIndex={goals.isEmpty()? -1 : 0};
        LinearLayout selector=card(c.surface,16);
        selector.setPadding(dp(14),dp(10),dp(12),dp(10));
        LinearLayout selectorRow=row();
        SimpleIconView selectorIcon=new SimpleIconView(this,isGoalSimpleIcon(goals.isEmpty()?"target":goals.get(0).icon)?(goals.isEmpty()?"target":goals.get(0).icon):"target",c.blue);
        selectorIcon.setBackground(bg(darkMode?Color.rgb(30,66,91):Color.rgb(229,242,255),14));
        selectorRow.addView(selectorIcon,new LinearLayout.LayoutParams(dp(42),dp(42)));
        LinearLayout selectorText=new LinearLayout(this);selectorText.setOrientation(LinearLayout.VERTICAL);selectorText.setPadding(dp(10),0,0,0);
        TextView selectorTitle=text(goals.isEmpty()?s(R.string.ui_78319fd3d4):goals.get(0).name,15,c.text);selectorTitle.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));selectorText.addView(selectorTitle);
        TextView selectorSub=text(goals.isEmpty()?s(R.string.ui_e70b226f78):money(Math.min(goals.get(0).saved,goals.get(0).target))+" / "+money(goals.get(0).target),12,c.muted);margins(selectorSub,0,3,0,0);selectorText.addView(selectorSub);
        selectorRow.addView(selectorText,new LinearLayout.LayoutParams(0,-2,1));
        TextView arrow=text("›",28,c.muted);arrow.setGravity(Gravity.CENTER);selectorRow.addView(arrow,new LinearLayout.LayoutParams(dp(28),dp(42)));selector.addView(selectorRow);
        margins(selector,0,9,0,9);box.addView(selector);
        selector.setOnClickListener(selectorView->{
            if(goals.isEmpty()) return;
            Dialog pick=new Dialog(this);pick.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout po=new LinearLayout(this);po.setOrientation(LinearLayout.VERTICAL);po.setPadding(dp(18),dp(18),dp(18),dp(12));po.setBackground(bg(c.surface,24));
            TextView ph=text(s(R.string.ui_78319fd3d4),20,c.text);ph.setTypeface(null,Typeface.BOLD);po.addView(ph);
            TextView ps=text(s(R.string.ui_55b497d0e1),12,c.muted);margins(ps,0,3,0,12);po.addView(ps);
            for(int gi=0;gi<goals.size();gi++){final int idx=gi;Goal gg=goals.get(gi);LinearLayout gr=card(c.surface,16);gr.setPadding(dp(12),dp(10),dp(12),dp(10));LinearLayout rr=row();View giView=goalIconView(gg.icon,idx==selectedGoalIndex[0]?c.blue:c.muted,42);rr.addView(giView,new LinearLayout.LayoutParams(dp(42),dp(42)));LinearLayout gt=new LinearLayout(this);gt.setOrientation(LinearLayout.VERTICAL);gt.setPadding(dp(10),0,0,0);TextView gn=text(gg.name,15,c.text);gn.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));gt.addView(gn);int gp=gg.target<=0?0:(int)Math.round(Math.min(gg.saved,gg.target)*100/gg.target);TextView gs=text(money(Math.min(gg.saved,gg.target))+" / "+money(gg.target)+"  •  %"+gp,12,c.muted);margins(gs,0,3,0,0);gt.addView(gs);rr.addView(gt,new LinearLayout.LayoutParams(0,-2,1));TextView check=text(idx==selectedGoalIndex[0]?"✓":"",20,c.blue);check.setGravity(Gravity.CENTER);rr.addView(check,new LinearLayout.LayoutParams(dp(28),dp(42)));gr.addView(rr);margins(gr,0,0,0,7);po.addView(gr);attachPressFeedback(gr);gr.setOnClickListener(goalRowView->{selectedGoalIndex[0]=idx;Goal sg=goals.get(idx);selectorTitle.setText(sg.name);selectorSub.setText(money(Math.min(sg.saved,sg.target))+" / "+money(sg.target));String nextIcon=isGoalSimpleIcon(sg.icon)?sg.icon:"target";selectorIcon.type=nextIcon;selectorIcon.color=c.blue;selectorIcon.invalidate();pick.dismiss();});}
            Button closePick=dialogButton(s(R.string.ui_05a86eba57),c.muted,c.surface);margins(closePick,0,4,0,0);po.addView(closePick,new LinearLayout.LayoutParams(-1,dp(48)));closePick.setOnClickListener(closeView->pick.dismiss());pick.setContentView(po);pick.show();Window pw=pick.getWindow();if(pw!=null){pw.setBackgroundDrawableResource(android.R.color.transparent);pw.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);}
        });

        LinearLayout actions=row();
        Button add=dialogButton(s(R.string.ui_b7a76f5751),Color.WHITE,c.green);
        Button del=dialogButton(s(R.string.ui_e55f244f5e),c.red,c.surface);
        actions.addView(add,new LinearLayout.LayoutParams(0,dp(46),1));
        LinearLayout.LayoutParams delLp=new LinearLayout.LayoutParams(dp(78),dp(46));delLp.setMargins(dp(8),0,0,0);actions.addView(del,delLp);
        box.addView(actions);
        add.setOnClickListener(v->{int i=selectedGoalIndex[0];if(i>=0&&i<goals.size())contributeGoal(goals.get(i));});
        del.setOnClickListener(v->{int i=selectedGoalIndex[0];if(i>=0&&i<goals.size())deleteGoal(goals.get(i));});
        margins(box,0,0,0,12);content.addView(box);
    }
    ArrayList<SavingEntry> getSavingEntries(){
        ArrayList<SavingEntry> list=new ArrayList<>();
        android.content.SharedPreferences p=getPreferences(0);
        String raw=p.getString("savings_entries_json","");
        if(raw!=null && !raw.trim().isEmpty()){
            try{
                JSONArray a=new JSONArray(raw);
                for(int i=0;i<a.length();i++){
                    JSONObject o=a.getJSONObject(i);
                    list.add(new SavingEntry(o.optLong("id",System.currentTimeMillis()+i),o.optDouble("amount",0),o.optString("unit","TRY"),o.optString("date",df.format(new Date()))));
                }
            }catch(Exception ignored){}
        }
        // Migrate the previous single-savings value into the new entry list once.
        if(list.isEmpty() && p.contains("savings_amount")){
            double old=p.getFloat("savings_amount",0f);String u=p.getString("savings_unit","TRY");
            if(old>0){list.add(new SavingEntry(System.currentTimeMillis(),old,u,df.format(new Date())));saveSavingEntries(list);}
        }
        return list;
    }
    void saveSavingEntries(ArrayList<SavingEntry> list){
        JSONArray a=new JSONArray();
        try{for(SavingEntry e:list){JSONObject o=new JSONObject();o.put("id",e.id);o.put("amount",e.amount);o.put("unit",e.unit);o.put("date",e.date);a.put(o);}}catch(Exception ignored){}
        getPreferences(0).edit().putString("savings_entries_json",a.toString()).apply();
    }
    double savingsTotal(ArrayList<SavingEntry> list,String unit){double t=0;for(SavingEntry e:list)if(unit.equals(e.unit))t+=e.amount;return t;}
    void addSavingsSection(){
        final Colors c=C();
        final ArrayList<SavingEntry> entries=getSavingEntries();

        // PREMIUM SAVINGS DASHBOARD
        // Presentation-only redesign: all existing saving calculations/actions are preserved.
        final LinearLayout hero=card(c.surface,22);
        hero.setPadding(dp(18),dp(17),dp(18),dp(17));
        GradientDrawable heroBg=new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                darkMode
                        ? new int[]{Color.rgb(18,67,72),Color.rgb(20,91,78),Color.rgb(25,57,78)}
                        : new int[]{Color.rgb(14,111,104),Color.rgb(28,157,126),Color.rgb(37,91,150)}
        );
        hero.setBackground(heroBg);

        LinearLayout heroTop=row();
        SimpleIconView heroIcon=new SimpleIconView(this,"savings",Color.WHITE);
        heroIcon.setBackground(bg(Color.argb(48,255,255,255),18));
        heroTop.addView(heroIcon,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout heroCopy=new LinearLayout(this);heroCopy.setOrientation(LinearLayout.VERTICAL);heroCopy.setPadding(dp(12),0,0,0);
        TextView heroTitle=text(s(R.string.ui_844419a6be),17,Color.WHITE);heroTitle.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));heroCopy.addView(heroTitle);
        TextView heroSub=text(s(R.string.ui_1128fbc5bf),11,Color.argb(215,255,255,255));margins(heroSub,0,3,0,0);heroCopy.addView(heroSub);
        heroTop.addView(heroCopy,new LinearLayout.LayoutParams(0,-2,1));
        TextView count=text(entries.size()+" "+s(R.string.ui_a6a7ac8f08),11,Color.argb(225,255,255,255));count.setGravity(Gravity.CENTER);count.setPadding(dp(10),0,dp(10),0);count.setBackground(bg(Color.argb(42,255,255,255),18));heroTop.addView(count,new LinearLayout.LayoutParams(-2,dp(32)));
        hero.addView(heroTop);

        final TextView totalValue=text("—",28,Color.WHITE);totalValue.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));margins(totalValue,0,14,0,2);hero.addView(totalValue);
        final TextView totalHint=text(s(R.string.ui_9db5cc50ad),10,Color.argb(205,255,255,255));hero.addView(totalHint);
        margins(hero,0,0,0,12);content.addView(hero);

        // Asset distribution cards
        TextView allocationTitle=text(s(R.string.ui_9ef78989e0),19,c.text);allocationTitle.setTypeface(null,Typeface.BOLD);margins(allocationTitle,2,2,2,8);content.addView(allocationTitle);
        final LinearLayout allocation=new LinearLayout(this);allocation.setOrientation(LinearLayout.VERTICAL);content.addView(allocation);

        String[] units={"TRY","USD","EUR","GRAMALTIN"};
        final LinearLayout totalsBox=new LinearLayout(this);totalsBox.setOrientation(LinearLayout.VERTICAL);content.addView(totalsBox);

        double usd=marketQuotes.containsKey("USDTRY")?marketQuotes.get("USDTRY").sell:0;
        double eur=marketQuotes.containsKey("EURTRY")?marketQuotes.get("EURTRY").sell:0;
        double gold=marketQuotes.containsKey("GRAMALTIN")?marketQuotes.get("GRAMALTIN").sell:0;
        double totalTry=0;
        for(SavingEntry e:entries){
            if("TRY".equals(e.unit)) totalTry+=e.amount;
            else if("USD".equals(e.unit) && usd>0) totalTry+=e.amount*usd;
            else if("EUR".equals(e.unit) && eur>0) totalTry+=e.amount*eur;
            else if("GRAMALTIN".equals(e.unit) && gold>0) totalTry+=e.amount*gold;
        }
        if(entries.isEmpty()){
            totalValue.setText("₺ 0,00");
            totalHint.setText(s(R.string.ui_258b006e00));
        }else if(totalTry>0){
            totalValue.setText("₺ "+fmtCalc(totalTry));
            totalHint.setText(s(R.string.ui_90981b7118)+"  •  "+entries.size()+" "+s(R.string.ui_a6a7ac8f08));
        }else{
            totalValue.setText("—");
            totalHint.setText(s(R.string.ui_a9b6ffc956));
        }

        allocation.removeAllViews();
        for(int rowIndex=0;rowIndex<units.length;rowIndex+=2){
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
            for(int j=rowIndex;j<Math.min(rowIndex+2,units.length);j++){
                final String u=units[j];double amount=savingsTotal(entries,u);
                LinearLayout tile=card(c.surface,16);tile.setPadding(dp(12),dp(11),dp(12),dp(11));
                SimpleIconView icon=new SimpleIconView(this,"TRY".equals(u)?"currency":("USD".equals(u)?"dollar":("EUR".equals(u)?"euro":"gold")),"GRAMALTIN".equals(u)?c.gold:("EUR".equals(u)?c.green:c.blue));
                icon.setBackground(bg("GRAMALTIN".equals(u)?(darkMode?Color.rgb(67,59,27):Color.rgb(252,246,224)):("EUR".equals(u)?c.green2:c.blue2),14));
                LinearLayout top=row();top.addView(icon,new LinearLayout.LayoutParams(dp(38),dp(38)));
                LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(9),0,0,0);
                TextView name=text(savingsUnitLabel(u),11,c.muted);info.addView(name);
                TextView value=text(formatSavings(amount,u),15,amount>0?("GRAMALTIN".equals(u)?c.gold:("EUR".equals(u)?c.green:c.blue)):c.muted);value.setTypeface(null,Typeface.BOLD);margins(value,0,1,0,0);info.addView(value);
                top.addView(info,new LinearLayout.LayoutParams(0,-2,1));tile.addView(top);
                LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,-2,1);if(j%2==1)tp.setMargins(dp(6),0,0,0);row.addView(tile,tp);
            }
            margins(row,0,0,0,6);allocation.addView(row);
        }

        TextView listTitle=text(s(R.string.ui_556e10901d),19,c.text);listTitle.setTypeface(null,Typeface.BOLD);margins(listTitle,2,12,2,8);content.addView(listTitle);
        TextView listSub=text(s(R.string.ui_8fcfc75d44),11,c.muted);margins(listSub,0,0,0,9);content.addView(listSub);

        final ArrayList<LinearLayout> resultViews=new ArrayList<>();
        if(entries.isEmpty()){
            LinearLayout empty=card(c.surface,18);empty.setPadding(dp(16),dp(18),dp(16),dp(18));
            SimpleIconView ei=new SimpleIconView(this,"savings",c.muted);ei.setBackground(bg(c.bg,18));empty.addView(ei,new LinearLayout.LayoutParams(dp(46),dp(46)));
            TextView eh=text(s(R.string.ui_860db92356),16,c.text);eh.setTypeface(null,Typeface.BOLD);margins(eh,0,10,0,2);empty.addView(eh);
            TextView es=text(s(R.string.ui_72db6d4287),12,c.muted);empty.addView(es);
            margins(empty,0,8,0,0);content.addView(empty);
        } else {
            for(SavingEntry e:entries){
                LinearLayout r=card(c.surface,17);r.setPadding(dp(12),dp(11),dp(8),dp(11));
                LinearLayout top=row();
                SimpleIconView icon=new SimpleIconView(this,"TRY".equals(e.unit)?"currency":("USD".equals(e.unit)?"dollar":("EUR".equals(e.unit)?"euro":"gold")),"GRAMALTIN".equals(e.unit)?c.gold:("EUR".equals(e.unit)?c.green:c.blue));
                icon.setBackground(bg("GRAMALTIN".equals(e.unit)?(darkMode?Color.rgb(67,59,27):Color.rgb(252,246,224)):("EUR".equals(e.unit)?c.green2:c.blue2),14));
                top.addView(icon,new LinearLayout.LayoutParams(dp(44),dp(44)));
                LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(10),0,dp(6),0);
                TextView a=text(formatSavings(e.amount,e.unit),16,c.text);a.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));info.addView(a);
                TextView unitLabel=text(savingsUnitLabel(e.unit)+"  •  "+e.date,10,c.muted);margins(unitLabel,2,0,0,0);info.addView(unitLabel);
                top.addView(info,new LinearLayout.LayoutParams(0,-2,1));
                Button del=dialogButton("×",c.red,c.surface);del.setTextSize(18);del.setContentDescription(s(R.string.ui_38bdba1b62));top.addView(del,new LinearLayout.LayoutParams(dp(42),dp(40)));del.setOnClickListener(v->deleteSavingEntry(e.id));
                r.addView(top);
                LinearLayout equivalents=new LinearLayout(this);equivalents.setOrientation(LinearLayout.VERTICAL);margins(equivalents,8,2,0,0);r.addView(equivalents);resultViews.add(equivalents);
                updateSavingsResults(equivalents,e.amount,e.unit);
                margins(r,0,5,0,0);content.addView(r);
            }
        }

        Button add=button(s(R.string.ui_6eeb01ce8e),c.green);add.setTextSize(13);margins(add,0,10,0,4);content.addView(add);add.setOnClickListener(v->savingsDialog());
        savingsMarketCallback=()->{
            int callbackCount=Math.min(entries.size(),resultViews.size());
            for(int i=0;i<callbackCount;i++) updateSavingsResults(resultViews.get(i),entries.get(i).amount,entries.get(i).unit);
        };
    }
    void deleteSavingEntry(final long id){
        final Colors c=C(); Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(18),dp(18),dp(18),dp(12));outer.setBackground(bg(c.surface,24));
        LinearLayout head=row();TextView badge=text("−",24,Color.WHITE);badge.setGravity(Gravity.CENTER);badge.setTypeface(null,Typeface.BOLD);badge.setBackground(bg(c.red,22));head.addView(badge,new LinearLayout.LayoutParams(dp(50),dp(50)));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(12),0,0,0);TextView title=text(s(R.string.ui_f72627e619),19,c.text);title.setTypeface(null,Typeface.BOLD);copy.addView(title);TextView sub=text(s(R.string.ui_ea6ab7252c),12,c.muted);margins(sub,0,3,0,0);copy.addView(sub);head.addView(copy,new LinearLayout.LayoutParams(0,-2,1));TextView close=text("×",30,c.muted);close.setGravity(Gravity.CENTER);close.setBackground(bg(darkMode?Color.rgb(24,48,69):Color.rgb(242,247,251),18));head.addView(close,new LinearLayout.LayoutParams(dp(44),dp(46)));outer.addView(head);
        LinearLayout actions=row();Button cancel=dialogButton(s(R.string.ui_9dc74649ac),c.muted,c.surface);Button del=dialogButton(s(R.string.ui_e55f244f5e),Color.WHITE,c.red);actions.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(52),1);sp.setMargins(dp(8),0,0,0);actions.addView(del,sp);margins(actions,0,16,0,0);outer.addView(actions);
        close.setOnClickListener(v->dlg.dismiss());cancel.setOnClickListener(v->dlg.dismiss());del.setOnClickListener(v->{ArrayList<SavingEntry> list=getSavingEntries();for(int i=list.size()-1;i>=0;i--)if(list.get(i).id==id)list.remove(i);saveSavingEntries(list);dlg.dismiss();new Handler().postDelayed(()->showGoals(),250);});
        dlg.setContentView(outer);Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}dlg.show();w=dlg.getWindow();if(w!=null){WindowManager.LayoutParams lp=w.getAttributes();lp.width=Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430));lp.height=WindowManager.LayoutParams.WRAP_CONTENT;lp.dimAmount=.55f;w.setAttributes(lp);}
    }
    String savingsUnitLabel(String u){if("USD".equals(u))return "$ "+s(R.string.ui_eaf03afec0);if("EUR".equals(u))return "€ "+s(R.string.ui_b3da56fa8d);if("GRAMALTIN".equals(u))return s(R.string.ui_e13744a751);return "₺ "+s(R.string.ui_4e6ce94a03);}
    String formatSavings(double v,String u){return "GRAMALTIN".equals(u)?fmtGold(v):fmtCalc(v);}
    void updateSavingsResults(LinearLayout parent,double value,String unit){
        parent.removeAllViews();MarketQuote usdq=marketQuotes.get("USDTRY"),eurq=marketQuotes.get("EURTRY"),goldq=marketQuotes.get("GRAMALTIN");
        if(usdq==null||eurq==null||goldq==null){TextView w=text(s(R.string.ui_a9b6ffc956),10,C().muted);parent.addView(w);return;}
        double usd=usdq.sell,eur=eurq.sell,gold=goldq.sell;if(usd<=0||eur<=0||gold<=0)return;
        double tl,usdVal,eurVal,goldGrams;if("USD".equals(unit)){usdVal=value;tl=value*usd;eurVal=tl/eur;goldGrams=tl/gold;}else if("EUR".equals(unit)){eurVal=value;tl=value*eur;usdVal=tl/usd;goldGrams=tl/gold;}else if("GRAMALTIN".equals(unit)){goldGrams=value;tl=value*gold;usdVal=tl/usd;eurVal=tl/eur;}else{tl=value;usdVal=value/usd;eurVal=value/eur;goldGrams=value/gold;}
        TextView label=text(s(R.string.ui_401d823534),10,C().muted);margins(label,0,0,0,5);parent.addView(label);
        addCalcResult(parent,"₺ TL",fmtCalc(tl),C().blue);addCalcResult(parent,"$ USD",fmtCalc(usdVal),C().blue);addCalcResult(parent,"€ EUR",fmtCalc(eurVal),C().green);addCalcResult(parent,s(R.string.ui_e13744a751),fmtGold(goldGrams),C().gold);
    }
    void savingsDialog(){
        Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(18),dp(16),dp(18),dp(12));outer.setBackground(bg(c.surface,24));
        TextView h=text("💰  "+s(R.string.ui_749ef1856d),20,c.text);h.setTypeface(null,Typeface.BOLD);outer.addView(h);
        String current=getPreferences(0).getString("savings_unit","TRY");
        EditText amount=modernEdit("GRAMALTIN".equals(current)?s(R.string.ui_38590074ee):s(R.string.ui_b877f50dc0),c);amount.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);attachNumberFormatter(amount);margins(amount,0,12,0,10);outer.addView(amount,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView choose=text(s(R.string.ui_022d2620f4),11,c.muted);outer.addView(choose);
        String[] unitCodes={"TRY","USD","EUR","GRAMALTIN"};
        TextView unit=new TextView(this);unit.setText(savingsUnitLabel(current));unit.setTextColor(c.text);unit.setTextSize(14);unit.setTypeface(null,Typeface.BOLD);unit.setGravity(Gravity.CENTER_VERTICAL);unit.setPadding(dp(14),0,dp(14),0);unit.setBackground(strokeBg(c.bg,c.border,15));margins(unit,0,6,0,12);outer.addView(unit,new LinearLayout.LayoutParams(-1,dp(54)));
        unit.setOnClickListener(v->showSavingsUnitPicker(unit,current,amount));
        LinearLayout actions=row();Button cancel=dialogButton(s(R.string.ui_989f51ec41),c.muted,c.surface);Button save=dialogButton(s(R.string.ui_f100a40ef5),Color.WHITE,c.green);actions.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(52),1);sp.setMargins(dp(8),0,0,0);actions.addView(save,sp);outer.addView(actions);
        cancel.setOnClickListener(v->dlg.dismiss());save.setOnClickListener(v->{try{double a=parseMoneyText(amount.getText().toString());if(a<=0)throw new Exception();String u=(String)unit.getTag();if(u==null)u=current;ArrayList<SavingEntry> list=getSavingEntries();list.add(new SavingEntry(System.currentTimeMillis(),a,u,df.format(new Date())));saveSavingEntries(list);getPreferences(0).edit().putString("savings_unit",u).apply();dlg.dismiss();showGoals();}catch(Exception e){amount.setError(s(R.string.ui_d9f77be516));}});
        dlg.setContentView(outer);dlg.show();Window w=dlg.getWindow();if(w!=null)w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);
    }
    void showSavingsUnitPicker(final TextView target, String initial, final EditText amount){
        final Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(16),dp(16),dp(16),dp(12));outer.setBackground(bg(c.surface,24));
        LinearLayout head=row();TextView icon=text("◈",24,c.green);icon.setGravity(Gravity.CENTER);icon.setBackground(bg(c.green2,18));head.addView(icon,new LinearLayout.LayoutParams(dp(46),dp(46)));LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(12),0,0,0);TextView h=text(s(R.string.ui_022d2620f4),18,c.text);h.setTypeface(null,Typeface.BOLD);copy.addView(h);TextView sub=text(s(R.string.ui_49de3735a3),11,c.muted);margins(sub,2,0,0,0);copy.addView(sub);head.addView(copy,new LinearLayout.LayoutParams(0,-2,1));TextView close=text("×",30,c.muted);close.setGravity(Gravity.CENTER);close.setBackground(bg(darkMode?Color.rgb(24,48,69):Color.rgb(242,247,251),18));head.addView(close,new LinearLayout.LayoutParams(dp(44),dp(46)));outer.addView(head);
        String[] codes={"TRY","USD","EUR","GRAMALTIN"};String[] icons={"₺","$","€","g"};String[] names={s(R.string.ui_4e6ce94a03),s(R.string.ui_eaf03afec0),"Euro",s(R.string.ui_e13744a751)};
        for(int i=0;i<codes.length;i++){final String code=codes[i];LinearLayout item=row();item.setPadding(dp(10),dp(9),dp(10),dp(9));item.setGravity(Gravity.CENTER_VERTICAL);item.setBackground(strokeBg(code.equals(initial)?c.blue2:c.bg,c.border,15));TextView ico=text(icons[i],17,code.equals(initial)?c.blue:c.text);ico.setGravity(Gravity.CENTER);ico.setTypeface(null,Typeface.BOLD);ico.setBackground(bg(code.equals(initial)?c.blue2:c.surface,14));item.addView(ico,new LinearLayout.LayoutParams(dp(42),dp(42)));LinearLayout cp=new LinearLayout(this);cp.setOrientation(LinearLayout.VERTICAL);cp.setPadding(dp(12),0,0,0);TextView nm=text(names[i],14,c.text);nm.setTypeface(null,Typeface.BOLD);cp.addView(nm);TextView cd=text(code.equals("GRAMALTIN")?"g · Gram":code,10,c.muted);margins(cd,2,0,0,0);cp.addView(cd);item.addView(cp,new LinearLayout.LayoutParams(0,-2,1));TextView mark=text(code.equals(initial)?"✓":"›",22,code.equals(initial)?c.blue:c.muted);mark.setGravity(Gravity.CENTER);item.addView(mark,new LinearLayout.LayoutParams(dp(32),dp(42)));margins(item,0,7,0,0);outer.addView(item);item.setOnClickListener(v->{target.setText(savingsUnitLabel(code));target.setTag(code);amount.setHint("GRAMALTIN".equals(code)?s(R.string.ui_38590074ee):s(R.string.ui_b877f50dc0));if("GRAMALTIN".equals(code)){amount.setTag(null);}else{attachNumberFormatter(amount);}dlg.dismiss();});}
        close.setOnClickListener(v->dlg.dismiss());dlg.setContentView(outer);dlg.show();Window w=dlg.getWindow();if(w!=null)w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);
    }
    void addCurrencyCalculator(){
        final Colors c=C();
        final LinearLayout box=card(darkMode?Color.rgb(14,42,61):Color.rgb(239,247,253),20);box.setPadding(dp(16),dp(15),dp(16),dp(15));
        LinearLayout head=row();TextView ico=text("💱",24,c.blue);ico.setGravity(Gravity.CENTER);head.addView(ico,new LinearLayout.LayoutParams(dp(46),dp(46)));
        LinearLayout titles=new LinearLayout(this);titles.setOrientation(LinearLayout.VERTICAL);titles.setPadding(dp(10),0,0,0);
        TextView h=text(s(R.string.ui_33b8b87168),17,c.text);h.setTypeface(null,Typeface.BOLD);titles.addView(h);
        TextView sub=text(s(R.string.ui_b08d404d2e),11,c.muted);sub.setMaxLines(2);margins(sub,0,2,0,0);titles.addView(sub);head.addView(titles,new LinearLayout.LayoutParams(0,-2,1));box.addView(head);
        final EditText amount=modernEdit(s(R.string.ui_b877f50dc0),c);amount.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);attachNumberFormatter(amount);margins(amount,0,12,0,10);box.addView(amount,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView choose=text(s(R.string.ui_9c5a1b8da1),11,c.muted);margins(choose,2,0,2,6);box.addView(choose);
        final LinearLayout choices=row();box.addView(choices,new LinearLayout.LayoutParams(-1,dp(46)));
        final String[] units={"TRY","USD","EUR","GRAMALTIN"};final TextView[] buttons=new TextView[4];final String[] selected={"TRY"};
        for(int i=0;i<units.length;i++){final String unit=units[i];TextView b=text(unit.equals("TRY")?"₺ TL":unit.equals("USD")?"$ USD":unit.equals("EUR")?"€ EUR":"g Gram Altın",12,unit.equals("TRY")?c.blue:c.muted);b.setGravity(Gravity.CENTER);b.setTypeface(null,Typeface.BOLD);b.setBackground(strokeBg(unit.equals("TRY")?c.blue2:c.surface,c.border,13));buttons[i]=b;LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(44),1);if(i>0)bp.setMargins(dp(6),0,0,0);choices.addView(b,bp);b.setOnClickListener(v->{selected[0]=unit;amount.setHint("GRAMALTIN".equals(unit)?s(R.string.ui_38590074ee):s(R.string.ui_b877f50dc0));for(int j=0;j<buttons.length;j++){boolean on=units[j].equals(selected[0]);buttons[j].setTextColor(on?c.blue:c.muted);buttons[j].setBackground(strokeBg(on?c.blue2:c.surface,c.border,13));}if(marketDataCallback!=null)marketDataCallback.run();});}
        final TextView status=text(s(R.string.ui_654c8482ba),10,c.muted);margins(status,2,10,2,6);box.addView(status);final LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);box.addView(results);
        final Runnable updater=()->{updateCurrencyCalculatorViews(amount,selected[0],results,status);if(savingsMarketCallback!=null)savingsMarketCallback.run();};marketDataCallback=updater;amount.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c1,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){updater.run();}public void afterTextChanged(Editable e){}});updater.run();if(marketQuotes.isEmpty()&&!marketLoading)loadMarketData(null);margins(box,0,0,0,14);content.addView(box);
    }
    void updateCurrencyCalculatorViews(EditText amount,String selected,LinearLayout results,TextView status){
        results.removeAllViews();double value;try{value=parseMoneyText(amount.getText().toString());}catch(Exception e){value=0;}
        MarketQuote usdq=marketQuotes.get("USDTRY"),eurq=marketQuotes.get("EURTRY"),goldq=marketQuotes.get("GRAMALTIN");if(usdq==null||eurq==null||goldq==null){status.setText(s(R.string.ui_a9b6ffc956));return;}
        double usd=usdq.sell,eur=eurq.sell,goldBuy=goldq.buy,goldSell=goldq.sell;
        if(usd<=0||eur<=0||goldBuy<=0||goldSell<=0){status.setText(s(R.string.ui_ba1974cfb6));return;}
        double tl=value,usdVal=0,eurVal=0,goldVal=0,goldBuyVal=0,goldSellVal=0;
        if("USD".equals(selected)){tl=value*usd;usdVal=value;eurVal=tl/eur;goldVal=tl/goldSell;}
        else if("EUR".equals(selected)){tl=value*eur;eurVal=value;usdVal=tl/usd;goldVal=tl/goldSell;}
        else if("GRAMALTIN".equals(selected)){goldVal=value;goldBuyVal=value*goldBuy;goldSellVal=value*goldSell;tl=goldSellVal;usdVal=tl/usd;eurVal=tl/eur;}
        else{usdVal=value/usd;eurVal=value/eur;goldVal=value/goldSell;}
        status.setText(s(R.string.ui_c76dd12ed7)+marketQuotes.get("USDTRY").updated);
        addCalcResult(results,"₺ TL",fmtCalc(tl),C().blue);
        addCalcResult(results,"$ USD",fmtCalc(usdVal),C().blue);
        addCalcResult(results,"€ EUR",fmtCalc(eurVal),C().green);
        addCalcGoldRatePair(results,goldq,goldVal,selected);
    }

    void addCalcResult(LinearLayout parent,String label,String value,int accent){LinearLayout r=row();r.setPadding(dp(12),dp(9),dp(12),dp(9));r.setBackground(strokeBg(C().surface,C().border,13));TextView l=text(label,12,C().muted);r.addView(l,new LinearLayout.LayoutParams(0,-2,1));TextView v=text(value,15,accent);v.setTypeface(null,Typeface.BOLD);r.addView(v);margins(r,0,3,0,0);parent.addView(r);}
    void addCalcGoldRatePair(LinearLayout parent,MarketQuote q,double equivalent,String selected){
        LinearLayout r=row();r.setPadding(dp(12),dp(8),dp(12),dp(8));r.setBackground(strokeBg(C().surface,C().border,13));
        LinearLayout left=new LinearLayout(this);left.setOrientation(LinearLayout.VERTICAL);
        TextView l=text(s(R.string.ui_e13744a751),12,C().text);l.setTypeface(null,Typeface.BOLD);left.addView(l);
        TextView bl=text(s(R.string.ui_661a285d8c)+formatMarket(q.buy),11,C().muted);left.addView(bl);
        TextView sl=text(s(R.string.ui_e5a1a52a7f)+formatMarket(q.sell),11,C().gold);left.addView(sl);
        TextView eq=text(s(R.string.ui_32cf3f829e)+fmtGold(equivalent),11,C().text);left.addView(eq);
        r.addView(left,new LinearLayout.LayoutParams(0,-2,1));parent.addView(r);margins(r,0,3,0,0);
    }

    void addCalcRatePair(LinearLayout parent,String label,String buy,String sell,int accent){LinearLayout r=row();r.setPadding(dp(12),dp(8),dp(12),dp(8));r.setBackground(strokeBg(C().surface,C().border,13));LinearLayout left=new LinearLayout(this);left.setOrientation(LinearLayout.VERTICAL);TextView l=text(label,12,C().text);l.setTypeface(null,Typeface.BOLD);left.addView(l);TextView bl=text(s(R.string.ui_e6ad46674a)+buy,11,C().muted);left.addView(bl);TextView sl=text(s(R.string.ui_50f21481fb)+sell,11,accent);left.addView(sl);r.addView(left,new LinearLayout.LayoutParams(0,-2,1));parent.addView(r);margins(r,0,3,0,0);}
    Locale numberLocale(){
        if("en".equals(language))return Locale.US; if("fr".equals(language))return Locale.FRANCE; if("de".equals(language))return Locale.GERMANY; if("it".equals(language))return Locale.ITALY; if("es".equals(language))return new Locale("es","ES"); if("ru".equals(language))return new Locale("ru","RU"); if("ja".equals(language))return Locale.JAPAN; if("zh".equals(language))return Locale.CHINA; if("ar".equals(language))return new Locale("ar","SA"); if("el".equals(language))return new Locale("el","GR"); return new Locale("tr","TR");
    }

    String fmtCalc(double v){NumberFormat f=NumberFormat.getNumberInstance(numberLocale());f.setMinimumFractionDigits(2);f.setMaximumFractionDigits(2);return f.format(v);}
    String fmtGold(double v){NumberFormat f=NumberFormat.getNumberInstance(numberLocale());f.setMinimumFractionDigits(4);f.setMaximumFractionDigits(4);return f.format(v)+" g";}

    void addProgressBar(LinearLayout parent,int percent,int color){
        FrameLayout track=new FrameLayout(this);track.setBackground(bg(C().border,8));
        View fill=new View(this);fill.setBackground(bg(color,8));FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(0,dp(9));fp.width=(int)(getResources().getDisplayMetrics().widthPixels*0.78f*Math.max(0,Math.min(100,percent))/100f);track.addView(fill,fp);parent.addView(track,new LinearLayout.LayoutParams(-1,dp(9)));
    }
    int monthsUntil(String deadline){
        if(deadline==null||deadline.trim().isEmpty())return 0;
        try{
            SimpleDateFormat f=new SimpleDateFormat("dd.MM.yyyy",Locale.US);f.setLenient(false);
            Date d=f.parse(deadline.trim()); Calendar end=Calendar.getInstance();end.setTime(d);Calendar now=Calendar.getInstance();
            int months=(end.get(Calendar.YEAR)-now.get(Calendar.YEAR))*12+(end.get(Calendar.MONTH)-now.get(Calendar.MONTH));
            if(end.get(Calendar.DAY_OF_MONTH)>now.get(Calendar.DAY_OF_MONTH))months++;
            return Math.max(1,months);
        }catch(Exception e){return 0;}
    }
    double monthlyNeeded(Goal g){
        double remaining=Math.max(0,g.target-g.saved);int months=monthsUntil(g.deadline);return months>0?remaining/months:0;
    }
    private boolean isGoalSimpleIcon(String icon) {
        if (icon == null) return false;
        return "target".equals(icon) || "car".equals(icon) || "home".equals(icon) ||
                "travel".equals(icon) || "laptop".equals(icon) || "school".equals(icon) ||
                "heart".equals(icon) || "cart".equals(icon) || "savings".equals(icon) ||
                "shield".equals(icon) || "debt".equals(icon) || "investment".equals(icon) ||
                "gold".equals(icon) || "dollar".equals(icon) || "euro".equals(icon) ||
                "currency".equals(icon) || "calendar".equals(icon) || "trend".equals(icon) ||
                "other".equals(icon);
    }
    private String goalCategoryIcon(String code) {
        if (code == null) return "target"; String x=code.trim().toLowerCase(Locale.ROOT);
        if(x.equals("🎯"))return "target"; if(x.equals("🚗"))return "car"; if(x.equals("🏠"))return "home";
        if(x.equals("✈️")||x.equals("✈"))return "travel"; if(x.equals("💻"))return "laptop"; if(x.equals("🎓"))return "school";
        if(x.equals("💍"))return "heart"; if(x.equals("🛍️")||x.equals("🛍"))return "cart"; if(x.equals("💰"))return "savings";
        if(x.equals("🛡️")||x.equals("🛡"))return "shield"; if(x.equals("💳"))return "debt"; if(x.equals("📈"))return "investment";
        return isGoalSimpleIcon(x)?x:"other";
    }
    private String goalCategoryLabel(String code) {
        String x=goalCategoryIcon(code); if(x.equals("car"))return "🚗 "+trUi("Araç","Car"); if(x.equals("home"))return "🏠 "+trUi("Ev","Home");
        if(x.equals("travel"))return "✈️ "+trUi("Tatil / Seyahat","Travel / Vacation"); if(x.equals("laptop"))return "💻 "+trUi("Teknoloji","Technology"); if(x.equals("school"))return "🎓 "+trUi("Eğitim","Education");
        if(x.equals("heart"))return "💍 "+trUi("Düğün / Özel Gün","Wedding / Special Day"); if(x.equals("cart"))return "🛍️ "+trUi("Alışveriş","Shopping"); if(x.equals("savings"))return "💰 "+trUi("Birikim","Savings");
        if(x.equals("shield"))return "🛡️ "+trUi("Acil Durum","Emergency"); if(x.equals("debt"))return "💳 "+trUi("Borç Kapatma","Debt Payoff"); if(x.equals("investment"))return "📈 "+trUi("Yatırım","Investment");
        return "🎯 "+trUi("Özel Hedef","Custom Goal");
    }
    private View goalIconView(String icon,int color,int size){SimpleIconView v=new SimpleIconView(this,goalCategoryIcon(icon),color);v.setBackground(bg(darkMode?Color.rgb(30,66,91):Color.rgb(229,242,255),14));return v;}
    void addGoalCard(final Goal g){
        Colors c=C();LinearLayout box=card(c.surface,18);box.setPadding(dp(16),dp(14),dp(16),dp(14));
        LinearLayout head=row();View ic=goalIconView(g.icon,c.blue,48);head.addView(ic,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(10),0,0,0);TextView n=text(g.name,17,c.text);n.setTypeface(null,1);info.addView(n);
        String dl=g.deadline.isEmpty()?s(R.string.ui_b9271d4ebc):s(R.string.ui_2d5013cce1)+g.deadline;TextView d=text(dl,11,c.muted);margins(d,0,2,0,0);info.addView(d);head.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        int pct=g.target<=0?0:(int)Math.min(100,Math.round(g.saved*100/g.target));TextView p=text("%"+pct,14,c.blue);p.setTypeface(null,1);head.addView(p);box.addView(head);
        TextView amount=text(money(g.saved)+" / "+money(g.target),18,c.text);amount.setTypeface(null,1);margins(amount,0,10,0,4);box.addView(amount);addProgressBar(box,pct,c.green);
        TextView remain=text(s(R.string.ui_d043c483b7)+money(Math.max(0,g.target-g.saved)),11,c.muted);margins(remain,0,7,0,4);box.addView(remain);
        double monthly=monthlyNeeded(g);
        if(monthly>0){
            LinearLayout plan=card(darkMode?Color.rgb(15,50,48):Color.rgb(235,251,245),13);plan.setPadding(dp(11),dp(9),dp(11),dp(9));
            TextView pt=text("📅  "+s(R.string.ui_2a478f5814),12,c.text);pt.setTypeface(null,1);plan.addView(pt);
            TextView pv=text(money(monthly)+s(R.string.ui_694b2018d2),12,c.green);margins(pv,0,3,0,0);plan.addView(pv);
            int months=monthsUntil(g.deadline);TextView pm=text(months+" "+s(R.string.ui_f703729505),10,c.muted);plan.addView(pm);margins(plan,0,8,0,2);box.addView(plan);
        } else if(!g.deadline.isEmpty()){
            TextView planHint=text(s(R.string.ui_932f568ff3),10,c.muted);margins(planHint,0,6,0,2);box.addView(planHint);
        } else {
            TextView planHint=text(s(R.string.ui_c677f53802),10,c.muted);margins(planHint,0,6,0,2);box.addView(planHint);
        }
        // Goal actions: make it easy to correct a mistakenly entered goal or delete it directly.
        LinearLayout goalActions=row();
        Button editBtn=dialogButton(s(R.string.ui_fe40f75d8b),c.blue,c.surface);
        Button deleteBtn=dialogButton(s(R.string.ui_063724d963),c.red,c.surface);
        goalActions.addView(editBtn,new LinearLayout.LayoutParams(0,dp(44),1));
        LinearLayout.LayoutParams delLp=new LinearLayout.LayoutParams(0,dp(44),1);delLp.setMargins(dp(8),0,0,0);goalActions.addView(deleteBtn,delLp);
        margins(goalActions,0,12,0,0);box.addView(goalActions);
        editBtn.setOnClickListener(v->goalDialog(g));
        deleteBtn.setOnClickListener(v->deleteGoal(g));
        box.setOnLongClickListener(v->{deleteGoal(g);return true;});margins(box,0,0,0,12);content.addView(box);
    }
    void addCompletedGoalCard(final Goal g){
        Colors c=C();LinearLayout box=card(darkMode?Color.rgb(18,50,44):Color.rgb(238,251,246),18);box.setPadding(dp(16),dp(14),dp(16),dp(14));
        LinearLayout head=row();TextView ic=text("✓",24,c.green);ic.setGravity(Gravity.CENTER);ic.setBackground(bg(darkMode?Color.rgb(20,82,67):Color.rgb(214,247,233),24));head.addView(ic,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(10),0,0,0);TextView n=text(g.icon+"  "+g.name,16,c.text);n.setTypeface(null,1);info.addView(n);TextView d=text(s(R.string.ui_065763bbea),11,c.green);margins(d,0,3,0,0);info.addView(d);head.addView(info,new LinearLayout.LayoutParams(0,-2,1));TextView pct=text("100%",13,c.green);pct.setTypeface(null,1);head.addView(pct);box.addView(head);
        TextView amount=text(money(g.target),17,c.text);amount.setTypeface(null,1);margins(amount,0,10,0,0);box.addView(amount);margins(box,0,0,0,12);content.addView(box);
    }
    void goalDialog(final Goal edit){
        Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(18),dp(16),dp(18),dp(12));outer.setBackground(bg(c.surface,24));
        LinearLayout head=row();View badge=goalIconView(edit==null?"target":edit.icon,c.blue,52);head.addView(badge,new LinearLayout.LayoutParams(dp(52),dp(52)));LinearLayout titles=new LinearLayout(this);titles.setOrientation(LinearLayout.VERTICAL);titles.setPadding(dp(12),0,0,0);TextView h=text(edit==null?s(R.string.ui_9510bd2ff0):s(R.string.ui_6257546e61),20,c.text);h.setTypeface(null,1);titles.addView(h);TextView sub=text(trUi("Bir hedef belirle, birikimini takip et.","Set a goal and track your savings."),11,c.muted);margins(sub,0,3,0,0);titles.addView(sub);head.addView(titles,new LinearLayout.LayoutParams(0,-2,1));TextView close=text("×",30,c.muted);close.setGravity(Gravity.CENTER);close.setBackground(bg(darkMode?Color.rgb(24,48,69):Color.rgb(242,247,251),18));head.addView(close,new LinearLayout.LayoutParams(dp(44),dp(46)));outer.addView(head);
        EditText name=modernEdit(s(R.string.ui_0ee496567a),c);if(edit!=null)name.setText(edit.name);margins(name,0,10,0,0);outer.addView(name,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView categoryLabel=text(trUi("Hedef kategorisi","Goal category"),12,c.text);categoryLabel.setTypeface(null,Typeface.BOLD);margins(categoryLabel,0,2,0,4);outer.addView(categoryLabel);
        Spinner category=new Spinner(this,Spinner.MODE_DROPDOWN);String[] cc={"car","home","travel","laptop","school","heart","cart","savings","shield","debt","investment","other"};ArrayList<String> labels=new ArrayList<>();for(String x:cc)labels.add(goalCategoryLabel(x));ModernSpinnerAdapter ca=new ModernSpinnerAdapter(this,labels);category.setAdapter(ca);category.setBackground(strokeBg(c.bg,c.border,14));String selected=goalCategoryIcon(edit==null?"target":edit.icon);int cp=0;for(int i=0;i<cc.length;i++)if(cc[i].equals(selected)){cp=i;break;}category.setSelection(cp);margins(category,0,10,0,0);outer.addView(category,new LinearLayout.LayoutParams(-1,dp(52)));
        EditText target=modernEdit(s(R.string.ui_5cc3b9ce2c),c);target.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);attachNumberFormatter(target);if(edit!=null){NumberFormat goalInputFormat=NumberFormat.getNumberInstance(numberLocale());goalInputFormat.setMaximumFractionDigits(0);goalInputFormat.setMinimumFractionDigits(0);target.setText(goalInputFormat.format(Math.max(0,edit.target)));}margins(target,0,10,0,0);outer.addView(target,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText deadline=modernEdit(s(R.string.ui_f04ccaa148),c);if(edit!=null)deadline.setText(edit.deadline);margins(deadline,0,10,0,0);outer.addView(deadline,new LinearLayout.LayoutParams(-1,dp(54)));
        LinearLayout actions=row();Button cancel=dialogButton(s(R.string.ui_989f51ec41),c.muted,c.surface);Button saveBtn=dialogButton(edit==null?s(R.string.ui_306c119eb2):s(R.string.ui_57ea23145d),Color.WHITE,c.blue);actions.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(52),1);sp.setMargins(dp(8),0,0,0);actions.addView(saveBtn,sp);outer.addView(actions);
        category.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){if(pos>=0&&pos<cc.length){View b=goalIconView(cc[pos],c.blue,52);head.removeViewAt(0);head.addView(b,0,new LinearLayout.LayoutParams(dp(52),dp(52)));}}});
        close.setOnClickListener(v->dlg.dismiss());cancel.setOnClickListener(v->dlg.dismiss());saveBtn.setOnClickListener(v->{try{String n=name.getText().toString().trim();String ic=category.getSelectedItemPosition()>=0&&category.getSelectedItemPosition()<cc.length?cc[category.getSelectedItemPosition()]:"other";double tar=parseMoneyText(target.getText().toString());if(n.isEmpty()||tar<=0){target.setError(s(R.string.ui_56307dbc84));return;}String dl=deadline.getText().toString().trim();if(!dl.isEmpty()&&monthsUntil(dl)<=0){deadline.setError(s(R.string.ui_a3e70a478a));return;}if(edit==null)goals.add(new Goal(System.currentTimeMillis(),n,ic,tar,0,dl));else{edit.name=n;edit.icon=ic;edit.target=tar;edit.deadline=dl;if(edit.saved>=edit.target){goals.remove(edit);completedGoals.add(edit);}}saveGoals();dlg.dismiss();showGoals();}catch(Exception ex){target.setError(s(R.string.ui_d9f77be516));}});
        dlg.setContentView(outer);Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);}dlg.show();w=dlg.getWindow();if(w!=null){WindowManager.LayoutParams lp=w.getAttributes();lp.width=Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430));lp.height=WindowManager.LayoutParams.WRAP_CONTENT;lp.dimAmount=.55f;w.setAttributes(lp);}
    }
    void contributeGoal(final Goal g){
        Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(18),dp(16),dp(18),dp(12));outer.setBackground(bg(c.surface,24));
        TextView h=text("💰  "+s(R.string.ui_58f2126aa2),20,c.text);h.setTypeface(null,1);outer.addView(h);TextView sub=text(g.name,13,c.muted);margins(sub,0,4,0,12);outer.addView(sub);EditText amount=modernEdit(s(R.string.ui_03071d35ea),c);amount.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);attachNumberFormatter(amount);outer.addView(amount,new LinearLayout.LayoutParams(-1,dp(54)));LinearLayout actions=row();Button cancel=dialogButton(s(R.string.ui_989f51ec41),c.muted,c.surface);Button add=dialogButton(s(R.string.ui_f100a40ef5),Color.WHITE,c.green);actions.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(52),1);sp.setMargins(dp(8),0,0,0);actions.addView(add,sp);margins(actions,0,14,0,0);outer.addView(actions);cancel.setOnClickListener(v->dlg.dismiss());add.setOnClickListener(v->{try{double a=parseMoneyText(amount.getText().toString());if(a<=0)throw new Exception();g.saved+=a;if(g.saved>=g.target){g.saved=g.target;goals.remove(g);completedGoals.add(g);}saveGoals();dlg.dismiss();showGoals();}catch(Exception e){amount.setError(s(R.string.ui_d9f77be516));}});dlg.setContentView(outer);Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}dlg.show();w=dlg.getWindow();if(w!=null){WindowManager.LayoutParams lp=w.getAttributes();lp.width=Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430));lp.height=WindowManager.LayoutParams.WRAP_CONTENT;lp.dimAmount=.55f;w.setAttributes(lp);}}
    void deleteGoal(final Goal g){
        Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(18),dp(18),dp(18),dp(12));outer.setBackground(bg(c.surface,24));TextView h=text("🗑  "+s(R.string.ui_f2fed5b0c8),20,c.text);h.setTypeface(null,1);outer.addView(h);TextView sub=text(g.name+" "+s(R.string.ui_4dbad2f007),12,c.muted);margins(sub,0,5,0,0);outer.addView(sub);LinearLayout actions=row();Button cancel=dialogButton(s(R.string.ui_9dc74649ac),c.muted,c.surface);Button del=dialogButton(s(R.string.ui_e55f244f5e),Color.WHITE,c.red);actions.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(52),1);sp.setMargins(dp(8),0,0,0);actions.addView(del,sp);margins(actions,0,14,0,0);outer.addView(actions);cancel.setOnClickListener(v->dlg.dismiss());del.setOnClickListener(v->{goals.remove(g);saveGoals();dlg.dismiss();showGoals();});dlg.setContentView(outer);Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}dlg.show();w=dlg.getWindow();if(w!=null){WindowManager.LayoutParams lp=w.getAttributes();lp.width=Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430));lp.height=WindowManager.LayoutParams.WRAP_CONTENT;lp.dimAmount=.55f;w.setAttributes(lp);}}


    void showCreditCards(){
        enterScreen("credit");
        marketsVisible=false; currentPage=1; Colors c=C(); base(s(R.string.ui_4e0458c1df));
        double totalDebt=0,totalLimit=0,thisMonth=0,remaining=0; for(CreditCard cc:creditCards){totalDebt+=Math.max(0,cc.debt);totalLimit+=Math.max(0,cc.limit);} Calendar now=Calendar.getInstance();
        for(Installment in:installments){if(in.count>in.paidCount)remaining+=installmentMonthly(in)*(in.count-in.paidCount);for(int i=in.paidCount;i<in.count;i++){Calendar d=installmentDate(in,i);if(sameMonth(d,now))thisMonth+=installmentMonthly(in);}}
        double available=Math.max(0,totalLimit-totalDebt),usage=totalLimit>0?Math.min(1,totalDebt/totalLimit):0;

        LinearLayout hero=new LinearLayout(this);hero.setOrientation(LinearLayout.VERTICAL);hero.setPadding(dp(20),dp(18),dp(20),dp(18));
        GradientDrawable hg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,darkMode?new int[]{Color.rgb(9,35,53),Color.rgb(15,82,91),Color.rgb(18,115,100)}:new int[]{Color.rgb(12,49,72),Color.rgb(15,101,119),Color.rgb(18,145,116)});hg.setCornerRadius(dp(28));hero.setBackground(hg);hero.setElevation(dp(3));
        LinearLayout hr=row();LinearLayout tb=new LinearLayout(this);tb.setOrientation(LinearLayout.VERTICAL);TextView ey=text(s(R.string.ui_b2e5f3de97),10,Color.WHITE);ey.setAlpha(.70f);ey.setTypeface(null,Typeface.BOLD);tb.addView(ey);TextView ht=text(s(R.string.ui_4e0458c1df),24,Color.WHITE);ht.setTypeface(null,Typeface.BOLD);margins(ht,0,3,0,0);tb.addView(ht);TextView hs=text(s(R.string.ui_2febd8a046),11,Color.WHITE);hs.setAlpha(.76f);tb.addView(hs);hr.addView(tb,new LinearLayout.LayoutParams(0,-2,1));TextView count=text(""+creditCards.size(),12,Color.WHITE);count.setGravity(Gravity.CENTER);count.setTypeface(null,Typeface.BOLD);count.setBackground(bg(Color.argb(42,255,255,255),18));count.setPadding(dp(11),dp(7),dp(11),dp(7));hr.addView(count);hero.addView(hr);
        TextView hd=text(money(totalDebt),31,Color.WHITE);hd.setTypeface(null,Typeface.BOLD);margins(hd,0,1,0,0);hero.addView(hd);TextView hl=text(s(R.string.ui_00745f985a),11,Color.WHITE);hl.setAlpha(.70f);hero.addView(hl);
        LinearLayout hm=row();hm.addView(heroMetric(s(R.string.ui_2747ff9a66),money(available)),new LinearLayout.LayoutParams(0,dp(54),1));LinearLayout.LayoutParams hm2=new LinearLayout.LayoutParams(0,dp(54),1);hm2.setMargins(dp(7),0,0,0);hm.addView(heroMetric(s(R.string.ui_096fd5652d),money(thisMonth)),hm2);LinearLayout.LayoutParams hm3=new LinearLayout.LayoutParams(0,dp(54),1);hm3.setMargins(dp(7),0,0,0);hm.addView(heroMetric(s(R.string.ui_5919960455),money(remaining)),hm3);margins(hm,0,12,0,0);hero.addView(hm);content.addView(hero);

        LinearLayout actions=row();actions.setPadding(0,dp(12),0,dp(4));Button add=button(s(R.string.ui_fef3cdd767),c.blue);add.setTextSize(12);actions.addView(add,new LinearLayout.LayoutParams(0,dp(48),1));add.setOnClickListener(v->creditCardDialog(null));Button banks=button(s(R.string.ui_7d5b9a6ddb),c.green);banks.setTextSize(11);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(dp(92),dp(48));bp.setMargins(dp(7),0,0,0);actions.addView(banks,bp);banks.setOnClickListener(v->bankManagerDialog());Button stmtSettings=button(s(R.string.ui_statement_settings),c.blue2);stmtSettings.setTextSize(10);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(112),dp(48));sp.setMargins(dp(7),0,0,0);actions.addView(stmtSettings,sp);stmtSettings.setOnClickListener(v->showStatementPaymentSettings());content.addView(actions);

        if(creditCards.isEmpty()){LinearLayout empty=card(c.surface,22);empty.setPadding(dp(22),dp(30),dp(22),dp(30));TextView icon=text("▣",34,c.blue);icon.setGravity(Gravity.CENTER);empty.addView(icon,new LinearLayout.LayoutParams(-1,dp(44)));TextView e=text(s(R.string.ui_327c1fe639),18,c.text);e.setGravity(Gravity.CENTER);e.setTypeface(null,Typeface.BOLD);margins(e,0,8,0,2);empty.addView(e);TextView sub=text(s(R.string.ui_b004fedcb4),12,c.muted);sub.setGravity(Gravity.CENTER);empty.addView(sub);content.addView(empty);return;}

        LinearLayout util=card(c.surface,20);util.setPadding(dp(16),dp(14),dp(16),dp(14));LinearLayout ur=row();TextView ut=text(s(R.string.ui_0437429321),14,c.text);ut.setTypeface(null,Typeface.BOLD);ur.addView(ut,new LinearLayout.LayoutParams(0,-2,1));TextView uv=text("%"+(int)Math.round(usage*100),16,usage>.8?c.red:(usage>.55?c.gold:c.green));uv.setTypeface(null,Typeface.BOLD);ur.addView(uv);util.addView(ur);TextView ul=text(money(totalDebt)+" / "+money(totalLimit),11,c.muted);margins(ul,0,3,0,0);util.addView(ul);FrameLayout trk=new FrameLayout(this);trk.setBackground(bg(c.bg,8));View fill=new View(this);fill.setBackground(bg(usage>.8?c.red:(usage>.55?c.gold:c.green),8));trk.addView(fill,new FrameLayout.LayoutParams(Math.max(dp(8),(int)(dp(280)*usage)),dp(8)));margins(trk,0,7,0,0);util.addView(trk,new LinearLayout.LayoutParams(-1,dp(8)));util.addView(text(s(R.string.ui_812c6601a8),10,c.muted));margins(util,0,14,0,0);content.addView(util);
        TextView section=text(s(R.string.ui_43ad3a73fe),20,c.text);section.setTypeface(null,Typeface.BOLD);margins(section,0,16,0,8);content.addView(section);for(CreditCard cc:new ArrayList<>(creditCards))addCreditCardCard(cc);
    }

    View heroMetric(String label,String value){LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setPadding(dp(10),dp(8),dp(8),dp(7));b.setBackground(bg(Color.argb(34,255,255,255),14));TextView v=text(value,13,Color.WHITE);v.setTypeface(null,Typeface.BOLD);b.addView(v);TextView l=text(label,9,Color.WHITE);l.setAlpha(.70f);margins(l,0,2,0,0);b.addView(l);return b;}

    View cardMetric(String label,String value,int accent){
        Colors c=C(); LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(10),dp(8),dp(8),dp(8)); box.setBackground(strokeBg(c.bg,c.border,14));
        TextView v=text(value,13,c.text); v.setTypeface(null,Typeface.BOLD); box.addView(v); TextView l=text(label,9,c.muted); margins(l,0,2,0,0); box.addView(l); return box;
    }

    void addCreditCardCard(final CreditCard cc){
        Colors c=C();LinearLayout shell=card(c.surface,24);shell.setPadding(dp(8),dp(8),dp(8),dp(12));shell.setElevation(dp(2));
        LinearLayout face=new LinearLayout(this);face.setOrientation(LinearLayout.VERTICAL);face.setPadding(dp(18),dp(16),dp(18),dp(16));int seed=Math.abs((cc.bank+cc.name).hashCode());int[][] ps={{Color.rgb(18,61,91),Color.rgb(31,130,145)},{Color.rgb(45,42,84),Color.rgb(94,65,145)},{Color.rgb(18,77,61),Color.rgb(35,145,108)}};GradientDrawable fg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,ps[seed%ps.length]);fg.setCornerRadius(dp(20));face.setBackground(fg);
        LinearLayout top=row();TextView bank=text(cc.bank.trim().length()>0?cc.bank.toUpperCase(Locale.getDefault()):s(R.string.ui_f3fe91e9a4),11,Color.WHITE);bank.setTypeface(null,Typeface.BOLD);top.addView(bank,new LinearLayout.LayoutParams(0,-2,1));TextView chip=text("▦",21,Color.WHITE);chip.setGravity(Gravity.CENTER);chip.setBackground(bg(Color.argb(48,255,255,255),9));top.addView(chip,new LinearLayout.LayoutParams(dp(38),dp(28)));face.addView(top);TextView type=text("CREDIT  •  FINWAY",9,Color.WHITE);type.setAlpha(.58f);margins(type,0,17,0,0);face.addView(type);TextView name=text(cc.name,21,Color.WHITE);name.setTypeface(null,Typeface.BOLD);face.addView(name);TextView mask=text("••••  ••••  ••••  FINWAY",11,Color.WHITE);mask.setAlpha(.62f);margins(mask,0,12,0,0);face.addView(mask);LinearLayout foot=row();TextView lim=text(s(R.string.ui_b32c30eff5)+money(cc.limit),10,Color.WHITE);lim.setAlpha(.72f);foot.addView(lim,new LinearLayout.LayoutParams(0,-2,1));TextView due=text(s(R.string.ui_beedb2ef3c)+cc.dueDay,10,Color.WHITE);due.setAlpha(.78f);foot.addView(due);face.addView(foot);shell.addView(face);
        double available=Math.max(0,cc.limit-cc.debt),ratio=cc.limit>0?Math.min(1,Math.max(0,cc.debt/cc.limit)):0;LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(10),dp(14),dp(10),dp(2));LinearLayout r1=row();TextView dl=text(s(R.string.ui_b01ea20920),12,c.muted);r1.addView(dl,new LinearLayout.LayoutParams(0,-2,1));TextView dv=text(money(cc.debt),18,c.text);dv.setTypeface(null,Typeface.BOLD);r1.addView(dv);info.addView(r1);LinearLayout r2=row();TextView al=text(s(R.string.ui_99fbfaf10c),11,c.muted);r2.addView(al,new LinearLayout.LayoutParams(0,-2,1));TextView av=text(money(available),12,c.green);av.setTypeface(null,Typeface.BOLD);r2.addView(av);margins(r2,0,5,0,0);info.addView(r2);FrameLayout track=new FrameLayout(this);track.setBackground(bg(c.bg,8));View pf=new View(this);pf.setBackground(bg(ratio>.8?c.red:(ratio>.55?c.gold:c.blue),8));track.addView(pf,new FrameLayout.LayoutParams(Math.max(dp(7),(int)(dp(270)*ratio)),dp(7)));margins(track,0,5,0,0);info.addView(track,new LinearLayout.LayoutParams(-1,dp(7)));info.addView(text(s(R.string.ui_5c5ea99de2)+"%"+(int)Math.round(ratio*100),10,c.muted));info.addView(text(s(R.string.ui_7edc50580a)+money(cc.statementDebt)+"   •   "+s(R.string.ui_b0974e6e16)+money(cc.minPayment),11,c.muted));TextView cm=text(s(R.string.ui_10f31aa59e)+money(minimumPaymentForCard(cc)),11,c.green);cm.setTypeface(null,Typeface.BOLD);margins(cm,0,4,0,0);info.addView(cm);info.addView(text(s(R.string.ui_8a68298273)+cc.statementDay+"  •  "+s(R.string.ui_3a00aacde3)+cc.dueDay,10,c.muted));shell.addView(info);
        LinearLayout actions=row();margins(actions,0,12,0,4);Button pay=button(s(R.string.ui_1a93bb35b9),c.green);pay.setTextSize(12);actions.addView(pay,new LinearLayout.LayoutParams(0,dp(44),1));pay.setOnClickListener(v->creditCardPaymentDialog(cc));Button edit=button(s(R.string.ui_6f9ce08dc9),c.blue);edit.setTextSize(12);LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(0,dp(44),1);ep.setMargins(dp(7),0,0,0);actions.addView(edit,ep);edit.setOnClickListener(v->creditCardDialog(cc));Button del=button("×",c.red);del.setTextSize(18);del.setPadding(0,0,0,0);LinearLayout.LayoutParams xp=new LinearLayout.LayoutParams(dp(44),dp(44));xp.setMargins(dp(7),0,0,0);actions.addView(del,xp);del.setOnClickListener(v->confirmDeleteCreditCard(cc));shell.addView(actions);
        ArrayList<CardPayment> pays=new ArrayList<>();for(CardPayment cp:cardPayments)if(cp.cardId==cc.id&&!cp.cancelled)pays.add(cp);if(!pays.isEmpty()){LinearLayout ph=row();TextView pht=text(s(R.string.ui_30e70ec4b7),13,c.text);pht.setTypeface(null,Typeface.BOLD);ph.addView(pht,new LinearLayout.LayoutParams(0,-2,1));TextView badge=text(""+pays.size(),10,c.green);badge.setGravity(Gravity.CENTER);badge.setBackground(bg(c.green2,14));badge.setPadding(dp(8),dp(4),dp(8),dp(4));ph.addView(badge);margins(ph,dp(4),8,dp(4),3);shell.addView(ph);for(CardPayment cp:new ArrayList<>(pays)){LinearLayout pr=row();pr.setPadding(dp(8),dp(8),dp(8),dp(8));pr.setBackground(strokeBg(c.bg,c.border,12));LinearLayout pd=new LinearLayout(this);pd.setOrientation(LinearLayout.VERTICAL);pd.addView(text(cp.installmentId!=0?"Taksit ödemesi":"Kart ödemesi",9,cp.installmentId!=0?c.green:c.blue));pd.addView(text(cp.date,10,c.muted));pr.addView(pd,new LinearLayout.LayoutParams(dp(92),-2));TextView pa=text(money(cp.amount),12,c.text);pa.setTypeface(null,Typeface.BOLD);pr.addView(pa,new LinearLayout.LayoutParams(0,-2,1));LinearLayout pnBox=new LinearLayout(this);pnBox.setOrientation(LinearLayout.VERTICAL);TextView pn=text(cp.account==null?"Genel":cp.account,9,c.muted);pnBox.addView(pn);if(cp.note!=null&&cp.note.trim().length()>0){TextView nn=text(cp.note,9,c.muted);nn.setMaxLines(1);nn.setEllipsize(android.text.TextUtils.TruncateAt.END);pnBox.addView(nn);}pr.addView(pnBox,new LinearLayout.LayoutParams(dp(100),-2));margins(pr,dp(4),2,dp(4),2);shell.addView(pr);}}
        ArrayList<Installment> insts=new ArrayList<>();for(Installment in:installments)if(in.cardId==cc.id)insts.add(in);LinearLayout ih=row();TextView iht=text(s(R.string.ui_1c098a29e8),13,c.text);iht.setTypeface(null,Typeface.BOLD);ih.addView(iht,new LinearLayout.LayoutParams(0,-2,1));ih.addView(text(s(R.string.ui_1f1a0b8d17),11,c.blue));margins(ih,dp(4),12,dp(4),5);shell.addView(ih);if(insts.isEmpty()){TextView no=text(s(R.string.ui_c541eaaa8f),11,c.muted);no.setBackground(strokeBg(c.bg,c.border,12));no.setPadding(dp(10),dp(10),dp(10),dp(10));margins(no,dp(4),0,dp(4),5);shell.addView(no);}else for(Installment in:new ArrayList<>(insts))addInstallmentRow(shell,in);Button ai=button(s(R.string.ui_81093cdac8),c.blue);ai.setTextSize(12);margins(ai,4,7,4,0);shell.addView(ai);ai.setOnClickListener(v->installmentDialog(cc));margins(shell,0,0,0,14);content.addView(shell);
    }

    void addInstallmentRow(LinearLayout parent,final Installment in){
        Colors c=C();
        LinearLayout r=row();r.setPadding(dp(10),dp(9),dp(8),dp(9));r.setBackground(strokeBg(c.bg,c.border,14));
        TextView badge=text("%",17,Color.WHITE);badge.setGravity(Gravity.CENTER);badge.setBackground(bg(in.paidCount>=in.count?c.green:c.blue,16));r.addView(badge,new LinearLayout.LayoutParams(dp(40),dp(40)));
        LinearLayout mid=new LinearLayout(this);mid.setOrientation(LinearLayout.VERTICAL);mid.setPadding(dp(10),0,dp(5),0);
        TextView merchant=text(in.merchant,13,c.text);merchant.setTypeface(null,1);mid.addView(merchant);
        String line=money(installmentMonthly(in))+" × "+in.count+"   •   "+s(R.string.ui_29ff90374d)+Math.max(0,in.count-in.paidCount);
        mid.addView(text(line,11,c.muted));
        if(in.firstDate.length()>0)mid.addView(text(s(R.string.ui_03ac35c791)+in.firstDate,10,c.muted));
        r.addView(mid,new LinearLayout.LayoutParams(0,-2,1));
        if(in.paidCount<in.count){
            Button pay=button("Taksiti Öde",c.green);pay.setTextSize(10);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(92),dp(40));pp.setMargins(dp(5),0,0,0);r.addView(pay,pp);pay.setOnClickListener(v->installmentPaymentDialog(in));
        }else{
            TextView status=text("✓ Tamamlandı",10,c.green);status.setGravity(Gravity.CENTER);r.addView(status,new LinearLayout.LayoutParams(dp(92),dp(40)));
        }
        TextView more=text("⋮",24,c.muted);more.setGravity(Gravity.CENTER);LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(dp(30),dp(40));mp.setMargins(dp(4),0,0,0);r.addView(more,mp);more.setOnClickListener(v->installmentOptionsDialog(in));
        r.setOnClickListener(v->showInstallmentSchedule(in));
        margins(r,0,3,0,3);parent.addView(r);
    }

    double installmentMonthly(Installment in){return in.count<=0?0:in.total/in.count;}
    Calendar parseCardDate(String value){
        Calendar cal=Calendar.getInstance();
        try{Date d=new SimpleDateFormat("dd.MM.yyyy",Locale.US).parse(value);if(d!=null)cal.setTime(d);}catch(Exception ignored){}
        return cal;
    }
    Calendar installmentDate(Installment in,int index){Calendar c=parseCardDate(in.firstDate);c.add(Calendar.MONTH,index);return c;}
    boolean sameMonth(Calendar a,Calendar b){return a.get(Calendar.YEAR)==b.get(Calendar.YEAR)&&a.get(Calendar.MONTH)==b.get(Calendar.MONTH);}
    String installmentDateText(Installment in,int index){return df.format(installmentDate(in,index).getTime());}

    /**
     * Tek tip para giriş formatter'ı.
     * Türkçe gösterimde nokta binlik, virgül ondalık ayırıcıdır.
     * Ancak programatik olarak gelen "2500.0" gibi değerleri de yanlışlıkla
     * "25.000" yapmamak için tek nokta + 1-2 basamak sonrasını ondalık kabul eder.
     * 2.500 / 25.000 / 2.500.000 ise binlik olarak korunur.
     */
    void attachNumberFormatter(final EditText e){
        if(e.getTag(R.id.number_formatter_tag)!=null)return;
        e.setTag(R.id.number_formatter_tag, Boolean.TRUE);
        e.addTextChangedListener(new TextWatcher(){
            boolean busy=false;
            public void beforeTextChanged(CharSequence s,int st,int count,int after){}
            public void onTextChanged(CharSequence s,int st,int before,int count){}
            public void afterTextChanged(Editable editable){
                if(busy)return;
                String raw=editable.toString();
                if(raw.length()==0)return;
                int oldPos=Math.max(0,Math.min(e.getSelectionStart(),raw.length()));
                int digitsBefore=0;
                for(int i=0;i<oldPos;i++) if(Character.isDigit(raw.charAt(i))) digitsBefore++;

                String cleaned=raw.replaceAll("[^0-9.,]","");
                if(cleaned.length()==0)return;
                int lastComma=cleaned.lastIndexOf(',');
                int lastDot=cleaned.lastIndexOf('.');
                boolean decimal=false;
                int decimalPos=-1;
                if(lastComma>=0 && lastDot>=0){
                    decimalPos=Math.max(lastComma,lastDot);
                    decimal=true;
                }else if(lastComma>=0){
                    decimalPos=lastComma;
                    decimal=true;
                }else if(lastDot>=0){
                    int dotCount=0;
                    for(int i=0;i<cleaned.length();i++) if(cleaned.charAt(i)=='.')dotCount++;
                    int digitsAfter=cleaned.length()-lastDot-1;
                    // Tek nokta + en fazla 2 basamak: ondalık; 3+ basamak: binlik.
                    decimal=dotCount==1 && digitsAfter>0 && digitsAfter<=2;
                    if(decimal)decimalPos=lastDot;
                }

                String integerPart=decimal?cleaned.substring(0,decimalPos):cleaned;
                String fractionPart=decimal?cleaned.substring(decimalPos+1):"";
                integerPart=integerPart.replaceAll("[^0-9]","");
                fractionPart=fractionPart.replaceAll("[^0-9]","");
                if(integerPart.length()==0)integerPart="0";

                StringBuilder grouped=new StringBuilder();
                for(int i=0;i<integerPart.length();i++){
                    if(i>0 && (integerPart.length()-i)%3==0)grouped.append('.');
                    grouped.append(integerPart.charAt(i));
                }
                String formatted=grouped.toString();
                if(decimal)formatted+=","+fractionPart;

                if(!formatted.equals(raw)){
                    busy=true;
                    e.setText(formatted);
                    int pos=0,seen=0;
                    while(pos<formatted.length() && seen<digitsBefore){
                        if(Character.isDigit(formatted.charAt(pos)))seen++;
                        pos++;
                    }
                    e.setSelection(Math.max(0,Math.min(pos,formatted.length())));
                    busy=false;
                }
            }
        });
    }

    String formatMoneyInput(double value){
        NumberFormat nf=NumberFormat.getNumberInstance(new Locale("tr","TR"));
        nf.setGroupingUsed(true);
        nf.setMinimumFractionDigits(0);
        nf.setMaximumFractionDigits(2);
        return nf.format(value);
    }

    double parseMoneyText(String value){
        if(value==null)return 0;
        String x=value.trim().replace(" ","").replace("\u00A0","");
        if(x.length()==0)return 0;
        try{
            // Tek para parserı: tüm gelir/harcama/hedef/birikim/kart/taksit alanları bunu kullanır.
            x=x.replace("₺","").replace("$","").replace("€","").replace("£","").trim();
            int comma=x.lastIndexOf(',');
            int dot=x.lastIndexOf('.');
            if(comma>=0){
                String integer=x.substring(0,comma).replaceAll("[^0-9-]","");
                String fraction=x.substring(comma+1).replaceAll("[^0-9]","");
                if(fraction.length()>2)fraction=fraction.substring(0,2);
                x=integer+(fraction.length()>0?"."+fraction:"");
            }else if(dot>=0){
                int count=0;for(int i=0;i<x.length();i++)if(x.charAt(i)=='.')count++;
                int digitsAfter=x.length()-dot-1;
                if(count==1&&digitsAfter>0&&digitsAfter<=2){
                    x=x.replaceAll("[^0-9.-]","");
                }else{
                    x=x.replace(".","").replaceAll("[^0-9-]","");
                }
            }else{
                x=x.replaceAll("[^0-9-]","");
            }
            if(x.equals("-")||x.length()==0)return 0;
            return Double.parseDouble(x);
        }catch(Exception ex){return 0;}
    }

    void setMoneyInput(EditText e,double value){
        e.setText(formatMoneyInput(value));
        e.setSelection(e.length());
    }
    EditText cardNumberEdit(String hint,Colors c){EditText e=modernEdit(hint,c);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);attachNumberFormatter(e);return e;}
    double customMinimumPaymentRate(){return getPreferences(0).getFloat("credit_min_payment_rate",-1f);}
    double minimumPaymentRate(double cardLimit){double custom=customMinimumPaymentRate();if(custom>=0)return Math.min(1.0,Math.max(0.0,custom));return cardLimit<=50000.0?0.20:0.40;}
    double minimumPaymentForCard(CreditCard cc){if(cc==null)return 0;double stb=Math.max(0,cc.statementDebt);return stb<=0?0:stb*minimumPaymentRate(cc.limit);}
    // Compatibility wrapper used by existing card-entry/installment preview code.
    // It now respects the user-selected minimum-payment rate when one is configured.
    double turkiyeMinimumPayment(double cardLimit,double statementDebt){
        if(cardLimit<=0||statementDebt<=0)return 0;
        return statementDebt*minimumPaymentRate(cardLimit);
    }
    String turkiyeMinimumRateText(double cardLimit){double custom=customMinimumPaymentRate();if(custom>=0)return String.format(Locale.getDefault(),"%s: %.0f%%",s(R.string.ui_custom_rate_label),custom*100);if(cardLimit<=0)return s(R.string.ui_fd4e7306e0);return cardLimit<=50000.0?s(R.string.ui_3fd4544e72):s(R.string.ui_75b79830fb);}
    void showStatementPaymentSettings(){Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout o=new LinearLayout(this);o.setOrientation(LinearLayout.VERTICAL);o.setPadding(dp(18),dp(18),dp(18),dp(14));o.setBackground(bg(c.surface,24));TextView h=text(s(R.string.ui_statement_settings),20,c.text);h.setTypeface(null,Typeface.BOLD);o.addView(h);TextView sub=text(s(R.string.ui_statement_settings_sub),12,c.muted);margins(sub,0,6,0,14);o.addView(sub);double current=customMinimumPaymentRate();RadioGroup group=new RadioGroup(this);RadioButton def=new RadioButton(this);def.setText(s(R.string.ui_statement_default));def.setTextColor(c.text);def.setTextSize(14);def.setChecked(current<0);group.addView(def);RadioButton custom=new RadioButton(this);custom.setText(s(R.string.ui_statement_custom));custom.setTextColor(c.text);custom.setTextSize(14);custom.setChecked(current>=0);group.addView(custom);o.addView(group);EditText rate=new EditText(this);rate.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);rate.setHint(s(R.string.ui_statement_rate_hint));rate.setSingleLine(true);rate.setText(current>=0?String.format(Locale.getDefault(),"%.0f",current*100):"");margins(rate,0,10,0,4);o.addView(rate);TextView info=text(s(R.string.ui_statement_rate_info),11,c.muted);o.addView(info);Runnable sync=()->rate.setEnabled(custom.isChecked());group.setOnCheckedChangeListener((g,id)->sync.run());sync.run();LinearLayout acts=row();Button cancel=dialogButton(s(R.string.ui_9dc74649ac),c.muted,c.surface);Button save=dialogButton(s(R.string.ui_b0ad98dc01),Color.WHITE,c.blue);acts.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams asp=new LinearLayout.LayoutParams(0,dp(52),1);asp.setMargins(dp(8),0,0,0);acts.addView(save,asp);margins(acts,0,14,0,0);o.addView(acts);cancel.setOnClickListener(v->dlg.dismiss());save.setOnClickListener(v->{try{SharedPreferences.Editor ed=getPreferences(0).edit();if(def.isChecked()){ed.remove("credit_min_payment_rate");}else{double pct=parseMoneyText(rate.getText().toString());if(pct<0||pct>100)throw new Exception();ed.putFloat("credit_min_payment_rate",(float)(pct/100.0));}ed.apply();for(CreditCard cc:creditCards)cc.minPayment=minimumPaymentForCard(cc);saveCreditCards();dlg.dismiss();showCreditCards();}catch(Exception e){rate.setError(s(R.string.ui_statement_rate_invalid));}});dlg.setContentView(o);dlg.show();Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);}}
    static class ModernSpinnerAdapter extends ArrayAdapter<String>{
        final MainActivity a;
        ModernSpinnerAdapter(MainActivity a,ArrayList<String> items){super(a,android.R.layout.simple_spinner_item,items);this.a=a;setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);}
        TextView make(String s,boolean drop){TextView v=new TextView(a);Colors c=a.C();v.setText(s);v.setTextColor(c.text);v.setTextSize(drop?15:14);v.setGravity(Gravity.CENTER_VERTICAL);v.setPadding(a.dp(14),0,a.dp(14),0);if(drop)v.setBackground(a.strokeBg(c.surface,c.border,14));return v;}
        @Override public View getView(int p,View v,android.view.ViewGroup parent){
            TextView t=make(getItem(p),false);
            // The Spinner itself supplies the single rounded field background.
            // Keeping the selected item transparent avoids a second nested box.
            return t;
        }
        @Override public View getDropDownView(int p,View v,android.view.ViewGroup parent){TextView t=make(getItem(p),true);android.widget.AbsListView.LayoutParams lp=new android.widget.AbsListView.LayoutParams(-1,a.dp(52));t.setLayoutParams(lp);return t;}
    }

    void bankManagerDialog(){ bankManagerDialog(null); }

    void bankManagerDialog(final Runnable onBankSaved){
        Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout o=new LinearLayout(this);o.setOrientation(LinearLayout.VERTICAL);o.setPadding(dp(18),dp(18),dp(18),dp(12));o.setBackground(bg(c.surface,24));
        TextView h=text("🏦  "+s(R.string.ui_c5c57f9e0b),20,c.text);h.setTypeface(null,Typeface.BOLD);o.addView(h);TextView sub=text(s(R.string.ui_200482fbfb),11,c.muted);margins(sub,0,4,0,12);o.addView(sub);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);
        if(savedBanks.isEmpty()) list.addView(text(s(R.string.ui_b86d145720),12,c.muted));
        else for(String bankName:new ArrayList<>(savedBanks)){LinearLayout r=row();r.setPadding(dp(12),dp(8),dp(8),dp(8));r.setBackground(strokeBg(c.bg,c.border,14));TextView n=text("🏦  "+bankName,14,c.text);n.setTypeface(null,Typeface.BOLD);r.addView(n,new LinearLayout.LayoutParams(0,dp(46),1));Button del=button("×",c.red);del.setTextSize(18);del.setPadding(0,0,0,0);r.addView(del,new LinearLayout.LayoutParams(dp(44),dp(44)));del.setOnClickListener(v->{savedBanks.remove(bankName);saveBanks();dlg.dismiss();bankManagerDialog();});margins(r,0,0,0,6);list.addView(r);}
        o.addView(list);EditText newName=modernEdit(s(R.string.ui_dddf1d975c),c);margins(newName,0,10,0,0);o.addView(newName,new LinearLayout.LayoutParams(-1,dp(54)));LinearLayout acts=row();Button cancel=dialogButton(s(R.string.ui_05a86eba57),c.muted,c.surface);Button add=dialogButton(s(R.string.ui_4576024df8),Color.WHITE,c.green);acts.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(52),1);ap.setMargins(dp(8),0,0,0);acts.addView(add,ap);o.addView(acts);cancel.setOnClickListener(v->dlg.dismiss());add.setOnClickListener(v->{String bn=newName.getText().toString().trim();if(bn.length()==0){newName.setError(s(R.string.ui_ce82e6fb1d));return;}if(!savedBanks.contains(bn))savedBanks.add(bn);saveBanks();dlg.dismiss();if(onBankSaved!=null){onBankSaved.run();}else{bankManagerDialog();}});dlg.setContentView(o);dlg.show();Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);}
    }

    void creditCardDialog(final CreditCard edit){
        Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(18),dp(18),dp(18),dp(12));outer.setBackground(bg(c.surface,24));
        TextView h=text("💳  "+s(edit==null?R.string.ui_card_title_add:R.string.ui_card_title_edit),20,c.text);h.setTypeface(null,1);outer.addView(h);
        ScrollView scroll=new ScrollView(this);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        EditText name=modernEdit(s(R.string.ui_b38b3d8cb8),c);box.addView(name,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView bankLabel=text(s(R.string.ui_d37c8e5aa0),12,c.text);bankLabel.setTypeface(null,Typeface.BOLD);margins(bankLabel,0,10,0,4);box.addView(bankLabel);
        ArrayList<String> bankOptions=new ArrayList<>();
        bankOptions.add(s(R.string.ui_acb1d990fe));
        bankOptions.addAll(savedBanks);
        if(edit!=null && edit.bank!=null && edit.bank.trim().length()>0 && !bankOptions.contains(edit.bank.trim())) bankOptions.add(edit.bank.trim());
        bankOptions.add(s(R.string.ui_91e63f65ab));
        Spinner bankSpinner=new Spinner(this,Spinner.MODE_DROPDOWN);ModernSpinnerAdapter bankAdapter=new ModernSpinnerAdapter(this,bankOptions);bankSpinner.setAdapter(bankAdapter);bankSpinner.setBackground(strokeBg(c.bg,c.border,14));box.addView(bankSpinner,new LinearLayout.LayoutParams(-1,dp(52)));
        EditText newBank=modernEdit(s(R.string.ui_0363214d52),c);newBank.setVisibility(View.GONE);margins(newBank,0,8,0,0);box.addView(newBank,new LinearLayout.LayoutParams(-1,dp(54)));
        bankSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){boolean isNew=pos==bankOptions.size()-1;newBank.setVisibility(isNew?View.VISIBLE:View.GONE);if(isNew){bankManagerDialog(()->{String newlyAdded=savedBanks.isEmpty()?"":savedBanks.get(savedBanks.size()-1);if(newlyAdded.length()>0&&!bankOptions.contains(newlyAdded)){bankOptions.add(bankOptions.size()-1,newlyAdded);bankAdapter.notifyDataSetChanged();bankSpinner.setSelection(bankOptions.indexOf(newlyAdded));}else if(newlyAdded.length()>0){bankSpinner.setSelection(bankOptions.indexOf(newlyAdded));}newBank.setVisibility(View.GONE);});}}});
        EditText limit=cardNumberEdit(s(R.string.ui_1d69cc766a),c);margins(limit,0,8,0,0);box.addView(limit,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText debt=cardNumberEdit(s(R.string.ui_b2f7589616),c);margins(debt,0,8,0,0);box.addView(debt,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText statement=cardNumberEdit(s(R.string.ui_2b106586e8),c);margins(statement,0,8,0,0);box.addView(statement,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView minInfo=text(s(R.string.ui_64285e3179),11,c.muted);margins(minInfo,0,5,0,0);box.addView(minInfo);
        TextView minimum=text(s(R.string.ui_b7fb584ffb),14,c.green);minimum.setTypeface(null,1);minimum.setPadding(dp(12),dp(10),dp(12),dp(10));minimum.setBackground(strokeBg(c.green2,c.border,12));margins(minimum,0,0,0,0);box.addView(minimum);
        TextView rateInfo=text(turkiyeMinimumRateText(0),11,c.muted);margins(rateInfo,0,4,0,8);box.addView(rateInfo);
        TextView statementDayLabel=text("Ekstre kesim günü",12,c.text);statementDayLabel.setTypeface(null,Typeface.BOLD);margins(statementDayLabel,0,4,0,4);box.addView(statementDayLabel);Spinner statementDay=new Spinner(this,Spinner.MODE_DROPDOWN);ArrayList<String> statementDayOptions=new ArrayList<>();for(int i=1;i<=31;i++)statementDayOptions.add(i+" "+trUi("gün","day"));ModernSpinnerAdapter statementDayAdapter=new ModernSpinnerAdapter(this,statementDayOptions);statementDay.setAdapter(statementDayAdapter);statementDay.setBackground(strokeBg(c.bg,c.border,14));margins(statementDay,0,8,0,0);box.addView(statementDay,new LinearLayout.LayoutParams(-1,dp(52)));
        TextView dueDayLabel=text("Son ödeme günü",12,c.text);dueDayLabel.setTypeface(null,Typeface.BOLD);margins(dueDayLabel,0,4,0,4);box.addView(dueDayLabel);Spinner dueDay=new Spinner(this,Spinner.MODE_DROPDOWN);ArrayList<String> dueDayOptions=new ArrayList<>();for(int i=1;i<=31;i++)dueDayOptions.add(i+" "+trUi("gün","day"));ModernSpinnerAdapter dueDayAdapter=new ModernSpinnerAdapter(this,dueDayOptions);dueDay.setAdapter(dueDayAdapter);dueDay.setBackground(strokeBg(c.bg,c.border,14));margins(dueDay,0,8,0,0);box.addView(dueDay,new LinearLayout.LayoutParams(-1,dp(52)));
        if(edit!=null){name.setText(edit.name);if(edit.bank!=null&&edit.bank.trim().length()>0){int bi=bankOptions.indexOf(edit.bank.trim());if(bi>=0)bankSpinner.setSelection(bi);}limit.setText(num(edit.limit));debt.setText(num(edit.debt));statement.setText(num(edit.statementDebt));statementDay.setSelection(Math.max(0,Math.min(30,edit.statementDay-1)));dueDay.setSelection(Math.max(0,Math.min(30,edit.dueDay-1)));}
        TextWatcher minWatcher=new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int count,int after){}public void onTextChanged(CharSequence s,int st,int before,int count){try{double lim=parseOptionalNum(limit),stb=parseOptionalNum(statement);double mp=turkiyeMinimumPayment(lim,stb);minimum.setText(s(R.string.ui_02c74d80e2)+money(mp));rateInfo.setText(turkiyeMinimumRateText(lim));}catch(Exception ignored){minimum.setText(s(R.string.ui_b7fb584ffb));}}public void afterTextChanged(Editable e){}};
        limit.addTextChangedListener(minWatcher);statement.addTextChangedListener(minWatcher);minWatcher.onTextChanged("",0,0,0);
        scroll.addView(box);outer.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout acts=row();Button cancel=dialogButton(s(R.string.ui_989f51ec41),c.muted,c.surface);Button save=dialogButton(edit==null?s(R.string.ui_57ea23145d):s(R.string.ui_61dce09793),Color.WHITE,c.blue);acts.addView(cancel,new LinearLayout.LayoutParams(0,dp(54),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(54),1);sp.setMargins(dp(8),0,0,0);acts.addView(save,sp);margins(acts,0,10,0,0);outer.addView(acts);
        cancel.setOnClickListener(v->dlg.dismiss());
        save.setOnClickListener(v->{try{String n=name.getText().toString().trim();if(n.length()==0)throw new Exception();String selectedBank=bankSpinner.getSelectedItem()==null?"":bankSpinner.getSelectedItem().toString().trim();String bankName=selectedBank;if(bankSpinner.getSelectedItemPosition()==0)bankName="";if(bankSpinner.getSelectedItemPosition()==bankOptions.size()-1)bankName=newBank.getText().toString().trim();if(bankName.length()>0&&!savedBanks.contains(bankName)){savedBanks.add(bankName);saveBanks();}double lim=parseNum(limit),deb=parseNum(debt),st=parseNum(statement),mi=st<=0?0:st*minimumPaymentRate(lim);if(lim<0||deb<0||st<0)throw new Exception();int sd=Math.max(1,statementDay.getSelectedItemPosition()+1),dd=Math.max(1,dueDay.getSelectedItemPosition()+1);if(edit==null){creditCards.add(new CreditCard(System.currentTimeMillis(),n,bankName,lim,deb,st,mi,sd,dd));}else{edit.name=n;edit.bank=bankName;edit.limit=lim;edit.debt=deb;edit.statementDebt=st;edit.minPayment=mi;edit.statementDay=sd;edit.dueDay=dd;}saveCreditCards();dlg.dismiss();showCreditCards();}catch(Exception ex){name.setError(s(R.string.ui_c56d9fd010));}});
        dlg.setContentView(outer);Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}
        dlg.setOnShowListener(x->{Window ww=dlg.getWindow();if(ww!=null){ww.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(440)),Math.min(dp(760),(int)(getResources().getDisplayMetrics().heightPixels*0.88f)));ww.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);}});dlg.show();
    }
    String num(double v){return String.format(Locale.US,"%.2f",v).replace(".",",");}
    double parseNum(EditText e){return parseMoneyText(e.getText().toString());}
    double parseOptionalNum(EditText e){return parseMoneyText(e.getText().toString());}
    int parseDay(EditText e,int fallback){String s=e.getText().toString().trim();if(s.length()==0)return fallback;int d=Integer.parseInt(s);if(d<1||d>31)throw new IllegalArgumentException();return d;}

    void installmentDialog(final CreditCard cc){
        Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(18),dp(18),dp(18),dp(12));outer.setBackground(bg(c.surface,24));
        TextView h=text("＋  "+s(R.string.ui_f052c295ad),20,c.text);h.setTypeface(null,1);outer.addView(h);TextView sub=text(cc.name,12,c.muted);margins(sub,0,3,0,10);outer.addView(sub);
        ScrollView scroll=new ScrollView(this);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        EditText merchant=modernEdit(s(R.string.ui_1f02feeead),c);box.addView(merchant,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText total=cardNumberEdit(s(R.string.ui_961a58c277),c);margins(total,0,8,0,0);box.addView(total,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView countLabel=text(s(R.string.ui_c0dcb4e14b),12,c.text);countLabel.setTypeface(null,Typeface.BOLD);margins(countLabel,0,8,0,5);box.addView(countLabel);
        Spinner count=new Spinner(this,Spinner.MODE_DROPDOWN);ArrayList<String> countOptions=new ArrayList<>();for(int i=1;i<=150;i++)countOptions.add(String.valueOf(i));ModernSpinnerAdapter countAdapter=new ModernSpinnerAdapter(this,countOptions);count.setAdapter(countAdapter);count.setBackground(strokeBg(c.bg,c.border,14));count.setSelection(0);margins(count,0,0,0,0);box.addView(count,new LinearLayout.LayoutParams(-1,dp(52)));
        EditText first=modernEdit(s(R.string.ui_807d604fc8),c);first.setText(df.format(new Date()));margins(first,0,8,0,0);box.addView(first,new LinearLayout.LayoutParams(-1,dp(54)));
        CheckBox addDebt=new CheckBox(this);addDebt.setText("Bu planı kart borcuna ekle");addDebt.setTextColor(c.text);addDebt.setTextSize(12);addDebt.setChecked(true);margins(addDebt,0,4,0,0);box.addView(addDebt);
        TextView debtHint=text("Yeni bir taksit planı oluşturuyorsan açık bırak. Mevcut bir planı sadece takip etmek için kapat.",10,c.muted);margins(debtHint,dp(4),0,0,6);box.addView(debtHint);
        Button reminder=dialogButton("🔔  "+s(R.string.ui_3c6c5ee77c),Color.WHITE,c.blue); reminder.setTextSize(12); margins(reminder,0,8,0,0); outer.addView(reminder,new LinearLayout.LayoutParams(-1,dp(48))); reminder.setOnClickListener(v->chooseCustomCardReminder(cc));
        EditText note=modernEdit(s(R.string.ui_aceec7a714),c);margins(note,0,8,0,0);box.addView(note,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView preview=text(s(R.string.ui_31c0799e11),12,c.muted);margins(preview,0,8,0,0);box.addView(preview);
        Runnable updatePreview=()->{try{double t=parseMoneyText(total.getText().toString());int n=count.getSelectedItemPosition()+1;if(t>0&&n>0)preview.setText(s(R.string.ui_eec62362ee)+money(t/n));else preview.setText(s(R.string.ui_31c0799e11));}catch(Exception ignored){preview.setText(s(R.string.ui_31c0799e11));}};
        TextWatcher tw=new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int countx){updatePreview.run();}public void afterTextChanged(Editable e){}};total.addTextChangedListener(tw);count.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){updatePreview.run();}});
        scroll.addView(box);outer.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout acts=row();Button cancel=dialogButton(s(R.string.ui_989f51ec41),c.muted,c.surface);Button save=dialogButton(s(R.string.ui_57ea23145d),Color.WHITE,c.green);acts.addView(cancel,new LinearLayout.LayoutParams(0,dp(54),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(54),1);sp.setMargins(dp(8),0,0,0);acts.addView(save,sp);margins(acts,0,10,0,0);outer.addView(acts);
        cancel.setOnClickListener(v->dlg.dismiss());save.setOnClickListener(v->{try{String m=merchant.getText().toString().trim();double t=parseNum(total);int n=count.getSelectedItemPosition()+1;if(m.length()==0||t<=0||n<=0)throw new Exception();String fd=first.getText().toString().trim();parseCardDateStrict(fd);Installment in=new Installment(System.currentTimeMillis(),cc.id,m,t,n,0,fd,note.getText().toString().trim(),addDebt.isChecked());installments.add(in);if(in.debtTracked)cc.debt+=t;saveCreditCards();saveInstallments();scheduleAllCardReminders();dlg.dismiss();showCreditCards();}catch(Exception e){merchant.setError(s(R.string.ui_f0a00b1f5c));}});
        dlg.setContentView(outer);Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}dlg.setOnShowListener(x->{Window ww=dlg.getWindow();if(ww!=null)ww.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(440)),Math.min(dp(690),(int)(getResources().getDisplayMetrics().heightPixels*0.84f)));});dlg.show();
    }
    void parseCardDateStrict(String s)throws Exception{Date d=new SimpleDateFormat("dd.MM.yyyy",Locale.US).parse(s);if(d==null)throw new Exception();}
    void showInstallmentSchedule(final Installment in){
        Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(18),dp(18),dp(18),dp(12));outer.setBackground(bg(c.surface,24));
        TextView h=text("📅  "+s(R.string.ui_bc692eb673),20,c.text);h.setTypeface(null,1);outer.addView(h);
        TextView sub=text(in.merchant+"  •  "+money(installmentMonthly(in))+" / "+s(R.string.ui_c2434749b8),12,c.muted);margins(sub,0,4,0,10);outer.addView(sub);
        if(in.note!=null && in.note.trim().length()>0){
            LinearLayout noteCard=card(c.bg,16);noteCard.setPadding(dp(13),dp(11),dp(13),dp(11));
            LinearLayout noteHead=row();
            TextView noteIcon=text("▤",15,c.blue);noteIcon.setGravity(Gravity.CENTER);noteIcon.setBackground(bg(c.blue2,12));noteHead.addView(noteIcon,new LinearLayout.LayoutParams(dp(34),dp(34)));
            TextView noteTitle=text(s(R.string.ui_9a03ed510f),12,c.text);noteTitle.setTypeface(null,Typeface.BOLD);margins(noteTitle,dp(10),0,0,0);noteHead.addView(noteTitle,new LinearLayout.LayoutParams(0,dp(34),1));
            noteCard.addView(noteHead);
            TextView noteText=text(in.note.trim(),13,c.text);noteText.setLineSpacing(0,1.08f);margins(noteText,dp(44),7,0,0);noteCard.addView(noteText);
            margins(noteCard,0,0,0,10);outer.addView(noteCard);
        }
        ScrollView scroll=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);
        for(int i=0;i<in.count;i++){boolean paid=i<in.paidCount;LinearLayout r=row();r.setPadding(dp(10),dp(8),dp(10),dp(8));r.setBackground(strokeBg(c.bg,c.border,12));TextView n=text((i+1)+". "+installmentDateText(in,i),13,c.text);n.setTypeface(null,1);r.addView(n,new LinearLayout.LayoutParams(0,dp(42),1));TextView amount=text(money(installmentMonthly(in)),12,c.text);r.addView(amount,new LinearLayout.LayoutParams(dp(105),dp(42)));TextView status=text(paid?"✓ "+s(R.string.ui_98338f84da):s(R.string.ui_4eccd8a5eb),11,paid?c.green:c.muted);status.setGravity(Gravity.CENTER);r.addView(status,new LinearLayout.LayoutParams(dp(78),dp(42)));margins(r,0,2,0,2);list.addView(r);}
        scroll.addView(list);outer.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        Button close=dialogButton(s(R.string.ui_05a86eba57),c.muted,c.surface);margins(close,0,10,0,0);outer.addView(close);close.setOnClickListener(v->dlg.dismiss());
        dlg.setContentView(outer);Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}dlg.setOnShowListener(x->{Window ww=dlg.getWindow();if(ww!=null)ww.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(440)),Math.min(dp(720),(int)(getResources().getDisplayMetrics().heightPixels*0.84f)));});dlg.show();
    }
    void syncInstallmentPaidCounts(){
        // Yeni sistemde genel kart ödemeleri taksit planlarını otomatik değiştirmez.
        // Sadece "Taksiti Öde" işlemi ilgili planın paidCount değerini artırır.
        // Eski verilerdeki paidCount değerleri korunur.
    }

    CreditCard findCard(long id){for(CreditCard c:creditCards)if(c.id==id)return c;return null;}
    void installmentOptionsDialog(final Installment in){
        Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout o=new LinearLayout(this);o.setOrientation(LinearLayout.VERTICAL);o.setPadding(dp(18),dp(18),dp(18),dp(12));o.setBackground(bg(c.surface,24));
        TextView h=text("Taksit Planı",20,c.text);h.setTypeface(null,Typeface.BOLD);o.addView(h);TextView sub=text(in.merchant+" • "+money(installmentMonthly(in))+" × "+in.count,12,c.muted);margins(sub,0,4,0,12);o.addView(sub);
        Button schedule=button("Ödeme planını görüntüle",c.blue);o.addView(schedule,new LinearLayout.LayoutParams(-1,dp(48)));
        Button edit=button("Planı düzenle",c.surface);edit.setTextColor(c.text);margins(edit,0,7,0,0);o.addView(edit,new LinearLayout.LayoutParams(-1,dp(48)));
        Button del=button("Planı kaldır",c.red);margins(del,0,7,0,0);o.addView(del,new LinearLayout.LayoutParams(-1,dp(48)));
        Button cancel=dialogButton("Vazgeç",c.muted,c.surface);margins(cancel,0,8,0,0);o.addView(cancel,new LinearLayout.LayoutParams(-1,dp(48)));
        schedule.setOnClickListener(v->{dlg.dismiss();showInstallmentSchedule(in);});
        edit.setOnClickListener(v->{dlg.dismiss();installmentEditDialog(in);});
        del.setOnClickListener(v->{dlg.dismiss();confirmDeleteInstallment(in);});cancel.setOnClickListener(v->dlg.dismiss());
        dlg.setContentView(o);dlg.show();Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);}
    }
    void confirmDeleteInstallment(final Installment in){Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout o=new LinearLayout(this);o.setOrientation(LinearLayout.VERTICAL);o.setPadding(dp(18),dp(18),dp(18),dp(12));o.setBackground(bg(c.surface,24));TextView h=text("Taksit planını kaldır?",20,c.text);h.setTypeface(null,1);o.addView(h);TextView sub=text("Bu işlem sadece planı takip listesinden kaldırır. Daha önce yapılan kart ödemeleri silinmez.",12,c.muted);margins(sub,0,6,0,0);o.addView(sub);LinearLayout a=row();Button cancel=dialogButton("Vazgeç",c.muted,c.surface);Button del=dialogButton("Planı Kaldır",Color.WHITE,c.red);a.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(52),1);sp.setMargins(dp(8),0,0,0);a.addView(del,sp);margins(a,0,14,0,0);o.addView(a);cancel.setOnClickListener(v->dlg.dismiss());del.setOnClickListener(v->{installments.remove(in);saveInstallments();dlg.dismiss();showCreditCards();});dlg.setContentView(o);dlg.show();Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);}}
    void installmentEditDialog(final Installment in){
        Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout o=new LinearLayout(this);o.setOrientation(LinearLayout.VERTICAL);o.setPadding(dp(18),dp(18),dp(18),dp(12));o.setBackground(bg(c.surface,24));TextView h=text("Taksit Planını Düzenle",20,c.text);h.setTypeface(null,1);o.addView(h);
        EditText merchant=modernEdit("Açıklama",c);merchant.setText(in.merchant);o.addView(merchant,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText total=cardNumberEdit("Toplam tutar",c);setMoneyInput(total,in.total);margins(total,0,7,0,0);o.addView(total,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText first=modernEdit("İlk taksit tarihi",c);first.setText(in.firstDate);margins(first,0,7,0,0);o.addView(first,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText note=modernEdit("Not",c);note.setText(in.note);margins(note,0,7,0,0);o.addView(note,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView info=text("Taksit sayısı ve daha önce ödenen taksitler korunur.",10,c.muted);margins(info,0,5,0,0);o.addView(info);
        LinearLayout a=row();Button cancel=dialogButton("Vazgeç",c.muted,c.surface);Button save=dialogButton("Kaydet",Color.WHITE,c.green);a.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(52),1);sp.setMargins(dp(8),0,0,0);a.addView(save,sp);margins(a,0,10,0,0);o.addView(a);cancel.setOnClickListener(v->dlg.dismiss());save.setOnClickListener(v->{try{String m=merchant.getText().toString().trim();double t=parseNum(total);String fd=first.getText().toString().trim();parseCardDateStrict(fd);if(m.isEmpty()||t<=0)throw new Exception();double oldRemaining=installmentMonthly(in)*Math.max(0,in.count-in.paidCount);double newMonthly=t/Math.max(1,in.count);in.merchant=m;in.total=t;in.firstDate=fd;in.note=note.getText().toString().trim();CreditCard cc=findCard(in.cardId);if(cc!=null&&in.debtTracked)cc.debt+=newMonthly*Math.max(0,in.count-in.paidCount)-oldRemaining;saveCreditCards();saveInstallments();dlg.dismiss();showCreditCards();}catch(Exception e){merchant.setError("Bilgileri kontrol et");}});dlg.setContentView(o);dlg.show();Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);}}

    CardPayment findCardPayment(long id){for(CardPayment cp:cardPayments)if(cp.id==id)return cp;return null;}
    void confirmDeleteCreditCard(final CreditCard cc){Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout o=new LinearLayout(this);o.setOrientation(LinearLayout.VERTICAL);o.setPadding(dp(18),dp(18),dp(18),dp(12));o.setBackground(bg(c.surface,24));TextView h=text("💳  "+s(R.string.ui_bb6657ccf5),20,c.text);h.setTypeface(null,1);o.addView(h);TextView sub=text(cc.name+" "+s(R.string.ui_9a8e5ab580),12,c.muted);margins(sub,0,5,0,0);o.addView(sub);LinearLayout a=row();Button cancel=dialogButton(s(R.string.ui_9dc74649ac),c.muted,c.surface);Button del=dialogButton(s(R.string.ui_e55f244f5e),Color.WHITE,c.red);a.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(52),1);sp.setMargins(dp(8),0,0,0);a.addView(del,sp);margins(a,0,14,0,0);o.addView(a);cancel.setOnClickListener(v->dlg.dismiss());del.setOnClickListener(v->{creditCards.remove(cc);for(int i=installments.size()-1;i>=0;i--)if(installments.get(i).cardId==cc.id)installments.remove(i);for(int i=cardPayments.size()-1;i>=0;i--)if(cardPayments.get(i).cardId==cc.id)cardPayments.remove(i);for(int i=txs.size()-1;i>=0;i--)if(!txs.get(i).isIncome&&((txs.get(i).creditCard&&txs.get(i).cardId==cc.id)||(txs.get(i).paymentId!=0&&findCardPayment(txs.get(i).paymentId)!=null)))txs.remove(i);save();saveCreditCards();saveInstallments();saveCardPayments();dlg.dismiss();showCreditCards();});dlg.setContentView(o);Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}dlg.show();w=dlg.getWindow();if(w!=null){WindowManager.LayoutParams lp=w.getAttributes();lp.width=Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430));w.setAttributes(lp);}}


    void showDigitalFinanceAssistant(){
        enterScreen("assistant");
        marketsVisible=false;
        currentPage=3;
        base(s(R.string.ui_140e31ff15));

        double income=sum(true), expense=sum(false), net=income-expense;
        double cardDebt=0, cardLimit=0;
        for(CreditCard cc:creditCards){cardDebt+=Math.max(0,cc.debt);cardLimit+=Math.max(0,cc.limit);}
        double savings=0, target=0;
        for(Goal g:goals){savings+=Math.min(g.saved,g.target);target+=Math.max(0,g.target);}
        int savingRate=income<=0?0:(int)Math.round(Math.max(0,net)*100.0/income);
        double cardRate=cardLimit<=0?0:cardDebt*100.0/cardLimit;
        int health=68;
        health+=(net>0?12:-10);
        health+=(savingRate>=20?10:(savingRate>=10?5:0));
        health-=(cardRate>80?15:(cardRate>50?8:0));
        health=Math.max(0,Math.min(100,health));

        LinearLayout hero=card(darkMode?Color.rgb(10,35,58):Color.rgb(19,73,112),22);
        hero.setPadding(dp(20),dp(20),dp(20),dp(20));
        TextView ht=text(s(R.string.ui_76a87d1f62),13,Color.WHITE);hero.addView(ht);
        TextView hs=text(String.valueOf(health)+"/100",38,Color.WHITE);hs.setTypeface(null,Typeface.BOLD);margins(hs,0,5,0,2);hero.addView(hs);
        String healthMsg=health>=80?s(R.string.ui_ed44314dfb):
                health>=60?s(R.string.ui_7e9b44d0c9):
                s(R.string.ui_2a4a075e4b);
        TextView hm=text(healthMsg,13,Color.WHITE);hm.setAlpha(.88f);hero.addView(hm);
        addProgressBar(hero,health,Color.WHITE);margins(hero,0,0,0,14);content.addView(hero);

        TextView title=text(s(R.string.ui_5e0f98fa1c),20,C().text);title.setTypeface(null,Typeface.BOLD);margins(title,2,8,2,8);content.addView(title);
        LinearLayout grid=row();
        String[] vals={money(income),money(expense),money(net),money(cardDebt)};
        String[] labs={s(R.string.ui_6c41c144f4),s(R.string.ui_2dcbf4a0f5),s(R.string.ui_d3c8c61950),s(R.string.ui_25876eb3fa)};
        int[] cols={C().green,C().red,net>=0?C().blue:C().red,C().blue};
        for(int i=0;i<4;i++){LinearLayout b=card(C().surface,16);b.setPadding(dp(12),dp(12),dp(12),dp(12));TextView v=text(vals[i],17,cols[i]);v.setTypeface(null,Typeface.BOLD);b.addView(v);TextView l=text(labs[i],11,C().muted);margins(l,0,3,0,0);b.addView(l);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(2),0,dp(2),0);grid.addView(b,lp);}
        content.addView(grid);

        TextView aiTitle=text(s(R.string.ui_60b07f1fff),20,C().text);aiTitle.setTypeface(null,Typeface.BOLD);margins(aiTitle,2,18,2,8);content.addView(aiTitle);
        LinearLayout insight=card(C().surface,18);
        String insight1=expense>income && income>0
                ?s(R.string.ui_44c25b4dc1)
                :s(R.string.ui_ed0fc2927d);
        String insight2=cardRate>=70
                ?s(R.string.ui_475eaafce1)
                :s(R.string.ui_b1c82c9a0b);
        TextView i1=text("💡  "+insight1,13,C().text);i1.setPadding(dp(2),dp(4),dp(2),dp(10));insight.addView(i1);
        TextView i2=text("💳  "+insight2,13,C().text);i2.setPadding(dp(2),dp(4),dp(2),dp(4));insight.addView(i2);margins(insight,0,0,0,12);content.addView(insight);

        TextView fc=text(s(R.string.ui_a0dd775923),20,C().text);fc.setTypeface(null,Typeface.BOLD);margins(fc,2,4,2,8);content.addView(fc);
        Calendar now=Calendar.getInstance();int day=Math.max(1,now.get(Calendar.DAY_OF_MONTH));int days=now.getActualMaximum(Calendar.DAY_OF_MONTH);
        double forecastIn=income<=0?0:income*days/day, forecastOut=expense<=0?0:expense*days/day, forecastNet=forecastIn-forecastOut;
        LinearLayout forecast=card(darkMode?Color.rgb(25,45,60):Color.rgb(239,247,252),18);
        TextView f1=text(s(R.string.ui_f74bb0b368)+money(forecastIn),14,C().green);f1.setTypeface(null,Typeface.BOLD);forecast.addView(f1);
        TextView f2=text(s(R.string.ui_29f0e15d44)+money(forecastOut),14,C().red);margins(f2,0,6,0,6);forecast.addView(f2);
        TextView f3=text(s(R.string.ui_91b7d67bb0)+money(forecastNet),21,forecastNet>=0?C().blue:C().red);f3.setTypeface(null,Typeface.BOLD);forecast.addView(f3);
        TextView fn=text(s(R.string.ui_ae64bc8d32),10,C().muted);margins(fn,0,7,0,0);forecast.addView(fn);margins(forecast,0,0,0,12);content.addView(forecast);

        TextView ca=text(s(R.string.ui_807975ce77),20,C().text);ca.setTypeface(null,Typeface.BOLD);margins(ca,2,4,2,8);content.addView(ca);
        LinearLayout ccbox=card(C().surface,18);
        TextView cct=text(s(R.string.ui_4c74d47925)+money(cardLimit)+"\n"+s(R.string.ui_076d524653)+money(cardDebt),14,C().text);ccbox.addView(cct);
        TextView pct=text("%"+Math.round(cardRate)+" "+s(R.string.ui_6ba989714b),13,cardRate>70?C().red:C().green);pct.setTypeface(null,Typeface.BOLD);margins(pct,0,8,0,4);ccbox.addView(pct);addProgressBar(ccbox,(int)Math.min(100,Math.round(cardRate)),cardRate>70?C().red:C().blue);
        TextView cch=text(creditCards.size()+" "+s(R.string.ui_26316a9cf5)+"  •  "+installments.size()+" "+s(R.string.ui_af8a89fa43),11,C().muted);margins(cch,0,7,0,0);ccbox.addView(cch);margins(ccbox,0,0,0,12);content.addView(ccbox);

        TextView gt=text(s(R.string.ui_f79d757d87),20,C().text);gt.setTypeface(null,Typeface.BOLD);margins(gt,2,4,2,8);content.addView(gt);
        LinearLayout gb=card(C().surface,18);
        TextView g1=text(money(savings)+" / "+money(target),21,C().blue);g1.setTypeface(null,Typeface.BOLD);gb.addView(g1);
        int gp=target<=0?0:(int)Math.round(savings*100/target);TextView g2=text("%"+gp+" "+s(R.string.ui_da8d090aeb),11,C().muted);margins(g2,0,5,0,3);gb.addView(g2);addProgressBar(gb,gp,C().blue);
        content.addView(gb);
    }

    void showMenu(){
        enterScreen("menu");
        marketsVisible=false;
        currentPage=3;
        base(s(R.string.ui_a6cc92d718));
        Colors c=C();

        LinearLayout hero=card(darkMode?Color.rgb(18,43,61):Color.rgb(235,245,255),22);
        hero.setPadding(dp(18),dp(18),dp(18),dp(16));
        LinearLayout heroTop=row();
        SimpleIconView mi=new SimpleIconView(this,"trend",c.blue);
        mi.setBackground(bg(darkMode?Color.rgb(28,67,92):Color.rgb(216,235,255),16));
        heroTop.addView(mi,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout heroText=new LinearLayout(this);heroText.setOrientation(LinearLayout.VERTICAL);heroText.setPadding(dp(12),0,0,0);
        TextView ht=text(s(R.string.ui_0bd2214f60),19,c.text);ht.setTypeface(null,Typeface.BOLD);heroText.addView(ht);
        TextView hs=text(s(R.string.ui_5744675181),11,c.muted);margins(hs,0,3,0,0);heroText.addView(hs);
        heroTop.addView(heroText,new LinearLayout.LayoutParams(0,-2,1));
        hero.addView(heroTop);

        double income=sum(true), expense=sum(false), net=income-expense;
        LinearLayout metrics=row();margins(metrics,0,16,0,0);
        menuMetric(metrics,s(R.string.ui_6c41c144f4),money(income),c.green);
        menuMetric(metrics,s(R.string.ui_47e07dfbe1),money(expense),c.red);
        menuMetric(metrics,s(R.string.ui_cef3b68516),money(net),net>=0?c.blue:c.red);
        hero.addView(metrics);
        margins(hero,0,0,0,16);content.addView(hero);

        menuSectionTitle(s(R.string.ui_f584704aa9));
        menuItem2("list",s(R.string.ui_5115cef58b),s(R.string.ui_f262bb4ac8),()->showTransactions());
        menuItem2("savings",trUi("Hesaplarım","My Accounts"),trUi("Banka, nakit ve diğer hesaplarını yönet","Manage bank, cash and other accounts"),()->showAccounts());
        menuItem2("stats",s(R.string.ui_ea7c2aa969),s(R.string.ui_aa6dce5f8b),()->showStats());
        menuItem2("trend",s(R.string.ui_c89739552b),s(R.string.ui_1474556b96),()->showMarkets());

        menuSectionTitle(s(R.string.ui_4942be744c));
        menuFinbiItem();
        menuItem2("calendar",s(R.string.ui_26e5e96c24),s(R.string.ui_97ba2a7943),()->showRecurringPayments());
        menuItem2("stats",trUi("Bütçeler","Budgets"),trUi("Genel ve kategori bütçelerini takip et","Track overall and category budgets"),()->showBudgets());
        menuItem2("calendar",trUi("Abonelikler","Subscriptions"),trUi("Aboneliklerini, tutarlarını ve ödeme günlerini takip et","Track subscriptions, amounts, and billing days"),()->showSubscriptions());
        menuItem2("target",s(R.string.ui_f79d757d87),s(R.string.ui_edb1e6ff98),()->showGoals());

        menuSectionTitle(s(R.string.ui_9352c6d3f6));
        menuItem2("refresh",s(R.string.ui_7f53713331),s(R.string.ui_fa673e1150),()->showDataTransfer());
        menuItem2("info",guideText("guide_title"),guideText("guide_intro"),()->showGuide());
        menuItem2("other",s(R.string.ui_e26cb640b4),s(R.string.ui_df67d46e7f),()->showSettings());
        menuItem2("info",s(R.string.ui_6e7a9e67fa),s(R.string.ui_6adf5dd178),()->showAbout());

        TextView version=text("Finway v"+appVersionName()+"  •  build "+appVersionCode(),11,c.muted);version.setGravity(Gravity.CENTER);margins(version,0,12,0,6);content.addView(version);
        LinearLayout danger=card(darkMode?Color.rgb(58,28,32):Color.rgb(255,244,244),16);danger.setPadding(dp(14),dp(12),dp(14),dp(12));
        TextView dangerTitle=text(s(R.string.ui_2964d564ec),13,c.text);dangerTitle.setTypeface(null,Typeface.BOLD);danger.addView(dangerTitle);
        TextView dangerInfo=text(s(R.string.ui_2d8739543f),10,c.muted);margins(dangerInfo,0,3,0,8);danger.addView(dangerInfo);
        Button clear=button(s(R.string.ui_a52166d3d5),c.red);clear.setTextSize(12);danger.addView(clear,new LinearLayout.LayoutParams(-1,dp(44)));clear.setOnClickListener(v->clearAll());
        margins(danger,0,0,0,8);content.addView(danger);
    }

    void menuMetric(LinearLayout parent,String label,String value,int color){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(9),dp(8),dp(9),dp(7));box.setBackground(bg(darkMode?Color.rgb(24,51,67):Color.WHITE,14));
        TextView v=text(value,13,color);v.setTypeface(null,Typeface.BOLD);box.addView(v);
        TextView l=text(label,9,C().muted);margins(l,0,2,0,0);box.addView(l);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(52),1);lp.setMargins(dp(3),0,dp(3),0);parent.addView(box,lp);
    }

    void menuSectionTitle(String title){
        TextView h=text(title,13,C().muted);h.setTypeface(null,Typeface.BOLD);margins(h,2,4,2,7);content.addView(h);
    }

    private String finbiMenuTitle(){
        if("en".equals(language)) return "Finbi (Digital Finance Assistant)";
        if("fr".equals(language)) return "Finbi (Assistant financier numérique)";
        if("de".equals(language)) return "Finbi (Digitaler Finanzassistent)";
        if("ru".equals(language)) return "Finbi (Цифровой финансовый помощник)";
        if("ja".equals(language)) return "Finbi（デジタル金融アシスタント）";
        if("zh".equals(language)) return "Finbi（数字财务助手）";
        if("ar".equals(language)) return "Finbi (المساعد المالي الرقمي)";
        if("el".equals(language)) return "Finbi (Ψηφιακός οικονομικός βοηθός)";
        if("es".equals(language)) return "Finbi (Asistente financiero digital)";
        if("it".equals(language)) return "Finbi (Assistente finanziario digitale)";
        return "Finbi (Dijital Finans Asistanı)";
    }

    private String finbiToggleSubtitle(){
        if("en".equals(language)) return "Open or close the floating Finbi assistant";
        if("fr".equals(language)) return "Afficher ou masquer l’assistant Finbi flottant";
        if("de".equals(language)) return "Den schwebenden Finbi-Assistenten ein- oder ausblenden";
        if("ru".equals(language)) return "Показать или скрыть плавающего помощника Finbi";
        if("ja".equals(language)) return "フローティングFinbiアシスタントの表示・非表示";
        if("zh".equals(language)) return "显示或隐藏悬浮的 Finbi 助手";
        if("ar".equals(language)) return "إظهار أو إخفاء مساعد Finbi العائم";
        if("el".equals(language)) return "Εμφάνιση ή απόκρυψη του αιωρούμενου βοηθού Finbi";
        if("es".equals(language)) return "Mostrar u ocultar el asistente flotante Finbi";
        if("it".equals(language)) return "Mostra o nascondi l’assistente Finbi fluttuante";
        return "Yüzen Finbi asistanını aç veya kapat";
    }

    void menuFinbiItem(){
        Colors c=C();
        LinearLayout item=row(); item.setPadding(dp(12),dp(10),dp(9),dp(10));
        item.setBackground(strokeBg(c.surface,c.border,16));
        SimpleIconView ic=new SimpleIconView(this,"trend",c.blue);
        ic.setBackground(bg(darkMode?Color.rgb(24,54,73):Color.rgb(235,244,255),13));
        item.addView(ic,new LinearLayout.LayoutParams(dp(44),dp(44)));
        LinearLayout tx=new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL); tx.setPadding(dp(11),0,dp(6),0);
        TextView t=text(finbiMenuTitle(),14,c.text); t.setTypeface(null,Typeface.BOLD); tx.addView(t);
        TextView st=text(finbiToggleSubtitle(),10,c.muted); margins(st,0,3,0,0); tx.addView(st);
        item.addView(tx,new LinearLayout.LayoutParams(0,-2,1));
        Switch sw=new Switch(this);
        finbiMenuSwitch=sw;
        sw.setChecked(finbiEnabled); sw.setContentDescription(finbiEnabled?"Finbi açık":"Finbi kapalı");
        item.addView(sw,new LinearLayout.LayoutParams(dp(54),dp(48)));
        margins(item,0,0,0,7); content.addView(item);
        sw.setOnCheckedChangeListener((button,checked)->setFinbiEnabled(checked));
        item.setOnClickListener(v->{ if(finbiEnabled) showFinbiChat(); });
    }

    private void setFinbiEnabled(boolean enabled){
        finbiEnabled=enabled;
        getPreferences(0).edit().putBoolean("finbi_enabled",enabled).apply();
        if(finbiMenuSwitch!=null && finbiMenuSwitch.isChecked()!=enabled){
            finbiMenuSwitch.setChecked(enabled);
            finbiMenuSwitch.setContentDescription(enabled?"Finbi açık":"Finbi kapalı");
        }
        ViewGroup host=(ViewGroup)findViewById(android.R.id.content);
        if(enabled){ installFinbiBubble(); }
        else if(finbiOverlay!=null){ ViewParent parent=finbiOverlay.getParent(); if(parent instanceof ViewGroup)((ViewGroup)parent).removeView(finbiOverlay); finbiOverlay=null; finbiBubble=null; }
    }

    void menuItem2(String icon,String title,String subtitle,final Runnable r){
        Colors c=C();LinearLayout item=row();item.setPadding(dp(12),dp(10),dp(9),dp(10));item.setBackground(strokeBg(c.surface,c.border,16));
        SimpleIconView ic=new SimpleIconView(this,icon,c.blue);ic.setBackground(bg(darkMode?Color.rgb(24,54,73):Color.rgb(235,244,255),13));item.addView(ic,new LinearLayout.LayoutParams(dp(44),dp(44)));
        LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.setPadding(dp(11),0,dp(6),0);
        TextView t=text(title,14,c.text);t.setTypeface(null,Typeface.BOLD);tx.addView(t);
        TextView st=text(subtitle,10,c.muted);margins(st,0,3,0,0);tx.addView(st);item.addView(tx,new LinearLayout.LayoutParams(0,-2,1));
        SimpleIconView ar=new SimpleIconView(this,"arrow",c.muted);item.addView(ar,new LinearLayout.LayoutParams(dp(26),dp(36)));
        margins(item,0,0,0,7);content.addView(item);
        if(r!=null)item.setOnClickListener(v->r.run());
    }

    void menuItem(String s,final Runnable r){
        // Kept for compatibility with older callers.
        menuItem2("other",s,"",r);
    }
    private JSONObject categoryBudgetsJson(){
        try{return new JSONObject(getPreferences(0).getString("categoryBudgets","{}"));}catch(Exception e){return new JSONObject();}
    }
    private double categoryBudget(String category){
        if(category==null)return 0; try{return Math.max(0,categoryBudgetsJson().optDouble(category,0));}catch(Exception e){return 0;}
    }
    private void saveCategoryBudget(String category,double amount){
        try{JSONObject o=categoryBudgetsJson();if(amount<=0)o.remove(category);else o.put(category,amount);getPreferences(0).edit().putString("categoryBudgets",o.toString()).apply();}catch(Exception ignored){}
    }
    private String budgetCategoryLabel(String cat){
        if("Market".equals(cat))return trUi("Market","Groceries");
        if("Kredi Kartı".equals(cat))return trUi("Kredi Kartı","Credit Card");
        if("Yemek".equals(cat))return trUi("Yemek","Food");
        if("Fatura".equals(cat))return trUi("Fatura","Bills");
        if("Eğlence".equals(cat))return trUi("Eğlence","Entertainment");
        if("Ulaşım".equals(cat))return trUi("Ulaşım","Transport");
        if("Ev".equals(cat))return trUi("Ev","Home");
        if("Sağlık".equals(cat))return trUi("Sağlık","Health");
        if("Eğitim".equals(cat))return trUi("Eğitim","Education");
        if("Giyim".equals(cat))return trUi("Giyim","Clothing");
        if("Seyahat".equals(cat))return trUi("Seyahat","Travel");
        if("Yakıt".equals(cat))return trUi("Yakıt","Fuel");
        if("Diğer".equals(cat))return trUi("Diğer","Other");
        if("Abonelik".equals(cat))return trUi("Abonelik","Subscription");
        return cat;
    }
    private ArrayList<String> budgetCategories(){
        LinkedHashSet<String> set=new LinkedHashSet<>();
        for(Category c:categories) if(c!=null&&c.name!=null&&!"Kredi Kartı".equals(c.name)) set.add(c.name);
        for(Tx t:txs) if(!t.isIncome&&t.cat!=null&&!t.cat.trim().isEmpty()) set.add(t.cat.trim());
        set.add("Abonelik");
        return new ArrayList<>(set);
    }
    void showBudgets(){
        enterScreen("budgets");marketsVisible=false;currentPage=3;base(trUi("Bütçeler","Budgets"));Colors c=C();
        LinearLayout hero=card(darkMode?Color.rgb(24,45,62):Color.rgb(239,248,255),22);hero.setPadding(dp(18),dp(16),dp(18),dp(16));
        TextView h=text(trUi("Bütçeni kontrol et","Keep your budget under control"),20,c.text);h.setTypeface(null,Typeface.BOLD);hero.addView(h);
        TextView sub=text(trUi("Genel bütçene ek olarak kategori bazında sınırlar belirleyebilirsin.","Set category limits in addition to your overall monthly budget."),11,c.muted);margins(sub,0,4,0,0);hero.addView(sub);margins(hero,0,0,0,12);content.addView(hero);
        double overall=monthlyBudget(),used=sum(false);LinearLayout overallCard=card(c.surface,18);overallCard.setPadding(dp(16),dp(14),dp(16),dp(14));
        TextView ot=text(trUi("Aylık genel bütçe","Overall monthly budget"),15,c.text);ot.setTypeface(null,Typeface.BOLD);overallCard.addView(ot);
        TextView ov=text(overall>0?money(used)+" / "+money(overall):trUi("Tanımlanmadı","Not set"),18,overall>0?(used>overall?c.red:c.green):c.muted);ov.setTypeface(null,Typeface.BOLD);margins(ov,0,5,0,0);overallCard.addView(ov);
        Button ob=button(trUi("Genel bütçeyi düzenle","Edit overall budget"),c.blue);margins(ob,0,9,0,0);overallCard.addView(ob);ob.setOnClickListener(v->budgetDialog());content.addView(overallCard);
        margins(overallCard,0,0,0,14);
        Button add=button("＋  "+trUi("Kategori bütçesi ekle","Add category budget"),c.green);margins(add,0,0,0,12);content.addView(add);add.setOnClickListener(v->categoryBudgetDialog(null));
        sectionHeader(content,trUi("Kategori bütçeleri","Category budgets"),false,null);
        JSONObject saved=categoryBudgetsJson();ArrayList<String> cats=budgetCategories();boolean any=false;
        for(String cat:cats){double lim=saved.optDouble(cat,0);if(lim<=0)continue;any=true;double spent=finbiCategoryTotal(viewMonth,cat);int pct=lim<=0?0:Math.min(100,(int)Math.round(spent*100.0/lim));LinearLayout card=card(c.surface,16);card.setPadding(dp(15),dp(13),dp(15),dp(13));
            LinearLayout r=row();TextView name=text(budgetCategoryLabel(cat),15,c.text);name.setTypeface(null,Typeface.BOLD);r.addView(name,new LinearLayout.LayoutParams(0,-2,1));TextView val=text(money(spent)+" / "+money(lim),12,pct>=100?c.red:c.muted);r.addView(val);card.addView(r);
            ProgressBar pb=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);pb.setMax(100);pb.setProgress(pct);pb.setProgressTintList(android.content.res.ColorStateList.valueOf(pct>=100?c.red:(pct>=80?Color.rgb(245,158,11):c.green)));pb.setBackgroundTintList(android.content.res.ColorStateList.valueOf(c.border));margins(pb,0,7,0,5);card.addView(pb);
            TextView meta=text(pct>=100?trUi("Bütçe aşıldı","Budget exceeded"):trUi("Kalan ","Remaining ")+money(Math.max(0,lim-spent)),11,pct>=100?c.red:c.muted);card.addView(meta);
            card.setOnClickListener(v->categoryBudgetDialog(cat));margins(card,0,0,0,8);content.addView(card);
        }
        if(!any){TextView empty=text(trUi("Henüz kategori bütçesi tanımlanmadı.","No category budgets have been set yet."),12,c.muted);empty.setGravity(Gravity.CENTER);margins(empty,0,8,0,0);content.addView(empty);}
    }
    private void categoryBudgetDialog(final String existing){
        Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout o=new LinearLayout(this);o.setOrientation(LinearLayout.VERTICAL);o.setPadding(dp(18),dp(18),dp(18),dp(12));o.setBackground(bg(c.surface,24));
        TextView h=text(existing==null?trUi("Kategori bütçesi","Category budget"):trUi("Kategori bütçesini düzenle","Edit category budget"),20,c.text);h.setTypeface(null,Typeface.BOLD);o.addView(h);
        TextView lab=text(trUi("Kategori","Category"),12,c.muted);margins(lab,0,10,0,5);o.addView(lab);
        ArrayList<String> cats=budgetCategories();ArrayList<String> labels=new ArrayList<>();for(String cat:cats)labels.add(budgetCategoryLabel(cat));Spinner sp=new Spinner(this,Spinner.MODE_DROPDOWN);ModernSpinnerAdapter ad=new ModernSpinnerAdapter(this,labels);sp.setAdapter(ad);if(existing!=null){int pos=cats.indexOf(existing);if(pos>=0)sp.setSelection(pos);}o.addView(sp,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText amount=modernEdit(trUi("Aylık limit","Monthly limit"),c);amount.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);attachNumberFormatter(amount);if(existing!=null&&categoryBudget(existing)>0)setMoneyInput(amount,categoryBudget(existing));margins(amount,0,12,0,0);o.addView(amount,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView hint=text(trUi("0 girersen bu kategori bütçesi kaldırılır.","Enter 0 to remove this category budget."),11,c.muted);margins(hint,0,6,0,0);o.addView(hint);
        LinearLayout acts=row();Button cancel=dialogButton(trUi("Vazgeç","Cancel"),c.muted,c.surface);Button save=dialogButton(trUi("Kaydet","Save"),Color.WHITE,c.blue);acts.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams sp2=new LinearLayout.LayoutParams(0,dp(52),1);sp2.setMargins(dp(8),0,0,0);acts.addView(save,sp2);margins(acts,0,12,0,0);o.addView(acts);
        cancel.setOnClickListener(v->dlg.dismiss());save.setOnClickListener(v->{try{int p=sp.getSelectedItemPosition();if(p<0||p>=cats.size())throw new Exception();double a=amount.getText().toString().trim().isEmpty()?0:parseMoneyText(amount.getText().toString());if(a<0||a>1e12)throw new Exception();saveCategoryBudget(cats.get(p),a);dlg.dismiss();showBudgets();}catch(Exception e){amount.setError(trUi("Geçerli bir tutar girin","Enter a valid amount"));}});
        dlg.setContentView(o);dlg.show();Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);}
    }

    private JSONArray subscriptionArray(){try{return new JSONArray(getPreferences(0).getString("subscriptions","[]"));}catch(Exception e){return new JSONArray();}}
    private String subscriptionCategoryLabel(String cat){return "Abonelik".equals(cat)?trUi("Abonelik","Subscription"):budgetCategoryLabel(cat);}
    void showSubscriptions(){
        enterScreen("subscriptions");marketsVisible=false;currentPage=3;base(trUi("Abonelikler","Subscriptions"));Colors c=C();JSONArray a=subscriptionArray();double total=0;int active=0;
        for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null||!o.optBoolean("active",true))continue;active++;total+=Math.max(0,o.optDouble("amount",0));}
        LinearLayout hero=card(darkMode?Color.rgb(25,40,55):Color.rgb(240,248,255),22);hero.setPadding(dp(18),dp(16),dp(18),dp(16));TextView h=text(trUi("Aboneliklerini kontrol et","Keep track of your subscriptions"),20,c.text);h.setTypeface(null,Typeface.BOLD);hero.addView(h);TextView sub=text(trUi("Tutarları, ödeme günlerini ve bu ay ödenip ödenmediğini takip et.","Track amounts, billing days, and whether each subscription has been paid this month."),11,c.muted);margins(sub,0,4,0,0);hero.addView(sub);margins(hero,0,0,0,12);content.addView(hero);
        LinearLayout metric=card(c.surface,16);metric.setPadding(dp(14),dp(12),dp(14),dp(12));metric.addView(text(trUi("Aktif abonelik","Active subscriptions"),11,c.muted));TextView mv=text(active+"  •  "+money(total)+" / "+trUi("ay","month"),18,c.blue);mv.setTypeface(null,Typeface.BOLD);margins(mv,0,3,0,0);metric.addView(mv);margins(metric,0,0,0,12);content.addView(metric);
        Button add=button("＋  "+trUi("Abonelik ekle","Add subscription"),c.blue);margins(add,0,0,0,12);content.addView(add);add.setOnClickListener(v->subscriptionDialog(-1));
        if(a.length()==0){TextView empty=text(trUi("Henüz abonelik eklenmedi.","No subscriptions have been added yet."),12,c.muted);empty.setGravity(Gravity.CENTER);content.addView(empty);return;}
        for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;final int idx=i;boolean on=o.optBoolean("active",true);String name=o.optString("name",trUi("Abonelik","Subscription"));double amount=o.optDouble("amount",0);int day=o.optInt("day",1);String last=o.optString("lastPaid","");boolean paid=last.equals(finbiMonthKey(Calendar.getInstance()));
            LinearLayout card=card(c.surface,17);card.setPadding(dp(15),dp(13),dp(12),dp(13));LinearLayout row=row();LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);TextView nt=text(name,15,c.text);nt.setTypeface(null,Typeface.BOLD);info.addView(nt);TextView mt=text(money(amount)+"  •  "+day+" "+trUi("gün","day")+"  •  "+subscriptionCategoryLabel(o.optString("category","Abonelik")),11,c.muted);margins(mt,0,4,0,0);info.addView(mt);TextView pt=text(on?(paid?trUi("Bu ay ödendi","Paid this month"):trUi("Bu ay bekliyor","Due this month")):trUi("Pasif","Inactive"),11,on?(paid?c.green:c.red):c.muted);info.addView(pt);row.addView(info,new LinearLayout.LayoutParams(0,-2,1));Switch sw=new Switch(this);sw.setChecked(on);sw.setOnCheckedChangeListener((b,checked)->{try{JSONArray arr=subscriptionArray();JSONObject x=arr.getJSONObject(idx);x.put("active",checked);getPreferences(0).edit().putString("subscriptions",arr.toString()).apply();if(!checked)showSubscriptions();}catch(Exception ignored){}});row.addView(sw,new LinearLayout.LayoutParams(dp(52),dp(44)));card.addView(row);
            LinearLayout acts=row();Button pay=button(paid?trUi("Bu ay ödendi","Paid"):trUi("Öde","Pay"),paid?c.muted:c.green);pay.setEnabled(!paid&&on);pay.setTextSize(11);acts.addView(pay,new LinearLayout.LayoutParams(0,dp(42),1));pay.setOnClickListener(v->applySubscription(idx));Button edit=button(trUi("Düzenle","Edit"),c.blue);edit.setTextSize(11);LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(0,dp(42),1);ep.setMargins(dp(8),0,0,0);acts.addView(edit,ep);edit.setOnClickListener(v->subscriptionDialog(idx));Button del=button(trUi("Sil","Delete"),c.red);del.setTextSize(11);LinearLayout.LayoutParams dp2=new LinearLayout.LayoutParams(0,dp(42),1);dp2.setMargins(dp(8),0,0,0);acts.addView(del,dp2);del.setOnClickListener(v->deleteSubscription(idx));margins(acts,0,11,0,0);card.addView(acts);margins(card,0,0,0,8);content.addView(card);
        }
    }
    private void subscriptionDialog(final int editIndex){
        Colors c=C();JSONArray arr=subscriptionArray();JSONObject edit=editIndex>=0&&editIndex<arr.length()?arr.optJSONObject(editIndex):null;Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout o=new LinearLayout(this);o.setOrientation(LinearLayout.VERTICAL);o.setPadding(dp(18),dp(18),dp(18),dp(12));o.setBackground(bg(c.surface,24));
        TextView h=text(edit==null?trUi("Abonelik ekle","Add subscription"):trUi("Aboneliği düzenle","Edit subscription"),20,c.text);h.setTypeface(null,Typeface.BOLD);o.addView(h);
        EditText name=modernEdit(trUi("Abonelik adı","Subscription name"),c);if(edit!=null)name.setText(edit.optString("name",""));margins(name,0,10,0,0);o.addView(name,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText amount=modernEdit(trUi("Aylık tutar","Monthly amount"),c);amount.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);attachNumberFormatter(amount);if(edit!=null)setMoneyInput(amount,edit.optDouble("amount",0));margins(amount,0,10,0,0);o.addView(amount,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView dayLabel=text(trUi("Ödeme günü","Billing day"),12,c.muted);margins(dayLabel,0,6,0,4);o.addView(dayLabel);ArrayList<String> days=new ArrayList<>();for(int i=1;i<=31;i++)days.add(i+" "+trUi("gün","day"));Spinner day=new Spinner(this,Spinner.MODE_DROPDOWN);day.setAdapter(new ModernSpinnerAdapter(this,days));day.setSelection(edit==null?0:Math.max(0,Math.min(30,edit.optInt("day",1)-1)));o.addView(day,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText category=modernEdit(trUi("Kategori (isteğe bağlı)","Category (optional)"),c);if(edit!=null)category.setText(edit.optString("category","Abonelik"));else category.setText("Abonelik");margins(category,0,10,0,0);o.addView(category,new LinearLayout.LayoutParams(-1,dp(54)));
        LinearLayout acts=row();Button cancel=dialogButton(trUi("Vazgeç","Cancel"),c.muted,c.surface);Button save=dialogButton(trUi("Kaydet","Save"),Color.WHITE,c.blue);acts.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(52),1);sp.setMargins(dp(8),0,0,0);acts.addView(save,sp);margins(acts,0,12,0,0);o.addView(acts);
        cancel.setOnClickListener(v->dlg.dismiss());save.setOnClickListener(v->{try{String n=name.getText().toString().trim();double a=parseMoneyText(amount.getText().toString());if(n.isEmpty()||a<=0)throw new Exception();int d=day.getSelectedItemPosition()+1;String cat=category.getText().toString().trim();if(cat.isEmpty())cat="Abonelik";JSONArray all=subscriptionArray();JSONObject x=edit==null?new JSONObject():all.getJSONObject(editIndex);x.put("name",n);x.put("amount",a);x.put("day",d);x.put("category",cat);if(edit==null){x.put("active",true);x.put("lastPaid","");all.put(x);}getPreferences(0).edit().putString("subscriptions",all.toString()).apply();dlg.dismiss();showSubscriptions();}catch(Exception e){amount.setError(trUi("Geçerli bir abonelik girin","Enter a valid subscription"));}});dlg.setContentView(o);dlg.show();Window w=dlg.getWindow();if(w!=null)w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);
    }
    private void applySubscription(int idx){try{JSONArray a=subscriptionArray();JSONObject o=a.getJSONObject(idx);String ym=finbiMonthKey(Calendar.getInstance());if(ym.equals(o.optString("lastPaid","")))return;double amount=o.optDouble("amount",0);if(amount<=0)return;String name=o.optString("name","Abonelik");String cat=o.optString("category","Abonelik");Tx t=new Tx(System.currentTimeMillis(),false,amount,trUi("Abonelik - ","Subscription - ")+name,df.format(new Date()),cat);txs.add(t);o.put("lastPaid",ym);getPreferences(0).edit().putString("subscriptions",a.toString()).apply();save();showSubscriptions();}catch(Exception ignored){}}
    private void deleteSubscription(int idx){try{JSONArray a=subscriptionArray();a.remove(idx);getPreferences(0).edit().putString("subscriptions",a.toString()).apply();showSubscriptions();}catch(Exception ignored){}}

    private String finbiSubscriptionAnalysis(){
        JSONArray a=subscriptionArray();double total=0;int active=0;StringBuilder b=new StringBuilder(trUi("Aktif aboneliklerin:\n","Your active subscriptions:\n"));
        for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null||!o.optBoolean("active",true))continue;active++;double v=Math.max(0,o.optDouble("amount",0));total+=v;if(active<=8)b.append("• ").append(o.optString("name",trUi("Abonelik","Subscription"))).append(": ").append(money(v)).append(" / ").append(o.optInt("day",1)).append(" ").append(trUi("gün","day")).append("\n");}
        if(active==0)return trUi("Henüz aktif aboneliğin yok.","You don't have any active subscriptions yet.");b.append(trUi("Aylık toplam: ","Monthly total: ")).append(money(total));return b.toString();
    }

    void showRecurringPayments(){
        enterScreen("recurring");
        marketsVisible=false;currentPage=3;base(s(R.string.ui_26e5e96c24));Colors c=C();JSONArray a;try{a=new JSONArray(getPreferences(0).getString("recurring","[]"));}catch(Exception e){a=new JSONArray();}double monthlyIncome=0,monthlyExpense=0;for(int i=0;i<a.length();i++){try{JSONObject o=a.getJSONObject(i);double v=o.optDouble("amount");if(o.optBoolean("income"))monthlyIncome+=v;else monthlyExpense+=v;}catch(Exception ignored){}}double monthlyNet=monthlyIncome-monthlyExpense;
        LinearLayout hero=card(darkMode?Color.rgb(20,38,32):Color.rgb(239,250,244),22);hero.setPadding(dp(18),dp(16),dp(18),dp(16));LinearLayout hr=row();SimpleIconView hv=new SimpleIconView(this,"calendar",c.green);hr.addView(hv,new LinearLayout.LayoutParams(dp(48),dp(48)));LinearLayout hc=new LinearLayout(this);hc.setOrientation(LinearLayout.VERTICAL);hc.setPadding(dp(12),0,0,0);TextView ht=text(s(R.string.ui_478b718835),19,c.text);ht.setTypeface(null,Typeface.BOLD);hc.addView(ht);TextView hs=text(s(R.string.ui_3b1b90424e),12,c.muted);margins(hs,0,3,0,0);hc.addView(hs);hr.addView(hc,new LinearLayout.LayoutParams(0,-2,1));hero.addView(hr);margins(hero,0,0,0,12);content.addView(hero);
        LinearLayout metrics=row();LinearLayout mi=card(c.surface,16);mi.setPadding(dp(12),dp(12),dp(12),dp(12));mi.addView(text(s(R.string.ui_6c41c144f4),11,c.muted));TextView mit=text(money(monthlyIncome),16,c.green);mit.setTypeface(null,Typeface.BOLD);mi.addView(mit);LinearLayout me=card(c.surface,16);me.setPadding(dp(12),dp(12),dp(12),dp(12));me.addView(text(s(R.string.ui_2dcbf4a0f5),11,c.muted));TextView met=text(money(monthlyExpense),16,c.red);met.setTypeface(null,Typeface.BOLD);me.addView(met);LinearLayout mn=card(c.surface,16);mn.setPadding(dp(12),dp(12),dp(12),dp(12));mn.addView(text(s(R.string.ui_9dd0ab3d89),11,c.muted));TextView mnt=text(money(monthlyNet),16,monthlyNet>=0?c.green:c.red);mnt.setTypeface(null,Typeface.BOLD);mn.addView(mnt);metrics.addView(mi,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams mep=new LinearLayout.LayoutParams(0,-2,1);mep.setMargins(dp(6),0,0,0);metrics.addView(me,mep);LinearLayout.LayoutParams mnp=new LinearLayout.LayoutParams(0,-2,1);mnp.setMargins(dp(6),0,0,0);metrics.addView(mn,mnp);margins(metrics,0,0,0,16);content.addView(metrics);
        Button add=button(s(R.string.ui_c3ec8281ef),c.blue);margins(add,0,0,0,12);content.addView(add);add.setOnClickListener(v->recurringDialog());sectionHeader(content,s(R.string.ui_8f763a74b7),false,null);if(a.length()==0){LinearLayout empty=card(c.surface,16);empty.setPadding(dp(18),dp(22),dp(18),dp(22));TextView et=text(s(R.string.ui_978f3ce921),14,c.muted);et.setGravity(Gravity.CENTER);empty.addView(et);content.addView(empty);}for(int i=0;i<a.length();i++){try{JSONObject o=a.getJSONObject(i);boolean income=o.optBoolean("income");LinearLayout r=card(c.surface,16);r.setPadding(dp(16),dp(14),dp(16),dp(14));LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);TextView t=text(o.optString("name",s(R.string.ui_399e03310d)),16,c.text);t.setTypeface(null,Typeface.BOLD);t.setMaxLines(2);info.addView(t);TextView amt=text((income?"+ ":"- ")+money(o.optDouble("amount")),15,income?c.green:c.red);amt.setTypeface(null,Typeface.BOLD);margins(amt,0,5,0,0);info.addView(amt);TextView meta=text(income?s(R.string.ui_f7afc7c046):s(R.string.ui_c418c88202),11,c.muted);info.addView(meta);r.addView(info,new LinearLayout.LayoutParams(-1,-2));LinearLayout actions=row();margins(actions,0,12,0,0);Button apply=button(s(R.string.ui_497b99ad84),income?c.green:c.blue);apply.setTextSize(11);apply.setAllCaps(false);actions.addView(apply,new LinearLayout.LayoutParams(0,dp(42),1));final int idx=i;apply.setOnClickListener(v->applyRecurring(idx));Button del=button(s(R.string.ui_e55f244f5e),c.red);del.setTextSize(11);del.setAllCaps(false);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(0,dp(42),1);pp.setMargins(dp(8),0,0,0);actions.addView(del,pp);del.setOnClickListener(v->deleteRecurring(idx));r.addView(actions,new LinearLayout.LayoutParams(-1,dp(42)));margins(r,0,0,0,9);content.addView(r);}catch(Exception ignored){}}
    }
    void recurringDialog(){Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout o=new LinearLayout(this);o.setOrientation(LinearLayout.VERTICAL);o.setPadding(dp(18),dp(18),dp(18),dp(12));o.setBackground(bg(c.surface,24));TextView h=text(s(R.string.ui_7712edae7b),20,c.text);h.setTypeface(null,1);o.addView(h);EditText name=modernEdit(s(R.string.ui_fb713e89c1),c);margins(name,0,14,0,8);o.addView(name,new LinearLayout.LayoutParams(-1,dp(54)));EditText amount=modernEdit(s(R.string.ui_b877f50dc0),c);amount.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);attachNumberFormatter(amount);o.addView(amount,new LinearLayout.LayoutParams(-1,dp(54)));TextView typeTitle=text(s(R.string.ui_e53f705e35),12,c.text);typeTitle.setTypeface(null,Typeface.BOLD);margins(typeTitle,0,10,0,5);o.addView(typeTitle);
        LinearLayout typeRow=row();TextView incomeChoice=text("↑  "+s(R.string.ui_6c41c144f4)+"\n"+s(R.string.ui_2a54fcaf08),14,c.green);incomeChoice.setGravity(Gravity.CENTER_VERTICAL);incomeChoice.setTypeface(null,Typeface.BOLD);incomeChoice.setPadding(dp(14),dp(8),dp(10),dp(8));TextView expenseChoice=text("↓  "+s(R.string.ui_5e6806f6e3)+"\n"+s(R.string.ui_326279ae2e),14,c.red);expenseChoice.setGravity(Gravity.CENTER_VERTICAL);expenseChoice.setTypeface(null,Typeface.BOLD);expenseChoice.setPadding(dp(14),dp(8),dp(10),dp(8));final boolean[] recurringIncome={true};Runnable paintType=()->{incomeChoice.setBackground(strokeBg(recurringIncome[0]?c.green2:c.bg,recurringIncome[0]?c.green:c.border,15));expenseChoice.setBackground(strokeBg(!recurringIncome[0]?c.red:c.bg,!recurringIncome[0]?c.red:c.border,15));};typeRow.addView(incomeChoice,new LinearLayout.LayoutParams(0,dp(64),1));LinearLayout.LayoutParams ep2=new LinearLayout.LayoutParams(0,dp(64),1);ep2.setMargins(dp(8),0,0,0);typeRow.addView(expenseChoice,ep2);o.addView(typeRow);paintType.run();incomeChoice.setOnClickListener(v->{recurringIncome[0]=true;paintType.run();});expenseChoice.setOnClickListener(v->{recurringIncome[0]=false;paintType.run();});margins(typeRow,0,0,0,10);LinearLayout acts=row();Button cancel=dialogButton(s(R.string.ui_989f51ec41),c.muted,c.surface);Button save=dialogButton(s(R.string.ui_b0ad98dc01),Color.WHITE,c.blue);acts.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(52),1);sp.setMargins(dp(8),0,0,0);acts.addView(save,sp);o.addView(acts);cancel.setOnClickListener(v->dlg.dismiss());save.setOnClickListener(v->{try{double a=parseMoneyText(amount.getText().toString());if(a<=0||name.getText().toString().trim().isEmpty())throw new Exception();JSONArray arr=new JSONArray(getPreferences(0).getString("recurring","[]"));JSONObject x=new JSONObject();x.put("name",name.getText().toString().trim());x.put("amount",a);x.put("income",recurringIncome[0]);arr.put(x);getPreferences(0).edit().putString("recurring",arr.toString()).apply();dlg.dismiss();showRecurringPayments();}catch(Exception e){amount.setError(s(R.string.ui_73dc6b5fa4));}});dlg.setContentView(o);dlg.show();Window w=dlg.getWindow();if(w!=null)w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);}
    void applyRecurring(int idx){try{JSONArray a=new JSONArray(getPreferences(0).getString("recurring","[]"));JSONObject o=a.getJSONObject(idx);txs.add(new Tx(System.currentTimeMillis(),o.optBoolean("income"),o.optDouble("amount"),o.optString("name",""),df.format(new Date()),o.optBoolean("income")?"Gelir":"Düzenli Harcama"));save();Toast.makeText(this,s(R.string.ui_2f5ae7fed9),Toast.LENGTH_SHORT).show();showRecurringPayments();}catch(Exception ignored){}}
    void deleteRecurring(int idx){try{JSONArray a=new JSONArray(getPreferences(0).getString("recurring","[]"));a.remove(idx);getPreferences(0).edit().putString("recurring",a.toString()).apply();showRecurringPayments();}catch(Exception ignored){}}
    void showDataTransfer(){
        enterScreen("data");
        marketsVisible=false;currentPage=3;base(s(R.string.ui_7f53713331));Colors c=C();LinearLayout hero=card(darkMode?Color.rgb(25,31,48):Color.rgb(242,246,255),22);hero.setPadding(dp(18),dp(16),dp(18),dp(16));LinearLayout hr=row();SimpleIconView hv=new SimpleIconView(this,"refresh",c.blue);hr.addView(hv,new LinearLayout.LayoutParams(dp(48),dp(48)));LinearLayout hc=new LinearLayout(this);hc.setOrientation(LinearLayout.VERTICAL);hc.setPadding(dp(12),0,0,0);TextView ht=text(s(R.string.ui_9ff1b060c9),19,c.text);ht.setTypeface(null,Typeface.BOLD);hc.addView(ht);TextView hs=text(s(R.string.ui_4f0857cfd3),12,c.muted);hc.addView(hs);hr.addView(hc,new LinearLayout.LayoutParams(0,-2,1));hero.addView(hr);margins(hero,0,0,0,12);content.addView(hero);
        LinearLayout exportCard=card(c.surface,18);exportCard.setPadding(dp(14),dp(12),dp(12),dp(12));
        LinearLayout er=row();SimpleIconView ei=new SimpleIconView(this,"arrow_up",c.blue);ei.setBackground(bg(darkMode?Color.rgb(25,49,68):Color.rgb(239,247,253),15));er.addView(ei,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout ec=new LinearLayout(this);ec.setOrientation(LinearLayout.VERTICAL);ec.setPadding(dp(12),0,dp(8),0);TextView et=text(s(R.string.ui_647e34df94),15,c.text);et.setTypeface(null,Typeface.BOLD);ec.addView(et);TextView es=text(s(R.string.ui_55ba845b35),11,c.muted);es.setMaxLines(2);ec.addView(es);er.addView(ec,new LinearLayout.LayoutParams(0,-2,1));
        SimpleIconView ea=new SimpleIconView(this,"arrow",c.blue);er.addView(ea,new LinearLayout.LayoutParams(dp(28),dp(36)));exportCard.addView(er);attachPressFeedback(exportCard);exportCard.setOnClickListener(v->exportTransfer());content.addView(exportCard);
        LinearLayout importCard=card(c.surface,18);importCard.setPadding(dp(14),dp(12),dp(12),dp(12));
        LinearLayout ir=row();SimpleIconView ii=new SimpleIconView(this,"arrow_down",c.green);ii.setBackground(bg(darkMode?Color.rgb(24,55,42):Color.rgb(238,250,244),15));ir.addView(ii,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout ic=new LinearLayout(this);ic.setOrientation(LinearLayout.VERTICAL);ic.setPadding(dp(12),0,dp(8),0);TextView it=text(s(R.string.ui_e0b7b96c9d),15,c.text);it.setTypeface(null,Typeface.BOLD);ic.addView(it);TextView is=text(s(R.string.ui_c0b0198671),11,c.muted);is.setMaxLines(2);ic.addView(is);ir.addView(ic,new LinearLayout.LayoutParams(0,-2,1));
        SimpleIconView ia=new SimpleIconView(this,"arrow",c.green);ir.addView(ia,new LinearLayout.LayoutParams(dp(28),dp(36)));importCard.addView(ir);margins(importCard,0,10,0,0);attachPressFeedback(importCard);importCard.setOnClickListener(v->startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("application/json").addCategory(Intent.CATEGORY_OPENABLE),REQ_TRANSFER_IMPORT));content.addView(importCard);
        TextView note=text(s(R.string.ui_095b77c22f),11,c.muted);note.setLineSpacing(0,1.12f);margins(note,4,12,4,0);content.addView(note);
    }
    String backupJson(){
        try{
            JSONObject root=new JSONObject();
            root.put("format","finway-data");
            root.put("version",2);
            root.put("txs",new JSONArray(getPreferences(0).getString("txs","[]")));
            root.put("goals",new JSONArray(getPreferences(0).getString("goals","[]")));
            root.put("completedGoals",new JSONArray(getPreferences(0).getString("completedGoals","[]")));
            root.put("recurring",new JSONArray(getPreferences(0).getString("recurring","[]")));
            root.put("creditCards",new JSONArray(getPreferences(0).getString("creditCards","[]")));
            root.put("installments",new JSONArray(getPreferences(0).getString("installments","[]")));
            root.put("cardPayments",new JSONArray(getPreferences(0).getString("cardPayments","[]")));
            JSONArray accArr=new JSONArray();for(String a:getPreferences(0).getString("accounts","Genel").split("\\|")){a=a.trim();if(!a.isEmpty())accArr.put(a);}if(accArr.length()==0)accArr.put("Genel");root.put("accounts",accArr);
            root.put("monthlyBudget",getPreferences(0).getString("monthlyBudget","0"));
            root.put("categoryBudgets",getPreferences(0).getString("categoryBudgets","{}"));
            root.put("subscriptions",getPreferences(0).getString("subscriptions","[]"));
            root.put("savingsEntries",getPreferences(0).getString("savings_entries_json","[]"));
            root.put("savedBanks",getPreferences(0).getString("savedBanks",""));
            return root.toString(2);
        }catch(Exception e){return "{}";}
    }
    void restoreFrom(Uri u){
        try{
            InputStream in=getContentResolver().openInputStream(u);
            BufferedReader br=new BufferedReader(new InputStreamReader(in,"UTF-8"));
            StringBuilder sb=new StringBuilder();String line;
            while((line=br.readLine())!=null)sb.append(line);
            br.close();
            JSONObject r=new JSONObject(sb.toString());
            if(!"finway-data".equals(r.optString("format")))throw new Exception("invalid format");
            JSONArray txArr=r.optJSONArray("txs"), goalArr=r.optJSONArray("goals"), completedArr=r.optJSONArray("completedGoals"), recurringArr=r.optJSONArray("recurring");
            if(txArr==null||goalArr==null||completedArr==null||recurringArr==null)throw new Exception("missing data");
            JSONArray cardArr=r.optJSONArray("creditCards"), installmentArr=r.optJSONArray("installments"), paymentArr=r.optJSONArray("cardPayments"), accountArr=r.optJSONArray("accounts");
            if(cardArr==null)cardArr=new JSONArray(); if(installmentArr==null)installmentArr=new JSONArray(); if(paymentArr==null)paymentArr=new JSONArray(); if(accountArr==null)accountArr=new JSONArray("[\"Genel\"]");
            StringBuilder accJoin=new StringBuilder();for(int i=0;i<accountArr.length();i++){String a=accountArr.optString(i,"").trim();if(a.isEmpty()||a.contains("|"))continue;if(accJoin.length()>0)accJoin.append('|');accJoin.append(a);}if(accJoin.length()==0)accJoin.append("Genel");
            getPreferences(0).edit()
                .putString("txs",txArr.toString())
                .putString("goals",goalArr.toString())
                .putString("completedGoals",completedArr.toString())
                .putString("recurring",recurringArr.toString())
                .putString("creditCards",cardArr.toString())
                .putString("installments",installmentArr.toString())
                .putString("cardPayments",paymentArr.toString())
                .putString("accounts",accJoin.toString())
                .apply();
            SharedPreferences.Editor ex=getPreferences(0).edit();
            if(r.has("monthlyBudget"))ex.putString("monthlyBudget",r.optString("monthlyBudget","0"));
            if(r.has("categoryBudgets"))ex.putString("categoryBudgets",r.optString("categoryBudgets","{}"));
            if(r.has("subscriptions"))ex.putString("subscriptions",r.optString("subscriptions","[]"));
            if(r.has("savingsEntries"))ex.putString("savings_entries_json",r.optString("savingsEntries","[]"));
            if(r.has("savedBanks"))ex.putString("savedBanks",r.optString("savedBanks",""));
            ex.apply();
            txs.clear();load();loadGoals();loadCreditCards();loadCardPayments();loadAccounts();loadPrefs();
            Toast.makeText(this,s(R.string.ui_3f460bd0d7),Toast.LENGTH_LONG).show();
            showHome();
        }catch(Exception e){
            Toast.makeText(this,s(R.string.ui_5e9e05b8f0),Toast.LENGTH_LONG).show();
        }
    }
    String exportEsc(String s){
        if(s==null)return "";
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");
    }
    void writeExcel(File f) throws Exception{
        OutputStreamWriter w=new OutputStreamWriter(new FileOutputStream(f),"UTF-8");
        w.write("<html><head><meta charset=\"UTF-8\"></head><body>");
        w.write("<h2>Finway - İşlemler</h2><table border=\"1\"><tr><th>Tarih</th><th>Tür</th><th>Tutar</th><th>Kategori</th><th>Açıklama</th></tr>");
        for(Tx t:txs){
            w.write("<tr><td>"+exportEsc(t.date)+"</td><td>"+exportEsc(t.isIncome?"Gelir":"Harcama")+"</td><td>"+String.format(Locale.US,"%.2f",t.amount)+"</td><td>"+exportEsc(t.cat)+"</td><td>"+exportEsc(t.desc)+"</td></tr>");
        }
        w.write("</table><h2>Finway - Hedefler</h2><table border=\"1\"><tr><th>Hedef</th><th>Hedef Tutarı</th><th>Birikim</th><th>Son Tarih</th></tr>");
        for(Goal g:goals){w.write("<tr><td>"+exportEsc(g.name)+"</td><td>"+String.format(Locale.US,"%.2f",g.target)+"</td><td>"+String.format(Locale.US,"%.2f",g.saved)+"</td><td>"+exportEsc(g.deadline)+"</td></tr>");}
        w.write("</table><h2>Finway - Kredi Kartları</h2><table border=\"1\"><tr><th>Kart</th><th>Banka</th><th>Limit</th><th>Güncel Borç</th><th>Kullanılabilir Limit</th></tr>");
        for(CreditCard c:creditCards){w.write("<tr><td>"+exportEsc(c.name)+"</td><td>"+exportEsc(c.bank)+"</td><td>"+String.format(Locale.US,"%.2f",c.limit)+"</td><td>"+String.format(Locale.US,"%.2f",c.debt)+"</td><td>"+String.format(Locale.US,"%.2f",Math.max(0,c.limit-c.debt))+"</td></tr>");}
        w.write("</table><h2>Finway - Taksitler</h2><table border=\"1\"><tr><th>Kart</th><th>İşlem</th><th>Toplam</th><th>Taksit</th><th>Ödenen</th><th>İlk Tarih</th></tr>");
        for(Installment in:installments){CreditCard cc=findCard(in.cardId);w.write("<tr><td>"+exportEsc(cc==null?"":cc.name)+"</td><td>"+exportEsc(in.merchant)+"</td><td>"+String.format(Locale.US,"%.2f",in.total)+"</td><td>"+in.count+"</td><td>"+in.paidCount+"</td><td>"+exportEsc(in.firstDate)+"</td></tr>");}
        w.write("</table></body></html>");w.close();
    }
    void writeWord(File f) throws Exception{
        OutputStreamWriter w=new OutputStreamWriter(new FileOutputStream(f),"UTF-8");
        w.write("<html><head><meta charset=\"UTF-8\"></head><body>");
        w.write("<h1>Finway Veri Raporu</h1><h2>İşlemler</h2><table border=\"1\"><tr><th>Tarih</th><th>Tür</th><th>Tutar</th><th>Kategori</th><th>Açıklama</th></tr>");
        for(Tx t:txs){w.write("<tr><td>"+exportEsc(t.date)+"</td><td>"+exportEsc(t.isIncome?"Gelir":"Harcama")+"</td><td>"+String.format(Locale.US,"%.2f",t.amount)+"</td><td>"+exportEsc(t.cat)+"</td><td>"+exportEsc(t.desc)+"</td></tr>");}
        w.write("</table><h2>Hedefler</h2><table border=\"1\"><tr><th>Hedef</th><th>Hedef Tutarı</th><th>Birikim</th><th>Son Tarih</th></tr>");
        for(Goal g:goals){w.write("<tr><td>"+exportEsc(g.name)+"</td><td>"+String.format(Locale.US,"%.2f",g.target)+"</td><td>"+String.format(Locale.US,"%.2f",g.saved)+"</td><td>"+exportEsc(g.deadline)+"</td></tr>");}
        w.write("</table><h2>Kredi Kartları</h2><table border=\"1\"><tr><th>Kart</th><th>Banka</th><th>Limit</th><th>Güncel Borç</th><th>Kullanılabilir Limit</th></tr>");
        for(CreditCard c:creditCards){w.write("<tr><td>"+exportEsc(c.name)+"</td><td>"+exportEsc(c.bank)+"</td><td>"+String.format(Locale.US,"%.2f",c.limit)+"</td><td>"+String.format(Locale.US,"%.2f",c.debt)+"</td><td>"+String.format(Locale.US,"%.2f",Math.max(0,c.limit-c.debt))+"</td></tr>");}
        w.write("</table><h2>Taksitler</h2><table border=\"1\"><tr><th>Kart</th><th>İşlem</th><th>Toplam</th><th>Taksit</th><th>Ödenen</th><th>İlk Tarih</th></tr>");
        for(Installment in:installments){CreditCard cc=findCard(in.cardId);w.write("<tr><td>"+exportEsc(cc==null?"":cc.name)+"</td><td>"+exportEsc(in.merchant)+"</td><td>"+String.format(Locale.US,"%.2f",in.total)+"</td><td>"+in.count+"</td><td>"+in.paidCount+"</td><td>"+exportEsc(in.firstDate)+"</td></tr>");}
        w.write("</table></body></html>");w.close();
    }
    void exportTransfer(){
        try{
            File dir=new File(getCacheDir(),"exports");dir.mkdirs();File[] oldExports=dir.listFiles();if(oldExports!=null)for(File of:oldExports)of.delete();
            File json=new File(dir,"Finway_Veri_Aktarimi.json");
            File xls=new File(dir,"Finway_Veriler.xls");
            File doc=new File(dir,"Finway_Veriler.doc");
            OutputStream out=new FileOutputStream(json);out.write(backupJson().getBytes("UTF-8"));out.close();
            writeExcel(xls);writeWord(doc);
            ArrayList<Uri> uris=new ArrayList<>();
            uris.add(FileProvider.getUriForFile(this,getPackageName()+".fileprovider",json));
            uris.add(FileProvider.getUriForFile(this,getPackageName()+".fileprovider",xls));
            uris.add(FileProvider.getUriForFile(this,getPackageName()+".fileprovider",doc));
            Intent share=new Intent(Intent.ACTION_SEND_MULTIPLE);share.setType("application/octet-stream");
            share.putParcelableArrayListExtra(Intent.EXTRA_STREAM,uris);share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share,s(R.string.ui_626334c6a7)));
        }catch(Exception e){Toast.makeText(this,s(R.string.ui_b1bccec7a3),Toast.LENGTH_LONG).show();}
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_DEVICE_RESET){
            boolean wasPending=pendingDeviceReset; pendingDeviceReset=false;
            if(wasPending&&resultCode==RESULT_OK){ new Handler(Looper.getMainLooper()).postDelayed(()->showPinResetSetupDialog(),120); }
            return;
        }
        if(resultCode!=RESULT_OK||data==null)return;
        try{
            if(requestCode==REQ_BACKUP){
                OutputStream out=getContentResolver().openOutputStream(data.getData());out.write(backupJson().getBytes("UTF-8"));out.close();
                Toast.makeText(this,s(R.string.ui_6e4c1dfad8),Toast.LENGTH_SHORT).show();
            }else if(requestCode==REQ_RESTORE||requestCode==REQ_TRANSFER_IMPORT)restoreFrom(data.getData());
        }catch(Exception e){Toast.makeText(this,s(R.string.ui_f38adcef99),Toast.LENGTH_LONG).show();}
    }


    void loadReminderPrefs(){
        android.content.SharedPreferences p=getPreferences(0);
        // Older builds used 5 days as an implicit default. Until the user makes
        // an explicit reminder choice, keep the reminder day unselected.
        boolean initialized=p.getBoolean("reminderPrefsInitialized",false);
        cardReminderDays=initialized?p.getInt("cardReminderDays",0):0;
        cardReminderSound=p.getBoolean("cardReminderSound",true);
        cardReminderUseRange=p.getBoolean("cardReminderUseRange",false);
        cardReminderStartMinute=p.getInt("cardReminderStartMinute",9*60);
        cardReminderEndMinute=p.getInt("cardReminderEndMinute",9*60+30);
    }
    void saveReminderPrefs(){
        getPreferences(0).edit().putInt("cardReminderDays",cardReminderDays).putBoolean("cardReminderSound",cardReminderSound)
            .putBoolean("cardReminderUseRange",cardReminderUseRange).putInt("cardReminderStartMinute",cardReminderStartMinute)
            .putInt("cardReminderEndMinute",cardReminderEndMinute).putBoolean("reminderPrefsInitialized",true).apply();
    }
    int reminderRequestCode(long cardId, boolean custom){
        long v=Math.abs(cardId%300000);
        return REMINDER_REQ_BASE+(int)v+(custom?400000:0);
    }
    boolean canScheduleExactAlarms(){
        if(Build.VERSION.SDK_INT<31)return true;
        try{return ((AlarmManager)getSystemService(ALARM_SERVICE)).canScheduleExactAlarms();}catch(Exception e){return false;}
    }
    void setReminderAlarm(AlarmManager am,long when,PendingIntent pi){
        if(Build.VERSION.SDK_INT>=23){
            if(canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
        }else am.setExact(AlarmManager.RTC_WAKEUP,when,pi);
    }
    void createReminderChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            android.net.Uri sound=Uri.parse("android.resource://"+getPackageName()+"/"+R.raw.finway_reminder);
            android.media.AudioAttributes attrs=new android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
            NotificationChannel soundCh=new NotificationChannel(REMINDER_CHANNEL,s(R.string.ui_269294bb3b),NotificationManager.IMPORTANCE_HIGH);
            soundCh.setSound(sound,attrs); soundCh.enableVibration(true);
            NotificationChannel silentCh=new NotificationChannel(REMINDER_CHANNEL_SILENT,s(R.string.ui_d89d8bfb49),NotificationManager.IMPORTANCE_HIGH);
            silentCh.setSound(null,null); silentCh.enableVibration(true);
            nm.createNotificationChannel(soundCh); nm.createNotificationChannel(silentCh);
        }
    }
    void requestNotificationPermissionIfNeeded(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},7788);
        }
    }
    void cancelReminderAlarm(CreditCard cc, boolean custom){
        try{
            AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE); if(am==null)return;
            Intent i=new Intent(this,CardReminderReceiver.class); i.putExtra("cardId",cc.id);
            PendingIntent pi=PendingIntent.getBroadcast(this,reminderRequestCode(cc.id,custom),i,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);
            if(pi!=null){am.cancel(pi);pi.cancel();}
        }catch(Exception ignored){}
    }
    void clearCustomReminder(CreditCard cc){
        getPreferences(0).edit().remove("customReminder_"+cc.id).apply();
        cancelReminderAlarm(cc,true);
    }
    Long getCustomReminder(long cardId){
        long v=getPreferences(0).getLong("customReminder_"+cardId,-1L); return v>0?v:null;
    }
    int reminderMinuteOfDay(){
        if(!cardReminderUseRange)return Math.max(0,Math.min(1439,cardReminderStartMinute));
        int start=Math.max(0,Math.min(1439,cardReminderStartMinute));
        int end=Math.max(0,Math.min(1439,cardReminderEndMinute));
        if(end<start){int tmp=start;start=end;end=tmp;}
        return start + (end-start)/2;
    }
    void applyReminderTime(Calendar c){
        int m=reminderMinuteOfDay(); c.set(Calendar.HOUR_OF_DAY,m/60); c.set(Calendar.MINUTE,m%60); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0);
    }
    String formatReminderMinute(int m){return String.format(Locale.getDefault(),"%02d:%02d",Math.max(0,Math.min(1439,m))/60,Math.max(0,Math.min(1439,m))%60);}
    String reminderTimeSummary(){
        if(cardReminderUseRange){int a=cardReminderStartMinute,b=cardReminderEndMinute; if(b<a){int t=a;a=b;b=t;} return formatReminderMinute(a)+" – "+formatReminderMinute(b);}
        return formatReminderMinute(cardReminderStartMinute);
    }
    void pickReminderTimeSettings(final Dialog dlg){
        final Colors c=C();
        LinearLayout o=new LinearLayout(this);o.setOrientation(LinearLayout.VERTICAL);o.setPadding(dp(18),dp(18),dp(18),dp(12));o.setBackground(bg(c.surface,24));
        TextView h=text("⏰  "+s(R.string.ui_9e62714a62),20,c.text);h.setTypeface(null,Typeface.BOLD);o.addView(h);
        TextView sub=text(s(R.string.ui_d48a5aaee7),12,c.muted);margins(sub,0,4,0,12);o.addView(sub);
        final TextView mode=text((cardReminderUseRange?s(R.string.ui_0efd3d4ec5):s(R.string.ui_9258db4d62)),14,c.blue);mode.setGravity(Gravity.CENTER);mode.setBackground(strokeBg(c.surface,c.border,14));o.addView(mode,new LinearLayout.LayoutParams(-1,dp(48)));attachPressFeedback(mode);
        mode.setOnClickListener(v->{cardReminderUseRange=!cardReminderUseRange;mode.setText(cardReminderUseRange?s(R.string.ui_0efd3d4ec5):s(R.string.ui_9258db4d62));});
        final TextView start=text(s(R.string.ui_659395fc1f)+formatReminderMinute(cardReminderStartMinute),14,c.text);start.setGravity(Gravity.CENTER_VERTICAL);start.setPadding(dp(14),0,dp(14),0);start.setBackground(strokeBg(c.bg,c.border,14));margins(start,0,10,0,0);o.addView(start,new LinearLayout.LayoutParams(-1,dp(50)));attachPressFeedback(start);
        final TextView end=text(s(R.string.ui_8a8e111993)+formatReminderMinute(cardReminderEndMinute),14,c.text);end.setGravity(Gravity.CENTER_VERTICAL);end.setPadding(dp(14),0,dp(14),0);end.setBackground(strokeBg(c.bg,c.border,14));margins(end,0,10,0,0);o.addView(end,new LinearLayout.LayoutParams(-1,dp(50)));
        end.setVisibility(cardReminderUseRange?View.VISIBLE:View.GONE);attachPressFeedback(end);
        mode.setOnClickListener(v->{cardReminderUseRange=!cardReminderUseRange;mode.setText(cardReminderUseRange?s(R.string.ui_0efd3d4ec5):s(R.string.ui_9258db4d62));end.setVisibility(cardReminderUseRange?View.VISIBLE:View.GONE);});
        start.setOnClickListener(v->showMinutePicker(cardReminderStartMinute,m->{cardReminderStartMinute=m;start.setText(s(R.string.ui_659395fc1f)+formatReminderMinute(m));}));
        end.setOnClickListener(v->showMinutePicker(cardReminderEndMinute,m->{cardReminderEndMinute=m;end.setText(s(R.string.ui_8a8e111993)+formatReminderMinute(m));}));
        LinearLayout acts=row();Button cancel=dialogButton(s(R.string.ui_989f51ec41),c.muted,c.surface);Button save=dialogButton(s(R.string.ui_57ea23145d),Color.WHITE,c.blue);acts.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(52),1);sp.setMargins(dp(8),0,0,0);acts.addView(save,sp);margins(acts,0,14,0,0);o.addView(acts);cancel.setOnClickListener(v->dlg.dismiss());
        save.setOnClickListener(v->{if(cardReminderUseRange&&cardReminderStartMinute==cardReminderEndMinute){Toast.makeText(this,s(R.string.ui_17085e51b2),Toast.LENGTH_SHORT).show();return;}saveReminderPrefs();scheduleAllCardReminders();dlg.dismiss();showSettings();});
        dlg.setContentView(o);dlg.show();Window w=dlg.getWindow();if(w!=null)w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);
    }
    interface MinuteCallback{void set(int minute);}
    void showMinutePicker(int current,final MinuteCallback callback){
        int h=Math.max(0,Math.min(23,current/60)),m=Math.max(0,Math.min(59,current%60));
        TimePickerDialog t=new TimePickerDialog(this,(view,hour,minute)->callback.set(hour*60+minute),h,m,true);t.setTitle(s(R.string.ui_bcce89fbde));t.show();
    }
    void chooseCustomReminderTime(final CreditCard cc, final Calendar day){
        final Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout o=new LinearLayout(this);o.setOrientation(LinearLayout.VERTICAL);o.setPadding(dp(18),dp(18),dp(18),dp(12));o.setBackground(bg(c.surface,24));
        TextView h=text("⏰  "+s(R.string.ui_9e62714a62),20,c.text);h.setTypeface(null,Typeface.BOLD);o.addView(h);TextView sub=text(s(R.string.ui_1fb3e5c2a0),12,c.muted);margins(sub,0,4,0,12);o.addView(sub);
        final TextView selected=text(s(R.string.ui_30c6cfc396)+formatReminderMinute(cardReminderStartMinute),15,c.text);selected.setGravity(Gravity.CENTER);selected.setBackground(strokeBg(c.bg,c.border,14));o.addView(selected,new LinearLayout.LayoutParams(-1,dp(54)));attachPressFeedback(selected);
        final boolean[] range={false};final TextView rangeBtn=text(s(R.string.ui_582d4a59b8),14,c.blue);rangeBtn.setGravity(Gravity.CENTER);rangeBtn.setBackground(strokeBg(c.surface,c.border,14));margins(rangeBtn,0,10,0,0);o.addView(rangeBtn,new LinearLayout.LayoutParams(-1,dp(48)));attachPressFeedback(rangeBtn);
        final TextView end=text(s(R.string.ui_8a8e111993)+formatReminderMinute(cardReminderEndMinute),14,c.text);end.setGravity(Gravity.CENTER);end.setBackground(strokeBg(c.bg,c.border,14));margins(end,0,10,0,0);end.setVisibility(View.GONE);o.addView(end,new LinearLayout.LayoutParams(-1,dp(50)));
        selected.setOnClickListener(v->showMinutePicker(cardReminderStartMinute,m->{day.set(Calendar.HOUR_OF_DAY,m/60);day.set(Calendar.MINUTE,m%60);day.set(Calendar.SECOND,0);day.set(Calendar.MILLISECOND,0);selected.setText(s(R.string.ui_30c6cfc396)+formatReminderMinute(m));}));
        rangeBtn.setOnClickListener(v->{range[0]=!range[0];end.setVisibility(range[0]?View.VISIBLE:View.GONE);rangeBtn.setText(range[0]?s(R.string.ui_fbf0f85b34):s(R.string.ui_582d4a59b8));});
        end.setOnClickListener(v->showMinutePicker(cardReminderEndMinute,m->{cardReminderEndMinute=m;end.setText(s(R.string.ui_8a8e111993)+formatReminderMinute(m));}));
        LinearLayout acts=row();Button cancel=dialogButton(s(R.string.ui_989f51ec41),c.muted,c.surface);Button save=dialogButton(s(R.string.ui_71920d2af5),Color.WHITE,c.blue);acts.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(52),1);sp.setMargins(dp(8),0,0,0);acts.addView(save,sp);margins(acts,0,14,0,0);o.addView(acts);cancel.setOnClickListener(v->dlg.dismiss());
        save.setOnClickListener(v->{if(range[0]){int a=day.get(Calendar.HOUR_OF_DAY)*60+day.get(Calendar.MINUTE),b=cardReminderEndMinute;if(b<a){Toast.makeText(this,s(R.string.ui_d10706fbc6),Toast.LENGTH_SHORT).show();return;}day.set(Calendar.HOUR_OF_DAY,a/60);day.set(Calendar.MINUTE,a%60);day.add(Calendar.MINUTE,(b-a)/2);}scheduleCustomReminder(cc,day);dlg.dismiss();});
        dlg.setContentView(o);dlg.show();Window w=dlg.getWindow();if(w!=null)w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);
    }

    Calendar nextDueDate(int dueDay){
        Calendar due=Calendar.getInstance(); due.set(Calendar.HOUR_OF_DAY,9); due.set(Calendar.MINUTE,0); due.set(Calendar.SECOND,0); due.set(Calendar.MILLISECOND,0);
        int max=due.getActualMaximum(Calendar.DAY_OF_MONTH); due.set(Calendar.DAY_OF_MONTH,Math.max(1,Math.min(dueDay,max)));
        Calendar now=Calendar.getInstance(); if(due.before(now)){due.add(Calendar.MONTH,1);max=due.getActualMaximum(Calendar.DAY_OF_MONTH);due.set(Calendar.DAY_OF_MONTH,Math.max(1,Math.min(dueDay,max)));}
        return due;
    }
    void scheduleAllCardReminders(){
        for(CreditCard cc:creditCards){
            cancelReminderAlarm(cc,false); cancelReminderAlarm(cc,true);
            Long custom=getCustomReminder(cc.id);
            if(custom!=null){
                Calendar w=Calendar.getInstance();w.setTimeInMillis(custom);
                if(w.after(Calendar.getInstance())) scheduleCustomReminderInternal(cc,w); else clearCustomReminder(cc);
            }else if(cardReminderDays>0) scheduleCardReminder(cc);
        }
    }
    void scheduleCardReminder(CreditCard cc){
        try{
            AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE); if(am==null||cardReminderDays<=0)return;
            Calendar due=nextDueDate(cc.dueDay); due.add(Calendar.DAY_OF_MONTH,-Math.max(0,cardReminderDays)); applyReminderTime(due);
            Intent i=new Intent(this,CardReminderReceiver.class); i.putExtra("cardId",cc.id); i.putExtra("cardName",cc.name); i.putExtra("dueDay",cc.dueDay); i.putExtra("offset",cardReminderDays); i.putExtra("custom",false); i.putExtra("sound",cardReminderSound);
            PendingIntent pi=PendingIntent.getBroadcast(this,reminderRequestCode(cc.id,false),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            setReminderAlarm(am,due.getTimeInMillis(),pi);
        }catch(Exception ignored){}
    }
    void scheduleCustomReminderInternal(final CreditCard cc, Calendar when){
        try{
            AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE); if(am==null)return;
            Intent i=new Intent(this,CardReminderReceiver.class); i.putExtra("cardId",cc.id); i.putExtra("cardName",cc.name); i.putExtra("custom",true); i.putExtra("sound",cardReminderSound);
            PendingIntent pi=PendingIntent.getBroadcast(this,reminderRequestCode(cc.id,true),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            setReminderAlarm(am,when.getTimeInMillis(),pi);
        }catch(Exception ignored){}
    }
    void scheduleCustomReminder(final CreditCard cc, Calendar when){
        Calendar now=Calendar.getInstance(); now.set(Calendar.SECOND,0); now.set(Calendar.MILLISECOND,0);
        if(!when.after(now)){Toast.makeText(this,s(R.string.ui_fdee2ec166),Toast.LENGTH_SHORT).show();return;}
        getPreferences(0).edit().putLong("customReminder_"+cc.id,when.getTimeInMillis()).apply();
        cancelReminderAlarm(cc,false); cancelReminderAlarm(cc,true);
        scheduleCustomReminderInternal(cc,when);
        Toast.makeText(this,s(R.string.ui_b92b126ccf),Toast.LENGTH_SHORT).show();
    }
    void chooseCustomCardReminder(final CreditCard cc){
        Calendar n=Calendar.getInstance();
        DatePickerDialog dpd=new DatePickerDialog(this,(v,y,m,d)->{
            Calendar when=Calendar.getInstance(); when.set(y,m,d,cardReminderStartMinute/60,cardReminderStartMinute%60); when.set(Calendar.SECOND,0); when.set(Calendar.MILLISECOND,0);
            chooseCustomReminderTime(cc,when);
        },n.get(Calendar.YEAR),n.get(Calendar.MONTH),n.get(Calendar.DAY_OF_MONTH));
        dpd.setTitle(s(R.string.ui_acc99b35ae));
        dpd.getDatePicker().setMinDate(System.currentTimeMillis());
        dpd.show();
    }
    void showCardReminderSettings(){
        Colors c=C(); Dialog dlg=new Dialog(this); dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout o=new LinearLayout(this); o.setOrientation(LinearLayout.VERTICAL); o.setPadding(dp(18),dp(18),dp(18),dp(12)); o.setBackground(bg(c.surface,24));
        TextView h=text("🔔  "+s(R.string.ui_def77f6fac),20,c.text); h.setTypeface(null,Typeface.BOLD); o.addView(h);
        TextView sub=text(s(R.string.ui_42d5bbac4d),12,c.muted); margins(sub,0,4,0,12); o.addView(sub);
        LinearLayout choices=card(c.bg,18); choices.setPadding(dp(8),dp(8),dp(8),dp(8));
        int[] days={10,5,3,1};
        for(int d:days){
            final int dd=d; final boolean selected=cardReminderDays==d;
            LinearLayout choice=row(); choice.setPadding(dp(12),dp(10),dp(10),dp(10));
            choice.setBackground(strokeBg(selected?c.blue2:c.surface,selected?c.blue:c.border,15));
            SimpleIconView ci=new SimpleIconView(this,"calendar",selected?c.blue:c.muted); choice.addView(ci,new LinearLayout.LayoutParams(dp(34),dp(34)));
            LinearLayout ccop=new LinearLayout(this);ccop.setOrientation(LinearLayout.VERTICAL);ccop.setPadding(dp(10),0,dp(8),0);
            TextView ct=text(s(R.string.ui_days_before,d),14,selected?c.blue:c.text);ct.setTypeface(null,Typeface.BOLD);ccop.addView(ct);
            choice.addView(ccop,new LinearLayout.LayoutParams(0,-2,1));
            TextView mark=text(selected?"✓":"›",18,selected?c.blue:c.muted);mark.setGravity(Gravity.CENTER);choice.addView(mark,new LinearLayout.LayoutParams(dp(28),dp(34)));margins(choice,0,4,0,0);choices.addView(choice);attachPressFeedback(choice);
            choice.setOnClickListener(v->{cardReminderDays=dd;saveReminderPrefs();for(CreditCard cc:creditCards)clearCustomReminder(cc);scheduleAllCardReminders();dlg.dismiss();showSettings();});
        }
        final boolean none=cardReminderDays<=0; LinearLayout off=row();off.setPadding(dp(12),dp(10),dp(10),dp(10));off.setBackground(strokeBg(none?c.red2:c.surface,none?c.red:c.border,15));SimpleIconView oi=new SimpleIconView(this,"bell",none?c.red:c.muted);off.addView(oi,new LinearLayout.LayoutParams(dp(34),dp(34)));LinearLayout oc=new LinearLayout(this);oc.setOrientation(LinearLayout.VERTICAL);oc.setPadding(dp(10),0,dp(8),0);TextView ot=text(s(R.string.ui_cfa29aeb37),14,none?c.red:c.text);ot.setTypeface(null,Typeface.BOLD);oc.addView(ot);off.addView(oc,new LinearLayout.LayoutParams(0,-2,1));TextView om=text(none?"✓":"›",18,none?c.red:c.muted);om.setGravity(Gravity.CENTER);off.addView(om,new LinearLayout.LayoutParams(dp(28),dp(34)));margins(off,0,0,0,0);choices.addView(off);attachPressFeedback(off);off.setOnClickListener(v->{cardReminderDays=0;saveReminderPrefs();for(CreditCard cc:creditCards){cancelReminderAlarm(cc,false);cancelReminderAlarm(cc,true);}dlg.dismiss();showSettings();});
        o.addView(choices);
        LinearLayout timeRow=row(); timeRow.setPadding(dp(12),dp(8),dp(8),dp(8)); timeRow.setBackground(strokeBg(c.bg,c.border,14));
        LinearLayout timeCopy=new LinearLayout(this); timeCopy.setOrientation(LinearLayout.VERTICAL);
        TextView timeTitle=text("⏰  "+s(R.string.ui_370839b675),14,c.text); timeTitle.setTypeface(null,Typeface.BOLD); timeCopy.addView(timeTitle);
        TextView timeSub=text(reminderTimeSummary(),11,c.muted); timeCopy.addView(timeSub); timeRow.addView(timeCopy,new LinearLayout.LayoutParams(0,-2,1));
        Button timeBtn=dialogButton(s(R.string.ui_2a953cab48),Color.WHITE,c.blue); timeBtn.setTextSize(12); timeRow.addView(timeBtn,new LinearLayout.LayoutParams(dp(88),dp(48)));
        margins(timeRow,0,12,0,0);o.addView(timeRow); timeBtn.setOnClickListener(v->pickReminderTimeSettings(dlg));
        LinearLayout sr=row(); sr.setPadding(dp(12),dp(8),dp(8),dp(8)); sr.setBackground(strokeBg(c.bg,c.border,14));
        LinearLayout st=new LinearLayout(this); st.setOrientation(LinearLayout.VERTICAL);
        TextView st1=text(s(R.string.ui_793bad1fe2),14,c.text); st1.setTypeface(null,Typeface.BOLD); st.addView(st1);
        TextView st2=text(s(R.string.ui_e8bcaf8e16),11,c.muted); st.addView(st2);
        sr.addView(st,new LinearLayout.LayoutParams(0,-2,1)); Switch sw=new Switch(this); sw.setChecked(cardReminderSound); sw.setOnCheckedChangeListener((b,is)->{cardReminderSound=is;saveReminderPrefs();createReminderChannel();scheduleAllCardReminders();}); sr.addView(sw,new LinearLayout.LayoutParams(dp(56),dp(52)));
        margins(sr,0,12,0,0); o.addView(sr);
        Button close=dialogButton(s(R.string.ui_05a86eba57),c.muted,c.surface); o.addView(close,new LinearLayout.LayoutParams(-1,dp(50))); close.setOnClickListener(v->dlg.dismiss());
        dlg.setContentView(o); dlg.show(); Window w=dlg.getWindow(); if(w!=null)w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);
    }

    void showSettings(){
        enterScreen("settings");
        int restoreScrollY=(activeScrollView!=null)?activeScrollView.getScrollY():0;
        rebuildingSettings=true;
        marketsVisible=false;
        base(s(R.string.ui_e26cb640b4));
        Colors settingsColors=C();LinearLayout settingsHero=card(darkMode?Color.rgb(31,31,31):Color.rgb(246,247,250),22);settingsHero.setPadding(dp(18),dp(16),dp(18),dp(16));LinearLayout settingsRow=row();SimpleIconView settingsIcon=new SimpleIconView(this,"settings",settingsColors.blue);settingsRow.addView(settingsIcon,new LinearLayout.LayoutParams(dp(48),dp(48)));LinearLayout settingsCopy=new LinearLayout(this);settingsCopy.setOrientation(LinearLayout.VERTICAL);settingsCopy.setPadding(dp(12),0,0,0);TextView settingsTitle=text(s(R.string.ui_54ce4d97af),19,settingsColors.text);settingsTitle.setTypeface(null,Typeface.BOLD);settingsCopy.addView(settingsTitle);TextView settingsSub=text(s(R.string.ui_37e9e286e4),12,settingsColors.muted);settingsCopy.addView(settingsSub);settingsRow.addView(settingsCopy,new LinearLayout.LayoutParams(0,-2,1));settingsHero.addView(settingsRow);margins(settingsHero,0,0,0,16);content.addView(settingsHero);
        TextView appearance=text(s(R.string.ui_14345c470e),17,C().text);appearance.setTypeface(null,1);margins(appearance,2,4,2,8);content.addView(appearance);
        LinearLayout theme=card(C().surface,16);theme.setPadding(dp(14),dp(6),dp(14),dp(6));
        addChoice(theme,"☀  "+s(R.string.ui_c8e7329350),themeMode==0,()->{themeMode=0;darkMode=false;savePrefs();showSettings();});
        addChoice(theme,"☾  "+s(R.string.ui_13cf0e60ca),themeMode==1,()->{themeMode=1;darkMode=true;savePrefs();showSettings();});
        addChoice(theme,"⚙  "+s(R.string.ui_50038a8361),themeMode==2,()->{themeMode=2;darkMode=isSystemDark();savePrefs();showSettings();});content.addView(theme);
        TextView lang=text(s(R.string.ui_98e07b9947),17,C().text);lang.setTypeface(null,1);margins(lang,2,18,2,8);content.addView(lang);
        LinearLayout langs=card(C().surface,16);langs.setPadding(dp(14),dp(6),dp(14),dp(6));
        addChoice(langs,"🇹🇷  Türkçe",language.equals("tr"),()->changeAppLanguage("tr"));
        addChoice(langs,"🇬🇧  English",language.equals("en"),()->changeAppLanguage("en"));
        addChoice(langs,"🇫🇷  Français",language.equals("fr"),()->changeAppLanguage("fr"));
        addChoice(langs,"🇷🇺  Русский",language.equals("ru"),()->changeAppLanguage("ru"));
        addChoice(langs,"🇩🇪  Deutsch",language.equals("de"),()->changeAppLanguage("de"));
        addChoice(langs,"🇯🇵  日本語",language.equals("ja"),()->changeAppLanguage("ja"));
        addChoice(langs,"🇨🇳  中文",language.equals("zh"),()->changeAppLanguage("zh"));
        addChoice(langs,"🇸🇦  العربية",language.equals("ar"),()->changeAppLanguage("ar"));
        addChoice(langs,"🇬🇷  Ελληνικά",language.equals("el"),()->changeAppLanguage("el"));
        addChoice(langs,"🇪🇸  Español",language.equals("es"),()->changeAppLanguage("es"));
        addChoice(langs,"🇮🇹  Italiano",language.equals("it"),()->changeAppLanguage("it"));
        content.addView(langs);
        TextView marketTitle=text(s(R.string.ui_953d1972c3),17,C().text);marketTitle.setTypeface(null,1);margins(marketTitle,2,18,2,8);content.addView(marketTitle);
        LinearLayout marketSetting=card(C().surface,16);marketSetting.setTag("finbi_market_auto");marketSetting.setPadding(dp(14),dp(8),dp(10),dp(8));
        LinearLayout marketRow=row();
        LinearLayout marketCopy=new LinearLayout(this);marketCopy.setOrientation(LinearLayout.VERTICAL);
        TextView mt=text(s(R.string.ui_6037d398d4),15,C().text);mt.setTypeface(null,Typeface.BOLD);marketCopy.addView(mt);
        TextView ms=text(s(R.string.ui_742f86079d),11,C().muted);margins(ms,0,3,0,0);marketCopy.addView(ms);
        marketRow.addView(marketCopy,new LinearLayout.LayoutParams(0,-2,1));
        Switch auto=new Switch(this);auto.setChecked(marketAutoUpdate);auto.setOnCheckedChangeListener((buttonView,isChecked)->{marketAutoUpdate=isChecked;savePrefs();if(isChecked){startMarketAutoUpdate(true);}else{stopMarketAutoUpdate();}showSettings();});
        marketRow.addView(auto,new LinearLayout.LayoutParams(dp(56),dp(52)));marketSetting.addView(marketRow);content.addView(marketSetting);
        TextView remTitle=text(s(R.string.ui_4aad807b6c),17,C().text);remTitle.setTypeface(null,1);margins(remTitle,2,18,2,8);content.addView(remTitle);
        LinearLayout remCard=card(C().surface,16);remCard.setPadding(dp(14),dp(8),dp(10),dp(8));
        LinearLayout remRow=row(); LinearLayout remCopy=new LinearLayout(this);remCopy.setOrientation(LinearLayout.VERTICAL);
        TextView rt=text(s(R.string.ui_93c10a0d08),15,C().text);rt.setTypeface(null,Typeface.BOLD);remCopy.addView(rt);
        TextView rs=text(s(R.string.ui_7bce4347cb),11,C().muted);remCopy.addView(rs);
        remRow.addView(remCopy,new LinearLayout.LayoutParams(0,-2,1));
        String reminderChoice=cardReminderDays>0?s(R.string.ui_days_before_arrow, cardReminderDays):s(R.string.ui_b82f91a3bd);
        Button rb=dialogButton(reminderChoice,Color.WHITE,C().blue);rb.setTextSize(12);remRow.addView(rb,new LinearLayout.LayoutParams(dp(156),dp(48)));rb.setOnClickListener(v->showCardReminderSettings());remCard.addView(remRow);content.addView(remCard);
        TextView securityTitle=text(trUi("Güvenlik","Security"),17,C().text);securityTitle.setTypeface(null,1);margins(securityTitle,2,18,2,8);content.addView(securityTitle);
        LinearLayout lockCard=card(C().surface,16); lockCard.setPadding(dp(14),dp(8),dp(10),dp(8)); LinearLayout lockRow=row(); LinearLayout lockCopy=new LinearLayout(this); lockCopy.setOrientation(LinearLayout.VERTICAL);TextView lt=text(trUi("Uygulama kilidi","App lock"),15,C().text);lt.setTypeface(null,Typeface.BOLD);lockCopy.addView(lt);TextView ls=text(trUi("Finway'i PIN ile koru","Protect Finway with a PIN"),11,C().muted);lockCopy.addView(ls);lockRow.addView(lockCopy,new LinearLayout.LayoutParams(0,-2,1));Switch lockSwitch=new Switch(this);lockSwitch.setChecked(appLockEnabled);lockRow.addView(lockSwitch,new LinearLayout.LayoutParams(dp(56),dp(52)));lockCard.addView(lockRow);content.addView(lockCard);lockSwitch.setOnCheckedChangeListener((bv,checked)->{if(rebuildingSettings)return;if(checked)setupAppPin();else disableAppLockWithPin();});
        if(appLockEnabled){ LinearLayout bioCard=card(C().surface,16); bioCard.setPadding(dp(14),dp(8),dp(10),dp(8)); LinearLayout bioRow=row(); LinearLayout bioCopy=new LinearLayout(this); bioCopy.setOrientation(LinearLayout.VERTICAL);TextView bt=text(trUi("Biyometrik giriş","Biometric login"),15,C().text);bt.setTypeface(null,Typeface.BOLD);bioCopy.addView(bt);TextView bs=text(trUi("Parmak izi veya biyometrik doğrulama ile aç","Unlock with fingerprint or biometric authentication"),11,C().muted);bioCopy.addView(bs);bioRow.addView(bioCopy,new LinearLayout.LayoutParams(0,-2,1));Switch bioSwitch=new Switch(this);bioSwitch.setChecked(biometricEnabled);bioRow.addView(bioSwitch,new LinearLayout.LayoutParams(dp(56),dp(52)));bioCard.addView(bioRow);content.addView(bioCard);bioSwitch.setOnCheckedChangeListener((bv,checked)->{
            if(rebuildingSettings)return;
            try{
                if(checked){
                    if(!biometricAvailable()){
                        if(bv.isChecked()) bv.setChecked(false);
                        Toast.makeText(this,trUi("Cihazda kullanılabilir bir biyometrik doğrulama bulunamadı.","No usable biometric authentication is available on this device."),Toast.LENGTH_LONG).show();
                        return;
                    }
                    biometricEnabled=true;
                    getPreferences(0).edit().putBoolean("app_lock_biometric",true).apply();
                }else{
                    biometricEnabled=false;
                    getPreferences(0).edit().putBoolean("app_lock_biometric",false).apply();
                }
            }catch(Throwable t){
                biometricEnabled=false;
                getPreferences(0).edit().putBoolean("app_lock_biometric",false).apply();
                if(bv.isChecked()) bv.setChecked(false);
                Toast.makeText(this,trUi("Biyometrik ayarı değiştirilemedi. PIN ile devam edebilirsiniz.","Biometric setting could not be changed. You can continue with your PIN."),Toast.LENGTH_LONG).show();
            }
        }); }
        TextView note=text(s(R.string.ui_c19e1d44e5),12,C().muted);margins(note,4,12,4,0);content.addView(note);
        final int y=Math.max(0,restoreScrollY);
        if(activeScrollView!=null){
            activeScrollView.post(()->{
                activeScrollView.scrollTo(0,y);
                activeScrollView.postDelayed(()->activeScrollView.scrollTo(0,y),80);
                rebuildingSettings=false;
            });
        }else rebuildingSettings=false;
    }
    void addChoice(LinearLayout parent,String label,boolean selected,final Runnable action){TextView t=text((selected?"●  ":"○  ")+label,15,selected?C().blue:C().text);t.setPadding(dp(8),dp(12),dp(8),dp(12));parent.addView(t);attachPressFeedback(t);t.setOnClickListener(v->action.run());}
    static class AppNotification {
        long id, time; String title, body, category, action; int priority; boolean read;
        AppNotification(long id,long time,String title,String body,boolean read){this(id,time,title,body,"general","",1,read);}
        AppNotification(long id,long time,String title,String body,String category,String action,int priority,boolean read){this.id=id;this.time=time;this.title=title;this.body=body;this.category=category;this.action=action;this.priority=priority;this.read=read;}
    }
    ArrayList<AppNotification> loadNotifications(){
        ArrayList<AppNotification> list=new ArrayList<>();
        try{
            JSONArray a=new JSONArray(getPreferences(0).getString("appNotifications","[]"));
            for(int i=0;i<a.length();i++){
                JSONObject o=a.getJSONObject(i);
                list.add(new AppNotification(o.optLong("id",System.currentTimeMillis()+i),o.optLong("time",System.currentTimeMillis()),o.optString("title","Finway"),o.optString("body",""),o.optString("category","general"),o.optString("action",""),o.optInt("priority",1),o.optBoolean("read",false)));
            }
        }catch(Exception ignored){}
        return list;
    }
    void saveNotifications(ArrayList<AppNotification> list){
        try{
            JSONArray a=new JSONArray();
            int start=Math.max(0,list.size()-50);
            for(int i=start;i<list.size();i++){
                AppNotification n=list.get(i); JSONObject o=new JSONObject();
                o.put("id",n.id);o.put("time",n.time);o.put("title",n.title);o.put("body",n.body);o.put("category",n.category);o.put("action",n.action);o.put("priority",n.priority);o.put("read",n.read);a.put(o);
            }
            getPreferences(0).edit().putString("appNotifications",a.toString()).apply();
        }catch(Exception ignored){}
    }
    int unreadNotificationCount(){
        int count=0; for(AppNotification n:loadNotifications()) if(!n.read) count++; return count;
    }
    void updateNotificationBadge(){
        if(notificationBadge==null)return;
        int count=unreadNotificationCount();
        if(count<=0){notificationBadge.setVisibility(View.GONE);return;}
        notificationBadge.setVisibility(View.VISIBLE);
        notificationBadge.setText(count>99?"99+":String.valueOf(count));
    }
    String[] smartNotice(String type, String name, int value, String amount1, String amount2){
        String n=name==null?"":name;
        String a1=amount1==null?"":amount1;
        String a2=amount2==null?"":amount2;
        if("en".equals(language)){
            if("card_due".equals(type)) return new String[]{"Credit card payment is approaching",n+" — "+value+" day(s) remain until the payment due date."};
            if("card_limit".equals(type)) return new String[]{"Card limit is getting close", "You are using "+value+"% of "+n+"'s limit. Available limit: "+a1+"."};
            if("goal".equals(type)) return new String[]{"You're getting close to your goal",n+" is "+value+"% complete. Remaining: "+a1+"."};
            if("spike".equals(type)) return new String[]{"Finbi noticed a change",n+" spending is approximately "+value+"% higher this month than last month. We can review it together."};
            if("budget_over".equals(type)) return new String[]{"You went over your monthly budget","You spent "+a1+" this month; your budget is "+a2+"."};
            if("budget_80".equals(type)) return new String[]{"You have used 80% of your budget","You spent "+a1+" this month. Remaining budget: "+a2+"."};
        }
        if("fr".equals(language)){
            if("card_due".equals(type)) return new String[]{"Le paiement de la carte approche",n+" — il reste "+value+" jour(s) avant la date d’échéance."};
            if("card_limit".equals(type)) return new String[]{"La limite de la carte approche","Vous utilisez "+value+" % de la limite de "+n+". Limite disponible : "+a1+"."};
            if("goal".equals(type)) return new String[]{"Vous approchez de votre objectif",n+" est réalisé à "+value+" %. Il reste : "+a1+"."};
            if("spike".equals(type)) return new String[]{"Finbi a remarqué un changement","Vos dépenses pour "+n+" ont augmenté d’environ "+value+" % ce mois-ci par rapport au mois dernier. Nous pouvons les examiner ensemble."};
            if("budget_over".equals(type)) return new String[]{"Vous avez dépassé votre budget mensuel","Vous avez dépensé "+a1+" ce mois-ci ; votre budget est de "+a2+"."};
            if("budget_80".equals(type)) return new String[]{"Vous avez utilisé 80 % de votre budget","Vous avez dépensé "+a1+" ce mois-ci. Budget restant : "+a2+"."};
        }
        if("de".equals(language)){
            if("card_due".equals(type)) return new String[]{"Kreditkartenzahlung steht bevor",n+" — noch "+value+" Tag(e) bis zum Zahlungstermin."};
            if("card_limit".equals(type)) return new String[]{"Das Kartenlimit wird knapp","Du nutzt "+value+" % des Limits von "+n+". Verfügbares Limit: "+a1+"."};
            if("goal".equals(type)) return new String[]{"Du bist deinem Ziel schon sehr nah",n+" ist zu "+value+" % erreicht. Verbleibend: "+a1+"."};
            if("spike".equals(type)) return new String[]{"Finbi hat eine Veränderung bemerkt","Deine Ausgaben für "+n+" sind diesen Monat etwa "+value+" % höher als im letzten Monat. Wir können sie gemeinsam prüfen."};
            if("budget_over".equals(type)) return new String[]{"Du hast dein Monatsbudget überschritten","Du hast diesen Monat "+a1+" ausgegeben; dein Budget beträgt "+a2+"."};
            if("budget_80".equals(type)) return new String[]{"Du hast 80 % deines Budgets erreicht","Du hast diesen Monat "+a1+" ausgegeben. Verbleibendes Budget: "+a2+"."};
        }
        if("ru".equals(language)){
            if("card_due".equals(type)) return new String[]{"Приближается платеж по карте",n+" — до срока платежа осталось дней: "+value+"."};
            if("card_limit".equals(type)) return new String[]{"Лимит карты близок","Вы используете "+value+"% лимита карты «"+n+"». Доступный лимит: "+a1+"."};
            if("goal".equals(type)) return new String[]{"Вы близки к своей цели",n+" выполнена на "+value+"%. Осталось: "+a1+"."};
            if("spike".equals(type)) return new String[]{"Finbi заметил изменение","Ваши расходы на «"+n+"» в этом месяце примерно на "+value+"% выше, чем в прошлом. Давайте разберёмся вместе."};
            if("budget_over".equals(type)) return new String[]{"Вы превысили месячный бюджет","В этом месяце вы потратили "+a1+"; ваш бюджет: "+a2+"."};
            if("budget_80".equals(type)) return new String[]{"Вы использовали 80% бюджета","В этом месяце вы потратили "+a1+". Остаток бюджета: "+a2+"."};
        }
        if("es".equals(language)){
            if("card_due".equals(type)) return new String[]{"Se acerca el pago de la tarjeta",n+" — quedan "+value+" día(s) para la fecha de pago."};
            if("card_limit".equals(type)) return new String[]{"Te acercas al límite de la tarjeta","Estás usando el "+value+" % del límite de "+n+". Límite disponible: "+a1+"."};
            if("goal".equals(type)) return new String[]{"Te acercas a tu objetivo",n+" está completado en un "+value+" %. Queda: "+a1+"."};
            if("spike".equals(type)) return new String[]{"Finbi detectó un cambio","Tus gastos en "+n+" han aumentado aproximadamente un "+value+" % este mes frente al anterior. Podemos revisarlos juntos."};
            if("budget_over".equals(type)) return new String[]{"Has superado tu presupuesto mensual","Este mes has gastado "+a1+"; tu presupuesto es de "+a2+"."};
            if("budget_80".equals(type)) return new String[]{"Has utilizado el 80 % de tu presupuesto","Este mes has gastado "+a1+". Presupuesto restante: "+a2+"."};
        }
        if("it".equals(language)){
            if("card_due".equals(type)) return new String[]{"Si avvicina il pagamento della carta",n+" — mancano "+value+" giorno/i alla scadenza del pagamento."};
            if("card_limit".equals(type)) return new String[]{"Ti stai avvicinando al limite della carta","Stai usando il "+value+"% del limite di "+n+". Limite disponibile: "+a1+"."};
            if("goal".equals(type)) return new String[]{"Sei vicino al tuo obiettivo",n+" è completato al "+value+"%. Rimanente: "+a1+"."};
            if("spike".equals(type)) return new String[]{"Finbi ha notato un cambiamento","Le tue spese per "+n+" sono aumentate di circa il "+value+"% questo mese rispetto al mese scorso. Possiamo esaminarle insieme."};
            if("budget_over".equals(type)) return new String[]{"Hai superato il budget mensile","Questo mese hai speso "+a1+"; il tuo budget è "+a2+"."};
            if("budget_80".equals(type)) return new String[]{"Hai utilizzato l’80% del budget","Questo mese hai speso "+a1+". Budget rimanente: "+a2+"."};
        }
        if("el".equals(language)){
            if("card_due".equals(type)) return new String[]{"Πλησιάζει η πληρωμή της κάρτας",n+" — απομένουν "+value+" ημέρες μέχρι την ημερομηνία πληρωμής."};
            if("card_limit".equals(type)) return new String[]{"Πλησιάζεις το όριο της κάρτας","Χρησιμοποιείς το "+value+"% του ορίου της "+n+". Διαθέσιμο όριο: "+a1+"."};
            if("goal".equals(type)) return new String[]{"Πλησιάζεις τον στόχο σου",n+" έχει ολοκληρωθεί κατά "+value+"%. Απομένουν: "+a1+"."};
            if("spike".equals(type)) return new String[]{"Το Finbi εντόπισε μια αλλαγή","Οι δαπάνες σου για "+n+" αυξήθηκαν περίπου κατά "+value+"% αυτόν τον μήνα σε σχέση με τον προηγούμενο. Μπορούμε να τις εξετάσουμε μαζί."};
            if("budget_over".equals(type)) return new String[]{"Ξεπέρασες τον μηνιαίο προϋπολογισμό σου","Αυτόν τον μήνα ξόδεψες "+a1+"· ο προϋπολογισμός σου είναι "+a2+"."};
            if("budget_80".equals(type)) return new String[]{"Έχεις χρησιμοποιήσει το 80% του προϋπολογισμού σου","Αυτόν τον μήνα ξόδεψες "+a1+". Υπόλοιπο προϋπολογισμού: "+a2+"."};
        }
        if("ar".equals(language)){
            if("card_due".equals(type)) return new String[]{"اقترب موعد سداد البطاقة",n+" — تبقى "+value+" يوم/أيام على موعد السداد."};
            if("card_limit".equals(type)) return new String[]{"اقتربت من حد البطاقة","تستخدم "+value+"٪ من حد بطاقة «"+n+"». الحد المتاح: "+a1+"."};
            if("goal".equals(type)) return new String[]{"أنت قريب من هدفك",n+" مكتمل بنسبة "+value+"٪. المتبقي: "+a1+"."};
            if("spike".equals(type)) return new String[]{"لاحظ Finbi تغييرًا","زادت نفقاتك في "+n+" بنحو "+value+"٪ هذا الشهر مقارنة بالشهر الماضي. يمكننا مراجعتها معًا."};
            if("budget_over".equals(type)) return new String[]{"لقد تجاوزت ميزانيتك الشهرية","أنفقت هذا الشهر "+a1+"؛ ميزانيتك هي "+a2+"."};
            if("budget_80".equals(type)) return new String[]{"استخدمت 80٪ من ميزانيتك","أنفقت هذا الشهر "+a1+". الميزانية المتبقية: "+a2+"."};
        }
        if("ja".equals(language)){
            if("card_due".equals(type)) return new String[]{"カードの支払日が近づいています",n+" — 支払日まであと"+value+"日です。"};
            if("card_limit".equals(type)) return new String[]{"カード利用限度額に近づいています",n+"の限度額の"+value+"%を利用しています。利用可能額: "+a1+"。"};
            if("goal".equals(type)) return new String[]{"目標達成まであと少しです",n+"は"+value+"%達成しています。残り: "+a1+"。"};
            if("spike".equals(type)) return new String[]{"Finbiが変化を検知しました",n+"への支出は先月と比べて今月約"+value+"%増えています。一緒に確認できます。"};
            if("budget_over".equals(type)) return new String[]{"月間予算を超えました","今月は"+a1+"を使いました。予算は"+a2+"です。"};
            if("budget_80".equals(type)) return new String[]{"予算の80%を使用しました","今月は"+a1+"を使いました。残りの予算: "+a2+"。"};
        }
        if("zh".equals(language)){
            if("card_due".equals(type)) return new String[]{"信用卡还款日期临近",n+" — 距离还款日期还有"+value+"天。"};
            if("card_limit".equals(type)) return new String[]{"信用卡额度即将达到上限","你已使用“"+n+"”额度的"+value+"%。可用额度："+a1+"。"};
            if("goal".equals(type)) return new String[]{"你离目标很近了",n+"已完成"+value+"%。剩余："+a1+"。"};
            if("spike".equals(type)) return new String[]{"Finbi发现了变化","你本月在“"+n+"”上的支出比上月增加约"+value+"%。我们可以一起查看。"};
            if("budget_over".equals(type)) return new String[]{"你已超出每月预算","你本月已花费"+a1+"；预算为"+a2+"。"};
            if("budget_80".equals(type)) return new String[]{"你已使用80%的预算","你本月已花费"+a1+"。剩余预算："+a2+"。"};
        }
        if("tr".equals(language)){
            if("card_due".equals(type)) return new String[]{"Kredi kartı ödemesi yaklaşıyor",n+" için son ödeme tarihine "+value+" gün kaldı."};
            if("card_limit".equals(type)) return new String[]{"Kart limitin yaklaşıyor",n+" limitinin %"+value+"'ini kullanıyorsun. Kullanılabilir limit: "+a1+"."};
            if("goal".equals(type)) return new String[]{"Hedefine çok yaklaştın",n+" hedefinin %"+value+"'ı tamamlandı. Kalan: "+a1+"."};
            if("spike".equals(type)) return new String[]{"Finbi bir değişiklik fark etti",n+" harcaman bu ay geçen aya göre yaklaşık %"+value+" arttı. İstersen birlikte inceleyebiliriz."};
            if("budget_over".equals(type)) return new String[]{"Aylık bütçeni aştın","Bu ay "+a1+" harcadın; bütçen "+a2+"."};
            if("budget_80".equals(type)) return new String[]{"Bütçenin %80'ine ulaştın","Bu ay "+a1+" harcadın. Kalan bütçe: "+a2+"."};
        }
        // Safe fallback for unknown/legacy locale values.
        if("card_due".equals(type)) return new String[]{"Kredi kartı ödemesi yaklaşıyor",n+" için son ödeme tarihine "+value+" gün kaldı."};
        if("card_limit".equals(type)) return new String[]{"Kart limitin yaklaşıyor",n+" limitinin %"+value+"'ini kullanıyorsun. Kullanılabilir limit: "+a1+"."};
        if("goal".equals(type)) return new String[]{"Hedefine çok yaklaştın",n+" hedefinin %"+value+"'ı tamamlandı. Kalan: "+a1+"."};
        if("spike".equals(type)) return new String[]{"Finbi bir değişiklik fark etti",n+" harcaman bu ay geçen aya göre yaklaşık %"+value+" arttı. İstersen birlikte inceleyebiliriz."};
        if("budget_over".equals(type)) return new String[]{"Aylık bütçeni aştın","Bu ay "+a1+" harcadın; bütçen "+a2+"."};
        return new String[]{"Bütçenin %80'ine ulaştın","Bu ay "+a1+" harcadın. Kalan bütçe: "+a2+"."};
    }

    void changeAppLanguage(String newLanguage){
        if(newLanguage==null || newLanguage.equals(language)) return;
        clearSmartNotificationsForLanguageChange();
        language=newLanguage;
        savePrefs();
        recreate();
    }
    boolean isSmartCardNotificationTitle(String title){
        if(title==null)return false;
        String[] titles={
            "Kredi kartı ödemesi yaklaşıyor","Kart limitin yaklaşıyor",
            "Credit card payment is approaching","Card limit is getting close",
            "Le paiement de la carte approche","La limite de la carte approche",
            "Приближается платеж по карте","Лимит карты близок",
            "Kreditkartenzahlung steht bevor","Das Kartenlimit wird knapp",
            "カードの支払日が近づいています","カード利用限度額に近づいています",
            "信用卡还款日期临近","信用卡额度即将达到上限",
            "اقترب موعد سداد البطاقة","اقتربت من حد البطاقة",
            "Πλησιάζει η πληρωμή της κάρτας","Πλησιάζεις το όριο της κάρτας",
            "Se acerca el pago de la tarjeta","Te acercas al límite de la tarjeta",
            "Si avvicina il pagamento della carta","Ti stai avvicinando al limite della carta"
        };
        for(String x:titles)if(x.equals(title))return true;
        return false;
    }
    void clearSmartNotificationsForLanguageChange(){
        try{
            SharedPreferences sp=getPreferences(0);
            Map<String,?> all=sp.getAll();
            SharedPreferences.Editor e=sp.edit();
            for(String key:all.keySet()) if(key.startsWith("smart_")) e.remove(key);
            e.apply();
            ArrayList<AppNotification> list=loadNotifications();
            ArrayList<AppNotification> kept=new ArrayList<>();
            for(AppNotification n:list){
                boolean smart = "goal".equals(n.category)
                    || ("spending".equals(n.category) && ("transactions".equals(n.action)||"finbi".equals(n.action)))
                    || ("card".equals(n.category) && "cards".equals(n.action) && isSmartCardNotificationTitle(n.title));
                if(!smart) kept.add(n);
            }
            saveNotifications(kept);
            if(Build.VERSION.SDK_INT>=23){
                NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
                if(nm!=null){
                    for(StatusBarNotification sbn:nm.getActiveNotifications()){
                        if(Build.VERSION.SDK_INT>=26 && "finway_smart".equals(sbn.getNotification().getChannelId())) nm.cancel(sbn.getId());
                    }
                }
            }
        }catch(Exception ignored){}
    }

    void runSmartNotificationEngine(){
        try{
            long now=System.currentTimeMillis(); Calendar today=Calendar.getInstance();
            String dayKey=new SimpleDateFormat("yyyyMMdd",Locale.US).format(today.getTime());
            SharedPreferences sp=getPreferences(0);
            ArrayList<AppNotification> existing=loadNotifications();
            int generated=0;
            // Keep the notification center lively without spamming: at most 3 smart notices/day.
            for(CreditCard cc:new ArrayList<>(creditCards)){
                if(generated>=3)break; if(cc==null)continue;
                int due=cc.dueDay; if(due<=0)continue;
                Calendar dueCal=(Calendar)today.clone();dueCal.set(Calendar.DAY_OF_MONTH,Math.min(due,dueCal.getActualMaximum(Calendar.DAY_OF_MONTH)));dueCal.set(Calendar.HOUR_OF_DAY,23);dueCal.set(Calendar.MINUTE,59);
                if(dueCal.before(today))dueCal.add(Calendar.MONTH,1);
                long days=Math.max(0,(dueCal.getTimeInMillis()-today.getTimeInMillis())/(24L*60L*60L*1000L));
                String fp="card_due_"+cc.id+"_"+dayKey;
                if(days<=3 && !sp.getBoolean("smart_"+fp,false)){
                    String[] sn=smartNotice("card_due",cc.name,(int)days,"",""); addSmartNotification("card",sn[0],sn[1],"cards",days<=1?3:2,fp);generated++;
                }
                if(generated>=3)break;
                double ratio=cc.limit>0?cc.debt/cc.limit:0;
                String uf="card_limit_"+cc.id+"_"+dayKey;
                if(ratio>=.80 && !sp.getBoolean("smart_"+uf,false)){
                    String[] sn=smartNotice("card_limit",cc.name,(int)Math.round(ratio*100),money(Math.max(0,cc.limit-cc.debt)),""); addSmartNotification("card",sn[0],sn[1],"cards",3,uf);generated++;
                }
            }
            if(generated<3){
                for(Goal g:new ArrayList<>(goals)){
                    if(g.target<=0)continue; double ratio=g.saved/g.target;
                    if(ratio>=.75){String fp="goal_"+g.id+"_"+dayKey;if(!sp.getBoolean("smart_"+fp,false)){String[] sn=smartNotice("goal",g.name,(int)Math.round(Math.min(1,ratio)*100),money(Math.max(0,g.target-g.saved)),""); addSmartNotification("goal",sn[0],sn[1],"goals",1,fp);generated++;break;}}
                }
            }
            if(generated<3){
                Calendar cur=Calendar.getInstance();Calendar prev=(Calendar)cur.clone();prev.add(Calendar.MONTH,-1);
                HashMap<String,Double> cm=categoryTotals(cur),pm=categoryTotals(prev);String best=null;double bestCur=0,bestPrev=0;
                for(String cat:cm.keySet()){double a=cm.getOrDefault(cat,0.0),b=pm.getOrDefault(cat,0.0);if(a>100 && a>b*1.25 && a>bestCur){best=cat;bestCur=a;bestPrev=b;}}
                if(best!=null){String fp="spike_"+best.replace(" ","_")+"_"+dayKey;if(!sp.getBoolean("smart_"+fp,false)){int pct=bestPrev>0?(int)Math.round((bestCur/bestPrev-1)*100):100;String[] sn=smartNotice("spike",best,pct,"",""); addSmartNotification("spending",sn[0],sn[1],"finbi",1,fp);}}
            }
            if(generated<3){
                double bud=monthlyBudget();
                if(bud>0){
                    Calendar cur2=Calendar.getInstance();double spent=0;for(double v:categoryTotals(cur2).values())spent+=v;
                    double r2=spent/bud;String mk=new SimpleDateFormat("yyyyMM",Locale.US).format(cur2.getTime());
                    if(r2>=1.0){String fp="budget_100_"+mk;if(!sp.getBoolean("smart_"+fp,false)){String[] sn=smartNotice("budget_over","",0,money(spent),money(bud)); addSmartNotification("spending",sn[0],sn[1],"transactions",3,fp);generated++;}}
                    else if(r2>=.8){String fp="budget_80_"+mk;if(!sp.getBoolean("smart_"+fp,false)){String[] sn=smartNotice("budget_80","",0,money(spent),money(Math.max(0,bud-spent))); addSmartNotification("spending",sn[0],sn[1],"transactions",2,fp);generated++;}}
                }
            }
        }catch(Exception ignored){}
    }
    HashMap<String,Double> categoryTotals(Calendar cal){HashMap<String,Double> m=new HashMap<>();for(Tx t:txs){if(t.isIncome||t.archived||t.cancelled)continue;Calendar d=parseDateCalendar(t.date);if(d==null||d.get(Calendar.YEAR)!=cal.get(Calendar.YEAR)||d.get(Calendar.MONTH)!=cal.get(Calendar.MONTH))continue;m.put(t.cat,m.getOrDefault(t.cat,0.0)+t.amount);}return m;}
    Calendar parseDateCalendar(String value){try{Calendar c=Calendar.getInstance();c.setTime(df.parse(value));return c;}catch(Exception e){return null;}}
    void addSmartNotification(String category,String title,String body,String action,int priority,String fingerprint){ArrayList<AppNotification> list=loadNotifications();list.add(new AppNotification(System.currentTimeMillis(),System.currentTimeMillis(),title,body,category,action,priority,false));saveNotifications(list);getPreferences(0).edit().putBoolean("smart_"+fingerprint,true).apply();updateNotificationBadge();postSmartSystemNotification(title,body,priority);}
    void postSmartSystemNotification(String title,String body,int priority){try{NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);String channel="finway_smart";if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(channel,trUi("Finway Akıllı Bildirimler","Finway Smart Notifications"),priority>=3?NotificationManager.IMPORTANCE_HIGH:NotificationManager.IMPORTANCE_DEFAULT);nm.createNotificationChannel(ch);}Intent open=new Intent(this,MainActivity.class);open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);PendingIntent pi=PendingIntent.getActivity(this,9101,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);NotificationCompat.Builder b=new NotificationCompat.Builder(this,channel).setSmallIcon(R.mipmap.ic_launcher).setContentTitle(title).setContentText(body).setStyle(new NotificationCompat.BigTextStyle().bigText(body)).setAutoCancel(true).setContentIntent(pi).setPriority(priority>=3?NotificationCompat.PRIORITY_HIGH:NotificationCompat.PRIORITY_DEFAULT);nm.notify((int)(System.currentTimeMillis()%1000000),b.build());}catch(Exception ignored){}}

    void showNotifications(){
        Colors c=C();
        ArrayList<AppNotification> list=loadNotifications();
        Collections.sort(list,(a,b)->Long.compare(b.time,a.time));
        Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(16),dp(18),dp(14));root.setBackground(bg(c.surface,24));
        LinearLayout header=row();
        LinearLayout titleBox=new LinearLayout(this);titleBox.setOrientation(LinearLayout.VERTICAL);
        TextView title=text(s(R.string.ui_57167f4624),22,c.text);title.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));titleBox.addView(title);
        TextView summary=text(notificationSummary(list),11,c.muted);margins(summary,0,2,0,0);titleBox.addView(summary);
        header.addView(titleBox,new LinearLayout.LayoutParams(0,dp(52),1));
        TextView markAll=text(trUi("Tümünü okundu yap","Mark all read"),11,c.blue);markAll.setGravity(Gravity.CENTER);markAll.setPadding(dp(8),0,dp(8),0);header.addView(markAll,new LinearLayout.LayoutParams(dp(104),dp(46)));
        TextView close=text("×",30,c.muted);close.setGravity(Gravity.CENTER);close.setBackground(bg(darkMode?Color.rgb(24,48,69):Color.rgb(242,247,251),18));header.addView(close,new LinearLayout.LayoutParams(dp(46),dp(46)));root.addView(header);close.setOnClickListener(v->dlg.dismiss());
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);LinearLayout listBox=new LinearLayout(this);listBox.setOrientation(LinearLayout.VERTICAL);listBox.setPadding(0,dp(10),0,dp(2));
        Runnable[] render={null};
        render[0]=()->{
            listBox.removeAllViews(); ArrayList<AppNotification> current=loadNotifications(); Collections.sort(current,(a,b)->Long.compare(b.time,a.time));
            if(current.isEmpty()){
                LinearLayout empty=card(darkMode?Color.rgb(14,43,61):Color.rgb(235,247,255),20);empty.setPadding(dp(18),dp(22),dp(18),dp(22));
                TextView et=text(s(R.string.ui_ae2b4921cd),15,c.text);et.setGravity(Gravity.CENTER);et.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));empty.addView(et);
                TextView es=text(s(R.string.ui_631dab4f6a),12,c.muted);es.setGravity(Gravity.CENTER);margins(es,0,7,0,0);empty.addView(es);listBox.addView(empty);return;
            }
            String lastDay="";
            for(AppNotification n:current){
                String day=new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).format(new Date(n.time));
                if(!day.equals(lastDay)){TextView sec=text(notificationDayLabel(n.time),12,c.muted);sec.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));margins(sec,dp(2),8,0,6);listBox.addView(sec);lastDay=day;}
                final AppNotification item=n;
                int accent=item.priority>=3?c.red:(item.priority==2?c.gold:c.blue);
                LinearLayout nc=card(item.read?c.bg:(darkMode?Color.rgb(17,48,70):Color.rgb(238,248,255)),18);nc.setPadding(dp(13),dp(12),dp(13),dp(12));
                LinearLayout r=row();
                FrameLayout iconWrap=new FrameLayout(this);iconWrap.setBackground(bg(darkMode?Color.rgb(19,57,80):Color.rgb(222,241,255),16));SimpleIconView bi=new SimpleIconView(this,notificationIcon(item.category),accent);iconWrap.addView(bi,new FrameLayout.LayoutParams(dp(42),dp(42)));r.addView(iconWrap,new LinearLayout.LayoutParams(dp(42),dp(42)));
                LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(12),0,0,0);
                LinearLayout titleRow=row();TextView nt=text(item.title,14,c.text);nt.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));titleRow.addView(nt,new LinearLayout.LayoutParams(0,-2,1));
                if(!item.read){TextView dot=text("●",10,accent);dot.setGravity(Gravity.CENTER);titleRow.addView(dot,new LinearLayout.LayoutParams(dp(18),dp(24)));} copy.addView(titleRow);
                TextView nb=text(item.body,12,c.muted);nb.setLineSpacing(0,1.12f);margins(nb,0,4,0,0);copy.addView(nb);
                TextView nd=text(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date(item.time)),10,c.muted);copy.addView(nd);
                if(item.action!=null&&!item.action.isEmpty()){
                    TextView act=text(notificationActionLabel(item.action),11,accent);act.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));act.setPadding(0,dp(6),0,0);copy.addView(act);
                }
                r.addView(copy,new LinearLayout.LayoutParams(0,-2,1));nc.addView(r);margins(nc,0,0,0,8);listBox.addView(nc);
                nc.setOnClickListener(v->{
                    item.read=true; ArrayList<AppNotification> saved=loadNotifications(); for(AppNotification x:saved)if(x.id==item.id)x.read=true; saveNotifications(saved); updateNotificationBadge();
                    if(item.action!=null&&!item.action.isEmpty()) handleNotificationAction(item.action,dlg);
                    else render[0].run();
                });
            }
        };
        markAll.setOnClickListener(v->{ArrayList<AppNotification> all=loadNotifications();for(AppNotification n:all)n.read=true;saveNotifications(all);updateNotificationBadge();render[0].run();});
        render[0].run();scroll.addView(listBox);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        Button done=button(trUi("Kapat","Close"),c.blue);done.setTextSize(14);done.setOnClickListener(v->dlg.dismiss());root.addView(done,new LinearLayout.LayoutParams(-1,dp(50)));
        dlg.setContentView(root);dlg.show();Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),Math.min(dp(720),(int)(getResources().getDisplayMetrics().heightPixels*0.86f)));}
    }

    String notificationSummary(ArrayList<AppNotification> list){int unread=0;for(AppNotification n:list)if(!n.read)unread++;return unread>0?unread+" "+trUi("yeni bildirim","new notifications"):(list.size()>0?trUi("Bildirimlerin güncel","Notifications are up to date"):trUi("Önemli gelişmeleri burada göreceksin","Important updates will appear here"));}
    String notificationDayLabel(long t){Calendar n=Calendar.getInstance();Calendar d=Calendar.getInstance();d.setTimeInMillis(t);if(n.get(Calendar.YEAR)==d.get(Calendar.YEAR)&&n.get(Calendar.DAY_OF_YEAR)==d.get(Calendar.DAY_OF_YEAR))return trUi("Bugün","Today");n.add(Calendar.DAY_OF_YEAR,-1);if(n.get(Calendar.YEAR)==d.get(Calendar.YEAR)&&n.get(Calendar.DAY_OF_YEAR)==d.get(Calendar.DAY_OF_YEAR))return trUi("Dün","Yesterday");return new SimpleDateFormat("dd MMMM yyyy",Locale.getDefault()).format(new Date(t));}
    String notificationIcon(String category){if("card".equals(category)||"payment".equals(category))return "card";if("goal".equals(category))return "target";if("spending".equals(category))return "stats";if("account".equals(category))return "savings";if("security".equals(category))return "info";if("finbi".equals(category))return "info";return "bell";}
    String notificationActionLabel(String action){if("cards".equals(action))return trUi("Kartları aç  ›","Open cards  ›");if("transactions".equals(action))return trUi("İşlemleri aç  ›","Open transactions  ›");if("goals".equals(action))return trUi("Hedefleri aç  ›","Open goals  ›");if("accounts".equals(action))return trUi("Hesapları aç  ›","Open accounts  ›");if("finbi".equals(action))return trUi("Finbi ile konuş  ›","Talk to Finbi  ›");return "";}
    void handleNotificationAction(String action,Dialog dlg){if(dlg!=null)dlg.dismiss();if("cards".equals(action)){showCreditCards();return;}if("transactions".equals(action)){showTransactions();return;}if("goals".equals(action)){showGoals();return;}if("accounts".equals(action)){showAccounts();return;}if("finbi".equals(action)){showFinbiChat();return;}}

    String appVersionName(){
        try { return getPackageManager().getPackageInfo(getPackageName(),0).versionName; } catch(Exception e){ return "?"; }
    }
    String appVersionCode(){
        try {
            android.content.pm.PackageInfo p=getPackageManager().getPackageInfo(getPackageName(),0);
            if(android.os.Build.VERSION.SDK_INT>=28) return String.valueOf(p.getLongVersionCode());
            return String.valueOf(p.versionCode);
        } catch(Exception e){ return "?"; }
    }
    void showAbout(){
        // Hakkında bir dialogdur; ekran geçmişine eklenmez.
        // Sürüm bilgisi build.gradle'dan değil, kurulu uygulama paketinden okunur; böylece sabit sürüm metni eskimez.
        // Dialog kapandığında currentScreen aynı sayfada kalmalıdır.
        marketsVisible=false;
        String title="Finway v"+appVersionName();
        String message=s(R.string.ui_baa1c9accc)+"\n\n"+trUi("Sürüm: ","Version: ")+appVersionName()+"\n"+trUi("Yapı: ","Build: ")+appVersionCode();
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton(R.string.ui_ok,null).show();
    }

    private String accountDisplayName(String account){ return "Genel".equals(account)?trUi("Genel","General"):account; }

    LinearLayout accountSelectorCard(String selected){
        Colors c=C();
        LinearLayout box=card(darkMode?Color.rgb(22,48,67):Color.rgb(244,249,253),16);
        box.setPadding(dp(12),dp(8),dp(10),dp(8));
        LinearLayout r=row();
        SimpleIconView icon=new SimpleIconView(this,"wallet",c.blue);
        icon.setBackground(bg(darkMode?Color.rgb(30,66,91):Color.rgb(228,241,255),13));
        r.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(42)));
        LinearLayout copy=new LinearLayout(this); copy.setOrientation(LinearLayout.VERTICAL); copy.setPadding(dp(10),0,0,0);
        TextView name=text(accountDisplayName(selected),15,c.text); name.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL)); copy.addView(name);
        TextView hint=text(trUi("Bakiyenin işlendiği hesap","Account used for this transaction"),10,c.muted); margins(hint,0,2,0,0); copy.addView(hint);
        r.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        TextView arrow=text("›",28,c.blue); arrow.setGravity(Gravity.CENTER); r.addView(arrow,new LinearLayout.LayoutParams(dp(28),dp(42)));
        box.addView(r);
        return box;
    }

    void showAccountPicker(ArrayList<String> options,final String[] selected,final LinearLayout selector){
        Colors c=C(); Dialog pick=new Dialog(this); pick.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(18),dp(18),dp(12)); root.setBackground(bg(c.surface,24));
        TextView h=text(trUi("Hesap seç","Select account"),20,c.text); h.setTypeface(null,Typeface.BOLD); root.addView(h);
        TextView sub=text(trUi("Bu işlem hangi hesaba işlensin?","Which account should receive this transaction?"),11,c.muted); margins(sub,0,4,0,12); root.addView(sub);
        for(String option:options){
            final String value=option;
            LinearLayout rowCard=card(value.equals(selected[0])?(darkMode?Color.rgb(24,61,83):Color.rgb(235,245,255)):c.surface,16);
            rowCard.setPadding(dp(12),dp(9),dp(10),dp(9));
            LinearLayout rr=row(); SimpleIconView ic=new SimpleIconView(this,"wallet",value.equals(selected[0])?c.blue:c.muted);
            ic.setBackground(bg(value.equals(selected[0])?(darkMode?Color.rgb(30,66,91):Color.rgb(228,241,255)):c.bg,13)); rr.addView(ic,new LinearLayout.LayoutParams(dp(40),dp(40)));
            TextView nm=text(accountDisplayName(value),15,c.text); nm.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL)); rr.addView(nm,new LinearLayout.LayoutParams(0,dp(40),1));
            TextView ck=text(value.equals(selected[0])?"✓":"",20,c.blue); ck.setGravity(Gravity.CENTER); rr.addView(ck,new LinearLayout.LayoutParams(dp(28),dp(40)));
            rowCard.addView(rr); margins(rowCard,0,0,0,7); root.addView(rowCard); attachPressFeedback(rowCard);
            rowCard.setOnClickListener(v->{
                selected[0]=value;
                LinearLayout row=(LinearLayout)selector.getChildAt(0);
                LinearLayout copy=(LinearLayout)row.getChildAt(1);
                ((TextView)copy.getChildAt(0)).setText(accountDisplayName(value));
                pick.dismiss();
            });
        }
        Button close=dialogButton(trUi("Vazgeç","Cancel"),c.muted,c.surface); margins(close,0,5,0,0); root.addView(close,new LinearLayout.LayoutParams(-1,dp(48))); close.setOnClickListener(v->pick.dismiss());
        pick.setContentView(root); pick.show(); Window w=pick.getWindow(); if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);}
    }

    private void refreshCurrentScreenAfterTransactionMutation() {
        // Stay on the page where the user started the action. The scroll-position
        // cache in enterScreen()/base() restores the exact visible area.
        switch (currentScreen) {
            case "transactions": showTransactions(); break;
            case "savings": showGoals(); break;
            case "credit": showCreditCards(); break;
            case "accounts": showAccounts(); break;
            case "stats": showStats(); break;
            case "markets": showMarkets(); break;
            case "home":
            default: showHome(); break;
        }
    }

    void dialog(boolean isIncome,Tx edit){
        Colors c=C();
        Dialog dlg=new Dialog(this);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(18),dp(16),dp(18),dp(8));outer.setBackground(bg(c.surface,24));

        LinearLayout header=row();
        TextView badge=text(isIncome?"+$":"-$",22,Color.WHITE);badge.setGravity(Gravity.CENTER);badge.setTypeface(null,1);badge.setBackground(bg(isIncome?c.green:c.red,24));
        header.addView(badge,new LinearLayout.LayoutParams(dp(54),dp(54)));
        LinearLayout ht=new LinearLayout(this);ht.setOrientation(LinearLayout.VERTICAL);ht.setPadding(dp(12),0,dp(4),0);
        TextView title=text(edit==null?(isIncome?s(R.string.ui_732d0cf46d):s(R.string.ui_227e02a0f2)):s(R.string.ui_ba78df83b7),20,isIncome?c.green:c.red);title.setTypeface(null,1);ht.addView(title);
        TextView subtitle=text(isIncome?s(R.string.ui_f33fae6279):s(R.string.ui_75c8460a3e),11,c.muted);margins(subtitle,0,2,0,0);ht.addView(subtitle);
        header.addView(ht,new LinearLayout.LayoutParams(0,-2,1));
        TextView close=text("×",30,c.muted);close.setGravity(Gravity.CENTER);header.addView(close,new LinearLayout.LayoutParams(dp(40),dp(54)));outer.addView(header);

        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(0,dp(12),0,dp(4));

        TextView amountLabel=text(s(R.string.ui_amount_currency, currencyCode),12,c.text);amountLabel.setTypeface(null,1);box.addView(amountLabel);
        EditText amount=modernEdit(s(R.string.ui_7e315f309a),c);amount.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);attachNumberFormatter(amount);amount.setTextSize(17);amount.setTextColor(c.text);box.addView(amount,new LinearLayout.LayoutParams(-1,dp(54)));

        TextView dateLabel=text(s(R.string.ui_3f6ff23cf6),12,c.text);dateLabel.setTypeface(null,1);margins(dateLabel,0,10,0,0);box.addView(dateLabel);
        EditText date=modernEdit("",c);date.setText(df.format(new Date()));date.setTextSize(16);box.addView(date,new LinearLayout.LayoutParams(-1,dp(54)));

        final boolean[] useCard={edit!=null && edit.creditCard}; final long[] selectedCard={edit!=null?edit.cardId:0};
        final Runnable[] refreshCardPreviewRef=new Runnable[]{()->{}};
        if(!isIncome){
            TextView typeLabel=text(s(R.string.ui_354be78e63),12,c.text);typeLabel.setTypeface(null,1);margins(typeLabel,0,10,0,0);box.addView(typeLabel);
            LinearLayout typeChoices=row();
            typeChoices.setPadding(0,dp(2),0,dp(2));
            TextView normalType=text("  "+s(R.string.ui_b3689620aa)+"  ",13,c.text);
            normalType.setGravity(Gravity.CENTER);
            normalType.setTypeface(null,Typeface.BOLD);
            TextView cardType=text("  "+s(R.string.ui_f9ae451d07)+"  ",13,c.muted);
            cardType.setGravity(Gravity.CENTER);
            cardType.setTypeface(null,Typeface.BOLD);
            LinearLayout.LayoutParams ntp=new LinearLayout.LayoutParams(0,dp(58),1);
            LinearLayout.LayoutParams ctp=new LinearLayout.LayoutParams(0,dp(58),1);
            ctp.setMargins(dp(8),0,0,0);
            typeChoices.addView(normalType,ntp);typeChoices.addView(cardType,ctp);
            box.addView(typeChoices);
            View typeAccent=new View(this);typeAccent.setBackground(bg(useCard[0]?c.blue:c.red,3));
            LinearLayout.LayoutParams tap=new LinearLayout.LayoutParams(dp(44),dp(4));
            tap.gravity=Gravity.CENTER_HORIZONTAL;
            margins(typeAccent,0,-4,0,10);
            box.addView(typeAccent,tap);

            TextView cardLabel=text(s(R.string.ui_b983b72fc2),12,c.text);cardLabel.setTypeface(null,1);margins(cardLabel,0,8,0,0);box.addView(cardLabel);
            LinearLayout cardSpinner=card(c.surface,16);cardSpinner.setPadding(dp(14),dp(10),dp(12),dp(10));
            LinearLayout cardRow=row();SimpleIconView cardIcon=new SimpleIconView(this,creditCards.isEmpty()?"card":"card",c.blue);cardIcon.setBackground(bg(darkMode?Color.rgb(30,66,91):Color.rgb(229,242,255),14));cardRow.addView(cardIcon,new LinearLayout.LayoutParams(dp(42),dp(42)));
            LinearLayout cardText=new LinearLayout(this);cardText.setOrientation(LinearLayout.VERTICAL);cardText.setPadding(dp(10),0,0,0);
            int initialCardIndex=0;for(int i=0;i<creditCards.size();i++)if(creditCards.get(i).id==selectedCard[0]){initialCardIndex=i;break;}if(!creditCards.isEmpty()&&selectedCard[0]==0)selectedCard[0]=creditCards.get(initialCardIndex).id;
            CreditCard initialCard=creditCards.isEmpty()?null:creditCards.get(initialCardIndex);
            TextView cardTitle=text(initialCard==null?s(R.string.ui_bf6db5ab56):initialCard.name,15,c.text);cardTitle.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));cardText.addView(cardTitle);
            TextView cardSub=text(initialCard==null?s(R.string.ui_74f5046bad):(initialCard.bank==null||initialCard.bank.trim().isEmpty()?s(R.string.ui_4b56360ff0):initialCard.bank),12,c.muted);margins(cardSub,0,3,0,0);cardText.addView(cardSub);
            cardRow.addView(cardText,new LinearLayout.LayoutParams(0,-2,1));TextView cardArrow=text("›",28,c.muted);cardArrow.setGravity(Gravity.CENTER);cardRow.addView(cardArrow,new LinearLayout.LayoutParams(dp(28),dp(42)));cardSpinner.addView(cardRow);
            box.addView(cardSpinner,new LinearLayout.LayoutParams(-1,dp(64)));
            cardSpinner.setOnClickListener(cardSpinnerView->{
                if(creditCards.isEmpty()){Toast.makeText(this,s(R.string.ui_fcdbe319a3),Toast.LENGTH_LONG).show();return;}
                Dialog pick=new Dialog(this);pick.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout po=new LinearLayout(this);po.setOrientation(LinearLayout.VERTICAL);po.setPadding(dp(18),dp(18),dp(18),dp(12));po.setBackground(bg(c.surface,24));
                TextView ph=text(s(R.string.ui_d7a05c61a2),20,c.text);ph.setTypeface(null,Typeface.BOLD);po.addView(ph);TextView ps=text(s(R.string.ui_2d4a199ca2),12,c.muted);margins(ps,0,3,0,12);po.addView(ps);
                for(int ci=0;ci<creditCards.size();ci++){final CreditCard cc=creditCards.get(ci);LinearLayout crd=card(c.surface,16);crd.setPadding(dp(12),dp(10),dp(12),dp(10));LinearLayout rr=row();SimpleIconView ciView=new SimpleIconView(this,"card",cc.id==selectedCard[0]?c.blue:c.muted);ciView.setBackground(bg(cc.id==selectedCard[0]?(darkMode?Color.rgb(30,66,91):Color.rgb(229,242,255)):c.bg,14));rr.addView(ciView,new LinearLayout.LayoutParams(dp(42),dp(42)));LinearLayout ct=new LinearLayout(this);ct.setOrientation(LinearLayout.VERTICAL);ct.setPadding(dp(10),0,0,0);TextView cn=text(cc.name,15,c.text);cn.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));ct.addView(cn);TextView cb=text((cc.bank==null||cc.bank.trim().isEmpty()?s(R.string.ui_4b56360ff0):cc.bank)+"  •  "+s(R.string.ui_223e7106ee)+" "+money(cc.debt)+"  •  "+s(R.string.ui_4e815149b5)+" "+money(cc.limit),12,c.muted);margins(cb,0,3,0,0);ct.addView(cb);rr.addView(ct,new LinearLayout.LayoutParams(0,-2,1));TextView ck=text(cc.id==selectedCard[0]?"✓":"",20,c.blue);ck.setGravity(Gravity.CENTER);rr.addView(ck,new LinearLayout.LayoutParams(dp(28),dp(42)));crd.addView(rr);margins(crd,0,0,0,7);po.addView(crd);attachPressFeedback(crd);crd.setOnClickListener(cardRowView->{selectedCard[0]=cc.id;cardTitle.setText(cc.name);cardSub.setText((cc.bank==null||cc.bank.trim().isEmpty()?s(R.string.ui_4b56360ff0):cc.bank));pick.dismiss();refreshCardPreviewRef[0].run();});}
                Button closePick=dialogButton(s(R.string.ui_05a86eba57),c.muted,c.surface);margins(closePick,0,4,0,0);po.addView(closePick,new LinearLayout.LayoutParams(-1,dp(48)));closePick.setOnClickListener(closeCardView->pick.dismiss());pick.setContentView(po);pick.show();Window pw=pick.getWindow();if(pw!=null){pw.setBackgroundDrawableResource(android.R.color.transparent);pw.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);}
            });
            TextView cardHint=text(s(R.string.ui_6e879d69f6),11,c.muted);margins(cardHint,0,4,0,8);box.addView(cardHint);

            // Kredi kartı harcaması girilirken borç ve tahmini asgari ödeme anlık gösterilir.
            LinearLayout cardPreview=card(darkMode?Color.rgb(16,48,67):Color.rgb(237,248,255),18);
            cardPreview.setPadding(dp(14),dp(12),dp(14),dp(12));
            TextView previewTitle=text(s(R.string.ui_588b3abc3b),12,c.blue);
            previewTitle.setTypeface(null,Typeface.BOLD);
            cardPreview.addView(previewTitle);
            TextView previewDebt=text(s(R.string.ui_16dd45eefc),14,c.text);
            previewDebt.setTypeface(null,Typeface.BOLD);
            margins(previewDebt,0,5,0,0);
            cardPreview.addView(previewDebt);
            TextView previewMin=text(s(R.string.ui_ae41ce408e),13,c.green);
            previewMin.setTypeface(null,Typeface.BOLD);
            cardPreview.addView(previewMin);
            TextView previewRate=text(s(R.string.ui_bf83680b06),10,c.muted);
            margins(previewRate,0,3,0,0);
            cardPreview.addView(previewRate);
            margins(cardPreview,0,0,0,10);
            box.addView(cardPreview);

            Runnable refreshCardPreview=()->{
                Colors pc=C();
                if(!useCard[0]){ cardPreview.setVisibility(View.GONE); return; }
                cardPreview.setVisibility(View.VISIBLE);
                int pos=-1;
                for(int i=0;i<creditCards.size();i++) if(creditCards.get(i).id==selectedCard[0]){pos=i;break;}
                if(creditCards.isEmpty() || pos<0 || pos>=creditCards.size()){
                    previewDebt.setText(s(R.string.ui_16dd45eefc));
                    previewMin.setText(s(R.string.ui_ae41ce408e));
                    previewRate.setText(s(R.string.ui_fc64cc8c99));
                    return;
                }
                CreditCard selected=creditCards.get(pos);
                double entered=0;
                try{ entered=parseOptionalNum(amount); }catch(Exception ignored){}
                // Düzenleme sırasında aynı kartın eski harcamasını bir kez düşüp yeni tutarı ekliyoruz.
                double baseDebt=Math.max(0,selected.debt);
                if(edit!=null && !edit.isIncome && edit.creditCard && edit.cardId==selected.id) baseDebt=Math.max(0,baseDebt-edit.amount);
                double projectedDebt=baseDebt+Math.max(0,entered);
                double projectedMin=turkiyeMinimumPayment(selected.limit,projectedDebt);
                previewDebt.setText(s(R.string.ui_e50d808654)+money(projectedDebt));
                if(selected.limit<=0){
                    previewMin.setText(s(R.string.ui_79dcbe66d6));
                    previewRate.setText(s(R.string.ui_0260e6fe1c));
                }else{
                    previewMin.setText(s(R.string.ui_6b5bce0957)+money(projectedMin));
                    previewRate.setText(turkiyeMinimumRateText(selected.limit)+s(R.string.ui_b62af2f81b));
                }
                cardPreview.setBackground(strokeBg(darkMode?Color.rgb(16,48,67):Color.rgb(237,248,255),pc.blue,18));
                previewTitle.setTextColor(pc.blue); previewDebt.setTextColor(pc.text); previewMin.setTextColor(pc.green); previewRate.setTextColor(pc.muted);
            };

            refreshCardPreviewRef[0]=refreshCardPreview;
            Runnable refreshTypeUi=()->{
                Colors tc=C();
                normalType.setTextColor(useCard[0]?tc.muted:tc.blue);
                cardType.setTextColor(useCard[0]?tc.blue:tc.muted);
                normalType.setBackground(strokeBg(useCard[0]?tc.surface:tc.blue2,tc.border,16));
                cardType.setBackground(strokeBg(useCard[0]?tc.blue2:tc.surface,tc.border,16));
                typeAccent.setBackground(bg(useCard[0]?tc.blue:tc.red,3));
                cardSpinner.setVisibility(useCard[0]?View.VISIBLE:View.GONE);
                cardLabel.setVisibility(useCard[0]?View.VISIBLE:View.GONE);
                cardHint.setVisibility(useCard[0]?View.VISIBLE:View.GONE);
                refreshCardPreview.run();
            };
            normalType.setOnClickListener(v->{useCard[0]=false;refreshTypeUi.run();});
            cardType.setOnClickListener(v->{useCard[0]=true;refreshTypeUi.run();});
            attachPressFeedback(normalType);attachPressFeedback(cardType);
            refreshTypeUi.run();
        }

        final int[] selectedCat={-1}; final String[] selectedCatName={""};
        if(!isIncome){
            TextView categoryTitle=text(s(R.string.ui_74f9e9e9a1),12,c.text);categoryTitle.setTypeface(null,Typeface.BOLD);margins(categoryTitle,0,2,0,8);box.addView(categoryTitle);
            LinearLayout catGrid=new LinearLayout(this);catGrid.setOrientation(LinearLayout.VERTICAL);
            ArrayList<Category> catList=new ArrayList<>();
            for(Category existing:categories) if(!"Kredi Kartı".equals(existing.name)) catList.add(existing);
            if(edit!=null){selectedCatName[0]=edit.cat;for(int i=0;i<catList.size();i++)if(catList.get(i).name.equals(edit.cat)){selectedCat[0]=i;break;}}
            final ArrayList<LinearLayout> tiles=new ArrayList<>();
            for(int i=0;i<catList.size();i+=3){
                LinearLayout cr=row();
                for(int j=i;j<Math.min(i+3,catList.size());j++){
                    final int idx=j;Category cat=catList.get(j);LinearLayout tile=new LinearLayout(this);tile.setOrientation(LinearLayout.VERTICAL);tile.setGravity(Gravity.CENTER);tile.setPadding(dp(5),dp(7),dp(5),dp(6));tile.setBackground(strokeBg(j==selectedCat[0]?c.blue2:c.surface,c.border,18));
                    SimpleIconView tiv=new SimpleIconView(this,cat.icon,j==selectedCat[0]?c.blue:c.muted);tile.addView(tiv,new LinearLayout.LayoutParams(dp(30),dp(30)));
                    TextView tname=text(categoryLabel(cat.name),10,j==selectedCat[0]?c.blue:c.text);tname.setGravity(Gravity.CENTER);tname.setTypeface(null,Typeface.BOLD);tile.addView(tname,new LinearLayout.LayoutParams(-1,dp(25)));
                    LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,dp(76),1);if(j>i)tp.setMargins(dp(8),0,0,0);cr.addView(tile,tp);tiles.add(tile);
                    attachPressFeedback(tile);tile.setOnClickListener(v->{selectedCat[0]=idx;selectedCatName[0]=cat.name;for(int k=0;k<tiles.size();k++){LinearLayout q=tiles.get(k);q.setBackground(strokeBg(k==selectedCat[0]?C().blue2:C().surface,C().border,18));if(q.getChildAt(0) instanceof SimpleIconView){SimpleIconView qiv=(SimpleIconView)q.getChildAt(0);qiv.color=k==selectedCat[0]?C().blue:C().muted;qiv.invalidate();}if(q.getChildAt(1) instanceof TextView)((TextView)q.getChildAt(1)).setTextColor(k==selectedCat[0]?C().blue:C().text);}});
                }
                if(i+3>catList.size())for(int k=catList.size();k<i+3;k++)cr.addView(new Space(this),new LinearLayout.LayoutParams(0,dp(76),1));
                margins(cr,0,0,0,6);catGrid.addView(cr);
            }
            box.addView(catGrid);
        }

        // Geçmiş tarihli kayıtlar gerçek bakiye zincirini etkiler; kullanıcıya bunu açıkça gösteriyoruz.
        LinearLayout balancePreview=card(darkMode?Color.rgb(16,48,67):Color.rgb(240,249,252),16);
        balancePreview.setPadding(dp(12),dp(10),dp(12),dp(10));
        TextView balancePreviewTitle=text(s(R.string.ui_69997140d7),11,c.blue);balancePreviewTitle.setTypeface(null,Typeface.BOLD);balancePreview.addView(balancePreviewTitle);
        TextView balancePreviewText=text("",12,c.text);margins(balancePreviewText,0,3,0,0);balancePreview.addView(balancePreviewText);
        TextView balancePreviewHint=text(s(R.string.ui_df58041e3c),10,c.muted);balancePreview.addView(balancePreviewHint);
        margins(balancePreview,0,10,0,0);box.addView(balancePreview);
        Runnable refreshBalancePreview=()->{
            double entered=0; try{entered=parseOptionalNum(amount);}catch(Exception ignored){}
            double current=totalBalance();
            if(edit!=null){ current-=cashImpact(edit); }
            double projected=current+((isIncome)?entered:(useCard[0]?0:-entered));
            if(isIncome){
                balancePreviewText.setText(s(R.string.ui_income_balance_preview, money(entered), money(projected)));
                balancePreviewText.setTextColor(C().green);
            }else if(useCard[0]){
                balancePreviewText.setText(s(R.string.ui_340142a6fd)+money(projected));
                balancePreviewText.setTextColor(C().blue);
            }else{
                balancePreviewText.setText(s(R.string.ui_expense_balance_preview, money(entered), money(projected)));
                balancePreviewText.setTextColor(C().red);
            }
            balancePreview.setBackground(strokeBg(darkMode?Color.rgb(16,48,67):Color.rgb(240,249,252),C().border,16));
        };
        amount.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int count,int after){}public void onTextChanged(CharSequence s,int st,int before,int count){refreshCardPreviewRef[0].run();refreshBalancePreview.run();}public void afterTextChanged(Editable e){}});
        TextView accountLabel=text(trUi("Hesap","Account"),12,c.text); accountLabel.setTypeface(null,Typeface.BOLD); margins(accountLabel,0,8,0,0); box.addView(accountLabel);
        ArrayList<String> accountOptions=new ArrayList<>(accounts); if(accountOptions.isEmpty())accountOptions.add("Genel");
        final String[] selectedAccount={edit==null?"Genel":(edit.account==null||edit.account.isEmpty()?"Genel":edit.account)};
        if(!accountOptions.contains(selectedAccount[0]))selectedAccount[0]="Genel";
        LinearLayout accountSelector=accountSelectorCard(selectedAccount[0]);
        box.addView(accountSelector,new LinearLayout.LayoutParams(-1,dp(64)));
        accountSelector.setOnClickListener(v->showAccountPicker(accountOptions,selectedAccount,accountSelector));

        TextView descLabel=text(s(R.string.ui_951aab8c44),12,c.text);descLabel.setTypeface(null,1);margins(descLabel,0,6,0,0);box.addView(descLabel);
        EditText desc=modernEdit(isIncome?s(R.string.ui_7b45083529):s(R.string.ui_e34c8896df),c);desc.setGravity(Gravity.TOP|Gravity.START);desc.setPadding(dp(14),dp(12),dp(14),dp(8));box.addView(desc,new LinearLayout.LayoutParams(-1,dp(72)));

        if(isIncome){
            LinearLayout incomeInsight=card(darkMode?Color.rgb(16,48,67):Color.rgb(238,248,255),16);
            incomeInsight.setPadding(dp(12),dp(10),dp(12),dp(10));
            LinearLayout ir=row();
            SimpleIconView ii=new SimpleIconView(this,"trend",c.green);
            ii.setBackground(bg(darkMode?Color.rgb(24,69,75):Color.rgb(224,247,238),14));
            ir.addView(ii,new LinearLayout.LayoutParams(dp(40),dp(40)));
            LinearLayout icopy=new LinearLayout(this);icopy.setOrientation(LinearLayout.VERTICAL);icopy.setPadding(dp(10),0,0,0);
            TextView it=text(trUi("Gelir özeti","Income summary"),13,c.text);it.setTypeface(null,Typeface.BOLD);icopy.addView(it);
            TextView isub=text(trUi("Bu gelir seçtiğin hesaba işlenecek ve bakiyeyi artıracak.","This income will be added to the selected account and increase its balance."),10,c.muted);isub.setLineSpacing(0,1.05f);margins(isub,0,2,0,0);icopy.addView(isub);
            ir.addView(icopy,new LinearLayout.LayoutParams(0,-2,1));incomeInsight.addView(ir);margins(incomeInsight,0,10,0,0);box.addView(incomeInsight);
        }

        date.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int count,int after){}public void onTextChanged(CharSequence s,int st,int before,int count){refreshBalancePreview.run();}public void afterTextChanged(Editable e){}});
        if(edit!=null){setMoneyInput(amount,edit.amount);date.setText(edit.date);desc.setText(edit.desc);}
        refreshBalancePreview.run();
        scroll.addView(box);outer.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        // When the description field receives focus, automatically scroll it
        // above the IME so typed text never disappears behind the keyboard.
        desc.setOnFocusChangeListener((v,hasFocus) -> {
            if(hasFocus) {
                scroll.postDelayed(() -> revealViewInScroll(scroll, desc), 120L);
            }
        });

        LinearLayout actions=row();
        Button cancel=dialogButton(s(R.string.ui_989f51ec41),c.muted,c.surface);
        Button saveBtn=dialogButton(edit==null?s(R.string.ui_57ea23145d):s(R.string.ui_61dce09793),Color.WHITE,isIncome?c.green:c.red);
        actions.addView(cancel,new LinearLayout.LayoutParams(0,dp(54),1));
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(54),1);sp.setMargins(dp(8),0,0,0);
        actions.addView(saveBtn,sp);
        margins(actions,0,10,0,0);
        outer.addView(actions);

        close.setOnClickListener(v->dlg.dismiss());
        cancel.setOnClickListener(v->dlg.dismiss());
        saveBtn.setOnClickListener(v->{
            try{
                double val=parseMoneyText(amount.getText().toString());
                if(val<=0)throw new Exception();
                String ds=desc.getText().toString().trim(),dt=date.getText().toString().trim(); String accountName=selectedAccount[0]==null?"Genel":selectedAccount[0];
                if(dt.length()!=10)dt=df.format(new Date());
                String cat=isIncome?"Gelir":"Diğer";boolean newCard=false;long newCardId=0;
                if(!isIncome){
                    if(selectedCatName[0]==null||selectedCatName[0].trim().isEmpty()){
                        Toast.makeText(this,s(R.string.ui_b48404ae49),Toast.LENGTH_LONG).show();return;
                    }
                    cat=selectedCatName[0];newCard=useCard[0];
                    if(newCard){
                        if(creditCards.isEmpty()||selectedCard[0]==0){
                            Toast.makeText(this,s(R.string.ui_c39f9d3d69),Toast.LENGTH_LONG).show();return;
                        }
                        newCardId=selectedCard[0];
                    }
                    if(edit!=null&&!edit.isIncome&&edit.creditCard){
                        CreditCard old=findCard(edit.cardId);if(old!=null)old.debt=Math.max(0,old.debt-edit.amount);
                    }
                }
                if(edit==null){Tx nt=new Tx(System.currentTimeMillis(),isIncome,val,ds,dt,cat,newCard,newCardId);nt.account=accountName;txs.add(nt);}
                else{edit.amount=val;edit.desc=ds;edit.date=dt;edit.cat=cat;edit.account=accountName;edit.creditCard=newCard;edit.cardId=newCardId;}
                if(!isIncome&&newCard){CreditCard cc=findCard(newCardId);if(cc!=null)cc.debt+=val;}
                save();saveCreditCards();dlg.dismiss();refreshCurrentScreenAfterTransactionMutation();
            }catch(Exception e){amount.setError(s(R.string.ui_d9f77be516));}
        });

        dlg.setContentView(outer);
        dlg.show();
        Window w=dlg.getWindow();
        if(w!=null){
            WindowCompat.setDecorFitsSystemWindows(w,true);
            w.setBackgroundDrawableResource(android.R.color.transparent);
            w.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
            final int screenW=getResources().getDisplayMetrics().widthPixels;
            final int screenH=getResources().getDisplayMetrics().heightPixels;
            // Gelir formu daha kısa olduğu için gereksiz boşluk bırakmıyoruz;
            // harcama formunda kategori/kart/bakiye bölümleri için daha geniş alan korunuyor.
            final int desiredMaxSheet=isIncome?dp(600):dp(720);
            final int maxSheetH=Math.min(desiredMaxSheet,(int)(screenH*.86f));
            w.setLayout(screenW, maxSheetH);
            installExpenseKeyboardHandling(dlg, outer, scroll, desc, maxSheetH);
        }
    }

    EditText modernEdit(String hint,Colors c){
        hint=legacyTranslate(hint);
        EditText e=new EditText(this);
        android.text.SpannableString hs=new android.text.SpannableString(hint);
        hs.setSpan(new android.text.style.AbsoluteSizeSpan(13,true),0,hs.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        int alpha=(int)(0.62f*255); int hc=Color.argb(alpha,Color.red(c.muted),Color.green(c.muted),Color.blue(c.muted));
        hs.setSpan(new android.text.style.ForegroundColorSpan(hc),0,hs.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        e.setHint(hs);
        e.setHintTextColor(hc);
        e.setTextColor(c.text);
        e.setTextSize(16);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES | InputType.TYPE_TEXT_FLAG_AUTO_CORRECT);
        e.setSingleLine();
        e.setBackground(strokeBg(c.bg,c.border,14));
        e.setPadding(dp(14),0,dp(14),0);
        return e;
    }
    Button dialogButton(String label,int textColor,int fill){Button b=new Button(this);b.setText(legacyTranslate(label));b.setTextColor(textColor);b.setTextSize(FinwayDS.TEXT_BODY_LARGE);b.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));b.setAllCaps(false);b.setMinHeight(0);b.setMinimumHeight(0);b.setBackground(strokeBg(fill,C().border,FinwayDS.R_BUTTON));attachPressFeedback(b);return b;}
    void confirmArchive(final Tx t){
        Colors c=C(); Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(18),dp(18),dp(18),dp(12));outer.setBackground(bg(c.surface,24));
        LinearLayout head=row();TextView badge=text(t.cancelled?"↩":"✓",24,t.cancelled?c.red:c.blue);badge.setGravity(Gravity.CENTER);badge.setTypeface(null,Typeface.BOLD);badge.setBackground(bg(t.cancelled?(darkMode?Color.rgb(76,38,45):Color.rgb(253,235,237)):(darkMode?Color.rgb(20,67,91):Color.rgb(231,246,251)),22));head.addView(badge,new LinearLayout.LayoutParams(dp(50),dp(50)));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(12),0,0,0);TextView title=text(t.cancelled?s(R.string.ui_5c35e9fbf8):s(R.string.ui_713868bb5a),19,c.text);title.setTypeface(null,Typeface.BOLD);copy.addView(title);TextView sub=text((t.desc.length()>0?t.desc:t.cat)+"  •  "+money(t.amount),12,c.muted);margins(sub,0,3,0,0);copy.addView(sub);head.addView(copy,new LinearLayout.LayoutParams(0,-2,1));TextView close=text("×",30,c.muted);close.setGravity(Gravity.CENTER);close.setBackground(bg(darkMode?Color.rgb(24,48,69):Color.rgb(242,247,251),18));head.addView(close,new LinearLayout.LayoutParams(dp(44),dp(46)));outer.addView(head);
        TextView info=text(t.cancelled?s(R.string.ui_2583eae7ea):s(R.string.ui_84faa5a6bc),12,c.muted);margins(info,0,10,0,0);outer.addView(info);
        LinearLayout actions=row();Button cancel=dialogButton(s(R.string.ui_9dc74649ac),c.muted,c.surface);actions.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));
        if(!t.cancelled){
            // Bir işlem aktifken yalnızca İPTAL etme seçeneği gösterilir.
            // Geçmişten temizleme, işlem iptal edilmeden hiçbir şekilde mümkün değildir.
            LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(52),1);sp.setMargins(dp(8),0,0,0);
            Button cancelTx=dialogButton(s(R.string.ui_6b73788af4),Color.WHITE,c.red);
            actions.addView(cancelTx,sp);
            cancelTx.setOnClickListener(v->{cancelTransaction(t);dlg.dismiss();});
        }else{
            // Sadece iptal edilmiş kayıtlar geçmişten temizlenebilir.
            LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(52),1);sp.setMargins(dp(8),0,0,0);
            Button archive=dialogButton(s(R.string.ui_5013d7a6f6),Color.WHITE,c.blue);
            actions.addView(archive,sp);
            archive.setOnClickListener(v->{
                t.archived=true; save(); dlg.dismiss();
                new Handler().postDelayed(()->showTransactions(),200);
                Toast.makeText(this,s(R.string.ui_1c19e36443),Toast.LENGTH_SHORT).show();
            });
        }
        margins(actions,0,16,0,0);outer.addView(actions);cancel.setOnClickListener(v->dlg.dismiss());
        dlg.setContentView(outer);Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}dlg.show();w=dlg.getWindow();if(w!=null){WindowManager.LayoutParams lp=w.getAttributes();lp.width=Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430));lp.height=WindowManager.LayoutParams.WRAP_CONTENT;lp.dimAmount=.55f;w.setAttributes(lp);}
    }
    void cancelTransaction(final Tx t){
        if(t==null||t.cancelled)return;
        t.cancelled=true;
        if(!t.isIncome&&t.creditCard){
            CreditCard cc=findCard(t.cardId);
            if(cc!=null&&t.paymentId==0)cc.debt+=t.amount;
        }
        if(t.paymentId!=0){
            for(CardPayment cp:cardPayments) if(cp.id==t.paymentId&&!cp.cancelled){cp.cancelled=true;CreditCard cc=findCard(cp.cardId);if(cc!=null){cc.debt+=cp.amount;cc.statementDebt+=cp.amount;cc.minPayment=minimumPaymentForCard(cc);}if(cp.installmentId!=0){for(Installment in:installments)if(in.id==cp.installmentId){in.paidCount=Math.max(0,in.paidCount-1);break;}}break;}
        }
        save();saveCreditCards();saveCardPayments();saveInstallments();
        new Handler().postDelayed(()->showTransactions(),180);
        Toast.makeText(this,s(R.string.ui_9c9e903402),Toast.LENGTH_SHORT).show();
    }
    void clearAll(){
        Colors c=C(); Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(18),dp(18),dp(18),dp(12));outer.setBackground(bg(c.surface,24));
        TextView title=text(s(R.string.ui_b6c8b27cf0),20,c.text);title.setTypeface(null,Typeface.BOLD);outer.addView(title);TextView sub=text(s(R.string.ui_0e94015a0f),12,c.muted);margins(sub,0,6,0,0);outer.addView(sub);LinearLayout actions=row();Button cancel=dialogButton(s(R.string.ui_9dc74649ac),c.muted,c.surface);Button del=dialogButton(s(R.string.ui_512987af5c),Color.WHITE,c.red);actions.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(52),1);sp.setMargins(dp(8),0,0,0);actions.addView(del,sp);margins(actions,0,16,0,0);outer.addView(actions);cancel.setOnClickListener(v->dlg.dismiss());del.setOnClickListener(v->{txs.clear();goals.clear();completedGoals.clear();creditCards.clear();installments.clear();savedBanks.clear();save();saveBanks();saveGoals();saveCreditCards();saveInstallments();saveCardPayments();saveSavingEntries(new ArrayList<SavingEntry>());getPreferences(0).edit().remove("savings_unit").remove("savings_amount").remove("savings_entries_json").remove("recurring").remove("categoryBudgets").remove("subscriptions").apply();dlg.dismiss();new Handler().postDelayed(()->showMenu(),250);});dlg.setContentView(outer);Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}dlg.show();w=dlg.getWindow();if(w!=null){WindowManager.LayoutParams lp=w.getAttributes();lp.width=Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430));lp.height=WindowManager.LayoutParams.WRAP_CONTENT;lp.dimAmount=.55f;w.setAttributes(lp);}
    }

    Button button(String s,int color){Button b=new Button(this);b.setText(legacyTranslate(s));b.setTextColor(Color.WHITE);b.setTextSize(FinwayDS.TEXT_BODY);b.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));b.setAllCaps(false);b.setMinHeight(0);b.setMinimumHeight(0);b.setBackground(bg(color,FinwayDS.R_BUTTON));attachPressFeedback(b);return b;}
    void attachPressFeedback(final View v){v.setOnTouchListener((view,event)->{if(event.getAction()==MotionEvent.ACTION_DOWN){view.animate().scaleX(.96f).scaleY(.96f).alpha(.78f).setDuration(70).start();}else if(event.getAction()==MotionEvent.ACTION_UP||event.getAction()==MotionEvent.ACTION_CANCEL){view.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(130).start();}return false;});}
    double sum(boolean inc){double s=0;String ym=new SimpleDateFormat("MM.yyyy",Locale.US).format(viewMonth.getTime());for(Tx t:txs)if(!t.cancelled&&t.isIncome==inc&&t.date.endsWith(ym))s+=t.amount;return s;}
    // Toplam bakiye tüm aylardaki gelirlerden tüm aylardaki harcamaların çıkarılmasıyla hesaplanır.
    // Böylece hangi ay görüntüleniyor olursa olsun yeni gelir bakiyeyi artırır, harcama ise güncel bakiyeden düşer.
    double cashImpact(Tx t){ if(t==null||t.cancelled)return 0; return t.isIncome?t.amount:(t.creditCard?0:-t.amount); }
    double totalBalance(){double s=0;for(Tx t:txs)s+=cashImpact(t);for(CardPayment cp:cardPayments)if(!cp.cancelled)s-=cp.amount;return s;}
    double catSum(String c){double s=0;String ym=new SimpleDateFormat("MM.yyyy",Locale.US).format(viewMonth.getTime());for(Tx t:txs)if(!t.cancelled&&!t.isIncome&&t.cat.equals(c)&&t.date.endsWith(ym))s+=t.amount;return s;}

    void loadPrefs(){android.content.SharedPreferences p=getPreferences(0);int defaultTheme=p.contains("themeMode")?p.getInt("themeMode",2):(p.contains("dark")?(p.getBoolean("dark",false)?1:0):2);themeMode=defaultTheme;darkMode=themeMode==1 || (themeMode==2 && isSystemDark());language=p.getString("lang","tr");currencyCode=p.getString("currency","TRY");marketAutoUpdate=p.getBoolean("marketAutoUpdate",false);marketBaseUnit=p.getString("marketBaseUnit","TRY");String banks=p.getString("savedBanks","");savedBanks.clear();for(String bn:banks.split("\\|")){if(bn.trim().length()>0&&!savedBanks.contains(bn.trim()))savedBanks.add(bn.trim());}String watched=p.getString("marketWatched","USDTRY,EURTRY,GRAMALTIN");watchedMarketCodes.clear();for(String w:watched.split(",")){w=w.trim();if(w.length()>0&&!"JPYTRY".equals(w)&&!"CNYTRY".equals(w)&&!watchedMarketCodes.contains(w))watchedMarketCodes.add(w);}if(watchedMarketCodes.isEmpty()){watchedMarketCodes.add("USDTRY");watchedMarketCodes.add("EURTRY");watchedMarketCodes.add("GRAMALTIN");}}
    void startMarketAutoUpdate(boolean immediate){ marketHandler.removeCallbacks(marketAutoRunnable); if(!marketAutoUpdate)return; if(immediate) loadMarketData(null); marketHandler.postDelayed(marketAutoRunnable,MARKET_AUTO_UPDATE_MS); }
    void stopMarketAutoUpdate(){ marketHandler.removeCallbacks(marketAutoRunnable); }
    @Override protected void onResume(){ super.onResume(); if(marketAutoUpdate) startMarketAutoUpdate(false); }
    @Override protected void onStop(){ super.onStop(); }
    @Override protected void onPause(){ super.onPause(); stopMarketAutoUpdate(); }
    boolean isSystemDark(){int ui=getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;return ui==android.content.res.Configuration.UI_MODE_NIGHT_YES;}
    void saveBanks(){getPreferences(0).edit().putString("savedBanks",android.text.TextUtils.join("|",savedBanks)).apply();}
    String hashPin(String pin){ try{java.security.MessageDigest md=java.security.MessageDigest.getInstance("SHA-256");byte[] b=md.digest(pin.getBytes("UTF-8"));StringBuilder sb=new StringBuilder();for(byte x:b)sb.append(String.format(Locale.US,"%02x",x));return sb.toString();}catch(Exception e){return pin;} }
    boolean biometricAvailable(){
        if(Build.VERSION.SDK_INT<28) return false;
        try{
            BiometricManager bm=BiometricManager.from(this);
            if(bm==null) return false;
            final int r=bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK);
            return r==BiometricManager.BIOMETRIC_SUCCESS;
        }catch(Throwable ignored){
            return false;
        }
    }
    void hideFinbiForLock(){ if(finbiChatPanel!=null) closeFinbiChat(); if(finbiOverlay!=null) finbiOverlay.setVisibility(View.GONE); }
    void showFinbiAfterUnlock(){ if(finbiEnabled && (!appLockEnabled || appSessionUnlocked)){ if(finbiOverlay!=null)finbiOverlay.setVisibility(View.VISIBLE);else installFinbiBubble(); } }
    void setupAppPin(){ setupAppPin(false); }

    void setupAppPin(final boolean replacing){
        hideFinbiForLock();
        final Dialog d=new Dialog(this); d.requestWindowFeature(Window.FEATURE_NO_TITLE); d.setCancelable(false); d.setCanceledOnTouchOutside(false);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER_HORIZONTAL); root.setPadding(dp(24),dp(28),dp(24),dp(22)); root.setBackgroundColor(Color.WHITE);
        TextView eyebrow=text("FINWAY SECURITY",11,Color.rgb(79,117,145)); eyebrow.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL)); eyebrow.setLetterSpacing(.14f); margins(eyebrow,0,0,0,10); root.addView(eyebrow);
        ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.finway_brand_f); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE); logo.setBackground(bg(Color.rgb(239,247,253),48)); root.addView(logo,new LinearLayout.LayoutParams(dp(72),dp(72)));
        TextView title=text(replacing?trUi("Yeni PIN belirle","Set a new PIN"):trUi("Finway'i güvene al","Secure Finway"),23,Color.rgb(28,52,72)); title.setTypeface(Typeface.create("sans-serif",Typeface.BOLD)); title.setGravity(Gravity.CENTER); margins(title,0,16,0,6); root.addView(title);
        TextView info=text(replacing?trUi("Cihaz doğrulaman tamamlandı. Yeni 6 haneli PIN'ini belirle.","Device verification complete. Create your new 6-digit PIN."):trUi("Finway'i açarken kullanacağın 6 haneli PIN'i belirle.","Create the 6-digit PIN you will use to unlock Finway."),12,Color.rgb(103,124,143)); info.setGravity(Gravity.CENTER); info.setLineSpacing(0,1.12f); margins(info,0,0,0,18); root.addView(info);
        EditText pin=modernEdit(trUi("Yeni PIN","New PIN"),C()); pin.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD); pin.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(6)}); pin.setGravity(Gravity.CENTER); pin.setTextSize(19); margins(pin,0,0,0,10); root.addView(pin,new LinearLayout.LayoutParams(-1,dp(56)));
        EditText confirm=modernEdit(trUi("PIN'i tekrar gir","Confirm PIN"),C()); confirm.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD); confirm.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(6)}); confirm.setGravity(Gravity.CENTER); confirm.setTextSize(19); root.addView(confirm,new LinearLayout.LayoutParams(-1,dp(56)));
        Button saveBtn=button(replacing?trUi("PIN'i güncelle","Update PIN"):trUi("PIN'i kaydet","Save PIN"),C().blue); margins(saveBtn,0,16,0,0); root.addView(saveBtn,new LinearLayout.LayoutParams(-1,dp(52)));
        TextView note=text(trUi("PIN düz metin olarak saklanmaz; yalnızca güvenli bir doğrulayıcı tutulur.","Your PIN is not stored as plain text; only a secure verifier is kept."),11,Color.rgb(103,124,143)); note.setGravity(Gravity.CENTER); note.setLineSpacing(0,1.1f); root.addView(note);
        saveBtn.setOnClickListener(v->{ String a=pin.getText().toString().trim(), b=confirm.getText().toString().trim(); if(a.length()!=6){pin.setError(trUi("6 hane gir","Enter 6 digits")); return;} if(!a.equals(b)){confirm.setError(trUi("PIN'ler eşleşmiyor","PINs do not match")); return;} storePin(a); appLockEnabled=true; appSessionUnlocked=true; pendingUnlock=false; pendingDeviceReset=false; getPreferences(0).edit().putBoolean("app_lock_enabled",true).putBoolean("app_lock_biometric",biometricEnabled).apply(); d.dismiss(); showSettings(); });
        d.setContentView(root); d.show(); Window w=d.getWindow(); if(w!=null){ w.setBackgroundDrawableResource(android.R.color.transparent); w.setGravity(Gravity.CENTER); w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(30),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT); WindowManager.LayoutParams lp=w.getAttributes(); lp.dimAmount=.34f; w.setAttributes(lp); w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND); }
    }

    void disableAppLockWithPin(){
        Colors c=C(); final Dialog d=new Dialog(this); d.requestWindowFeature(Window.FEATURE_NO_TITLE); d.setCancelable(false);
        LinearLayout o=new LinearLayout(this); o.setOrientation(LinearLayout.VERTICAL); o.setPadding(dp(22),dp(22),dp(22),dp(16)); o.setBackground(bg(c.surface,24));
        TextView h=text("🔐  "+trUi("Kilidi kapat","Disable lock"),21,c.text); h.setTypeface(null,Typeface.BOLD); o.addView(h);
        TextView info=text(trUi("Güvenlik için mevcut 6 haneli PIN'ini gir.","Enter your current 6-digit PIN for security."),12,c.muted); margins(info,0,5,0,14); o.addView(info);
        EditText pin=modernEdit(trUi("Mevcut PIN","Current PIN"),c); pin.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD); pin.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(6)}); pin.setGravity(Gravity.CENTER); o.addView(pin,new LinearLayout.LayoutParams(-1,dp(56)));
        LinearLayout acts=row(); Button cancel=dialogButton(trUi("Vazgeç","Cancel"),c.muted,c.surface); Button ok=dialogButton(trUi("Kilidi kapat","Disable lock"),Color.WHITE,c.red); acts.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1)); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(52),1); sp.setMargins(dp(8),0,0,0); acts.addView(ok,sp); margins(acts,0,14,0,0); o.addView(acts);
        cancel.setOnClickListener(v->{d.dismiss();showSettings();});
        ok.setOnClickListener(v->{ String p=pin.getText().toString().trim(); if(verifyPin(p)){ appLockEnabled=false; appSessionUnlocked=true; biometricEnabled=false; pendingUnlock=false; getPreferences(0).edit().putBoolean("app_lock_enabled",false).remove("app_lock_salt").remove("app_lock_verifier").remove("app_lock_pin_length").remove("app_lock_hash").putBoolean("app_lock_biometric",false).apply(); d.dismiss(); showFinbiAfterUnlock(); showSettings(); } else { pin.setError(trUi("PIN hatalı","Wrong PIN")); } });
        d.setContentView(o); d.show(); Window w=d.getWindow(); if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(30),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);}
    }

    String createPinSalt(){ byte[] salt=new byte[16]; new java.security.SecureRandom().nextBytes(salt); return android.util.Base64.encodeToString(salt,android.util.Base64.NO_WRAP); }
    String derivePin(String pin,String saltB64){ try{ byte[] salt=android.util.Base64.decode(saltB64,android.util.Base64.NO_WRAP); javax.crypto.spec.PBEKeySpec spec=new javax.crypto.spec.PBEKeySpec(pin.toCharArray(),salt,120000,256); javax.crypto.SecretKeyFactory f=javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1"); byte[] out=f.generateSecret(spec).getEncoded(); spec.clearPassword(); return android.util.Base64.encodeToString(out,android.util.Base64.NO_WRAP); }catch(Exception e){ return hashPin(pin); } }
    void storePin(String pin){ String salt=createPinSalt(); String verifier=derivePin(pin,salt); getPreferences(0).edit().putString("app_lock_salt",salt).putString("app_lock_verifier",verifier).putInt("app_lock_pin_length",pin.length()).remove("app_lock_hash").apply(); }
    long pinLockRemainingMs(){ return Math.max(0L,getPreferences(0).getLong("pin_lock_until",0L)-System.currentTimeMillis()); }
    String pinLockText(long ms){
        long sec=(ms+999)/1000;
        boolean minute=sec>=60;
        long n=minute?(sec+59)/60:sec;
        if("tr".equals(language)) return n+" "+(minute?"dakika":"saniye");
        if("en".equals(language)) return n+" "+(minute?"minutes":"seconds");
        if("fr".equals(language)) return n+" "+(minute?"minutes":"secondes");
        if("ru".equals(language)) return n+" "+(minute?"минут":"секунд");
        if("de".equals(language)) return n+" "+(minute?"Minuten":"Sekunden");
        if("ja".equals(language)) return n+(minute?"分":"秒");
        if("zh".equals(language)) return n+(minute?"分钟":"秒");
        if("ar".equals(language)) return n+" "+(minute?"دقائق":"ثوانٍ");
        if("el".equals(language)) return n+" "+(minute?"λεπτά":"δευτερόλεπτα");
        if("es".equals(language)) return n+" "+(minute?"minutos":"segundos");
        if("it".equals(language)) return n+" "+(minute?"minuti":"secondi");
        return n+" "+(minute?"minutes":"seconds");
    }
    boolean verifyPin(String pin){
        long left=pinLockRemainingMs();
        if(left>0){ Toast.makeText(this,trUi("Çok fazla hatalı deneme. "+pinLockText(left)+" sonra tekrar deneyin.","Too many wrong attempts. Try again in "+pinLockText(left)+"."),Toast.LENGTH_SHORT).show(); return false; }
        boolean ok=verifyPinRaw(pin);
        SharedPreferences.Editor ed=getPreferences(0).edit();
        if(ok){ ed.remove("pin_fail_count").remove("pin_lock_until").apply(); return true; }
        if(pin!=null&&pin.length()>=4){
            int n=getPreferences(0).getInt("pin_fail_count",0)+1; ed.putInt("pin_fail_count",n);
            if(n>=5){ long secs=Math.min(3600L,30L<<Math.min(7,n-5)); ed.putLong("pin_lock_until",System.currentTimeMillis()+secs*1000L); ed.apply(); Toast.makeText(this,trUi("Çok fazla hatalı deneme. "+pinLockText(secs*1000L)+" sonra tekrar deneyin.","Too many wrong attempts. Try again in "+pinLockText(secs*1000L)+"."),Toast.LENGTH_LONG).show(); return false; }
        }
        ed.apply(); return false;
    }
    boolean verifyPinRaw(String pin){ if(pin==null||pin.length()<4||pin.length()>6)return false; android.content.SharedPreferences p=getPreferences(0); String salt=p.getString("app_lock_salt",""); String verifier=p.getString("app_lock_verifier",""); if(!salt.isEmpty()&&!verifier.isEmpty()){ return verifier.equals(derivePin(pin,salt)); } String legacy=p.getString("app_lock_hash",""); if(!legacy.isEmpty()&&legacy.equals(hashPin(pin))){ storePin(pin); return true; } return false; }

    void showUnlockDialog(){
        if(!appLockEnabled||appSessionUnlocked||isFinishing()||isDestroyed())return;
        hideFinbiForLock();
        if(activeLockDialog!=null&&activeLockDialog.isShowing())return;

        final Dialog d=new Dialog(this);
        activeLockDialog=d;
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(false);
        d.setCanceledOnTouchOutside(false);

        FrameLayout frame=new FrameLayout(this);
        frame.setBackgroundColor(Color.WHITE);
        frame.addView(new LockBackdropView(this),new FrameLayout.LayoutParams(-1,-1));

        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.TRANSPARENT);
        root.setPadding(dp(28),dp(18),dp(28),dp(20));

        // Finway wordmark — centered and intentionally kept as the primary brand element.
        LinearLayout brandRow=new LinearLayout(this);
        brandRow.setGravity(Gravity.CENTER);
        View brand=brandMark();
        brandRow.addView(brand,new LinearLayout.LayoutParams(dp(215),dp(70)));
        root.addView(brandRow,new LinearLayout.LayoutParams(-1,dp(76)));

        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout body=new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.setPadding(0,dp(12),0,dp(8));

        // App icon, matching the launcher icon exactly.
        ImageView appIcon=new ImageView(this);
        appIcon.setImageResource(R.mipmap.ic_launcher);
        appIcon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        appIcon.setPadding(dp(12),dp(12),dp(12),dp(12));
        appIcon.setBackground(bg(Color.argb(235,248,252,255),64));
        LinearLayout.LayoutParams iconLp=new LinearLayout.LayoutParams(dp(116),dp(116));
        iconLp.gravity=Gravity.CENTER_HORIZONTAL;
        body.addView(appIcon,iconLp);

        TextView welcome=text(trUi("Finway'e Hoşgeldiniz","Welcome to Finway"),27,Color.rgb(25,40,54));
        welcome.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
        welcome.setGravity(Gravity.CENTER);
        margins(welcome,0,22,0,4);
        body.addView(welcome,new LinearLayout.LayoutParams(-1,dp(40)));

        TextView secured=text(trUi("Finansal bilgileriniz güvende.","Your financial information is protected."),14,Color.rgb(103,124,143));
        secured.setGravity(Gravity.CENTER);
        secured.setLineSpacing(0,1.08f);
        body.addView(secured,new LinearLayout.LayoutParams(-1,dp(30)));

        android.content.SharedPreferences lockPrefs=getPreferences(0);
        final boolean legacyUnlockMode=lockPrefs.getString("app_lock_verifier","").isEmpty()&&!lockPrefs.getString("app_lock_hash","").isEmpty();
        final int requiredPinLength=legacyUnlockMode?0:lockPrefs.getInt("app_lock_pin_length",6);

        TextView pinLabel=text("PIN",15,Color.rgb(28,52,72));
        pinLabel.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        pinLabel.setGravity(Gravity.CENTER);
        margins(pinLabel,0,24,0,8);
        body.addView(pinLabel,new LinearLayout.LayoutParams(-1,dp(28)));

        FrameLayout pinBox=new FrameLayout(this);
        PinDotsView dots=new PinDotsView(this);
        dots.setErrorState(false);
        pinBox.addView(dots,new FrameLayout.LayoutParams(-1,dp(68)));
        final EditText hidden=new EditText(this);
        hidden.setSingleLine(true);
        hidden.setInputType(InputType.TYPE_CLASS_NUMBER);
        hidden.setTextColor(Color.TRANSPARENT);
        hidden.setTextSize(1);
        hidden.setBackgroundColor(Color.TRANSPARENT);
        hidden.setCursorVisible(false);
        hidden.setPadding(0,0,0,0);
        hidden.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(6)});
        hidden.setAlpha(.02f);
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,dp(68));
        hp.leftMargin=dp(2); hp.rightMargin=dp(2);
        pinBox.addView(hidden,hp);
        body.addView(pinBox,new LinearLayout.LayoutParams(-1,dp(68)));

        TextView hint=text(legacyUnlockMode?trUi("PIN'ini gir","Enter your PIN"):(requiredPinLength==6?trUi("6 haneli PIN'inizi girin","Enter your 6-digit PIN"):trUi(requiredPinLength+" haneli PIN'inizi girin","Enter your "+requiredPinLength+"-digit PIN")),13,Color.rgb(103,124,143));
        hint.setGravity(Gravity.CENTER);
        margins(hint,0,8,0,0);
        body.addView(hint,new LinearLayout.LayoutParams(-1,dp(30)));

        final boolean bioReady=biometricEnabled&&biometricAvailable();
        if(bioReady){
            LinearLayout bioCard=new LinearLayout(this);
            bioCard.setOrientation(LinearLayout.HORIZONTAL);
            bioCard.setGravity(Gravity.CENTER_VERTICAL);
            bioCard.setPadding(dp(20),dp(12),dp(14),dp(12));
            bioCard.setBackground(strokeBg(Color.argb(225,248,252,255),Color.rgb(218,231,244),24));
            SimpleIconView fp=new SimpleIconView(this,"fingerprint",Color.rgb(31,105,222));
            bioCard.addView(fp,new LinearLayout.LayoutParams(dp(54),dp(54)));
            LinearLayout bioCopy=new LinearLayout(this);
            bioCopy.setOrientation(LinearLayout.VERTICAL);
            bioCopy.setPadding(dp(14),0,0,0);
            TextView bioTitle=text(trUi("Biyometrik ile hızlı giriş","Quick biometric sign-in"),15,Color.rgb(25,40,54));
            bioTitle.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
            bioCopy.addView(bioTitle);
            TextView bioSub=text(trUi("Parmak izi veya yüz tanıma ile giriş yapın","Sign in with fingerprint or face recognition"),12,Color.rgb(103,124,143));
            margins(bioSub,0,3,0,0);
            bioCopy.addView(bioSub);
            bioCard.addView(bioCopy,new LinearLayout.LayoutParams(0,-2,1));
            TextView chevron=text("›",32,Color.rgb(38,112,221));
            chevron.setGravity(Gravity.CENTER);
            bioCard.addView(chevron,new LinearLayout.LayoutParams(dp(32),dp(58)));
            bioCard.setOnClickListener(v->authenticateBiometric(d));
            margins(bioCard,0,22,0,0);
            body.addView(bioCard,new LinearLayout.LayoutParams(-1,dp(84)));
        }else{
            LinearLayout safe=row(); safe.setGravity(Gravity.CENTER);
            SimpleIconView shield=new SimpleIconView(this,"health",Color.rgb(48,137,218));
            safe.addView(shield,new LinearLayout.LayoutParams(dp(24),dp(24)));
            TextView safeText=text(trUi("Güvenli giriş","Secure sign-in"),13,Color.rgb(87,106,121));
            safe.addView(safeText);
            margins(safe,0,18,0,0);
            body.addView(safe,new LinearLayout.LayoutParams(-1,dp(34)));
        }

        LinearLayout links=row();
        links.setGravity(Gravity.CENTER);
        links.setPadding(0,dp(8),0,0);
        TextView forgot=text(trUi("🔒  PIN'i Unuttum","🔒  Forgot PIN"),13,Color.rgb(25,40,54));
        forgot.setGravity(Gravity.CENTER);
        forgot.setBackground(bg(Color.argb(150,241,246,251),28));
        links.addView(forgot,new LinearLayout.LayoutParams(0,dp(52),1));
        TextView help=text(trUi("❔  Yardım Merkezi","❔  Help Center"),13,Color.rgb(25,40,54));
        help.setGravity(Gravity.CENTER);
        help.setBackground(bg(Color.argb(150,241,246,251),28));
        LinearLayout.LayoutParams helpLp=new LinearLayout.LayoutParams(0,dp(52),1);
        helpLp.setMargins(dp(10),0,0,0);
        links.addView(help,helpLp);
        margins(links,0,26,0,0);
        body.addView(links,new LinearLayout.LayoutParams(-1,dp(52)));

        forgot.setOnClickListener(v->startDeviceCredentialReset());
        help.setOnClickListener(v->showLockHelpDialog());

        scroll.addView(body,new ScrollView.LayoutParams(-1,-2));
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        Button unlock=button(trUi("Giriş Yap   →","Sign in   →"),Color.WHITE);
        unlock.setTextSize(17);
        unlock.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        unlock.setGravity(Gravity.CENTER);
        unlock.setBackground(roundGradient(Color.rgb(58,65,205),Color.rgb(31,105,222),26));
        unlock.setEnabled(false);
        unlock.setAlpha(.50f);
        margins(unlock,0,10,0,0);
        root.addView(unlock,new LinearLayout.LayoutParams(-1,dp(62)));

        frame.addView(root,new FrameLayout.LayoutParams(-1,-1));
        d.setContentView(frame);

        android.text.TextWatcher watcher=new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){
                int n=Math.min(6,s==null?0:s.length());
                boolean ready=legacyUnlockMode?n>=4:n==requiredPinLength;
                dots.setPinLength(n); dots.setErrorState(false);
                unlock.setEnabled(ready); unlock.setAlpha(ready?1f:.50f);
            }
            public void afterTextChanged(Editable e){}
        };
        hidden.addTextChangedListener(watcher);
        View.OnClickListener focusPin=v->{hidden.requestFocus();hidden.setSelection(hidden.length());((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(hidden,InputMethodManager.SHOW_IMPLICIT);};
        dots.setOnClickListener(focusPin); pinBox.setOnClickListener(focusPin); hint.setOnClickListener(focusPin);
        unlock.setOnClickListener(v->{String p=hidden.getText().toString();if(verifyPin(p)){((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(hidden.getWindowToken(),0);unlockAppSession(d);}else{dots.setErrorState(true);shakeView(pinBox);}});
        d.setOnDismissListener(x->{((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(frame.getWindowToken(),0);activeLockDialog=null;});

        d.show();
        Window w=d.getWindow();
        if(w!=null){
            w.setBackgroundDrawableResource(android.R.color.transparent);
            w.setGravity(Gravity.TOP|Gravity.LEFT);
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE|WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
            w.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS|WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER);
            WindowCompat.setDecorFitsSystemWindows(w,false);
            w.setStatusBarColor(Color.TRANSPARENT);
            w.setNavigationBarColor(Color.TRANSPARENT);
            if(Build.VERSION.SDK_INT>=28)w.getAttributes().layoutInDisplayCutoutMode=WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            if(Build.VERSION.SDK_INT>=23)w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
            WindowManager.LayoutParams lp=w.getAttributes();lp.width=WindowManager.LayoutParams.MATCH_PARENT;lp.height=WindowManager.LayoutParams.MATCH_PARENT;w.setAttributes(lp);w.setLayout(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT);
        }
        if(bioReady)new Handler(Looper.getMainLooper()).postDelayed(()->authenticateBiometric(d),450);
    }

    void showLockHelpDialog(){
        final Dialog h=new Dialog(this);h.requestWindowFeature(Window.FEATURE_NO_TITLE);h.setCancelable(true);
        LinearLayout o=new LinearLayout(this);o.setOrientation(LinearLayout.VERTICAL);o.setPadding(dp(22),dp(20),dp(22),dp(16));o.setBackground(bg(Color.WHITE,24));
        TextView title=text(trUi("Yardım Merkezi","Help Center"),20,Color.rgb(25,40,54));title.setTypeface(null,Typeface.BOLD);o.addView(title);
        TextView msg=text(trUi("Finway kilidini PIN'inizle açabilirsiniz. Biyometrik giriş etkinse parmak izi veya yüz tanıma ile daha hızlı giriş yapabilirsiniz. PIN'inizi unuttuysanız cihazınızın ekran kilidiyle güvenli sıfırlama başlatabilirsiniz.","Unlock Finway with your PIN. If biometric sign-in is enabled, you can use fingerprint or face recognition. If you forgot your PIN, you can securely reset it using your device screen lock."),13,Color.rgb(103,124,143));msg.setLineSpacing(0,1.15f);margins(msg,0,10,0,18);o.addView(msg);
        Button ok=button(trUi("Tamam","Done"),Color.WHITE);ok.setBackground(roundGradient(Color.rgb(58,65,205),Color.rgb(31,105,222),20));o.addView(ok,new LinearLayout.LayoutParams(-1,dp(52)));ok.setOnClickListener(v->h.dismiss());
        h.setContentView(o);h.show();Window w=h.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);}
    }

    class LockBackdropView extends View{
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        Path path=new Path();
        LockBackdropView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        protected void onDraw(Canvas c){
            super.onDraw(c);
            final float w=getWidth();
            final float h=getHeight();
            c.drawColor(Color.WHITE);
            p.setStyle(Paint.Style.FILL);

            // Top-left soft blue wave. Every coordinate is explicitly float so
            // Java cannot perform an implicit double-to-float conversion.
            final float a1=w*0.22f, b1=h*0.05f, a2=w*0.28f, b2=h*0.16f;
            final float a3=w*0.48f, b3=h*0.02f, a4=w*0.62f, b4=-h*0.04f;
            final float a5=w*0.68f, b5=-h*0.02f, a6=w*0.76f;
            p.setColor(Color.argb(42,78,190,245));
            path.reset();
            path.moveTo(0f,0f);
            path.cubicTo(a1,b1,a2,b2,a3,b3);
            path.cubicTo(a4,b4,a5,b5,a6,0f);
            path.lineTo(0f,0f); path.close(); c.drawPath(path,p);

            final float b7=h*0.07f, a7=w*0.17f, a8=w*0.29f, b8=h*0.17f;
            final float a9=w*0.55f, b9=h*0.03f, a10=w*0.68f, b10=-h*0.01f;
            final float a11=w*0.78f, a12=w*0.90f;
            p.setColor(Color.argb(26,44,222,192));
            path.reset();
            path.moveTo(0f,0f);
            path.cubicTo(a7,b7,a8,b8,a9,b9);
            path.cubicTo(a10,b10,a11,b10,a12,0f);
            path.lineTo(0f,0f); path.close(); c.drawPath(path,p);

            final float bottomY1=h*0.80f, bottomX2=w*0.80f, bottomY2=h*0.91f;
            final float bottomX3=w*0.67f, bottomY3=h*0.94f, bottomX4=w*0.46f;
            p.setColor(Color.argb(34,77,187,244));
            path.reset(); path.moveTo(w,bottomY1);
            path.cubicTo(bottomX2,bottomY2,bottomX3,bottomY3,bottomX4,h);
            path.lineTo(w,h); path.close(); c.drawPath(path,p);

            final float bottomY4=h*0.88f, bottomY5=h*0.96f;
            final float bottomX5=w*0.69f, bottomX6=w*0.56f;
            p.setColor(Color.argb(26,40,220,188));
            path.reset(); path.moveTo(w,bottomY4);
            path.cubicTo(bottomX2,bottomY5,bottomX5,h*0.98f,bottomX6,h);
            path.lineTo(w,h); path.close(); c.drawPath(path,p);
        }
    }

    void unlockAppSession(Dialog d){ appSessionUnlocked=true; pendingUnlock=false; getPreferences(0).edit().putBoolean("unlock_dialog_open",false).apply(); if(d!=null)d.dismiss(); showFinbiAfterUnlock(); }

    void startDeviceCredentialReset(){
        android.app.KeyguardManager km=(android.app.KeyguardManager)getSystemService(KEYGUARD_SERVICE);
        if(km!=null && km.isKeyguardSecure()){
            try{
                Intent intent=km.createConfirmDeviceCredentialIntent(trUi("Finway PIN sıfırlama","Finway PIN reset"),trUi("Yeni PIN oluşturmak için cihaz kilidini doğrula.","Verify your device lock to create a new PIN."));
                if(intent!=null){ pendingDeviceReset=true; startActivityForResult(intent,REQ_DEVICE_RESET); return; }
            }catch(Exception ignored){}
        }
        final Dialog d=new Dialog(this); d.requestWindowFeature(Window.FEATURE_NO_TITLE); d.setCancelable(true); LinearLayout o=new LinearLayout(this); o.setOrientation(LinearLayout.VERTICAL); o.setPadding(dp(22),dp(22),dp(22),dp(16)); o.setBackground(bg(Color.WHITE,24)); TextView h=text(trUi("PIN sıfırlanamıyor","PIN reset unavailable"),20,Color.rgb(28,52,72)); h.setTypeface(null,Typeface.BOLD); o.addView(h); TextView m=text(trUi("Güvenli bir sıfırlama için telefonunda ekran kilidi (PIN, desen veya şifre) bulunması gerekiyor.","A secure reset requires a device screen lock (PIN, pattern or password)."),12,Color.rgb(103,124,143)); m.setLineSpacing(0,1.15f); margins(m,0,8,0,16); o.addView(m); Button ok=button("Tamam",Color.rgb(48,56,190)); o.addView(ok,new LinearLayout.LayoutParams(-1,dp(50))); ok.setOnClickListener(v->d.dismiss()); d.setContentView(o); d.show(); Window w=d.getWindow(); if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(30),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);}
    }

    void showPinResetSetupDialog(){ if(activeLockDialog!=null){ activeLockDialog.dismiss(); activeLockDialog=null; } setupAppPin(true); }

    void authenticateBiometric(final Dialog d){
        try{
            if(!biometricAvailable()) {
                Toast.makeText(this,trUi("Kayıtlı biyometrik doğrulama bulunamadı. PIN ile giriş yapabilirsiniz.","No enrolled biometric authentication is available. You can use your PIN."),Toast.LENGTH_LONG).show();
                return;
            }
            Executor executor=getMainExecutor();
            BiometricPrompt.AuthenticationCallback callback=new BiometricPrompt.AuthenticationCallback(){
                @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result){
                    runOnUiThread(()->unlockAppSession(d));
                }
                @Override public void onAuthenticationError(int errorCode,CharSequence errString){
                    // Cancellation, lockout and sensor errors leave the PIN screen usable.
                }
                @Override public void onAuthenticationFailed(){
                    Toast.makeText(MainActivity.this,trUi("Biyometrik doğrulama başarısız","Biometric authentication failed"),Toast.LENGTH_SHORT).show();
                }
            };
            BiometricPrompt prompt=new BiometricPrompt(this,executor,callback);
            BiometricPrompt.PromptInfo info=new BiometricPrompt.PromptInfo.Builder()
                .setTitle(trUi("Finway ile güvenli giriş","Secure sign-in to Finway"))
                .setSubtitle(trUi("Biyometrik doğrulama","Biometric authentication"))
                .setDescription(trUi("Finway hesabınızı açmak için biyometrinizi doğrulayın.","Verify your biometric to unlock Finway."))
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
                .setNegativeButtonText(trUi("PIN ile giriş","Use PIN instead"))
                .build();
            prompt.authenticate(info);
        }catch(Throwable t){
            Toast.makeText(this,trUi("Biyometrik giriş şu anda kullanılamıyor. PIN ile giriş yapabilirsiniz.","Biometric sign-in is currently unavailable. You can use your PIN."),Toast.LENGTH_LONG).show();
        }
    }

    void shakeView(View v){ v.animate().translationX(dp(10)).setDuration(55).withEndAction(()->v.animate().translationX(-dp(10)).setDuration(55).withEndAction(()->v.animate().translationX(dp(6)).setDuration(45).withEndAction(()->v.animate().translationX(0).setDuration(45).start()).start()).start()).start(); }

    class PinDotsView extends View{
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); int length=0; boolean error=false;
        PinDotsView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);setClickable(true);}
        void setPinLength(int n){length=Math.max(0,Math.min(6,n));invalidate();}
        void setErrorState(boolean v){error=v;invalidate();}
        protected void onDraw(Canvas canvas){ super.onDraw(canvas); float h=getHeight(), centerY=h/2f, gap=dp(46), radius=dp(11); float start=getWidth()/2f-gap*2.5f; for(int i=0;i<6;i++){float cx=start+i*gap; p.setStyle(Paint.Style.FILL); p.setColor(i<length?(error?Color.rgb(214,75,82):Color.rgb(48,56,190)):Color.rgb(245,247,249)); canvas.drawCircle(cx,centerY,radius,p); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.6f)); p.setColor(error?Color.rgb(214,75,82):Color.rgb(205,214,221)); canvas.drawCircle(cx,centerY,radius,p); } p.setStyle(Paint.Style.FILL); }
    }

    void savePrefs(){getPreferences(0).edit().putInt("themeMode",themeMode).putBoolean("dark",darkMode).putString("lang",language).putString("currency",currencyCode).putBoolean("marketAutoUpdate",marketAutoUpdate).putString("marketBaseUnit",marketBaseUnit).putString("marketWatched",android.text.TextUtils.join(",",watchedMarketCodes)).apply();applySystemUi();}
    void save(){try{JSONArray a=new JSONArray();for(Tx t:txs){JSONObject o=new JSONObject();o.put("id",t.id);o.put("income",t.isIncome);o.put("amount",t.amount);o.put("desc",t.desc);o.put("date",t.date);o.put("cat",t.cat);o.put("account",t.account==null?"Genel":t.account);o.put("creditCard",t.creditCard);o.put("cardId",t.cardId);o.put("paymentId",t.paymentId);o.put("archived",t.archived);o.put("cancelled",t.cancelled);a.put(o);}getPreferences(0).edit().putString("txs",a.toString()).apply();}catch(Exception ignored){}}
    // v39 global legacy bridge: every old trUi("TR","EN") pair now resolves through all supported locales.
    private static final String[][] FINBI_OUTPUT_TRANSLATIONS = new String[][]{
            {"Genel","General","Général","Общий","Allgemein","一般","常用","عام","Γενικά","General","Generale"},
            {"gün","day","jour","день","Tag","日","天","يوم","ημέρα","día","giorno"},
            {"hedef daha","more goals","objectifs supplémentaires","целей дополнительно","weitere Ziele","その他の目標","个更多目标","أهداف أخرى","επιπλέον στόχοι","objetivos más","altri obiettivi"},
            {"Kart","Card","Carte","Карта","Karte","カード","卡片","بطاقة","Κάρτα","Tarjeta","Carta"},
            {": borç ",", debt ",": dette ",": долг ",": Schulden ",": 利用額 ",": 欠款 ",": الدين ",": χρέος ",": deuda ",": debito "},
            {", kullanılabilir ",", available ",", disponible ",", доступно ",", verfügbar ","、利用可能額 ","，可用额度 ","، المتاح ","، διαθέσιμα ",", disponible ",", disponibile "},
            {", asgari ",", minimum payment ",", paiement minimum ",", минимальный платёж ",", Mindestzahlung ","、最低支払額 ","，最低还款额 ","، الحد الأدنى للدفع ","، ελάχιστη πληρωμή ",", pago mínimo ",", pagamento minimo "},
            {", son ödeme günü ",", due date ",", date d’échéance ",", срок оплаты ",", Fälligkeitsdatum ","、支払期限 ","，还款日 ","، تاريخ الاستحقاق ","، ημερομηνία πληρωμής ",", fecha de pago ",", scadenza "},
            {" kategorisinde bu ay "," this month in the category "," ce mois-ci dans la catégorie "," в этом месяце в категории "," diesen Monat in der Kategorie ","今月のカテゴリ「","本月在"," هذا الشهر في فئة "," αυτόν τον μήνα στην κατηγορία "," este mes en la categoría "," questo mese nella categoria "},
            {" harcadın."," you spent."," vous avez dépensé."," вы потратили."," hast du ausgegeben.","」で使用した金額は","的支出为"," أنفقت."," ξόδεψες."," gastaste."," hai speso."},
            {" Geçen ay ",", last month, "," Le mois dernier, "," В прошлом месяце "," Letzten Monat "," 先月は"," 上个月"," في الشهر الماضي "," Τον προηγούμενο μήνα "," El mes pasado "," Il mese scorso "},
            {" harcamıştın (değişim ",", you spent (change "," vous aviez dépensé (variation "," вы потратили (изменение "," hattest du ausgegeben (Änderung ","支出額は（変化 ","支出为（变化 "," أنفقت (التغير "," είχες ξοδέψει (μεταβολή "," habías gastado (cambio "," avevi speso (variazione "},
            {"Bu ay günlük ortalama harcaman yaklaşık ","Your average daily spending this month is about ","Votre dépense quotidienne moyenne ce mois-ci est d’environ ","Ваша средняя дневная трата в этом месяце составляет около ","Deine durchschnittlichen täglichen Ausgaben in diesem Monat betragen etwa ","今月の1日あたりの平均支出は約","你本月的日均支出约为","متوسط إنفاقك اليومي هذا الشهر حوالي ","Η μέση ημερήσια δαπάνη σου αυτόν τον μήνα είναι περίπου ","Tu gasto diario medio este mes es de aproximadamente ","La tua spesa media giornaliera questo mese è di circa "},
            {"Bu ay ","This month ","Ce mois-ci ","В этом месяце ","Diesen Monat ","今月は","本月","هذا الشهر ","Αυτόν τον μήνα ","Este mes ","Questo mese "},
            {" gider ve "," expenses and "," dépenses et "," расходов и "," Ausgaben und "," 支出、"," 笔支出和 "," مصروف و "," έξοδα και "," gastos y "," spese e "},
            {" gelir işlemin var."," income transactions."," transactions de revenus."," операций дохода."," Einnahmentransaktionen."," 収入取引があります。"," 笔收入交易。"," معاملات دخل."," συναλλαγές εσόδων."," transacciones de ingresos."," transazioni di entrata."},
            {" toplam harcaman "," total spending "," les dépenses totales "," общие расходы "," deine Gesamtausgaben ","、総支出は","，总支出为"," إجمالي إنفاقك "," η συνολική σου δαπάνη "," de gasto total "," di spesa totale "},
            {"En yüksek kategoriler:","Top categories:","Catégories principales :","Основные категории:","Top-Kategorien:","主なカテゴリ：","主要类别：","أبرز الفئات:","Κορυφαίες κατηγορίες:","Principales categorías:","Categorie principali:"},
            {"Bu ay en yüksek harcama kategorilerin:\n","Your highest spending categories this month:\n","Vos catégories de dépenses les plus élevées ce mois-ci :\n","Ваши самые крупные категории расходов в этом месяце:\n","Deine größten Ausgabenkategorien in diesem Monat:\n","今月の支出が最も多いカテゴリ：\n","本月支出最高的类别：\n","أعلى فئات إنفاقك هذا الشهر:\n","Οι κατηγορίες με τις μεγαλύτερες δαπάνες σου αυτόν τον μήνα:\n","Tus categorías de mayor gasto este mes:\n","Le categorie di spesa più alte questo mese:\n"},
            {"Kredi kartı ödeme ekranına yönlendirebilirim. Genel kart ödemesi yaptığında kart borcun azalır; taksit planların ise ayrı şekilde korunur. İstersen ödeme ekranını açabilirim.","I can take you to the credit card payment screen. A general card payment reduces your card debt; your installment plans remain separate. I can open the payment screen for you.","Je peux vous conduire à l’écran de paiement de la carte de crédit. Un paiement général réduit votre dette de carte ; vos plans de paiement restent séparés. Je peux ouvrir l’écran de paiement.","Я могу открыть экран оплаты кредитной карты. Обычная оплата уменьшает долг по карте, а планы рассрочки остаются отдельно. Я могу открыть экран оплаты.","Ich kann dich zum Kreditkartenzahlungsbildschirm führen. Eine allgemeine Kartenzahlung reduziert deine Kartenschuld; deine Ratenpläne bleiben getrennt. Ich kann den Zahlungsbildschirm öffnen.","クレジットカードの支払い画面を開けます。通常のカード支払いでカード残高が減り、分割プランは別に維持されます。支払い画面を開けます。","我可以带你进入信用卡付款页面。普通的卡片还款会减少卡债，分期计划会单独保留。我可以打开付款页面。","يمكنني فتح شاشة سداد بطاقة الائتمان. تؤدي دفعة البطاقة العادية إلى تقليل الدين، بينما تبقى خطط التقسيط منفصلة. يمكنني فتح شاشة الدفع.","Μπορώ να σε μεταφέρω στην οθόνη πληρωμής πιστωτικής κάρτας. Μια γενική πληρωμή μειώνει το χρέος της κάρτας, ενώ τα προγράμματα δόσεων παραμένουν ξεχωριστά. Μπορώ να ανοίξω την οθόνη πληρωμής.","Puedo llevarte a la pantalla de pago de la tarjeta de crédito. Un pago general reduce la deuda de la tarjeta; los planes de cuotas se mantienen por separado. Puedo abrir la pantalla de pago.","Posso portarti alla schermata di pagamento della carta di credito. Un pagamento generale riduce il debito della carta; i piani rateali restano separati. Posso aprire la schermata di pagamento."},
            {"Bu ay gelirlerinden giderlerini çıkardığımda ","After subtracting your spending from your income this month, you have ","Après déduction de vos dépenses de vos revenus ce mois-ci, il vous reste ","После вычета расходов из доходов за этот месяц остаётся ","Nach Abzug deiner Ausgaben von deinen Einnahmen in diesem Monat bleiben dir ","今月の収入から支出を差し引くと、残りは","从本月收入中扣除支出后，你还剩","بعد خصم إنفاقك من دخلك هذا الشهر، يتبقى لديك","Αφού αφαιρέσουμε τις δαπάνες από τα έσοδά σου αυτόν τον μήνα, σου μένουν","Después de restar tus gastos de tus ingresos este mes, te quedan","Dopo aver sottratto le spese dalle entrate di questo mese, ti rimangono "},
            {" kalıyor."," remaining."," restants."," остаётся."," übrig.","残ります。","。"," متبقٍ."," υπόλοιπο."," restantes."," rimanenti."},
            {"Finway’de ","In Finway, ","Dans Finway, ","В Finway ","In Finway ","Finwayでは","在 Finway 中，","في Finway،","Στο Finway,","En Finway,","In Finway,"},
            {"Finway'de ","In Finway, ","Dans Finway, ","В Finway ","In Finway ","Finwayでは","在 Finway 中，","في Finway،","Στο Finway,","En Finway,","In Finway,"},
            {" kredi kartı kayıtlı."," registered credit cards."," cartes de crédit enregistrées."," зарегистрированных кредитных карт."," registrierte Kreditkarten."," 枚のクレジットカードが登録されています。"," 张信用卡已登记。"," بطاقات ائتمان مسجلة."," καταχωρημένες πιστωτικές κάρτες."," tarjetas de crédito registradas."," carte di credito registrate."},
            {"Kayıtlı kartlarının toplam asgari ödeme tutarı ","The total minimum payment for your registered cards is ","Le paiement minimum total de vos cartes enregistrées est de ","Общая минимальная сумма платежа по зарегистрированным картам составляет ","Die gesamte Mindestzahlung für deine registrierten Karten beträgt ","登録カードの最低支払額の合計は","你已登记卡片的最低还款总额为","إجمالي الحد الأدنى للدفع لبطاقاتك المسجلة هو ","Η συνολική ελάχιστη πληρωμή των καταχωρημένων καρτών σου είναι ","El pago mínimo total de tus tarjetas registradas es de ","Il pagamento minimo totale delle carte registrate è di "},
            {" kredi kartı ödeme tutarı "," credit card payment amount "," montant du paiement de la carte de crédit "," сумма платежа по кредитной карте "," Kreditkartenzahlungsbetrag "," クレジットカードの支払額 "," 信用卡付款金额 "," مبلغ سداد بطاقة الائتمان "," ποσό πληρωμής πιστωτικής κάρτας "," importe del pago de la tarjeta "," importo del pagamento della carta "},
            {" aktif taksidin var. Aylık yaklaşık yük: "," active installments. Approximate monthly load: "," échéances actives. Charge mensuelle approximative : "," активных рассрочек. Примерная ежемесячная нагрузка: "," aktive Raten. Ungefähre monatliche Belastung: ","件の分割払いがあります。月間のおおよその負担：","笔活跃分期。每月大约负担："," أقساط نشطة. العبء الشهري التقريبي: "," ενεργές δόσεις. Περίπου μηνιαίο βάρος: "," cuotas activas. Carga mensual aproximada: "," rate attive. Carico mensile approssimativo: "},
            {". Kalan toplam tahmini yük: ",". Estimated remaining total load: ",". Charge totale restante estimée : ",". Оставшаяся общая расчетная нагрузка: ",". Geschätzte verbleibende Gesamtbelastung: ","。残りの推定総負担：","。预计剩余总负担：",". إجمالي العبء المتبقي المقدر: "," Συνολικό εκτιμώμενο υπόλοιπο φορτίο: ",". Carga total restante estimada: ",". Carico totale residuo stimato: "},
            {" tamamlandı, "," completed, "," terminé, "," выполнено, "," abgeschlossen, "," 完了、","已完成，"," مكتمل،"," ολοκληρώθηκε, "," completado, "," completato, "},
            {" kaldı"," remaining"," restant"," осталось"," übrig"," 残り","剩余"," متبقٍ"," απομένουν"," restantes"," rimanenti"},
            {" — hedef tarihi "," — target date "," — date cible "," — дата цели "," — Zieldatum "," — 目標日"," — 目标日期"," — تاريخ الهدف "," — ημερομηνία στόχου "," — fecha objetivo "," — data obiettivo "},
            {"Bu ay: gelir ","This month: income ","Ce mois-ci : revenus ","В этом месяце: доход ","Diesen Monat: Einnahmen ","今月：収入","本月：收入","هذا الشهر: الدخل ","Αυτόν τον μήνα: έσοδα ","Este mes: ingresos ","Questo mese: entrate "},
            {", gider ",", spending ",", dépenses ",", расходы ",", Ausgaben ","、支出","，支出","، المصروف ","، έξοδα ",", gastos ",", spese "},
            {".\nGeçen ay: gelir ",".\nLast month: income ",".\nLe mois dernier : revenus ",".\nВ прошлом месяце: доход ",".\nLetzten Monat: Einnahmen ","。\n先月：収入","。\n上个月：收入",".\nفي الشهر الماضي: الدخل ",".\nΤον προηγούμενο μήνα: έσοδα ",".\nEl mes pasado: ingresos ",".\nIl mese scorso: entrate "},
            {".\nHarcama değişimi: ",".\nSpending change: ",".\nVariation des dépenses : ",".\nИзменение расходов: ",".\nAusgabenänderung: ","。\n支出の変化：","。\n支出变化：",".\nتغير الإنفاق: ",".\nΜεταβολή δαπανών: ",".\nCambio de gasto: ",".\nVariazione delle spese: "},
            {" Gelir değişimi: "," Income change: "," Variation des revenus : "," Изменение дохода: "," Einnahmenänderung: "," 収入の変化："," 收入变化："," تغير الدخل: "," Μεταβολή εσόδων: "," Cambio de ingresos: "," Variazione delle entrate: "},
            {": gelir ",": income "," : revenus "," : доход "," : Einnahmen ","：収入","：收入"," : الدخل "," : έσοδα "," : ingresos "," : entrate "},
            {" / gider "," / spending "," / dépenses "," / расходы "," / Ausgaben "," / 支出"," / 支出"," / المصروف "," / έξοδα "," / gastos "," / spese "},
            {"\nToplam: gelir ","\nTotal: income ","\nTotal : revenus ","\nИтого: доход ","\nGesamt: Einnahmen ","\n合計：収入","\n总计：收入","\nالإجمالي: الدخل ","\nΣύνολο: έσοδα ","\nTotal: ingresos ","\nTotale: entrate "},
            {", net ",", net ",", net ",", нетто ",", netto ","、純額","，净额","، الصافي ","، καθαρό ",", neto ",", netto "},
            {" alış "," buy "," achat "," покупка "," Kauf "," 買値"," 买入"," شراء "," αγορά "," compra "," acquisto "},
            {", satış ",", sell ",", vente ",", продажа ",", Verkauf ","、売値","，卖出","، بيع ","، πώληση ",", venta ",", vendita "},
            {". Değişim: ",". Change: ",". Variation : ",". Изменение: ",". Änderung: ","。変化：","。变化：",". التغير: ",". Μεταβολή: ",". Cambio: ",". Variazione: "},
            {"• Gelir: ","• Income: ","• Revenus : ","• Einnahmen: ","• Einnahmen: ","• 収入：","• 收入：","• الدخل: ","• Έσοδα: ","• Ingresos: ","• Entrate: "},
            {"• Gider: ","• Spending: ","• Dépenses : ","• Расходы: ","• Ausgaben: ","• 支出：","• 支出：","• المصروف: ","• Δαπάνες: ","• Gastos: ","• Spese: "},
            {"• Net: ","• Net: ","• Net : ","• Нетто: ","• Netto: ","• 純額：","• 净额：","• الصافي: ","• Καθαρό: ","• Neto: ","• Netto: "},
            {"\n• Bütçe kullanımı: ","\n• Budget usage: ","\n• Utilisation du budget : ","\n• Использование бюджета: ","\n• Budgetnutzung: ","\n• 予算使用率：","\n• 预算使用率：","\n• استخدام الميزانية: ","\n• Χρήση προϋπολογισμού: ","\n• Uso del presupuesto: ","\n• Utilizzo del budget: "},
            {" — kalan "," — remaining "," — restant "," — осталось "," — verbleibend "," — 残り "," — 剩余 "," — المتبقي "," — απομένουν "," — restante "," — rimanente "},
            {"\n\nEn yüksek harcamaların:\n","\n\nHighest spending:\n","\n\nDépenses les plus élevées :\n","\n\nСамые крупные расходы:\n","\n\nHöchste Ausgaben:\n","\n\n支出上位：\n","\n\n最高支出：\n","\n\nأعلى المصروفات:\n","\n\nΜεγαλύτερες δαπάνες:\n","\n\nMayores gastos:\n","\n\nSpese più alte:\n"},
            {"\n\nGeçen aya göre gider değişimi: ","\n\nSpending change vs last month: ","\n\nVariation des dépenses par rapport au mois dernier : ","\n\nИзменение расходов по сравнению с прошлым месяцем: ","\n\nAusgabenänderung gegenüber dem Vormonat: ","\n\n先月との支出変化：","\n\n与上月相比的支出变化：","\n\nتغير الإنفاق مقارنة بالشهر الماضي: ","\n\nΜεταβολή δαπανών σε σχέση με τον προηγούμενο μήνα: ","\n\nCambio de gasto respecto al mes pasado: ","\n\nVariazione delle spese rispetto al mese scorso: "},
            {"\n\nBu ay giderlerin gelirlerini aşmış görünüyor; önce en yüksek harcama kategorilerini incelemek faydalı olabilir.","\n\nYour spending appears to exceed your income this month; it may help to review your highest spending categories first.","\n\nVos dépenses semblent dépasser vos revenus ce mois-ci ; il peut être utile d’examiner d’abord vos catégories de dépenses les plus élevées.","\n\nПохоже, в этом месяце расходы превышают доходы; сначала стоит посмотреть на самые крупные категории расходов.","\n\nDeine Ausgaben scheinen diesen Monat deine Einnahmen zu übersteigen; es kann helfen, zuerst die größten Ausgabenkategorien zu prüfen.","\n\n今月は支出が収入を上回っているようです。まず支出の大きいカテゴリを確認するとよいでしょう。","\n\n你本月的支出似乎超过了收入；可以先查看支出最高的类别。","\n\nيبدو أن إنفاقك يتجاوز دخلك هذا الشهر؛ قد يكون من المفيد مراجعة أعلى فئات الإنفاق أولاً.","\n\nΟι δαπάνες σου φαίνεται να ξεπερνούν τα έσοδά σου αυτόν τον μήνα· ίσως βοηθήσει να εξετάσεις πρώτα τις κατηγορίες με τις μεγαλύτερες δαπάνες.","\n\nTus gastos parecen superar tus ingresos este mes; puede ser útil revisar primero tus categorías de mayor gasto.","\n\nLe tue spese sembrano superare le entrate questo mese; può essere utile esaminare prima le categorie con la spesa più alta."},
            {"\n\nBu ay bütçeni aşmış görünüyorsun.","\n\nYou appear to have exceeded your budget this month.","\n\nVous semblez avoir dépassé votre budget ce mois-ci.","\n\nПохоже, в этом месяце вы превысили бюджет.","\n\nDu scheinst diesen Monat dein Budget überschritten zu haben.","\n\n今月は予算を超えているようです。","\n\n你本月似乎超出了预算。","\n\nيبدو أنك تجاوزت ميزانيتك هذا الشهر.","\n\nΦαίνεται ότι ξεπέρασες τον προϋπολογισμό σου αυτόν τον μήνα.","\n\nParece que has superado tu presupuesto este mes.","\n\nSembra che tu abbia superato il budget questo mese."},
            {"\n\nŞu an gelir-gider farkın pozitif görünüyor.","\n\nYour income-spending difference currently appears positive.","\n\nLa différence entre vos revenus et vos dépenses semble actuellement positive.","\n\nСейчас разница между доходами и расходами положительная.","\n\nDie Differenz zwischen deinen Einnahmen und Ausgaben ist derzeit positiv.","\n\n現在、収入と支出の差額はプラスです。","\n\n目前你的收入与支出差额为正。","\n\nيبدو أن الفرق بين دخلك وإنفاقك إيجابي حاليًا.","\n\nΗ διαφορά εσόδων-δαπανών σου είναι προς το παρόν θετική.","\n\nLa diferencia entre tus ingresos y gastos es actualmente positiva.","\n\nLa differenza tra entrate e spese è attualmente positiva."},
            {"Tahmin için mevcut aya geçmen gerekiyor.","You need to switch to the current month for a forecast.","Vous devez passer au mois en cours pour obtenir une prévision.","Для прогноза нужно перейти на текущий месяц.","Für eine Prognose musst du zum aktuellen Monat wechseln.","予測するには現在の月に切り替える必要があります。","要进行预测，请切换到当前月份。","تحتاج إلى الانتقال إلى الشهر الحالي للحصول على توقع.","Για πρόβλεψη πρέπει να μεταβείς στον τρέχοντα μήνα.","Debes pasar al mes actual para obtener una previsión.","Per una previsione devi passare al mese corrente."},
            {"\n• Bütçe: ","\n• Budget: ","\n• Budget : ","\n• Бюджет: ","\n• Budget: ","\n• 予算：","\n• 预算：","\n• الميزانية: ","\n• Προϋπολογισμός: ","\n• Presupuesto: ","\n• Budget: "},
            {" — tahmini "," — estimated "," — estimé "," — прогноз "," — geschätzt "," — 予測 "," — 预计 "," — تقديري "," — εκτιμώμενο "," — estimado "," — stimato "},
            {"aşım","overage","dépassement","превышение","Überschreitung","超過","超支","تجاوز","υπέρβαση","exceso","superamento"},
            {"sınır içinde","within budget","dans le budget","в пределах бюджета","im Budgetrahmen","予算内","在预算内","ضمن الميزانية","εντός προϋπολογισμού","dentro del presupuesto","entro il budget"},
            {"\n\nBu yalnızca mevcut günlük harcama hızına dayalı bir tahmindir; yeni gelir veya giderler sonucu değiştirebilir.","\n\nThis is only an estimate based on your current daily spending pace; new income or spending can change the result.","\n\nIl s’agit uniquement d’une estimation basée sur votre rythme actuel de dépenses quotidiennes ; de nouveaux revenus ou dépenses peuvent modifier le résultat.","\n\nЭто лишь прогноз на основе текущего ежедневного темпа расходов; новые доходы или расходы могут изменить результат.","\n\nDies ist nur eine Schätzung auf Grundlage deines aktuellen täglichen Ausgabentempos; neue Einnahmen oder Ausgaben können das Ergebnis verändern.","\n\nこれは現在の1日あたりの支出ペースに基づく推定であり、新しい収入や支出によって結果が変わる可能性があります。","\n\n这只是根据你当前日均支出速度做出的估算；新的收入或支出可能会改变结果。","\n\nهذا مجرد تقدير يعتمد على وتيرة إنفاقك اليومية الحالية؛ قد يغيّر الدخل أو الإنفاق الجديد النتيجة.","\n\nΑυτό είναι μόνο μια εκτίμηση με βάση τον τρέχοντα ημερήσιο ρυθμό δαπανών σου· νέα έσοδα ή έξοδα μπορεί να αλλάξουν το αποτέλεσμα.","\n\nEsto es solo una estimación basada en tu ritmo diario de gasto actual; nuevos ingresos o gastos pueden cambiar el resultado.","\n\nÈ solo una stima basata sul tuo attuale ritmo di spesa giornaliero; nuove entrate o spese possono modificare il risultato."},
            {" işlem)\n"," transaction)\n"," transaction)\n"," операций)\n"," Transaktionen)\n"," 取引）\n"," 笔交易）\n"," معاملة)\n"," συναλλαγές)\n"," transacciones)\n"," transazioni)\n"},
            {"\n\nHedeflerin:\n","\n\nYour goals:\n","\n\nVos objectifs :\n","\n\nВаши цели:\n","\n\nDeine Ziele:\n","\n\n目標：\n","\n\n你的目标：\n","\n\nأهدافك:\n","\n\nΟι στόχοι σου:\n","\n\nTus objetivos:\n","\n\nI tuoi obiettivi:\n"},
            {"Bunu Finway verilerinden yorumlayabilmem için biraz daha açık sorabilirsin. Örneğin “Bu ay durumum nasıl?”, “Geçen aya göre market harcamam nasıl değişti?”, “Ay sonunda ne kadar param kalabilir?”, “Kart taksitlerim ne durumda?” veya “Hedeflerim ne durumda?” diyebilirsin.","You can ask a little more clearly so I can interpret it using Finway data. For example: “How am I doing this month?”, “How did my market spending change compared with last month?”, “How much money might I have left at the end of the month?”, “How are my card installments doing?” or “How are my goals doing?”","Vous pouvez préciser votre question pour que je puisse l’interpréter avec les données Finway. Par exemple : « Comment vais-je ce mois-ci ? », « Comment mes dépenses de supermarché ont-elles changé par rapport au mois dernier ? », « Combien d’argent pourrais-je avoir à la fin du mois ? », « Où en sont mes paiements en plusieurs fois ? » ou « Comment vont mes objectifs ? »","Сформулируйте вопрос чуть яснее, чтобы я мог интерпретировать его по данным Finway. Например: «Как у меня дела в этом месяце?», «Как изменились мои расходы на продукты по сравнению с прошлым месяцем?», «Сколько денег может остаться к концу месяца?», «Как обстоят дела с рассрочками по карте?» или «Как идут мои цели?»","Du kannst etwas konkreter fragen, damit ich die Finway-Daten besser auswerten kann. Zum Beispiel: „Wie läuft es diesen Monat?“, „Wie haben sich meine Supermarktausgaben gegenüber dem letzten Monat verändert?“, „Wie viel Geld könnte mir am Monatsende bleiben?“, „Wie stehen meine Kartenraten?“ oder „Wie laufen meine Ziele?“","Finwayのデータから判断できるように、もう少し具体的に質問してください。たとえば「今月の調子は？」「先月と比べて買い物の支出はどう変わった？」「月末にいくら残りそう？」「カードの分割払いはどうなっている？」「目標の進み具合は？」などです。","你可以问得更具体一些，这样我才能根据 Finway 数据进行分析。例如：“我这个月情况怎么样？”、“和上个月相比，我的购物支出有什么变化？”、“月底可能还剩多少钱？”、“我的信用卡分期怎么样？”或“我的目标进展如何？”","يمكنك طرح السؤال بمزيد من الوضوح حتى أتمكن من تحليله باستخدام بيانات Finway. مثلًا: «كيف وضعي هذا الشهر؟» أو «كيف تغيّر إنفاقي على التسوق مقارنة بالشهر الماضي؟» أو «كم قد يتبقى من مالي في نهاية الشهر؟» أو «كيف هي أقساط بطاقتي؟» أو «كيف تسير أهدافي؟»","Ρώτησέ με λίγο πιο συγκεκριμένα ώστε να μπορώ να το αναλύσω με τα δεδομένα του Finway. Για παράδειγμα: «Πώς τα πάω αυτόν τον μήνα;», «Πώς άλλαξαν τα έξοδά μου για αγορές σε σχέση με τον προηγούμενο μήνα;», «Πόσα χρήματα μπορεί να μου μείνουν στο τέλος του μήνα;», «Πώς πάνε οι δόσεις της κάρτας μου;» ή «Πώς πάνε οι στόχοι μου;»","Puedes preguntar de forma un poco más clara para que pueda interpretarlo usando los datos de Finway. Por ejemplo: “¿Cómo voy este mes?”, “¿Cómo cambiaron mis gastos de compras respecto al mes pasado?”, “¿Cuánto dinero podría quedarme a final de mes?”, “¿Cómo van las cuotas de mi tarjeta?” o “¿Cómo van mis objetivos?”","Puoi fare una domanda un po’ più chiara così posso interpretarla usando i dati di Finway. Per esempio: “Come sto andando questo mese?”, “Come sono cambiate le mie spese per acquisti rispetto al mese scorso?”, “Quanti soldi potrei avere a fine mese?”, “Come stanno andando le rate della mia carta?” oppure “Come stanno andando i miei obiettivi?”"},
            {"Ben Finbi. Finansal durumunu birlikte takip edebiliriz.\n\n","I’m Finbi. We can track your financial situation together.\n\n","Je suis Finbi. Nous pouvons suivre ensemble votre situation financière.\n\n","Я Finbi. Мы можем вместе отслеживать ваше финансовое состояние.\n\n","Ich bin Finbi. Wir können deine finanzielle Situation gemeinsam verfolgen.\n\n","Finbiです。財務状況を一緒に確認できます。\n\n","我是 Finbi。我们可以一起跟踪你的财务状况。\n\n","أنا Finbi. يمكننا متابعة وضعك المالي معًا.\n\n","Είμαι ο Finbi. Μπορούμε να παρακολουθούμε μαζί την οικονομική σου κατάσταση.\n\n","Soy Finbi. Podemos seguir juntos tu situación financiera.\n\n","Sono Finbi. Possiamo seguire insieme la tua situazione finanziaria.\n\n"},
            {"• Bakiye, gelir ve harcamalarını analiz edebilirim.\n","• I can analyze your balance, income, and spending.\n","• Je peux analyser votre solde, vos revenus et vos dépenses.\n","• Я могу анализировать ваш баланс, доходы и расходы.\n","• Ich kann deinen Kontostand, Einnahmen und Ausgaben analysieren.\n","• 残高、収入、支出を分析できます。\n","• 我可以分析你的余额、收入和支出。\n","• يمكنني تحليل رصيدك ودخلك وإنفاقك.\n","• Μπορώ να αναλύσω το υπόλοιπο, τα έσοδα και τις δαπάνες σου.\n","• Puedo analizar tu saldo, ingresos y gastos.\n","• Posso analizzare saldo, entrate e spese.\n"},
            {"• Kategorilerini ve aylık değişimleri karşılaştırabilirim.\n","• I can compare your categories and monthly changes.\n","• Je peux comparer vos catégories et leurs variations mensuelles.\n","• Я могу сравнивать категории и изменения по месяцам.\n","• Ich kann deine Kategorien und monatlichen Veränderungen vergleichen.\n","• カテゴリと月ごとの変化を比較できます。\n","• 我可以比较你的类别和每月变化。\n","• يمكنني مقارنة فئاتك والتغيرات الشهرية.\n","• Μπορώ να συγκρίνω τις κατηγορίες σου και τις μηνιαίες μεταβολές.\n","• Puedo comparar tus categorías y cambios mensuales.\n","• Posso confrontare le categorie e le variazioni mensili.\n"},
            {"• Kredi kartı borcu, asgari ödeme ve taksitlerini özetleyebilirim.\n","• I can summarize your credit card debt, minimum payments, and installments.\n","• Je peux résumer votre dette de carte, vos paiements minimums et vos échéances.\n","• Я могу обобщить долг по карте, минимальные платежи и рассрочки.\n","• Ich kann deine Kreditkartenschulden, Mindestzahlungen und Raten zusammenfassen.\n","• クレジットカードの残高、最低支払額、分割払いをまとめられます。\n","• 我可以总结你的信用卡债务、最低还款和分期。\n","• يمكنني تلخيص دين بطاقتك والحد الأدنى للسداد والأقساط.\n","• Μπορώ να συνοψίσω το χρέος της κάρτας σου, τις ελάχιστες πληρωμές και τις δόσεις.\n","• Puedo resumir la deuda de tu tarjeta, los pagos mínimos y las cuotas.\n","• Posso riassumere il debito della carta, i pagamenti minimi e le rate.\n"},
            {"• Birikim ve hedeflerini takip edebilirim.\n","• I can track your savings and goals.\n","• Je peux suivre votre épargne et vos objectifs.\n","• Я могу отслеживать накопления и цели.\n","• Ich kann deine Ersparnisse und Ziele verfolgen.\n","• 貯蓄と目標を追跡できます。\n","• 我可以跟踪你的储蓄和目标。\n","• يمكنني متابعة مدخراتك وأهدافك.\n","• Μπορώ να παρακολουθώ τις αποταμιεύσεις και τους στόχους σου.\n","• Puedo seguir tus ahorros y objetivos.\n","• Posso seguire i tuoi risparmi e obiettivi.\n"},
            {"• Dolar, euro ve gram altın gibi piyasa verilerini gösterebilirim.\n","• I can show market data such as the dollar, euro, and gram gold.\n","• Je peux afficher des données de marché comme le dollar, l’euro et l’or au gramme.\n","• Я могу показывать рыночные данные по доллару, евро и граммовому золоту.\n","• Ich kann Marktdaten wie Dollar, Euro und Grammgold anzeigen.\n","• ドル、ユーロ、グラム金などの市場データを表示できます。\n","• 我可以显示美元、欧元和克黄金等市场数据。\n","• يمكنني عرض بيانات السوق مثل الدولار واليورو والذهب بالغرام.\n","• Μπορώ να εμφανίσω δεδομένα αγοράς για δολάριο, ευρώ και χρυσό ανά γραμμάριο.\n","• Puedo mostrar datos de mercado como dólar, euro y oro por gramo.\n","• Posso mostrare dati di mercato come dollaro, euro e oro al grammo.\n"},
            {"• İstediğin Finway ekranına seni yönlendirebilirim.\n","• I can take you to the Finway screen you need.\n","• Je peux vous diriger vers l’écran Finway dont vous avez besoin.\n","• Я могу открыть нужный вам экран Finway.\n","• Ich kann dich zum gewünschten Finway-Bildschirm führen.\n","• 必要なFinway画面に案内できます。\n","• 我可以带你进入需要的 Finway 页面。\n","• يمكنني توجيهك إلى شاشة Finway التي تريدها.\n","• Μπορώ να σε κατευθύνω στην οθόνη του Finway που θέλεις.\n","• Puedo llevarte a la pantalla de Finway que necesitas.\n","• Posso portarti alla schermata Finway che ti serve.\n"},
            {"Örneğin “Piyasa otomatik güncellemeyi aç”, “Bu ay en çok nereye harcadım?” veya “Kaç taksidim kaldı?” diyebilirsin.","For example, you can say “Turn on automatic market updates,” “What did I spend the most on this month?” or “How many installments do I have left?”","Par exemple, vous pouvez dire « Active les mises à jour automatiques du marché », « Dans quoi ai-je le plus dépensé ce mois-ci ? » ou « Combien de mensualités me reste-t-il ? ».","Например: «Включи автоматическое обновление рынка», «На что я больше всего потратил в этом месяце?» или «Сколько рассрочек у меня осталось?».","Zum Beispiel: „Aktiviere automatische Marktaktualisierungen“, „Wofür habe ich diesen Monat am meisten ausgegeben?“ oder „Wie viele Raten habe ich noch übrig?“.","たとえば「市場の自動更新をオンにして」「今月は何に一番使った？」「分割払いはあと何回？」などと聞けます。","例如：“开启市场自动更新”、“我这个月主要花在哪了？”或“我还剩多少期分期？”","مثلًا: «فعّل تحديث السوق تلقائيًا» أو «على ماذا أنفقت أكثر هذا الشهر؟» أو «كم قسطًا بقي لدي؟».","Για παράδειγμα: «Ενεργοποίησε την αυτόματη ενημέρωση αγοράς», «Πού ξόδεψα τα περισσότερα αυτόν τον μήνα;» ή «Πόσες δόσεις μου έχουν μείνει;».","Por ejemplo: “Activa las actualizaciones automáticas del mercado”, “¿En qué gasté más este mes?” o “¿Cuántas cuotas me quedan?”.","Ad esempio: “Attiva gli aggiornamenti automatici del mercato”, “In cosa ho speso di più questo mese?” oppure “Quante rate mi restano?”."},
            {"Bu ay ","This month ","Ce mois-ci ","В этом месяце ","Diesen Monat ","今月は","本月","هذا الشهر ","Αυτόν τον μήνα ","Este mes ","Questo mese "},
            {"arttı","increased","a augmenté","выросло","gestiegen","増加しました","增加了","زاد","αυξήθηκε","aumentó","è aumentato"},
            {"değişmedi","did not change","n’a pas changé","не изменилось","hat sich nicht verändert","変化なし","没有变化","لم يتغير","δεν άλλαξε","no cambió","non è cambiato"},
            {"Finway'de ","In Finway, ","Dans Finway, ","В Finway ","In Finway ","Finwayでは","在 Finway 中，","في Finway،","Στο Finway,","En Finway,","In Finway,"},
            {"Bütçeni","your budget","votre budget","ваш бюджет","dein Budget","予算","你的预算","ميزانيتك","τον προϋπολογισμό σου","tu presupuesto","il tuo budget"},
            {"Henüz aylık bütçe tanımlanmamış. İstersen Finway'de bir bütçe belirleyip harcamalarını takip edebiliriz.","No monthly budget has been defined yet. We can set a budget in Finway and track your spending.","Aucun budget mensuel n’est encore défini. Nous pouvons définir un budget dans Finway et suivre vos dépenses.","Ежемесячный бюджет ещё не задан. Мы можем установить бюджет в Finway и отслеживать расходы.","Es wurde noch kein Monatsbudget festgelegt. Wir können in Finway ein Budget festlegen und deine Ausgaben verfolgen.","まだ月間予算が設定されていません。Finwayで予算を設定して支出を追跡できます。","尚未设置月度预算。我们可以在 Finway 中设置预算并跟踪你的支出。","لم يتم تحديد ميزانية شهرية بعد. يمكننا تحديد ميزانية في Finway ومتابعة إنفاقك.","Δεν έχει οριστεί ακόμη μηνιαίος προϋπολογισμός. Μπορούμε να ορίσουμε προϋπολογισμό στο Finway και να παρακολουθούμε τις δαπάνες σου.","Aún no se ha definido un presupuesto mensual. Podemos establecer uno en Finway y seguir tus gastos.","Non è ancora stato definito un budget mensile. Possiamo impostare un budget in Finway e monitorare le tue spese."},
            {"Bu ay gelir-gider farkın ","This month your income-spending difference is ","Ce mois-ci, la différence entre vos revenus et dépenses est de ","В этом месяце разница между доходами и расходами составляет ","In diesem Monat beträgt die Differenz zwischen Einnahmen und Ausgaben ","今月の収入と支出の差額は","本月收入与支出的差额为","فرق دخلك وإنفاقك هذا الشهر هو ","Η διαφορά εσόδων-δαπανών σου αυτόν τον μήνα είναι ","Este mes la diferencia entre tus ingresos y gastos es de ","Questo mese la differenza tra entrate e spese è "},
            {". İstersen önce en yüksek harcama kategorini, sonra kart ve hedeflerini birlikte inceleyebiliriz.",". We can review your highest spending category first, then your cards and goals together.",". Nous pouvons d’abord examiner votre catégorie de dépenses la plus élevée, puis vos cartes et vos objectifs.",". Сначала мы можем посмотреть на самую крупную категорию расходов, затем вместе проверить карты и цели.",". Wir können zuerst deine größte Ausgabenkategorie und danach gemeinsam deine Karten und Ziele prüfen.","。まず支出の多いカテゴリを確認し、その後カードと目標を一緒に見られます。","。我们可以先查看支出最高的类别，再一起看看你的卡片和目标。",". يمكننا أولًا مراجعة أعلى فئة إنفاق لديك، ثم بطاقاتك وأهدافك معًا.",". Μπορούμε πρώτα να εξετάσουμε την κατηγορία με τη μεγαλύτερη δαπάνη και μετά τις κάρτες και τους στόχους σου μαζί.",". Primero podemos revisar tu categoría de mayor gasto y después tus tarjetas y objetivos.",". Possiamo prima controllare la categoria con la spesa più alta, poi carte e obiettivi insieme."},
            {"Hedeflerinde toplam ","Your goals have a total gap of ","Vos objectifs présentent un écart total de ","По вашим целям остаётся общий дефицит ","Bei deinen Zielen fehlen insgesamt ","目標の合計不足額は","你的目标总差额为","إجمالي العجز في أهدافك هو ","Οι στόχοι σου έχουν συνολικό υπόλοιπο ","A tus objetivos les faltan en total ","Per i tuoi obiettivi mancano in totale "},
            {" açık var. Düzenli birikimle ilerlemek için aylık sabit bir tutar belirleyebilirsin."," remaining. You can set a fixed monthly amount to make steady progress with your savings."," restants. Vous pouvez définir un montant mensuel fixe pour progresser régulièrement dans votre épargne."," остатка. Можно установить фиксированную ежемесячную сумму, чтобы регулярно продвигаться к целям.",". Du kannst einen festen monatlichen Betrag festlegen, um mit deinen Ersparnissen regelmäßig voranzukommen.","。定期的に貯蓄を進めるには、毎月一定額を設定できます。","。你可以设定每月固定金额，稳定推进储蓄目标。"," متبقية. يمكنك تحديد مبلغ شهري ثابت للتقدم بانتظام في الادخار.",". Μπορείς να ορίσεις ένα σταθερό μηνιαίο ποσό για σταθερή πρόοδο στις αποταμιεύσεις σου."," pendientes. Puedes fijar una cantidad mensual para avanzar de forma constante con tus ahorros."," rimanenti. Puoi fissare un importo mensile per avanzare con regolarità nei risparmi."},
            {"Bu ay gelir-gider farkın ","This month your income-spending difference is ","Ce mois-ci, la différence entre vos revenus et dépenses est de ","В этом месяце разница между доходами и расходами составляет ","In diesem Monat beträgt die Differenz zwischen Einnahmen und Ausgaben ","今月の収入と支出の差額は","本月收入与支出的差额为","فرق دخلك وإنفاقك هذا الشهر هو ","Η διαφορά εσόδων-δαπανών σου αυτόν τον μήνα είναι ","Este mes la diferencia entre tus ingresos y gastos es de ","Questo mese la differenza tra entrate e spese è "},
            {". İstersen önce en yüksek harcama kategorini, sonra kart ve hedeflerini birlikte inceleyebiliriz.",". We can review your highest spending category first, then your cards and goals together.",". Nous pouvons d’abord examiner votre catégorie de dépenses la plus élevée, puis vos cartes et vos objectifs.",". Сначала мы можем посмотреть на самую крупную категорию расходов, затем вместе проверить карты и цели.",". Wir können zuerst deine größte Ausgabenkategorie und danach gemeinsam deine Karten und Ziele prüfen.","。まず支出の多いカテゴリを確認し、その後カードと目標を一緒に見られます。","。我们可以先查看支出最高的类别，再一起看看你的卡片和目标。",". يمكننا أولًا مراجعة أعلى فئة إنفاق لديك، ثم بطاقاتك وأهدافك معًا.",". Μπορούμε πρώτα να εξετάσουμε την κατηγορία με τη μεγαλύτερη δαπάνη και μετά τις κάρτες και τους στόχους σου μαζί.",". Primero podemos revisar tu categoría de mayor gasto y después tus tarjetas y objetivos.",". Possiamo prima controllare la categoria con la spesa più alta, poi carte e obiettivi insieme."},
            {"Tamam. Güvenlik ayarlarını açıyorum.","Okay. I’m opening Security settings.","D’accord. J’ouvre les paramètres de sécurité.","Хорошо. Открываю настройки безопасности.","Okay. Ich öffne die Sicherheitseinstellungen.","わかりました。セキュリティ設定を開きます。","好的。正在打开安全设置。","حسنًا. سأفتح إعدادات الأمان.","Εντάξει. Ανοίγω τις ρυθμίσεις ασφαλείας.","De acuerdo. Voy a abrir los ajustes de seguridad.","Va bene. Apro le impostazioni di sicurezza."},
            {"Tamam. Ayarlar ekranını açıyorum.","Okay. I’m opening Settings.","D’accord. J’ouvre les paramètres.","Хорошо. Открываю настройки.","Okay. Ich öffne die Einstellungen.","わかりました。設定を開きます。","好的。正在打开设置。","حسنًا. سأفتح الإعدادات.","Εντάξει. Ανοίγω τις ρυθμίσεις.","De acuerdo. Voy a abrir los ajustes.","Va bene. Apro le impostazioni."},
            {". Bu ay gelirlerin ",". Your income this month is ",". Vos revenus ce mois-ci sont de ",". Ваш доход в этом месяце составляет ",". Deine Einnahmen in diesem Monat betragen ","。今月の収入は","。你本月收入为",". دخلك هذا الشهر هو ",". Τα έσοδά σου αυτόν τον μήνα είναι ",". Tus ingresos este mes son de ",". Le tue entrate questo mese sono "},
            {", giderlerin ",", your spending is ",", vos dépenses sont de ",", ваши расходы составляют ",", deine Ausgaben betragen ","、支出は","，你的支出为","، إنفاقك هو ","، οι δαπάνες σου είναι ",", tus gastos son de ",", le tue spese sono "},
            {" ve net farkın "," and your net difference is "," et votre différence nette est de "," а чистая разница составляет "," und deine Nettodifferenz beträgt ","、純差額は","，净差额为"," والفرق الصافي هو "," και η καθαρή διαφορά είναι "," y la diferencia neta es de "," e la differenza netta è "},
            {". En yüksek kategoriler:\n",". Top categories:\n",". Catégories principales :\n",". Основные категории:\n",". Top-Kategorien:\n","。主なカテゴリ：\n","。主要类别：\n",". أبرز الفئات:\n",". Κορυφαίες κατηγορίες:\n",". Principales categorías:\n",". Categorie principali:\n"},
            {"kategorisini","category","catégorie","категорию","Kategorie","カテゴリ","类别","الفئة","κατηγορία","categoría","categoria"},
            {" incelemek mantıklı olabilir."," it may be helpful to review."," il peut être utile de l’examiner."," возможно, стоит её изучить."," kann es sinnvoll sein, sie zu prüfen.","確認するとよいでしょう。","建议查看该类别。"," قد يكون من المفيد مراجعتها."," ίσως είναι χρήσιμο να την εξετάσεις."," puede ser útil revisarla."," può essere utile esaminarla."},
            {" daha yüksek. Öncelikle "," higher. First, it may help to review "," plus élevées. Il peut être utile de commencer par examiner "," выше. Сначала стоит посмотреть на "," höher. Zuerst kann es hilfreich sein, "," 高くなっています。まず","更高。首先可以查看"," أعلى. أولًا قد يكون من المفيد مراجعة "," υψηλότερα. Αρχικά ίσως βοηθήσει να εξετάσεις "," más altos. Primero puede ser útil revisar "," più alte. Prima può essere utile esaminare "},
            {"Bu ay gelir-gider farkın ","This month your income-spending difference is ","Ce mois-ci, la différence entre vos revenus et dépenses est de ","В этом месяце разница между доходами и расходами составляет ","In diesem Monat beträgt die Differenz zwischen Einnahmen und Ausgaben ","今月の収入と支出の差額は","本月收入与支出的差额为","فرق دخلك وإنفاقك هذا الشهر هو ","Η διαφορά εσόδων-δαπανών σου αυτόν τον μήνα είναι ","Este mes la diferencia entre tus ingresos y gastos es de ","Questo mese la differenza tra entrate e spese è "},
            {"Bu ay gelir-gider farkın ","This month your income-spending difference is ","Ce mois-ci, la différence entre vos revenus et dépenses est de ","В этом месяце разница между доходами и расходами составляет ","In diesem Monat beträgt die Differenz zwischen Einnahmen und Ausgaben ","今月の収入と支出の差額は","本月收入与支出的差额为","فرق دخلك وإنفاقك هذا الشهر هو ","Η διαφορά εσόδων-δαπανών σου αυτόν τον μήνα είναι ","Este mes la diferencia entre tus ingresos y gastos es de ","Questo mese la differenza tra entrate e spese è "},
            {". İstersen önce en yüksek harcama kategorini, sonra kart ve hedeflerini birlikte inceleyebiliriz.",". We can review your highest spending category first, then your cards and goals together.",". Nous pouvons d’abord examiner votre catégorie de dépenses la plus élevée, puis vos cartes et vos objectifs.",". Сначала мы можем посмотреть на самую крупную категорию расходов, затем вместе проверить карты и цели.",". Wir können zuerst deine größte Ausgabenkategorie und danach gemeinsam deine Karten und Ziele prüfen.","。まず支出の多いカテゴリを確認し、その後カードと目標を一緒に見られます。","。我们可以先查看支出最高的类别，再一起看看你的卡片和目标。",". يمكننا أولًا مراجعة أعلى فئة إنفاق لديك، ثم بطاقاتك وأهدافك معًا.",". Μπορούμε πρώτα να εξετάσουμε την κατηγορία με τη μεγαλύτερη δαπάνη και μετά τις κάρτες και τους στόχους σου μαζί.",". Primero podemos revisar tu categoría de mayor gasto y después tus tarjetas y objetivos.",". Possiamo prima controllare la categoria con la spesa più alta, poi carte e obiettivi insieme."},
            {"Hedeflerinde toplam ","Your goals have a total gap of ","Vos objectifs présentent un écart total de ","По вашим целям остаётся общий дефицит ","Bei deinen Zielen fehlen insgesamt ","目標の合計不足額は","你的目标总差额为","إجمالي العجز في أهدافك هو ","Οι στόχοι σου έχουν συνολικό υπόλοιπο ","A tus objetivos les faltan en total ","Per i tuoi obiettivi mancano in totale "},
            {" açık var. Düzenli birikimle ilerlemek için aylık sabit bir tutar belirleyebilirsin."," remaining. You can set a fixed monthly amount to make steady progress with your savings."," restants. Vous pouvez définir un montant mensuel fixe pour progresser régulièrement dans votre épargne."," остатка. Можно установить фиксированную ежемесячную сумму, чтобы регулярно продвигаться к целям.",". Du kannst einen festen monatlichen Betrag festlegen, um mit deinen Ersparnissen regelmäßig voranzukommen.","。定期的に貯蓄を進めるには、毎月一定額を設定できます。","。你可以设定每月固定金额，稳定推进储蓄目标。"," متبقية. يمكنك تحديد مبلغ شهري ثابت للتقدم بانتظام في الادخار.",". Μπορείς να ορίσεις ένα σταθερό μηνιαίο ποσό για σταθερή πρόοδο στις αποταμιεύσεις σου."," pendientes. Puedes fijar una cantidad mensual para avanzar de forma constante con tus ahorros."," rimanenti. Puoi fissare un importo mensile per avanzare con regolarità nei risparmi."},
    };

    private static final String[][] LEGACY_UI_TRANSLATIONS = new String[][]{
            {"Genel","General","Général","Общий","Allgemein","一般","常用","عام","Γενικά","General","Generale"},
            {"gün","day","jour","день","Tag","日","天","يوم","ημέρα","día","giorno"},
            {"Piyasa ayarlarını aç  ›","Open market settings  ›","Ouvrir les paramètres du marché  ›","Открыть настройки рынка  ›","Markteinstellungen öffnen  ›","市場設定を開く  ›","打开市场设置  ›","فتح إعدادات السوق  ›","Άνοιγμα ρυθμίσεων αγοράς  ›","Abrir ajustes del mercado  ›","Apri impostazioni di mercato  ›"},
            {"Piyasaları aç  ›","Open markets  ›","Ouvrir les marchés  ›","Открыть рынки  ›","Märkte öffnen  ›","市場を開く  ›","打开市场  ›","فتح الأسواق  ›","Άνοιγμα αγορών  ›","Abrir mercados  ›","Apri mercati  ›"},
            {"Kredi kartlarını aç  ›","Open credit cards  ›","Ouvrir les cartes de crédit  ›","Открыть кредитные карты  ›","Kreditkarten öffnen  ›","クレジットカードを開く  ›","打开信用卡  ›","فتح بطاقات الائتمان  ›","Άνοιγμα πιστωτικών καρτών  ›","Abrir tarjetas de crédito  ›","Apri carte di credito  ›"},
            {"Birikimleri aç  ›","Open savings  ›","Ouvrir les épargnes  ›","Открыть накопления  ›","Ersparnisse öffnen  ›","貯蓄を開く  ›","打开储蓄  ›","فتح المدخرات  ›","Άνοιγμα αποταμιεύσεων  ›","Abrir ahorros  ›","Apri risparmi  ›"},
            {"Güvenlik ayarlarını aç  ›","Open security settings  ›","Ouvrir les paramètres de sécurité  ›","Открыть настройки безопасности  ›","Sicherheitseinstellungen öffnen  ›","セキュリティ設定を開く  ›","打开安全设置  ›","فتح إعدادات الأمان  ›","Άνοιγμα ρυθμίσεων ασφαλείας  ›","Abrir ajustes de seguridad  ›","Apri impostazioni di sicurezza  ›"},
            {"Ayarları aç  ›","Open settings  ›","Ouvrir les paramètres  ›","Открыть настройки  ›","Einstellungen öffnen  ›","設定を開く  ›","打开设置  ›","فتح الإعدادات  ›","Άνοιγμα ρυθμίσεων  ›","Abrir ajustes  ›","Apri impostazioni  ›"},
            {"Kazancını kaydet","Record income","Enregistrer les revenus","Записать доход","Einnahmen erfassen","収入を記録","记录收入","سجّل الدخل","Καταγραφή εσόδων","Registrar ingresos","Registra entrate"},
            {"Harcamayı kaydet","Record expense","Enregistrer une dépense","Записать расход","Ausgabe erfassen","支出を記録","记录支出","سجّل المصروف","Καταγραφή εξόδου","Registrar gasto","Registra spesa"},
            {"Birikimini takip et","Track savings","Suivre votre épargne","Отслеживать сбережения","Ersparnisse verfolgen","貯蓄を追跡","跟踪储蓄","تتبّع مدخراتك","Παρακολούθηση αποταμιεύσεων","Seguimiento del ahorro","Monitora i risparmi"},
            {"İşlem ara...","Search transactions...","Rechercher des transactions...","Поиск операций...","Transaktionen suchen...","取引を検索...","搜索交易...","البحث في المعاملات...","Αναζήτηση συναλλαγών...","Buscar transacciones...","Cerca transazioni..."},
            {"Filtre","Filter","Filtrer","Фильтр","Filter","フィルター","筛选","تصفية","Φίλτρο","Filtro","Filtro"},
            {"Filtreye uyan işlem yok","No matching transactions","Aucune transaction correspondante","Нет подходящих операций","Keine passenden Transaktionen","一致する取引はありません","没有匹配的交易","لا توجد معاملات مطابقة","Δεν υπάρχουν αντίστοιχες συναλλαγές","No hay transacciones coincidentes","Nessuna transazione corrispondente"},
            {"Gelir","Income","Revenu","Доход","Einnahmen","収入","收入","الدخل","Έσοδα","Ingresos","Entrate"},
            {"Hesaplarım","My Accounts","Mes comptes","Мои счета","Meine Konten","マイアカウント","我的账户","حساباتي","Οι λογαριασμοί μου","Mis cuentas","I miei conti"},
            {"Banka, nakit ve diğer hesaplarını yönet","Manage bank, cash and other accounts","Gérez vos comptes bancaires, espèces et autres comptes","Управляйте банковскими, наличными и другими счетами","Verwalten Sie Bank-, Bargeld- und andere Konten","銀行・現金・その他の口座を管理","管理银行、现金和其他账户","أدر الحسابات البنكية والنقدية والحسابات الأخرى","Διαχειριστείτε τραπεζικούς, μετρητούς και άλλους λογαριασμούς","Gestiona tus cuentas bancarias, de efectivo y otras cuentas","Gestisci conti bancari, contanti e altri conti"},
            {"Güvenlik","Security","Sécurité","Безопасность","Sicherheit","セキュリティ","安全","الأمان","Ασφάλεια","Seguridad","Sicurezza"},
            {"Uygulama kilidi","App lock","Verrouillage de l’application","Блокировка приложения","App-Sperre","アプリロック","应用锁","قفل التطبيق","Κλείδωμα εφαρμογής","Bloqueo de la aplicación","Blocco app"},
            {"Finway'i PIN ile koru","Protect Finway with a PIN","Protégez Finway avec un code PIN","Защитите Finway с помощью PIN-кода","Schützen Sie Finway mit einer PIN","PINでFinwayを保護","使用PIN保护Finway","احمِ Finway برمز PIN","Προστατέψτε το Finway με PIN","Protege Finway con un PIN","Proteggi Finway con un PIN"},
            {"Biyometrik giriş","Biometric login","Connexion biométrique","Биометрический вход","Biometrische Anmeldung","生体認証ログイン","生物识别登录","تسجيل الدخول البيومتري","Βιομετρική σύνδεση","Inicio de sesión biométrico","Accesso biometrico"},
            {"Parmak izi veya biyometrik doğrulama ile aç","Unlock with fingerprint or biometric authentication","Déverrouillez avec votre empreinte ou une authentification biométrique","Разблокируйте с помощью отпечатка пальца или биометрии","Mit Fingerabdruck oder biometrischer Authentifizierung entsperren","指紋または生体認証でロック解除","使用指纹或生物识别解锁","إلغاء القفل ببصمة الإصبع أو المصادقة البيومترية","Ξεκλειδώστε με δακτυλικό αποτύπωμα ή βιομετρική ταυτοποίηση","Desbloquea con huella dactilar o autenticación biométrica","Sblocca con impronta digitale o autenticazione biometrica"},
            {"Cihazda kullanılabilir bir biyometrik doğrulama bulunamadı.","No usable biometric authentication is available on this device.","Aucune authentification biométrique utilisable n’est disponible sur cet appareil.","На этом устройстве нет доступной биометрической аутентификации.","Auf diesem Gerät ist keine nutzbare biometrische Authentifizierung verfügbar.","このデバイスでは利用可能な生体認証がありません。","此设备没有可用的生物识别认证。","لا تتوفر مصادقة بيومترية قابلة للاستخدام على هذا الجهاز.","Δεν υπάρχει διαθέσιμη βιομετρική ταυτοποίηση σε αυτήν τη συσκευή.","No hay autenticación biométrica utilizable disponible en este dispositivo.","Su questo dispositivo non è disponibile alcuna autenticazione biometrica utilizzabile."},
            {"Biyometrik ayarı değiştirilemedi. PIN ile devam edebilirsiniz.","Biometric setting could not be changed. You can continue with your PIN.","Impossible de modifier le réglage biométrique. Vous pouvez continuer avec votre code PIN.","Не удалось изменить настройку биометрии. Вы можете продолжить с PIN-кодом.","Die biometrische Einstellung konnte nicht geändert werden. Sie können mit Ihrer PIN fortfahren.","生体認証設定を変更できませんでした。PINで続行できます。","无法更改生物识别设置。您可以使用PIN继续。","تعذر تغيير إعداد المصادقة البيومترية. يمكنك المتابعة باستخدام رمز PIN.","Δεν ήταν δυνατή η αλλαγή της ρύθμισης βιομετρικής ταυτοποίησης. Μπορείτε να συνεχίσετε με το PIN σας.","No se pudo cambiar la configuración biométrica. Puedes continuar con tu PIN.","Non è stato possibile modificare l’impostazione biometrica. Puoi continuare con il PIN."},
            {"Finway Akıllı Bildirimler","Finway Smart Notifications","Notifications intelligentes Finway","Умные уведомления Finway","Intelligente Finway-Benachrichtigungen","Finwayスマート通知","Finway智能通知","إشعارات Finway الذكية","Έξυπνες ειδοποιήσεις Finway","Notificaciones inteligentes de Finway","Notifiche intelligenti Finway"},
            {"Tümünü okundu yap","Mark all read","Tout marquer comme lu","Отметить всё как прочитанное","Alle als gelesen markieren","すべて既読にする","全部标为已读","وضع علامة مقروء على الكل","Σήμανση όλων ως αναγνωσμένων","Marcar todo como leído","Segna tutto come letto"},
            {"Kapat","Close","Fermer","Закрыть","Schließen","閉じる","关闭","إغلاق","Κλείσιμο","Cerrar","Chiudi"},
            {"yeni bildirim","new notifications","nouvelles notifications","новых уведомлений","neue Benachrichtigungen","新しい通知","新通知","إشعارات جديدة","νέες ειδοποιήσεις","nuevas notificaciones","nuove notifiche"},
            {"Bildirimlerin güncel","Notifications are up to date","Vos notifications sont à jour","Уведомления актуальны","Ihre Benachrichtigungen sind aktuell","通知は最新です","通知已是最新","إشعاراتك محدثة","Οι ειδοποιήσεις σας είναι ενημερωμένες","Tus notificaciones están al día","Le notifiche sono aggiornate"},
            {"Önemli gelişmeleri burada göreceksin","Important updates will appear here","Les mises à jour importantes apparaîtront ici","Здесь будут появляться важные обновления","Wichtige Aktualisierungen werden hier angezeigt","重要な更新はここに表示されます","重要更新会显示在这里","ستظهر التحديثات المهمة هنا","Σημαντικές ενημερώσεις θα εμφανίζονται εδώ","Las actualizaciones importantes aparecerán aquí","Gli aggiornamenti importanti appariranno qui"},
            {"Bugün","Today","Aujourd’hui","Сегодня","Heute","今日","今天","اليوم","Σήμερα","Hoy","Oggi"},
            {"Dün","Yesterday","Hier","Вчера","Gestern","昨日","昨天","أمس","Χθες","Ayer","Ieri"},
            {"Kartları aç  ›","Open cards  ›","Ouvrir les cartes  ›","Открыть карты  ›","Karten öffnen  ›","カードを開く  ›","打开卡片  ›","فتح البطاقات  ›","Άνοιγμα καρτών  ›","Abrir tarjetas  ›","Apri carte  ›"},
            {"İşlemleri aç  ›","Open transactions  ›","Ouvrir les transactions  ›","Открыть операции  ›","Transaktionen öffnen  ›","取引を開く  ›","打开交易  ›","فتح المعاملات  ›","Άνοιγμα συναλλαγών  ›","Abrir transacciones  ›","Apri transazioni  ›"},
            {"Hedefleri aç  ›","Open goals  ›","Ouvrir les objectifs  ›","Открыть цели  ›","Ziele öffnen  ›","目標を開く  ›","打开目标  ›","فتح الأهداف  ›","Άνοιγμα στόχων  ›","Abrir objetivos  ›","Apri obiettivi  ›"},
            {"Hesapları aç  ›","Open accounts  ›","Ouvrir les comptes  ›","Открыть счета  ›","Konten öffnen  ›","口座を開く  ›","打开账户  ›","فتح الحسابات  ›","Άνοιγμα λογαριασμών  ›","Abrir cuentas  ›","Apri conti  ›"},
            {"Finbi ile konuş  ›","Talk to Finbi  ›","Parler à Finbi  ›","Поговорить с Finbi  ›","Mit Finbi sprechen  ›","Finbiと話す  ›","与Finbi对话  ›","تحدث مع Finbi  ›","Συνομιλία με το Finbi  ›","Habla con Finbi  ›","Parla con Finbi  ›"},
            {"Sürüm: ","Version: ","Version : ","Версия: ","Version: ","バージョン: ","版本：","الإصدار: ","Έκδοση: ","Versión: ","Versione: "},
            {"Yapı: ","Build: ","Build : ","Сборка: ","Build: ","ビルド: ","构建：","البنية: ","Build: ","Compilación: ","Build: "},
            {"Bakiyenin işlendiği hesap","Account used for this transaction","Compte utilisé pour cette transaction","Счёт, используемый для этой операции","Für diese Transaktion verwendetes Konto","この取引に使用する口座","此交易使用的账户","الحساب المستخدم لهذه المعاملة","Λογαριασμός που χρησιμοποιείται για αυτήν τη συναλλαγή","Cuenta utilizada para esta transacción","Conto utilizzato per questa transazione"},
            {"Hesap seç","Select account","Sélectionner un compte","Выберите счёт","Konto auswählen","口座を選択","选择账户","اختر حسابًا","Επιλέξτε λογαριασμό","Selecciona una cuenta","Seleziona conto"},
            {"Bu işlem hangi hesaba işlensin?","Which account should receive this transaction?","À quel compte cette transaction doit-elle être associée ?","На какой счёт следует отнести эту операцию?","Welchem Konto soll diese Transaktion zugeordnet werden?","この取引をどの口座に登録しますか？","这笔交易应记入哪个账户？","إلى أي حساب يجب تسجيل هذه المعاملة؟","Σε ποιον λογαριασμό πρέπει να καταχωρηθεί αυτή η συναλλαγή;","¿A qué cuenta debe asignarse esta transacción?","Su quale conto deve essere registrata questa transazione?"},
            {"Vazgeç","Cancel","Annuler","Отмена","Abbrechen","キャンセル","取消","إلغاء","Ακύρωση","Cancelar","Annulla"},
            {"Hesap","Account","Compte","Счёт","Konto","口座","账户","حساب","Λογαριασμός","Cuenta","Conto"},
            {"Gelir özeti","Income summary","Résumé des revenus","Сводка доходов","Einnahmenübersicht","収入概要","收入摘要","ملخص الدخل","Σύνοψη εσόδων","Resumen de ingresos","Riepilogo entrate"},
            {"Bu gelir seçtiğin hesaba işlenecek ve bakiyeyi artıracak.","This income will be added to the selected account and increase its balance.","Ce revenu sera ajouté au compte sélectionné et augmentera son solde.","Этот доход будет добавлен на выбранный счёт и увеличит его баланс.","Diese Einnahme wird dem ausgewählten Konto gutgeschrieben und erhöht dessen Saldo.","この収入は選択した口座に追加され、残高が増えます。","这笔收入将添加到所选账户并增加其余额。","سيُضاف هذا الدخل إلى الحساب المحدد ويزيد رصيده.","Αυτό το έσοδο θα προστεθεί στον επιλεγμένο λογαριασμό και θα αυξήσει το υπόλοιπό του.","Este ingreso se añadirá a la cuenta seleccionada y aumentará su saldo.","Questa entrata verrà aggiunta al conto selezionato e ne aumenterà il saldo."},
            {"Yeni PIN belirle","Set a new PIN","Définir un nouveau code PIN","Установить новый PIN-код","Neue PIN festlegen","新しいPINを設定","设置新PIN","تعيين رمز PIN جديد","Ορισμός νέου PIN","Establecer un PIN nuevo","Imposta un nuovo PIN"},
            {"Finway'i güvene al","Secure Finway","Sécuriser Finway","Защитить Finway","Finway sichern","Finwayを保護","保护Finway","تأمين Finway","Ασφαλίστε το Finway","Proteger Finway","Metti in sicurezza Finway"},
            {"Cihaz doğrulaman tamamlandı. Yeni 6 haneli PIN'ini belirle.","Device verification complete. Create your new 6-digit PIN.","La vérification de l’appareil est terminée. Créez votre nouveau code PIN à 6 chiffres.","Проверка устройства завершена. Создайте новый 6-значный PIN-код.","Geräteüberprüfung abgeschlossen. Erstellen Sie Ihre neue 6-stellige PIN.","デバイスの確認が完了しました。新しい6桁のPINを設定してください。","设备验证完成。请创建新的6位PIN。","اكتمل التحقق من الجهاز. أنشئ رمز PIN جديدًا من 6 أرقام.","Η επαλήθευση της συσκευής ολοκληρώθηκε. Δημιουργήστε το νέο 6ψήφιο PIN σας.","Verificación del dispositivo completada. Crea tu nuevo PIN de 6 dígitos.","Verifica del dispositivo completata. Crea il tuo nuovo PIN di 6 cifre."},
            {"Finway'i açarken kullanacağın 6 haneli PIN'i belirle.","Create the 6-digit PIN you will use to unlock Finway.","Créez le code PIN à 6 chiffres que vous utiliserez pour déverrouiller Finway.","Создайте 6-значный PIN-код для разблокировки Finway.","Erstellen Sie die 6-stellige PIN, mit der Sie Finway entsperren.","Finwayのロック解除に使用する6桁のPINを設定してください。","创建用于解锁Finway的6位PIN。","أنشئ رمز PIN من 6 أرقام ستستخدمه لفتح Finway.","Δημιουργήστε το 6ψήφιο PIN που θα χρησιμοποιείτε για να ξεκλειδώνετε το Finway.","Crea el PIN de 6 dígitos que usarás para desbloquear Finway.","Crea il PIN di 6 cifre che userai per sbloccare Finway."},
            {"Yeni PIN","New PIN","Nouveau code PIN","Новый PIN-код","Neue PIN","新しいPIN","新PIN","رمز PIN جديد","Νέο PIN","PIN nuevo","Nuovo PIN"},
            {"PIN'i tekrar gir","Confirm PIN","Confirmer le code PIN","Подтвердите PIN-код","PIN bestätigen","PINを確認","确认PIN","تأكيد رمز PIN","Επιβεβαίωση PIN","Confirmar PIN","Conferma PIN"},
            {"PIN'i güncelle","Update PIN","Mettre à jour le code PIN","Обновить PIN-код","PIN aktualisieren","PINを更新","更新PIN","تحديث رمز PIN","Ενημέρωση PIN","Actualizar PIN","Aggiorna PIN"},
            {"PIN'i kaydet","Save PIN","Enregistrer le code PIN","Сохранить PIN-код","PIN speichern","PINを保存","保存PIN","حفظ رمز PIN","Αποθήκευση PIN","Guardar PIN","Salva PIN"},
            {"PIN düz metin olarak saklanmaz; yalnızca güvenli bir doğrulayıcı tutulur.","Your PIN is not stored as plain text; only a secure verifier is kept.","Votre code PIN n’est pas stocké en clair ; seul un vérificateur sécurisé est conservé.","PIN не хранится в открытом виде; сохраняется только защищённый проверочный код.","Ihre PIN wird nicht im Klartext gespeichert; nur ein sicherer Prüfer wird aufbewahrt.","PINは平文で保存されず、安全な検証情報のみが保持されます。","PIN不会以明文存储，只会保留安全的验证信息。","لا يتم تخزين رمز PIN كنص صريح، بل يتم الاحتفاظ بآلية تحقق آمنة فقط.","Το PIN σας δεν αποθηκεύεται ως απλό κείμενο· διατηρείται μόνο ασφαλής επαληθευτής.","Tu PIN no se almacena en texto plano; solo se conserva un verificador seguro.","Il PIN non viene memorizzato in testo semplice; viene conservato solo un verificatore sicuro."},
            {"6 hane gir","Enter 6 digits","Saisissez 6 chiffres","Введите 6 цифр","6 Ziffern eingeben","6桁を入力","输入6位数字","أدخل 6 أرقام","Εισαγάγετε 6 ψηφία","Introduce 6 dígitos","Inserisci 6 cifre"},
            {"PIN'ler eşleşmiyor","PINs do not match","Les codes PIN ne correspondent pas","PIN-коды не совпадают","PINs stimmen nicht überein","PINが一致しません","PIN不匹配","رموز PIN غير متطابقة","Τα PIN δεν ταιριάζουν","Los PIN no coinciden","I PIN non corrispondono"},
            {"Kilidi kapat","Disable lock","Désactiver le verrouillage","Отключить блокировку","Sperre deaktivieren","ロックを無効にする","禁用锁定","تعطيل القفل","Απενεργοποίηση κλειδώματος","Desactivar bloqueo","Disabilita blocco"},
            {"Güvenlik için mevcut 6 haneli PIN'ini gir.","Enter your current 6-digit PIN for security.","Saisissez votre code PIN actuel à 6 chiffres pour des raisons de sécurité.","Введите текущий 6-значный PIN-код для безопасности.","Geben Sie aus Sicherheitsgründen Ihre aktuelle 6-stellige PIN ein.","セキュリティのため現在の6桁のPINを入力してください。","出于安全考虑，请输入当前6位PIN。","أدخل رمز PIN الحالي المكون من 6 أرقام لأغراض الأمان.","Για ασφάλεια, εισαγάγετε το τρέχον 6ψήφιο PIN σας.","Introduce tu PIN actual de 6 dígitos por seguridad.","Inserisci il PIN attuale di 6 cifre per motivi di sicurezza."},
            {"Mevcut PIN","Current PIN","Code PIN actuel","Текущий PIN","Aktuelle PIN","現在のPIN","当前PIN","رمز PIN الحالي","Τρέχον PIN","PIN actual","PIN attuale"},
            {"PIN hatalı","Wrong PIN","Code PIN incorrect","Неверный PIN","Falsche PIN","PINが正しくありません","PIN错误","رمز PIN غير صحيح","Λανθασμένο PIN","PIN incorrecto","PIN errato"},
            {"Finway'e Hoşgeldiniz","Welcome to Finway","Bienvenue sur Finway","Добро пожаловать в Finway","Willkommen bei Finway","Finwayへようこそ","欢迎使用Finway","مرحبًا بك في Finway","Καλώς ήρθατε στο Finway","Bienvenido a Finway","Benvenuto in Finway"},
            {"Finansal bilgileriniz güvende.","Your financial information is protected.","Vos informations financières sont protégées.","Ваша финансовая информация защищена.","Ihre Finanzinformationen sind geschützt.","財務情報は保護されています。","您的财务信息受到保护。","معلوماتك المالية محمية.","Τα οικονομικά σας στοιχεία προστατεύονται.","Tu información financiera está protegida.","Le tue informazioni finanziarie sono protette."},
            {"PIN'ini gir","Enter your PIN","Saisissez votre code PIN","Введите PIN-код","PIN eingeben","PINを入力","输入PIN","أدخل رمز PIN","Εισαγάγετε το PIN σας","Introduce tu PIN","Inserisci il PIN"},
            {"6 haneli PIN'inizi girin","Enter your 6-digit PIN","Saisissez votre code PIN à 6 chiffres","Введите ваш 6-значный PIN","Geben Sie Ihre 6-stellige PIN ein","6桁のPINを入力してください","输入您的6位PIN","أدخل رمز PIN المكون من 6 أرقام","Εισαγάγετε το 6ψήφιο PIN σας","Introduce tu PIN de 6 dígitos","Inserisci il tuo PIN di 6 cifre"},
            {"Biyometrik ile hızlı giriş","Quick biometric sign-in","Connexion biométrique rapide","Быстрый вход с биометрией","Schnelle biometrische Anmeldung","生体認証ですばやくログイン","快速生物识别登录","تسجيل دخول بيومتري سريع","Γρήγορη βιομετρική σύνδεση","Inicio rápido con biometría","Accesso rapido biometrico"},
            {"Parmak izi veya yüz tanıma ile giriş yapın","Sign in with fingerprint or face recognition","Connectez-vous avec votre empreinte ou la reconnaissance faciale","Войдите с помощью отпечатка пальца или распознавания лица","Mit Fingerabdruck oder Gesichtserkennung anmelden","指紋または顔認証でログイン","使用指纹或面部识别登录","سجّل الدخول ببصمة الإصبع أو التعرف على الوجه","Συνδεθείτε με δακτυλικό αποτύπωμα ή αναγνώριση προσώπου","Inicia sesión con huella dactilar o reconocimiento facial","Accedi con impronta digitale o riconoscimento facciale"},
            {"Güvenli giriş","Secure sign-in","Connexion sécurisée","Безопасный вход","Sichere Anmeldung","安全なサインイン","安全登录","تسجيل دخول آمن","Ασφαλής σύνδεση","Inicio de sesión seguro","Accesso sicuro"},
            {"🔒  PIN'i Unuttum","🔒  Forgot PIN","🔒  Code PIN oublié","🔒  Забыли PIN?","🔒  PIN vergessen","🔒  PINを忘れた","🔒  忘记PIN","🔒  نسيت رمز PIN","🔒  Ξέχασα το PIN","🔒  Olvidé el PIN","🔒  PIN dimenticato"},
            {"❔  Yardım Merkezi","❔  Help Center","❔  Centre d’aide","❔  Центр помощи","❔  Hilfezentrum","❔  ヘルプセンター","❔  帮助中心","❔  مركز المساعدة","❔  Κέντρο βοήθειας","❔  Centro de ayuda","❔  Centro assistenza"},
            {"Giriş Yap   →","Sign in   →","Se connecter   →","Войти   →","Anmelden   →","ログイン   →","登录   →","تسجيل الدخول   →","Σύνδεση   →","Iniciar sesión   →","Accedi   →"},
            {"Yardım Merkezi","Help Center","Centre d’aide","Центр помощи","Hilfezentrum","ヘルプセンター","帮助中心","مركز المساعدة","Κέντρο βοήθειας","Centro de ayuda","Centro assistenza"},
            {"Finway kilidini PIN'inizle açabilirsiniz. Biyometrik giriş etkinse parmak izi veya yüz tanıma ile daha hızlı giriş yapabilirsiniz. PIN'inizi unuttuysanız cihazınızın ekran kilidiyle güvenli sıfırlama başlatabilirsiniz.","Unlock Finway with your PIN. If biometric sign-in is enabled, you can use fingerprint or face recognition. If you forgot your PIN, you can securely reset it using your device screen lock.","Déverrouillez Finway avec votre code PIN. Si la connexion biométrique est activée, vous pouvez utiliser votre empreinte ou la reconnaissance faciale. Si vous avez oublié votre PIN, vous pouvez lancer une réinitialisation sécurisée avec le verrouillage de votre appareil.","Разблокируйте Finway с помощью PIN-кода. Если включён биометрический вход, используйте отпечаток пальца или распознавание лица. Если вы забыли PIN, запустите безопасный сброс с помощью блокировки устройства.","Entsperren Sie Finway mit Ihrer PIN. Wenn die biometrische Anmeldung aktiviert ist, können Sie Fingerabdruck oder Gesichtserkennung verwenden. Wenn Sie Ihre PIN vergessen haben, können Sie sie sicher über die Gerätesperre zurücksetzen.","PINでFinwayのロックを解除できます。生体認証が有効なら指紋または顔認証を使えます。PINを忘れた場合は、デバイスの画面ロックを使って安全にリセットできます。","使用PIN解锁Finway。如果启用了生物识别登录，可以使用指纹或面部识别。如果忘记PIN，可以通过设备锁屏安全地重置。","يمكنك فتح قفل Finway باستخدام رمز PIN. إذا تم تمكين تسجيل الدخول البيومتري، يمكنك استخدام بصمة الإصبع أو التعرف على الوجه. إذا نسيت رمز PIN، يمكنك بدء إعادة تعيين آمنة باستخدام قفل شاشة جهازك.","Ξεκλειδώστε το Finway με το PIN σας. Αν είναι ενεργή η βιομετρική σύνδεση, μπορείτε να χρησιμοποιήσετε δακτυλικό αποτύπωμα ή αναγνώριση προσώπου. Αν ξεχάσατε το PIN, μπορείτε να ξεκινήσετε ασφαλή επαναφορά με το κλείδωμα της συσκευής σας.","Desbloquea Finway con tu PIN. Si el acceso biométrico está activado, puedes usar huella dactilar o reconocimiento facial. Si olvidaste el PIN, puedes iniciar un restablecimiento seguro con el bloqueo de pantalla del dispositivo.","Sblocca Finway con il PIN. Se l'accesso biometrico è attivo, puoi usare impronta digitale o riconoscimento facciale. Se hai dimenticato il PIN, puoi avviare un ripristino sicuro usando il blocco del dispositivo."},
            {"Tamam","Done","OK","Готово","Fertig","完了","完成","تم","Τέλος","Listo","Fine"},
            {"Finway PIN sıfırlama","Finway PIN reset","Réinitialisation du PIN Finway","Сброс PIN-кода Finway","Finway-PIN zurücksetzen","Finway PINのリセット","重置Finway PIN","إعادة تعيين رمز PIN في Finway","Επαναφορά PIN Finway","Restablecimiento del PIN de Finway","Reimpostazione PIN Finway"},
            {"Yeni PIN oluşturmak için cihaz kilidini doğrula.","Verify your device lock to create a new PIN.","Vérifiez le verrouillage de votre appareil pour créer un nouveau PIN.","Подтвердите блокировку устройства, чтобы создать новый PIN.","Bestätigen Sie die Gerätesperre, um eine neue PIN zu erstellen.","新しいPINを作成するにはデバイスのロックを確認してください。","验证设备锁以创建新的PIN。","تحقق من قفل جهازك لإنشاء رمز PIN جديد.","Επαληθεύστε το κλείδωμα της συσκευής σας για να δημιουργήσετε νέο PIN.","Verifica el bloqueo de tu dispositivo para crear un nuevo PIN.","Verifica il blocco del dispositivo per creare un nuovo PIN."},
            {"PIN sıfırlanamıyor","PIN reset unavailable","Réinitialisation du PIN indisponible","Сброс PIN недоступен","PIN-Zurücksetzung nicht verfügbar","PINをリセットできません","PIN重置不可用","إعادة تعيين PIN غير متاحة","Η επαναφορά PIN δεν είναι διαθέσιμη","Restablecimiento del PIN no disponible","Ripristino PIN non disponibile"},
            {"Güvenli bir sıfırlama için telefonunda ekran kilidi (PIN, desen veya şifre) bulunması gerekiyor.","A secure reset requires a device screen lock (PIN, pattern or password).","Une réinitialisation sécurisée nécessite un verrouillage d’écran sur l’appareil (PIN, schéma ou mot de passe).","Для безопасного сброса требуется блокировка экрана устройства (PIN, рисунок или пароль).","Für eine sichere Zurücksetzung ist eine Gerätesperre (PIN, Muster oder Passwort) erforderlich.","安全にリセットするには、デバイスに画面ロック（PIN、パターン、パスワード）が必要です。","安全重置需要设备屏幕锁定（PIN、图案或密码）。","تتطلب إعادة التعيين الآمنة وجود قفل شاشة على الجهاز (PIN أو نمط أو كلمة مرور).","Για ασφαλή επαναφορά απαιτείται κλείδωμα οθόνης στη συσκευή (PIN, μοτίβο ή κωδικός πρόσβασης).","Para un restablecimiento seguro se necesita un bloqueo de pantalla del dispositivo (PIN, patrón o contraseña).","Per un ripristino sicuro è necessario un blocco schermo del dispositivo (PIN, sequenza o password)."},
            {"Kayıtlı biyometrik doğrulama bulunamadı. PIN ile giriş yapabilirsiniz.","No enrolled biometric authentication is available. You can use your PIN.","Aucune authentification biométrique enregistrée n’est disponible. Vous pouvez utiliser votre code PIN.","Зарегистрированная биометрическая аутентификация недоступна. Вы можете использовать PIN.","Es ist keine registrierte biometrische Authentifizierung verfügbar. Sie können Ihre PIN verwenden.","登録済みの生体認証は利用できません。PINを使用できます。","没有已注册的生物识别认证。您可以使用PIN。","لا تتوفر مصادقة بيومترية مسجلة. يمكنك استخدام رمز PIN.","Δεν υπάρχει καταχωρημένη βιομετρική ταυτοποίηση. Μπορείτε να χρησιμοποιήσετε το PIN σας.","No hay autenticación biométrica registrada disponible. Puedes usar tu PIN.","Non è disponibile alcuna autenticazione biometrica registrata. Puoi usare il PIN."},
            {"Biyometrik doğrulama başarısız","Biometric authentication failed","Échec de l’authentification biométrique","Биометрическая аутентификация не удалась","Biometrische Authentifizierung fehlgeschlagen","生体認証に失敗しました","生物识别认证失败","فشلت المصادقة البيومترية","Η βιομετρική ταυτοποίηση απέτυχε","La autenticación biométrica ha fallado","Autenticazione biometrica non riuscita"},
            {"Finway ile güvenli giriş","Secure sign-in to Finway","Connexion sécurisée à Finway","Безопасный вход в Finway","Sichere Anmeldung bei Finway","Finwayへの安全なサインイン","安全登录Finway","تسجيل دخول آمن إلى Finway","Ασφαλής σύνδεση στο Finway","Inicio de sesión seguro en Finway","Accesso sicuro a Finway"},
            {"Biyometrik doğrulama","Biometric authentication","Authentification biométrique","Биометрическая аутентификация","Biometrische Authentifizierung","生体認証","生物识别认证","المصادقة البيومترية","Βιομετρική ταυτοποίηση","Autenticación biométrica","Autenticazione biometrica"},
            {"Finway hesabınızı açmak için biyometrinizi doğrulayın.","Verify your biometric to unlock Finway.","Vérifiez votre identité biométrique pour déverrouiller Finway.","Подтвердите биометрию, чтобы разблокировать Finway.","Bestätigen Sie Ihre biometrischen Daten, um Finway zu entsperren.","生体認証を確認してFinwayのロックを解除してください。","验证您的生物识别信息以解锁Finway。","تحقق من هويتك البيومترية لفتح قفل Finway.","Επαληθεύστε τη βιομετρική σας ταυτότητα για να ξεκλειδώσετε το Finway.","Verifica tu biometría para desbloquear Finway.","Verifica i tuoi dati biometrici per sbloccare Finway."},
            {"PIN ile giriş","Use PIN instead","Utiliser le code PIN","Использовать PIN","PIN verwenden","PINを使用","改用PIN","استخدم PIN بدلاً من ذلك","Χρήση PIN","Usar PIN","Usa PIN"},
            {"Biyometrik giriş şu anda kullanılamıyor. PIN ile giriş yapabilirsiniz.","Biometric sign-in is currently unavailable. You can use your PIN.","La connexion biométrique est indisponible pour le moment. Vous pouvez utiliser votre code PIN.","Биометрический вход сейчас недоступен. Вы можете использовать PIN.","Die biometrische Anmeldung ist derzeit nicht verfügbar. Sie können Ihre PIN verwenden.","現在、生体認証でのログインは利用できません。PINを使用できます。","当前无法使用生物识别登录。您可以使用PIN。","تسجيل الدخول البيومتري غير متاح حاليًا. يمكنك استخدام رمز PIN.","Η βιομετρική σύνδεση δεν είναι διαθέσιμη αυτήν τη στιγμή. Μπορείτε να χρησιμοποιήσετε το PIN σας.","El inicio de sesión biométrico no está disponible. Puedes usar tu PIN.","L'accesso biometrico non è attualmente disponibile. Puoi usare il PIN."},
            {"Paranı nerede tuttuğunu yönet","Manage where you keep your money","Gérez où vous conservez votre argent","Управляйте местами хранения денег","Verwalten Sie, wo Sie Ihr Geld aufbewahren","お金を保管する口座を管理","管理资金存放位置","أدر أماكن الاحتفاظ بأموالك","Διαχειριστείτε πού κρατάτε τα χρήματά σας","Gestiona dónde guardas tu dinero","Gestisci dove tieni il denaro"},
            {"Banka, nakit ve diğer hesaplarını tek yerde takip et.","Track bank, cash and other accounts in one place.","Suivez vos comptes bancaires, espèces et autres comptes au même endroit.","Отслеживайте банковские, наличные и другие счета в одном месте.","Behalten Sie Bank-, Bargeld- und andere Konten an einem Ort im Blick.","銀行・現金・その他の口座を1か所で管理できます。","在一个地方跟踪银行、现金和其他账户。","تتبّع حساباتك البنكية والنقدية وغيرها في مكان واحد.","Παρακολουθήστε τραπεζικούς, μετρητούς και άλλους λογαριασμούς σε ένα μέρος.","Controla tus cuentas bancarias, efectivo y otras en un solo lugar.","Tieni sotto controllo conti bancari, contanti e altri conti in un unico posto."},
            {"Hesap Ekle","Add Account","Ajouter un compte","Добавить счёт","Konto hinzufügen","口座を追加","添加账户","إضافة حساب","Προσθήκη λογαριασμού","Añadir cuenta","Aggiungi conto"},
            {"Toplam hesap bakiyesi","Total account balance","Solde total des comptes","Общий баланс счетов","Gesamtsaldo der Konten","口座合計残高","账户总余额","إجمالي رصيد الحسابات","Συνολικό υπόλοιπο λογαριασμών","Saldo total de las cuentas","Saldo totale dei conti"},
            {"Hesabı Düzenle","Edit Account","Modifier le compte","Редактировать счёт","Konto bearbeiten","口座を編集","编辑账户","تعديل الحساب","Επεξεργασία λογαριασμού","Editar cuenta","Modifica conto"},
            {"Hesap adı","Account name","Nom du compte","Название счёта","Kontoname","口座名","账户名称","اسم الحساب","Όνομα λογαριασμού","Nombre de la cuenta","Nome del conto"},
            {"Kaydet","Save","Enregistrer","Сохранить","Speichern","保存","保存","حفظ","Αποθήκευση","Guardar","Salva"},
            {"Hesabı Sil","Delete Account","Supprimer le compte","Удалить счёт","Konto löschen","口座を削除","删除账户","حذف الحساب","Διαγραφή λογαριασμού","Eliminar cuenta","Elimina conto"},
            {"İşlem Filtresi","Transaction Filter","Filtre des transactions","Фильтр операций","Transaktionsfilter","取引フィルター","交易筛选","تصفية المعاملات","Φίλτρο συναλλαγών","Filtro de transacciones","Filtro transazioni"},
            {"Tür","Type","Type","Тип","Typ","種類","类型","النوع","Τύπος","Tipo","Tipo"},
            {"Tümü","All","Tous","Все","Alle","すべて","全部","الكل","Όλα","Todos","Tutti"},
            {"Harcama","Expense","Dépense","Расход","Ausgabe","支出","支出","المصروف","Έξοδο","Gasto","Spesa"},
            {"Kategori","Category","Catégorie","Категория","Kategorie","カテゴリー","类别","الفئة","Κατηγορία","Categoría","Categoria"},
            {"Tüm kategoriler","All categories","Toutes les catégories","Все категории","Alle Kategorien","すべてのカテゴリー","所有类别","كل الفئات","Όλες οι κατηγορίες","Todas las categorías","Tutte le categorie"},
        {"Taksit ödemesi","Installment payment","Paiement de mensualité","Платёж по рассрочке","Ratenzahlung","分割払い","分期付款","دفعة تقسيط","Πληρωμή δόσης","Pago de cuota","Pagamento rata"},
        {"Kart ödemesi","Card payment","Paiement de carte","Платёж по карте","Kartenzahlung","カード支払い","卡片付款","دفعة البطاقة","Πληρωμή κάρτας","Pago con tarjeta","Pagamento carta"},
        {"Taksiti Öde","Pay installment","Payer la mensualité","Оплатить рассрочку","Rate zahlen","分割払いを支払う","支付分期款","دفع القسط","Πληρωμή δόσης","Pagar cuota","Paga rata"},
        {"✓ Tamamlandı","✓ Completed","✓ Terminé","✓ Выполнено","✓ Abgeschlossen","✓ 完了","✓ 已完成","✓ مكتمل","✓ Ολοκληρώθηκε","✓ Completado","✓ Completato"},
        {"Ekstre kesim günü","Statement closing day","Jour de clôture du relevé","День закрытия выписки","Abrechnungsstichtag","明細締め日","账单结算日","يوم إغلاق كشف الحساب","Ημέρα έκδοσης κίνησης","Día de cierre del extracto","Giorno di chiusura dell’estratto"},
        {"Son ödeme günü","Payment due day","Jour d’échéance","День платежа","Fälligkeitstag","支払期限日","付款到期日","يوم استحقاق الدفع","Ημέρα πληρωμής","Día de vencimiento","Giorno di scadenza"},
        {"Bu planı kart borcuna ekle","Add this plan to card debt","Ajouter ce plan à la dette de la carte","Добавить этот план к долгу по карте","Diesen Plan zur Kartenschuld hinzufügen","このプランをカード残高に追加","将此计划计入卡片欠款","إضافة هذه الخطة إلى دين البطاقة","Προσθήκη αυτού του προγράμματος στο χρέος της κάρτας","Añadir este plan a la deuda de la tarjeta","Aggiungi questo piano al debito della carta"},
        {"Yeni bir taksit planı oluşturuyorsan açık bırak. Mevcut bir planı sadece takip etmek için kapat.","Leave enabled when creating a new installment plan. Turn it off to track an existing plan only.","Laissez activé lors de la création d’un nouveau plan de mensualités. Désactivez-le pour suivre uniquement un plan existant.","Оставьте включённым при создании нового плана рассрочки. Отключите, чтобы только отслеживать существующий план.","Beim Erstellen eines neuen Ratenplans aktiviert lassen. Zum reinen Verfolgen eines bestehenden Plans deaktivieren.","新しい分割払いプランを作成するときはオンのままにします。既存のプランを追跡するだけならオフにします。","创建新的分期计划时保持开启。仅跟踪现有计划时将其关闭。","اتركه مفعّلًا عند إنشاء خطة تقسيط جديدة. عطّله لمتابعة خطة موجودة فقط.","Αφήστε το ενεργό όταν δημιουργείτε νέο πρόγραμμα δόσεων. Απενεργοποιήστε το για απλή παρακολούθηση υπάρχοντος προγράμματος.","Déjalo activado al crear un nuevo plan de cuotas. Desactívalo para seguir solo un plan existente.","Lascialo attivo quando crei un nuovo piano rateale. Disattivalo per seguire solo un piano esistente."},
        {"Ödeme planını görüntüle","View payment plan","Voir le plan de paiement","Просмотреть план платежей","Zahlungsplan anzeigen","支払いプランを表示","查看付款计划","عرض خطة الدفع","Προβολή προγράμματος πληρωμών","Ver plan de pagos","Visualizza piano di pagamento"},
        {"Planı düzenle","Edit plan","Modifier le plan","Изменить план","Plan bearbeiten","プランを編集","编辑计划","تعديل الخطة","Επεξεργασία προγράμματος","Editar plan","Modifica piano"},
        {"Planı kaldır","Remove plan","Supprimer le plan","Удалить план","Plan entfernen","プランを削除","删除计划","إزالة الخطة","Αφαίρεση προγράμματος","Eliminar plan","Rimuovi piano"},
        {"Vazgeç","Cancel","Annuler","Отмена","Abbrechen","キャンセル","取消","إلغاء","Ακύρωση","Cancelar","Annulla"},
        {"Taksit planını kaldır?","Remove installment plan?","Supprimer le plan de mensualités ?","Удалить план рассрочки?","Ratenplan entfernen?","分割払いプランを削除しますか？","删除分期计划？","إزالة خطة التقسيط؟","Να καταργηθεί το πρόγραμμα δόσεων;","¿Eliminar el plan de cuotas?","Rimuovere il piano rateale?"},
        {"Bu işlem sadece planı takip listesinden kaldırır. Daha önce yapılan kart ödemeleri silinmez.","This only removes the plan from the tracking list. Previous card payments are not deleted.","Cette action retire uniquement le plan de la liste de suivi. Les paiements par carte déjà effectués ne sont pas supprimés.","Это удаляет план только из списка отслеживания. Предыдущие платежи по карте не удаляются.","Dadurch wird der Plan nur aus der Beobachtungsliste entfernt. Bereits geleistete Kartenzahlungen werden nicht gelöscht.","これは追跡リストからプランを削除するだけです。以前のカード支払いは削除されません。","此操作仅会从跟踪列表中移除计划。之前的卡片付款不会被删除。","يؤدي هذا إلى إزالة الخطة من قائمة المتابعة فقط. لن يتم حذف مدفوعات البطاقة السابقة.","Αυτό αφαιρεί μόνο το πρόγραμμα από τη λίστα παρακολούθησης. Οι προηγούμενες πληρωμές κάρτας δεν διαγράφονται.","Esto solo elimina el plan de la lista de seguimiento. Los pagos anteriores de la tarjeta no se eliminan.","Rimuove il piano solo dall’elenco di monitoraggio. I pagamenti con carta già effettuati non vengono eliminati."},
        {"Planı Kaldır","Remove plan","Supprimer le plan","Удалить план","Plan entfernen","プランを削除","删除计划","إزالة الخطة","Αφαίρεση προγράμματος","Eliminar plan","Rimuovi piano"},
        {"Taksit Planını Düzenle","Edit Installment Plan","Modifier le plan de mensualités","Изменить план рассрочки","Ratenplan bearbeiten","分割払いプランを編集","编辑分期计划","تعديل خطة التقسيط","Επεξεργασία προγράμματος δόσεων","Editar plan de cuotas","Modifica piano rateale"},
        {"Açıklama","Description","Description","Описание","Beschreibung","説明","说明","الوصف","Περιγραφή","Descripción","Descrizione"},
        {"İlk taksit tarihi","First installment date","Date de la première mensualité","Дата первого платежа","Datum der ersten Rate","初回支払日","首次分期日期","تاريخ القسط الأول","Ημερομηνία πρώτης δόσης","Fecha de la primera cuota","Data della prima rata"},
        {"Taksit sayısı ve daha önce ödenen taksitler korunur.","The installment count and previously paid installments are preserved.","Le nombre de mensualités et les mensualités déjà payées sont conservés.","Количество платежей и ранее оплаченные платежи сохраняются.","Die Anzahl der Raten und bereits bezahlte Raten bleiben erhalten.","分割回数と支払い済みの回数は維持されます。","分期次数和已支付的分期款将保留。","سيتم الاحتفاظ بعدد الأقساط والأقساط المدفوعة سابقًا.","Ο αριθμός των δόσεων και οι ήδη πληρωμένες δόσεις διατηρούνται.","Se conservan el número de cuotas y las cuotas ya pagadas.","Il numero di rate e le rate già pagate vengono mantenuti."},
        {"₺  Kredi Kartı Ödemesi","₺  Credit Card Payment","₺  Paiement de carte","₺  Платёж по кредитной карте","₺  Kreditkartenzahlung","₺  クレジットカード支払い","₺  信用卡付款","₺  دفعة بطاقة ائتمان","₺  Πληρωμή πιστωτικής κάρτας","₺  Pago de tarjeta de crédito","₺  Pagamento carta di credito"},
        {"  •  Güncel borç: ","  •  Current debt: ","  •  Dette actuelle : ","  •  Текущий долг: ","  •  Aktuelle Schuld: ","  •  現在の残高: ","  •  当前欠款：","  •  الدين الحالي: ","  •  Τρέχον χρέος: ","  •  Deuda actual: ","  •  Debito attuale: "},
        {"Ödeme hesabı","Payment account","Compte de paiement","Счёт для платежа","Zahlungskonto","支払い口座","付款账户","حساب الدفع","Λογαριασμός πληρωμής","Cuenta de pago","Conto di pagamento"},
        {"Ödeme tarihi","Payment date","Date de paiement","Дата платежа","Zahlungsdatum","支払日","付款日期","تاريخ الدفع","Ημερομηνία πληρωμής","Fecha de pago","Data di pagamento"},
        {"Not (isteğe bağlı)","Note (optional)","Note (facultatif)","Примечание (необязательно)","Notiz (optional)","メモ（任意）","备注（可选）","ملاحظة (اختياري)","Σημείωση (προαιρετικό)","Nota (opcional)","Nota (facoltativa)"},
        {"Bu işlem sadece kart borcunu azaltır. Taksit planları otomatik olarak değiştirilmez.","This payment only reduces the card debt. Installment plans are not changed automatically.","Ce paiement réduit uniquement la dette de la carte. Les plans de mensualités ne sont pas modifiés automatiquement.","Этот платёж только уменьшает долг по карте. Планы рассрочки автоматически не изменяются.","Diese Zahlung reduziert nur die Kartenschuld. Ratenpläne werden nicht automatisch geändert.","この支払いはカード残高のみを減らします。分割払いプランは自動的には変更されません。","此付款仅减少卡片欠款。分期计划不会自动更改。","هذا الدفع يقلل دين البطاقة فقط. لا يتم تغيير خطط التقسيط تلقائيًا.","Αυτή η πληρωμή μειώνει μόνο το χρέος της κάρτας. Τα προγράμματα δόσεων δεν αλλάζουν αυτόματα.","Este pago solo reduce la deuda de la tarjeta. Los planes de cuotas no cambian automáticamente.","Questo pagamento riduce solo il debito della carta. I piani rateali non vengono modificati automaticamente."},
        {"Ödemeyi Yap","Make Payment","Effectuer le paiement","Выполнить платёж","Zahlung ausführen","支払いを実行","付款","إجراء الدفع","Εκτέλεση πληρωμής","Realizar pago","Effettua pagamento"},
        {"Kart borcu güncellendi. Taksit planları değişmedi.","Card debt updated. Installment plans were not changed.","Dette de la carte mise à jour. Les plans de mensualités n’ont pas changé.","Долг по карте обновлён. Планы рассрочки не изменились.","Kartenschuld aktualisiert. Ratenpläne wurden nicht geändert.","カード残高を更新しました。分割払いプランは変更されていません。","卡片欠款已更新。分期计划未更改。","تم تحديث دين البطاقة. لم تتغير خطط التقسيط.","Το χρέος της κάρτας ενημερώθηκε. Τα προγράμματα δόσεων δεν άλλαξαν.","Deuda de tarjeta actualizada. Los planes de cuotas no han cambiado.","Debito della carta aggiornato. I piani rateali non sono cambiati."},
        {"Geçerli bir ödeme tutarı girin","Enter a valid payment amount","Saisissez un montant de paiement valide","Введите корректную сумму платежа","Geben Sie einen gültigen Zahlungsbetrag ein","有効な支払金額を入力してください","请输入有效的付款金额","أدخل مبلغ دفع صالحًا","Εισαγάγετε έγκυρο ποσό πληρωμής","Introduce un importe de pago válido","Inserisci un importo di pagamento valido"},
        {"Ödemeyi Yap","Make Payment","Effectuer le paiement","Выполнить платёж","Zahlung ausführen","支払いを実行","付款","إجراء الدفع","Εκτέλεση πληρωμής","Realizar pago","Effettua pagamento"},
        {"Ödeme yapıldığında kart borcu azalır ve bu taksit otomatik olarak ödendi olarak işaretlenir. Genel kart ödemeleri diğer taksitleri değiştirmez.","When payment is made, the card debt decreases and this installment is automatically marked as paid. General card payments do not change other installments.","Lorsque le paiement est effectué, la dette de la carte diminue et cette mensualité est automatiquement marquée comme payée. Les paiements généraux de la carte ne modifient pas les autres mensualités.","После оплаты долг по карте уменьшается, а эта рассрочка автоматически отмечается как оплаченная. Общие платежи по карте не изменяют другие рассрочки.","Nach der Zahlung sinkt die Kartenschuld und diese Rate wird automatisch als bezahlt markiert. Allgemeine Kartenzahlungen ändern andere Raten nicht.","支払いを行うとカード残高が減り、この分割払いは自動的に支払い済みになります。通常のカード支払いは他の分割払いを変更しません。","付款后卡片欠款会减少，此分期会自动标记为已支付。普通卡片付款不会更改其他分期。","عند إجراء الدفع، ينخفض دين البطاقة ويتم وضع علامة مدفوع على هذا القسط تلقائيًا. المدفوعات العامة للبطاقة لا تغيّر الأقساط الأخرى.","Με την πληρωμή, το χρέος της κάρτας μειώνεται και η δόση σημειώνεται αυτόματα ως πληρωμένη. Οι γενικές πληρωμές κάρτας δεν αλλάζουν άλλες δόσεις.","Al realizar el pago, la deuda de la tarjeta disminuye y esta cuota se marca automáticamente como pagada. Los pagos generales de la tarjeta no cambian otras cuotas.","Quando viene effettuato il pagamento, il debito della carta diminuisce e questa rata viene automaticamente segnata come pagata. I pagamenti generali della carta non modificano le altre rate."},
        {"Taksit Ödemesi - ","Installment Payment - ","Paiement de mensualité - ","Платёж по рассрочке — ","Ratenzahlung – ","分割払い - ","分期付款 - ","دفعة تقسيط - ","Πληρωμή δόσης - ","Pago de cuota - ","Pagamento rata - "},
        {"Kredi Kartı Taksiti","Credit Card Installment","Mensualité de carte de crédit","Рассрочка по кредитной карте","Kreditkartenrate","クレジットカード分割払い","信用卡分期","قسط بطاقة ائتمان","Δόση πιστωτικής κάρτας","Cuota de tarjeta de crédito","Rata carta di credito"},
        {"Taksit ödendi.","Installment paid.","Mensualité payée.","Рассрочка оплачена.","Rate bezahlt.","分割払いを支払いました。","分期已支付。","تم دفع القسط.","Η δόση πληρώθηκε.","Cuota pagada.","Rata pagata."},
        {"Taksit ödemesi kaydedilemedi.","Installment payment could not be saved.","Le paiement de la mensualité n’a pas pu être enregistré.","Не удалось сохранить платёж по рассрочке.","Ratenzahlung konnte nicht gespeichert werden.","分割払いの支払いを保存できませんでした。","无法保存分期付款。","تعذر حفظ دفعة التقسيط.","Δεν ήταν δυνατή η αποθήκευση της πληρωμής δόσης.","No se pudo guardar el pago de la cuota.","Impossibile salvare il pagamento della rata."},
            {"Finbi'ye bir şey sor...","Ask Finbi something...","Demandez quelque chose à Finbi...","Спросите что-нибудь у Finbi...","Frage Finbi etwas...","Finbiに何か聞いてみてください…","问问Finbi……","اسأل Finbi شيئًا...","Ρώτησε κάτι τον Finbi...","Pregúntale algo a Finbi...","Chiedi qualcosa a Finbi..."},
            {"Bu ay durumum nasıl?","How am I doing this month?","Comment vais-je ce mois-ci ?","Как у меня дела в этом месяце?","Wie geht es mir diesen Monat?","今月の状況はどう？","我这个月的情况怎么样？","كيف وضعي هذا الشهر؟","Πώς τα πάω αυτόν τον μήνα;","¿Cómo voy este mes?","Come sto andando questo mese?"},
            {"Geçen aya göre nasılım?","How am I doing compared with last month?","Comment vais-je par rapport au mois dernier ?","Как у меня дела по сравнению с прошлым месяцем?","Wie geht es mir im Vergleich zum letzten Monat?","先月と比べてどう？","和上个月相比怎么样？","كيف وضعي مقارنة بالشهر الماضي؟","Πώς τα πάω σε σύγκριση με τον προηγούμενο μήνα;","¿Cómo voy en comparación con el mes pasado?","Come sto rispetto al mese scorso?"},
            {"En çok neye harcadım?","What did I spend the most on?","Pour quoi ai-je le plus dépensé ?","На что я потратил больше всего?","Wofür habe ich am meisten ausgegeben?","何に一番お金を使った？","我花钱最多的是什么？","على ماذا أنفقت أكثر؟","Σε τι ξόδεψα τα περισσότερα;","¿En qué gasté más?","Per cosa ho speso di più?"},
            {"Kart borcum ne kadar?","How much is my card debt?","Quel est le montant de ma dette de carte ?","Сколько составляет мой долг по карте?","Wie hoch ist meine Kartenschuld?","カードの残債はいくら？","我的卡债是多少？","كم تبلغ مديونية بطاقتي؟","Πόσο είναι το χρέος της κάρτας μου;","¿Cuánto debo de mi tarjeta?","Quanto ammonta il debito della mia carta?"},
            {"Hedeflerim ne durumda?","How are my goals doing?","Comment avancent mes objectifs ?","Как продвигаются мои цели?","Wie entwickeln sich meine Ziele?","目標の進捗はどう？","我的目标进展如何？","كيف تسير أهدافي؟","Πώς πάνε οι στόχοι μου;","¿Cómo van mis objetivos?","Come stanno andando i miei obiettivi?"},
            {"Son 3 ayımı özetle?","Summarize my last 3 months?","Résume mes 3 derniers mois.","Подведи итог моих последних 3 месяцев.","Fasse meine letzten 3 Monate zusammen.","過去3か月をまとめて。","总结我过去3个月的情况。","لخّص آخر 3 أشهر لي.","Κάνε μια σύνοψη των τελευταίων 3 μηνών μου.","Resume mis últimos 3 meses.","Riassumi i miei ultimi 3 mesi."},
            {"Finans merkezini aç  ›","Open financial center  ›","Ouvrir le centre financier  ›","Открыть финансовый центр  ›","Finanzzentrum öffnen  ›","ファイナンスセンターを開く  ›","打开财务中心  ›","فتح المركز المالي  ›","Άνοιγμα οικονομικού κέντρου  ›","Abrir el centro financiero  ›","Apri il centro finanziario  ›"},
            {"Bir hedef belirle, birikimini takip et.","Set a goal and track your savings.","Définissez un objectif et suivez votre épargne.","Установите цель и отслеживайте свои накопления.","Setze ein Ziel und verfolge deine Ersparnisse.","目標を設定して貯蓄を追跡しましょう。","设定目标并跟踪你的储蓄。","حدد هدفًا وتابع مدخراتك.","Θέσε έναν στόχο και παρακολούθησε τις αποταμιεύσεις σου.","Establece un objetivo y sigue tus ahorros.","Imposta un obiettivo e monitora i tuoi risparmi."},
            {"Hedef kategorisi","Goal category","Catégorie d’objectif","Категория цели","Zielkategorie","目標カテゴリ","目标类别","فئة الهدف","Κατηγορία στόχου","Categoría del objetivo","Categoria dell'obiettivo"},
            {"Araç","Car","Voiture","Автомобиль","Auto","車","汽车","سيارة","Αυτοκίνητο","Coche","Auto"},
            {"Ev","Home","Maison","Дом","Zuhause","家","住房","منزل","Σπίτι","Hogar","Casa"},
            {"Tatil / Seyahat","Travel / Vacation","Voyage / Vacances","Путешествия / Отпуск","Reise / Urlaub","旅行 / 休暇","旅行 / 度假","سفر / عطلة","Ταξίδι / Διακοπές","Viaje / Vacaciones","Viaggio / Vacanza"},
            {"Teknoloji","Technology","Technologie","Технологии","Technologie","テクノロジー","科技","تقنية","Τεχνολογία","Tecnología","Tecnologia"},
            {"Eğitim","Education","Éducation","Образование","Bildung","教育","教育","تعليم","Εκπαίδευση","Educación","Istruzione"},
            {"Düğün / Özel Gün","Wedding / Special Day","Mariage / Jour spécial","Свадьба / Особый день","Hochzeit / Besonderer Tag","結婚式 / 特別な日","婚礼 / 特别日","زفاف / يوم خاص","Γάμος / Ειδική ημέρα","Boda / Día especial","Matrimonio / Giorno speciale"},
            {"Alışveriş","Shopping","Achats","Покупки","Einkaufen","ショッピング","购物","تسوق","Αγορές","Compras","Acquisti"},
            {"Birikim","Savings","Épargne","Накопления","Ersparnisse","貯蓄","储蓄","مدخرات","Αποταμίευση","Ahorros","Risparmi"},
            {"Acil Durum","Emergency","Urgence","Чрезвычайная ситуация","Notfall","緊急","紧急情况","طوارئ","Έκτακτη ανάγκη","Emergencia","Emergenza"},
            {"Borç Kapatma","Debt Payoff","Remboursement de dette","Погашение долга","Schuldenabbau","借金返済","偿还债务","سداد الديون","Εξόφληση χρέους","Pago de deudas","Estinzione del debito"},
            {"Yatırım","Investment","Investissement","Инвестиции","Investition","投資","投资","استثمار","Επένδυση","Inversión","Investimento"},
            {"Özel Hedef","Custom Goal","Objectif personnalisé","Пользовательская цель","Benutzerdefiniertes Ziel","カスタム目標","自定义目标","هدف مخصص","Προσαρμοσμένος στόχος","Objetivo personalizado","Obiettivo personalizzato"},
        {"Henüz aktif bir hedefin görünmüyor. İstersen birlikte bir hedef oluşturabiliriz.","You don't have an active goal yet. We can create one together if you want.","Vous n’avez pas encore d’objectif actif. Nous pouvons en créer un ensemble si vous le souhaitez.","Пока нет активной цели. Если хотите, можем создать её вместе.","Du hast noch kein aktives Ziel. Wenn du möchtest, können wir gemeinsam eines erstellen.","まだ有効な目標がありません。必要なら一緒に作成できます。","你目前还没有活跃目标。如果愿意，我们可以一起创建一个。","لا يوجد لديك هدف نشط حتى الآن. يمكننا إنشاء هدف معًا إذا أردت.","Δεν έχεις ακόμη ενεργό στόχο. Αν θέλεις, μπορούμε να δημιουργήσουμε έναν μαζί.","Aún no tienes ningún objetivo activo. Si quieres, podemos crear uno juntos.","Non hai ancora un obiettivo attivo. Se vuoi, possiamo crearne uno insieme."},
        {"Henüz kayıtlı kredi kartın görünmüyor.","No registered credit card is visible yet.","Aucune carte de crédit enregistrée n’est encore visible.","Зарегистрированных кредитных карт пока нет.","Noch keine registrierte Kreditkarte vorhanden.","登録済みのクレジットカードはまだありません。","目前没有已登记的信用卡。","لا توجد بطاقة ائتمان مسجلة حتى الآن.","Δεν υπάρχει ακόμη καταχωρημένη πιστωτική κάρτα.","Aún no hay ninguna tarjeta de crédito registrada.","Non è ancora presente alcuna carta di credito registrata."},
        {"Kredi kartı durumun:\n","Your credit card status:\n","État de votre carte de crédit :\n","Состояние вашей кредитной карты:\n","Status deiner Kreditkarte:\n","クレジットカードの状況：\n","你的信用卡状态：\n","حالة بطاقتك الائتمانية:\n","Κατάσταση της πιστωτικής σου κάρτας:\n","Estado de tu tarjeta de crédito:\n","Stato della tua carta di credito:\n"},
        {"Aktif taksit görünmüyor.","No active installments are visible.","Aucun paiement échelonné actif n’est visible.","Активных рассрочек не найдено.","Keine aktiven Ratenzahlungen vorhanden.","有効な分割払いはありません。","没有活跃的分期付款。","لا توجد أقساط نشطة.","Δεν υπάρχουν ενεργές δόσεις.","No hay cuotas activas.","Non risultano rate attive."},
        {"Henüz kayıtlı birikim hareketi görünmüyor.","No saved savings activity is visible yet.","Aucune activité d’épargne enregistrée n’est encore visible.","Сохранённых операций накоплений пока нет.","Noch keine gespeicherten Sparvorgänge vorhanden.","保存された貯蓄履歴はまだありません。","目前没有已保存的储蓄记录。","لا توجد حركات ادخار محفوظة حتى الآن.","Δεν υπάρχουν ακόμη καταχωρημένες κινήσεις αποταμίευσης.","Aún no hay movimientos de ahorro registrados.","Non risultano ancora movimenti di risparmio registrati."},
        {"Birikimlerin:\n","Your savings:\n","Votre épargne :\n","Ваши накопления:\n","Deine Ersparnisse:\n","あなたの貯蓄：\n","你的储蓄：\n","مدخراتك:\n","Οι αποταμιεύσεις σου:\n","Tus ahorros:\n","I tuoi risparmi:\n"},
        {"Bu ay: gelir ","This month: income ","Ce mois-ci : revenus ","В этом месяце: доходы ","Diesen Monat: Einnahmen ","今月：収入 ","本月：收入 ","هذا الشهر: الدخل ","Αυτόν τον μήνα: έσοδα ","Este mes: ingresos ","Questo mese: entrate "},
        {"Geçen ay: gelir ","Last month: income ","Le mois dernier : revenus ","В прошлом месяце: доходы ","Letzten Monat: Einnahmen ","先月：収入 ","上个月：收入 ","الشهر الماضي: الدخل ","Τον προηγούμενο μήνα: έσοδα ","El mes pasado: ingresos ","Il mese scorso: entrate "},
        {"Harcama değişimi: ","Spending change: ","Évolution des dépenses : ","Изменение расходов: ","Ausgabenänderung: ","支出の変化： ","支出变化： ","تغير الإنفاق: ","Μεταβολή δαπανών: ","Cambio de gastos: ","Variazione delle spese: "},
        {"Gelir değişimi: ","Income change: ","Évolution des revenus : ","Изменение доходов: ","Einnahmenänderung: ","収入の変化： ","收入变化： ","تغير الدخل: ","Μεταβολή εσόδων: ","Cambio de ingresos: ","Variazione delle entrate: "},
        {"Son 3 ayın özeti:","Summary of the last 3 months:","Résumé des 3 derniers mois :","Итоги последних 3 месяцев:","Zusammenfassung der letzten 3 Monate:","過去3か月の概要：","过去3个月总结：","ملخص آخر 3 أشهر:","Σύνοψη των τελευταίων 3 μηνών:","Resumen de los últimos 3 meses:","Riepilogo degli ultimi 3 mesi:"},
        {"Toplam: gelir ","Total: income ","Total : revenus ","Итого: доходы ","Gesamt: Einnahmen ","合計：収入 ","总计：收入 ","الإجمالي: الدخل ","Σύνολο: έσοδα ","Total: ingresos ","Totale: entrate "},
        {"Piyasa tarafında dolar, euro veya gram altın için de bilgi verebilirim.","I can also provide information about the dollar, euro, or gram gold market.","Je peux aussi fournir des informations sur le dollar, l’euro ou l’or au gramme.","Я также могу предоставить информацию о долларе, евро и золоте за грамм.","Ich kann auch Informationen zu Dollar, Euro oder Gold pro Gramm geben.","ドル、ユーロ、金相場についても案内できます。","我也可以提供美元、欧元或克金的市场信息。","يمكنني أيضًا تقديم معلومات عن الدولار واليورو وسعر الذهب للغرام.","Μπορώ επίσης να δώσω πληροφορίες για δολάριο, ευρώ ή χρυσό ανά γραμμάριο.","También puedo darte información sobre el dólar, el euro o el oro por gramo.","Posso anche fornire informazioni su dollaro, euro o oro al grammo."},
        {"Bu piyasa verisi şu anda yüklenmemiş. Piyasa ekranını açıp güncel veriyi yenileyebilirsin.","This market data is not loaded right now. Open the Markets screen and refresh the latest data.","Ces données de marché ne sont pas chargées actuellement. Ouvrez l’écran Marchés et actualisez les données.","Эти рыночные данные сейчас не загружены. Откройте экран Рынки и обновите данные.","Diese Marktdaten sind derzeit nicht geladen. Öffne den Marktbildschirm und aktualisiere die Daten.","現在この市場データは読み込まれていません。市場画面を開いて最新データを更新してください。","当前市场数据尚未加载。打开市场页面并刷新最新数据。","بيانات السوق هذه غير محملة حاليًا. افتح شاشة الأسواق وحدّث أحدث البيانات.","Αυτά τα δεδομένα αγοράς δεν έχουν φορτωθεί. Άνοιξε την οθόνη Αγορές και ανανέωσε τα δεδομένα.","Estos datos de mercado no están cargados ahora. Abre la pantalla Mercados y actualiza los datos.","Questi dati di mercato non sono ancora caricati. Apri la schermata Mercati e aggiorna i dati."},
        {"Bu ayki finansal görünümün:\n","Your financial picture this month:\n","Votre situation financière ce mois-ci :\n","Вашая финансовая картина за этот месяц:\n","Deine finanzielle Lage in diesem Monat:\n","今月の財務状況：\n","你本月的财务状况：\n","وضعك المالي هذا الشهر:\n","Η οικονομική σου εικόνα αυτόν τον μήνα:\n","Tu situación financiera este mes:\n","La tua situazione finanziaria questo mese:\n"},
        {"En yüksek harcamaların:\n","Your highest expenses:\n","Vos dépenses les plus élevées :\n","Ваши самые крупные расходы:\n","Deine höchsten Ausgaben:\n","最も多い支出：\n","你的最高支出：\n","أعلى مصروفاتك:\n","Οι υψηλότερες δαπάνες σου:\n","Tus gastos más altos:\n","Le tue spese maggiori:\n"},
        {"Geçen aya göre gider değişimi: ","Spending change compared with last month: ","Évolution des dépenses par rapport au mois dernier : ","Изменение расходов по сравнению с прошлым месяцем: ","Ausgabenänderung gegenüber dem letzten Monat: ","先月と比べた支出の変化： ","与上月相比的支出变化： ","تغير الإنفاق مقارنة بالشهر الماضي: ","Μεταβολή δαπανών σε σχέση με τον προηγούμενο μήνα: ","Cambio de gastos respecto al mes pasado: ","Variazione delle spese rispetto al mese scorso: "},
        {"Mevcut harcama hızına göre ay sonu tahminin:\n","Your month-end estimate based on your current spending pace:\n","Votre estimation de fin de mois selon votre rythme de dépenses actuel :\n","Прогноз на конец месяца по текущему темпу расходов:\n","Deine Monatsendprognose auf Basis deines aktuellen Ausgabentempos:\n","現在の支出ペースに基づく月末予測：\n","根据当前支出速度预测的月末情况：\n","تقدير نهاية الشهر بناءً على وتيرة إنفاقك الحالية:\n","Η εκτίμηση τέλους μήνα με βάση τον τρέχοντα ρυθμό δαπανών σου:\n","Tu previsión de fin de mes según tu ritmo de gasto actual:\n","La tua previsione di fine mese in base al ritmo attuale delle spese:\n"},
        {"• Tahmini gider: ","• Estimated spending: ","• Dépenses estimées : ","• Прогноз расходов: ","• Geschätzte Ausgaben: ","• 推定支出： ","• 预计支出： ","• الإنفاق المتوقع: ","• Εκτιμώμενες δαπάνες: ","• Gastos estimados: ","• Spese stimate: "},
        {"• Kayıtlı gelir: ","• Recorded income: ","• Revenus enregistrés : ","• Зарегистрированные доходы: ","• Erfasste Einnahmen: ","• 記録済み収入： ","• 已记录收入： ","• الدخل المسجل: ","• Καταγεγραμμένα έσοδα: ","• Ingresos registrados: ","• Entrate registrate: "},
        {"• Tahmini net: ","• Estimated net: ","• Net estimé : ","• Прогноз чистого результата: ","• Geschätzter Nettobetrag: ","• 推定純額： ","• 预计净额： ","• صافي التقدير: ","• Εκτιμώμενο καθαρό: ","• Neto estimado: ","• Netto stimato: "},
        {"• Bütçe: ","• Budget: ","• Budget : ","• Бюджет: ","• Budget: ","• 予算： ","• 预算： ","• الميزانية: ","• Προϋπολογισμός: ","• Presupuesto: ","• Budget: "},
        {"Finansal özetin:\n","Your financial summary:\n","Votre résumé financier :\n","Ваш финансовый обзор:\n","Deine Finanzübersicht:\n","財務概要：\n","你的财务摘要：\n","ملخصك المالي:\n","Η οικονομική σου σύνοψη:\n","Tu resumen financiero:\n","Il tuo riepilogo finanziario:\n"},
        {"• Toplam bakiye: ","• Total balance: ","• Solde total : ","• Общий баланс: ","• Gesamtsaldo: ","• 総残高： ","• 总余额： ","• الرصيد الإجمالي: ","• Συνολικό υπόλοιπο: ","• Saldo total: ","• Saldo totale: "},
        {"• Bu ay gelir: ","• Income this month: ","• Revenus ce mois-ci : ","• Доходы за этот месяц: ","• Einnahmen diesen Monat: ","• 今月の収入： ","• 本月收入： ","• الدخل هذا الشهر: ","• Έσοδα αυτόν τον μήνα: ","• Ingresos este mes: ","• Entrate di questo mese: "},
        {"• Bu ay gider: ","• Spending this month: ","• Dépenses ce mois-ci : ","• Расходы за этот месяц: ","• Ausgaben diesen Monat: ","• 今月の支出： ","• 本月支出： ","• الإنفاق هذا الشهر: ","• Δαπάνες αυτόν τον μήνα: ","• Gastos este mes: ","• Spese di questo mese: "},
        {"• Ay neti: ","• Monthly net: ","• Net mensuel : ","• Чистый результат за месяц: ","• Monatlicher Nettobetrag: ","• 月間純額： ","• 月度净额： ","• صافي الشهر: ","• Μηνιαίο καθαρό: ","• Neto mensual: ","• Netto mensile: "},
        {"• Kart borcu: ","• Card debt: ","• • Dette de carte : ","• Долг по карте: ","• Kartenschuld: ","• カード残高： ","• 卡片欠款： ","• مديونية البطاقة: ","• Χρέος κάρτας: ","• Deuda de tarjeta: ","• Debito della carta: "},
        {"Hedeflerin:\n","Your goals:\n","Vos objectifs :\n","Ваши цели:\n","Deine Ziele:\n","目標：\n","你的目标：\n","أهدافك:\n","Οι στόχοι σου:\n","Tus objetivos:\n","I tuoi obiettivi:\n"},
        {"Buradayım. Bakiye, harcamalar, gelirler, kartlar, taksitler, birikimler veya hedeflerin hakkında sorabilirsin.","I'm here. You can ask about your balance, spending, income, cards, installments, savings, or goals.","Je suis là. Vous pouvez me demander votre solde, vos dépenses, vos revenus, vos cartes, vos mensualités, votre épargne ou vos objectifs.","Я здесь. Вы можете спросить о балансе, расходах, доходах, картах, рассрочках, накоплениях или целях.","Ich bin hier. Du kannst mich zu Kontostand, Ausgaben, Einnahmen, Karten, Raten, Ersparnissen oder Zielen fragen.","ここにいます。残高、支出、収入、カード、分割払い、貯蓄、目標について質問できます。","我在这里。你可以询问余额、支出、收入、卡片、分期、储蓄或目标。","أنا هنا. يمكنك السؤال عن رصيدك أو إنفاقك أو دخلك أو بطاقاتك أو أقساطك أو مدخراتك أو أهدافك.","Είμαι εδώ. Μπορείς να ρωτήσεις για υπόλοιπο, δαπάνες, έσοδα, κάρτες, δόσεις, αποταμιεύσεις ή στόχους.","Estoy aquí. Puedes preguntar por tu saldo, gastos, ingresos, tarjetas, cuotas, ahorros u objetivos.","Sono qui. Puoi chiedere del saldo, delle spese, delle entrate, delle carte, delle rate, dei risparmi o degli obiettivi."},
        {"Bu ay henüz gider kaydın yok.","You have no spending recorded this month yet.","Aucune dépense n’est encore enregistrée ce mois-ci.","В этом месяце расходы пока не зарегистрированы.","Diesen Monat sind noch keine Ausgaben erfasst.","今月はまだ支出が記録されていません。","本月还没有记录支出。","لم يتم تسجيل أي إنفاق هذا الشهر حتى الآن.","Δεν έχει καταγραφεί ακόμη καμία δαπάνη αυτόν τον μήνα.","Este mes aún no hay gastos registrados.","Questo mese non risultano ancora spese registrate."},
        {"Bu ay en yüksek harcama kategorilerin:\n","Your highest spending categories this month:\n","Vos catégories de dépenses les plus élevées ce mois-ci :\n","Ваши самые крупные категории расходов в этом месяце:\n","Deine höchsten Ausgabenkategorien in diesem Monat:\n","今月の支出上位カテゴリ：\n","本月支出最高的类别：\n","أعلى فئات الإنفاق هذا الشهر:\n","Οι κατηγορίες με τις υψηλότερες δαπάνες σου αυτόν τον μήνα:\n","Tus categorías de gasto más altas este mes:\n","Le categorie di spesa più alte di questo mese:\n"},
        {"Güncel toplam bakiyen ","Your current total balance is ","Votre solde total actuel est de ","Ваш текущий общий баланс: ","Dein aktueller Gesamtsaldo beträgt ","現在の総残高は ","你当前的总余额为 ","رصيدك الإجمالي الحالي هو ","Το τρέχον συνολικό υπόλοιπό σου είναι ","Tu saldo total actual es ","Il tuo saldo totale attuale è "},
        {"Bu ay gelirlerinden giderlerini çıkardığımda ","After subtracting your spending from your income this month, you have ","Après déduction de vos dépenses de vos revenus ce mois-ci, il vous reste ","После вычета расходов из доходов за этот месяц остаётся ","Nach Abzug deiner Ausgaben von deinen Einnahmen in diesem Monat bleiben dir ","今月の収入から支出を差し引くと、残りは ","从本月收入中扣除支出后，你还剩 ","بعد خصم إنفاقك من دخلك هذا الشهر، يتبقى لديك ","Αφού αφαιρέσουμε τις δαπάνες από τα έσοδά σου αυτόν τον μήνα, σου μένουν ","Después de restar tus gastos de tus ingresos este mes, te quedan ","Dopo aver sottratto le spese dalle entrate di questo mese, ti rimangono "},
            {"Bütçeler","Budgets","Budgets","Бюджеты","Budgets","予算","预算","الميزانيات","Προϋπολογισμοί","Presupuestos","Budget"},
            {"Genel ve kategori bütçelerini takip et","Track overall and category budgets","Suivez les budgets global et par catégorie","Отслеживайте общий бюджет и бюджеты категорий","Verfolge Gesamt- und Kategoriebudgets","全体予算とカテゴリ予算を管理","跟踪总预算和分类预算","تابع الميزانية العامة وميزانيات الفئات","Παρακολούθησε τον συνολικό προϋπολογισμό και τις κατηγορίες","Controla el presupuesto general y por categoría","Tieni sotto controllo il budget generale e per categoria"},
            {"Bütçeni kontrol et","Keep your budget under control","Gardez votre budget sous contrôle","Держите бюджет под контролем","Behalte dein Budget im Blick","予算を管理しましょう","控制你的预算","تحكم في ميزانيتك","Κράτησε τον προϋπολογισμό σου υπό έλεγχο","Controla tu presupuesto","Tieni sotto controllo il tuo budget"},
            {"Genel ve kategori bütçelerini takip et","Track overall and category budgets","Suivez les budgets global et par catégorie","Отслеживайте общий бюджет и бюджеты категорий","Verfolge Gesamt- und Kategoriebudgets","全体予算とカテゴリ予算を管理","跟踪总预算和分类预算","تابع الميزانية العامة وميزانيات الفئات","Παρακολούθησε τον συνολικό προϋπολογισμό και τις κατηγορίες","Controla el presupuesto general y por categoría","Tieni sotto controllo il budget generale e per categoria"},
            {"Genel bütçe","Overall monthly budget","Budget mensuel global","Общий месячный бюджет","Gesamt-Monatsbudget","全体月間予算","每月总预算","الميزانية الشهرية العامة","Συνολικός μηνιαίος προϋπολογισμός","Presupuesto mensual general","Budget mensile complessivo"},
            {"Tanımlanmadı","Not set","Non défini","Не задано","Nicht festgelegt","未設定","未设置","غير محدد","Δεν έχει οριστεί","No definido","Non impostato"},
            {"Genel bütçeyi düzenle","Edit overall budget","Modifier le budget global","Изменить общий бюджет","Gesamtbudget bearbeiten","全体予算を編集","编辑总预算","تعديل الميزانية العامة","Επεξεργασία συνολικού προϋπολογισμού","Editar presupuesto general","Modifica budget complessivo"},
            {"Kategori bütçesi ekle","Add category budget","Ajouter un budget de catégorie","Добавить бюджет категории","Kategoriebudget hinzufügen","カテゴリ予算を追加","添加分类预算","إضافة ميزانية لفئة","Προσθήκη προϋπολογισμού κατηγορίας","Añadir presupuesto de categoría","Aggiungi budget categoria"},
            {"Kategori bütçeleri","Category budgets","Budgets par catégorie","Бюджеты категорий","Kategoriebudgets","カテゴリ予算","分类预算","ميزانيات الفئات","Προϋπολογισμοί κατηγοριών","Presupuestos por categoría","Budget per categoria"},
            {"Bütçe aşıldı","Budget exceeded","Budget dépassé","Бюджет превышен","Budget überschritten","予算超過","超出预算","تم تجاوز الميزانية","Υπέρβαση προϋπολογισμού","Presupuesto excedido","Budget superato"},
            {"Kalan ","Remaining ","Restant ","Осталось ","Verbleibend ","残り","剩余","المتبقي ","Υπόλοιπο ","Restante ","Rimanente "},
            {"Henüz kategori bütçesi tanımlanmadı.","No category budgets have been set yet.","Aucun budget de catégorie n’est encore défini.","Бюджеты категорий ещё не заданы.","Es wurden noch keine Kategoriebudgets festgelegt.","カテゴリ予算はまだ設定されていません。","尚未设置分类预算。","لم يتم تحديد ميزانيات للفئات بعد.","Δεν έχουν οριστεί ακόμη προϋπολογισμοί κατηγοριών.","Aún no se han definido presupuestos por categoría.","Non sono ancora stati definiti budget per categoria."},
            {"Kategori bütçesi","Category budget","Budget de catégorie","Бюджет категории","Kategoriebudget","カテゴリ予算","分类预算","ميزانية الفئة","Προϋπολογισμός κατηγορίας","Presupuesto de categoría","Budget categoria"},
            {"Kategori bütçesini düzenle","Edit category budget","Modifier le budget de catégorie","Изменить бюджет категории","Kategoriebudget bearbeiten","カテゴリ予算を編集","编辑分类预算","تعديل ميزانية الفئة","Επεξεργασία προϋπολογισμού κατηγορίας","Editar presupuesto de categoría","Modifica budget categoria"},
            {"0 girersen bu kategori bütçesi kaldırılır.","Enter 0 to remove this category budget.","Entrez 0 pour supprimer ce budget de catégorie.","Введите 0, чтобы удалить бюджет этой категории.","Gib 0 ein, um dieses Kategoriebudget zu entfernen.","0を入力するとカテゴリ予算を削除します。","输入0可删除该分类预算。","أدخل 0 لإزالة ميزانية هذه الفئة.","Πληκτρολόγησε 0 για να αφαιρέσεις αυτόν τον προϋπολογισμό κατηγορίας.","Introduce 0 para eliminar este presupuesto de categoría.","Inserisci 0 per rimuovere questo budget categoria."},
            {"Abonelikler","Subscriptions","Abonnements","Подписки","Abonnements","サブスクリプション","订阅","الاشتراكات","Συνδρομές","Suscripciones","Abbonamenti"},
            {"Aboneliklerini, tutarlarını ve ödeme günlerini takip et","Track subscriptions, amounts, and billing days","Suivez les abonnements, les montants et les jours de paiement","Отслеживайте подписки, суммы и дни оплаты","Verfolge Abonnements, Beträge und Zahlungstage","サブスク、金額、支払日を管理","跟踪订阅、金额和付款日","تابع الاشتراكات والمبالغ وأيام الدفع","Παρακολούθησε συνδρομές, ποσά και ημέρες πληρωμής","Controla suscripciones, importes y días de pago","Tieni traccia di abbonamenti, importi e giorni di pagamento"},
            {"Aboneliklerini kontrol et","Keep track of your subscriptions","Gardez le contrôle de vos abonnements","Следите за своими подписками","Behalte deine Abonnements im Blick","サブスクリプションを管理","管理你的订阅","تابع اشتراكاتك","Παρακολούθησε τις συνδρομές σου","Controla tus suscripciones","Tieni sotto controllo i tuoi abbonamenti"},
            {"Tutarları, ödeme günlerini ve bu ay ödenip ödenmediğini takip et.","Track amounts, billing days, and whether each subscription has been paid this month.","Suivez les montants, les jours de paiement et si chaque abonnement a été payé ce mois-ci.","Отслеживайте суммы, дни оплаты и факт оплаты каждой подписки в этом месяце.","Verfolge Beträge, Zahlungstage und ob jedes Abo diesen Monat bezahlt wurde.","金額、支払日、今月支払い済みかを確認できます。","跟踪金额、付款日以及本月是否已支付。","تابع المبالغ وأيام الدفع وما إذا تم دفع كل اشتراك هذا الشهر.","Παρακολούθησε ποσά, ημέρες πληρωμής και αν κάθε συνδρομή έχει πληρωθεί αυτόν τον μήνα.","Controla importes, días de pago y si cada suscripción se ha pagado este mes.","Tieni traccia degli importi, dei giorni di pagamento e dei pagamenti effettuati questo mese."},
            {"Aktif abonelik","Active subscriptions","Abonnements actifs","Активные подписки","Aktive Abonnements","有効なサブスクリプション","活跃订阅","الاشتراكات النشطة","Ενεργές συνδρομές","Suscripciones activas","Abbonamenti attivi"},
            {"ay","month","mois","месяц","Monat","月","月","شهر","μήνα","mes","mese"},
            {"Abonelik ekle","Add subscription","Ajouter un abonnement","Добавить подписку","Abonnement hinzufügen","サブスクリプションを追加","添加订阅","إضافة اشتراك","Προσθήκη συνδρομής","Añadir suscripción","Aggiungi abbonamento"},
            {"Henüz abonelik eklenmedi.","No subscriptions have been added yet.","Aucun abonnement n’a encore été ajouté.","Подписки ещё не добавлены.","Noch keine Abonnements hinzugefügt.","サブスクリプションはまだありません。","尚未添加订阅。","لم تتم إضافة أي اشتراكات بعد.","Δεν έχουν προστεθεί ακόμη συνδρομές.","Aún no se han añadido suscripciones.","Non sono ancora stati aggiunti abbonamenti."},
            {"Bu ay ödendi","Paid this month","Payé ce mois-ci","Оплачено в этом месяце","Diesen Monat bezahlt","今月支払い済み","本月已支付","تم الدفع هذا الشهر","Πληρώθηκε αυτόν τον μήνα","Pagado este mes","Pagato questo mese"},
            {"Bu ay bekliyor","Due this month","À payer ce mois-ci","Ожидает оплаты в этом месяце","Diesen Monat fällig","今月支払い予定","本月待支付","مستحق هذا الشهر","Προς πληρωμή αυτόν τον μήνα","Pendiente este mes","In scadenza questo mese"},
            {"Pasif","Inactive","Inactif","Неактивна","Inaktiv","無効","未启用","غير نشط","Ανενεργή","Inactiva","Inattivo"},
            {"Öde","Pay","Payer","Оплатить","Bezahlen","支払う","支付","دفع","Πληρωμή","Pagar","Paga"},
            {"Düzenle","Edit","Modifier","Изменить","Bearbeiten","編集","编辑","تعديل","Επεξεργασία","Editar","Modifica"},
            {"Sil","Delete","Supprimer","Удалить","Löschen","削除","删除","حذف","Διαγραφή","Eliminar","Elimina"},
            {"Abonelik adı","Subscription name","Nom de l’abonnement","Название подписки","Name des Abonnements","サブスクリプション名","订阅名称","اسم الاشتراك","Όνομα συνδρομής","Nombre de la suscripción","Nome abbonamento"},
            {"Aylık tutar","Monthly amount","Montant mensuel","Ежемесячная сумма","Monatlicher Betrag","月額","每月金额","المبلغ الشهري","Μηνιαίο ποσό","Importe mensual","Importo mensile"},
            {"Ödeme günü","Billing day","Jour de paiement","День оплаты","Zahlungstag","支払日","付款日","يوم الدفع","Ημέρα πληρωμής","Día de pago","Giorno di pagamento"},
            {"Kategori (isteğe bağlı)","Category (optional)","Catégorie (facultatif)","Категория (необязательно)","Kategorie (optional)","カテゴリ（任意）","类别（可选）","الفئة (اختياري)","Κατηγορία (προαιρετικό)","Categoría (opcional)","Categoria (opzionale)"},
            {"Geçerli bir abonelik girin","Enter a valid subscription","Saisissez un abonnement valide","Введите корректную подписку","Gib ein gültiges Abonnement ein","有効なサブスクリプションを入力してください","请输入有效的订阅","أدخل اشتراكًا صالحًا","Εισήγαγε μια έγκυρη συνδρομή","Introduce una suscripción válida","Inserisci un abbonamento valido"},
            {"Abonelik - ","Subscription - ","Abonnement - ","Подписка — ","Abonnement – ","サブスクリプション - ","订阅 - ","اشتراك - ","Συνδρομή - ","Suscripción - ","Abbonamento - "},
            {"Bütçe durumun:\n","Your budget status:\n","État de votre budget :\n","Состояние вашего бюджета:\n","Dein Budgetstatus:\n","予算状況：\n","你的预算情况：\n","حالة ميزانيتك:\n","Κατάσταση προϋπολογισμού:\n","Estado de tu presupuesto:\n","Stato del tuo budget:\n"},
            {"Genel bütçe: ","Overall budget: ","Budget global : ","Общий бюджет: ","Gesamtbudget: ","全体予算：","总预算：","الميزانية العامة: ","Συνολικός προϋπολογισμός: ","Presupuesto general: ","Budget complessivo: "},
            {"kullanılan ","used ","utilisé ","использовано ","verwendet ","使用済み","已使用","المستخدم ","χρησιμοποιημένο ","utilizado ","utilizzato "},
            {"Kalan: ","Remaining: ","Restant : ","Осталось: ","Verbleibend: ","残り：","剩余：","المتبقي: ","Υπόλοιπο: ","Restante: ","Rimanente: "},
            {"Kategori bütçesi tanımlanmamış.","No category budgets are set.","Aucun budget de catégorie n’est défini.","Бюджеты категорий не заданы.","Keine Kategoriebudgets festgelegt.","カテゴリ予算は設定されていません。","未设置分类预算。","لم يتم تحديد ميزانيات للفئات.","Δεν έχουν οριστεί προϋπολογισμοί κατηγοριών.","No hay presupuestos de categoría definidos.","Non sono impostati budget per categoria."},
            {"Aktif aboneliklerin:\n","Your active subscriptions:\n","Vos abonnements actifs :\n","Ваши активные подписки:\n","Deine aktiven Abonnements:\n","有効なサブスクリプション：\n","你的活跃订阅：\n","اشتراكاتك النشطة:\n","Οι ενεργές συνδρομές σου:\n","Tus suscripciones activas:\n","I tuoi abbonamenti attivi:\n"},
            {"Aylık toplam: ","Monthly total: ","Total mensuel : ","Итого за месяц: ","Monatssumme: ","月額合計：","每月总计：","الإجمالي الشهري: ","Μηνιαίο σύνολο: ","Total mensual: ","Totale mensile: "},
            {"Henüz aktif aboneliğin yok.","You don't have any active subscriptions yet.","Vous n’avez pas encore d’abonnement actif.","У вас пока нет активных подписок.","Du hast noch keine aktiven Abonnements.","有効なサブスクリプションはまだありません。","你还没有活跃订阅。","ليس لديك اشتراكات نشطة بعد.","Δεν έχεις ακόμη ενεργές συνδρομές.","Aún no tienes suscripciones activas.","Non hai ancora abbonamenti attivi."},
            {"Genel aylık bütçen tanımlı değil. ","Your overall monthly budget is not set. ","Votre budget mensuel global n’est pas défini. ","Ваш общий месячный бюджет не задан. ","Dein monatliches Gesamtbudget ist nicht festgelegt. ","毎月の総予算は設定されていません。 ","你尚未设置每月总预算。 ","لم يتم تحديد ميزانيتك الشهرية الإجمالية. ","Ο συνολικός μηνιαίος προϋπολογισμός σου δεν έχει οριστεί. ","Tu presupuesto mensual general no está definido. ","Il tuo budget mensile complessivo non è impostato. "},
            {"Aylık bütçe belirlemek için dokunun","Tap to set a monthly budget","Touchez pour définir un budget mensuel","Нажмите, чтобы задать месячный бюджет","Tippen, um ein monatliches Budget festzulegen","タップして月間予算を設定","点击以设置每月预算","اضغط لتحديد ميزانية شهرية","Πάτησε για να ορίσεις μηνιαίο προϋπολογισμό","Toca para establecer un presupuesto mensual","Tocca per impostare un budget mensile"},
            {"Aylık bütçe","Monthly budget","Budget mensuel","Месячный бюджет","Monatliches Budget","月間予算","每月预算","الميزانية الشهرية","Μηνιαίος προϋπολογισμός","Presupuesto mensual","Budget mensile"},
            {"Bu ay harcayabileceğiniz üst tutarı girin. %80 ve %100'e ulaşınca uyarı alırsınız. Bütçeyi kaldırmak için 0 girin.","Enter the most you plan to spend each month. You will be alerted at 80% and 100%. Enter 0 to remove the budget.","Saisissez le montant maximal que vous prévoyez de dépenser chaque mois. Vous serez alerté à 80 % et 100 %. Saisissez 0 pour supprimer le budget.","Geben Sie den Betrag ein, den Sie monatlich höchstens ausgeben möchten. Bei 80 % und 100 % erhalten Sie eine Warnung. Geben Sie 0 ein, um das Budget zu entfernen.","Geben Sie den maximalen monatlichen Ausgabenbetrag ein. Bei 80 % und 100 % erhalten Sie eine Warnung. Geben Sie 0 ein, um das Budget zu entfernen.","毎月の支出上限を入力してください。80%と100%に達すると通知されます。予算を削除するには0を入力してください。","输入每月计划支出的最高金额。达到80%和100%时会收到提醒。输入0可移除预算。","أدخل الحد الأقصى الذي تخطط لإنفاقه كل شهر. ستتلقى تنبيهًا عند 80٪ و100٪. أدخل 0 لإزالة الميزانية.","Εισήγαγε το μέγιστο ποσό που σκοπεύεις να ξοδεύεις κάθε μήνα. Θα ειδοποιείσαι στο 80% και 100%. Εισήγαγε 0 για να καταργήσεις τον προϋπολογισμό.","Introduce el máximo que planeas gastar cada mes. Recibirás una alerta al 80 % y al 100 %. Introduce 0 para eliminar el presupuesto.","Inserisci il massimo che prevedi di spendere ogni mese. Riceverai un avviso all'80% e al 100%. Inserisci 0 per rimuovere il budget."},
            {"Bütçe tutarı","Budget amount","Montant du budget","Сумма бюджета","Budgetbetrag","予算額","预算金额","مبلغ الميزانية","Ποσό προϋπολογισμού","Importe del presupuesto","Importo del budget"},
            {"Geçerli bir tutar girin","Enter a valid amount","Saisissez un montant valide","Введите корректную сумму","Geben Sie einen gültigen Betrag ein","有効な金額を入力してください","请输入有效金额","أدخل مبلغًا صالحًا","Εισήγαγε ένα έγκυρο ποσό","Introduce un importe válido","Inserisci un importo valido"},
            {"Market","Groceries","Épicerie","Продукты","Lebensmittel","食料品","食品杂货","البقالة","Είδη παντοπωλείου","Comestibles","Spesa"},
            {"Kredi Kartı","Credit Card","Carte de crédit","Кредитная карта","Kreditkarte","クレジットカード","信用卡","بطاقة ائتمان","Πιστωτική κάρτα","Tarjeta de crédito","Carta di credito"},
            {"Yemek","Food","Nourriture","Еда","Essen","食事","餐饮","الطعام","Φαγητό","Comida","Cibo"},
            {"Fatura","Bills","Factures","Счета","Rechnungen","請求書","账单","الفواتير","Λογαριασμοί","Facturas","Bollette"},
            {"Eğlence","Entertainment","Divertissement","Развлечения","Unterhaltung","エンターテインメント","娱乐","الترفيه","Ψυχαγωγία","Entretenimiento","Intrattenimento"},
            {"Ulaşım","Transport","Transport","Транспорт","Transport","交通","交通","المواصلات","Μετακινήσεις","Transporte","Trasporti"},
            {"Sağlık","Health","Santé","Здоровье","Gesundheit","健康","健康","الصحة","Υγεία","Salud","Salute"},
            {"Giyim","Clothing","Vêtements","Одежда","Kleidung","衣類","服装","الملابس","Ένδυση","Ropa","Abbigliamento"},
            {"Seyahat","Travel","Voyage","Путешествия","Reisen","旅行","旅行","السفر","Ταξίδια","Viajes","Viaggi"},
            {"Yakıt","Fuel","Carburant","Топливо","Kraftstoff","燃料","燃油","الوقود","Καύσιμα","Combustible","Carburante"},
            {"Diğer","Other","Autre","Другое","Sonstiges","その他","其他","أخرى","Άλλο","Otro","Altro"},
            {"Abonelik","Subscription","Abonnement","Подписка","Abonnement","サブスクリプション","订阅","اشتراك","Συνδρομή","Suscripción","Abbonamento"},
            {"Genel bütçene ek olarak kategori bazında sınırlar belirleyebilirsin.","Set category limits in addition to your overall monthly budget.","Définissez des limites par catégorie en plus de votre budget mensuel global.","Помимо общего месячного бюджета можно задать лимиты для отдельных категорий.","Zusätzlich zum monatlichen Gesamtbudget können Sie Limits für einzelne Kategorien festlegen.","全体の月間予算に加えて、カテゴリごとの上限を設定できます。","除了每月总预算外，还可以为各类别设置限额。","يمكنك تحديد حدود لكل فئة بالإضافة إلى ميزانيتك الشهرية الإجمالية.","Μπορείς να ορίσεις όρια ανά κατηγορία επιπλέον του συνολικού μηνιαίου προϋπολογισμού.","Además del presupuesto mensual general, puedes establecer límites por categoría.","Oltre al budget mensile complessivo, puoi impostare limiti per categoria."},
            {"Aylık genel bütçe","Overall monthly budget","Budget mensuel global","Общий месячный бюджет","Monatliches Gesamtbudget","月間総予算","每月总预算","الميزانية الشهرية الإجمالية","Συνολικός μηνιαίος προϋπολογισμός","Presupuesto mensual general","Budget mensile complessivo"},
            {"Aylık limit","Monthly limit","Limite mensuelle","Месячный лимит","Monatliches Limit","月間上限","每月限额","الحد الشهري","Μηνιαίο όριο","Límite mensual","Limite mensile"},
            {"Aboneliği düzenle","Edit subscription","Modifier l’abonnement","Изменить подписку","Abonnement bearbeiten","サブスクリプションを編集","编辑订阅","تعديل الاشتراك","Επεξεργασία συνδρομής","Editar suscripción","Modifica abbonamento"},
            {"Aylık bütçeni aştın","You went over your monthly budget","Vous avez dépassé votre budget mensuel","Вы превысили месячный бюджет","Du hast dein Monatsbudget überschritten","月間予算を超えました","你已超出每月预算","لقد تجاوزت ميزانيتك الشهرية","Ξεπέρασες τον μηνιαίο προϋπολογισμό σου","Has superado tu presupuesto mensual","Hai superato il tuo budget mensile"},
            {"Bütçenin %80'ine ulaştın","You have used 80% of your budget","Vous avez utilisé 80 % de votre budget","Вы использовали 80 % бюджета","Du hast 80 % deines Budgets verbraucht","予算の80%を使用しました","你已使用80%的预算","لقد استخدمت 80٪ من ميزانيتك","Έχεις χρησιμοποιήσει το 80% του προϋπολογισμού σου","Has utilizado el 80 % de tu presupuesto","Hai utilizzato l'80% del tuo budget"},
    };

    private int finbiLanguageIndex(){
        if("en".equals(language))return 1; if("fr".equals(language))return 2; if("ru".equals(language))return 3; if("de".equals(language))return 4; if("ja".equals(language))return 5; if("zh".equals(language))return 6; if("ar".equals(language))return 7; if("el".equals(language))return 8; if("es".equals(language))return 9; if("it".equals(language))return 10; return 0;
    }
    private String finbiLocalizeOutput(String value){
        if(value==null || "tr".equals(language)) return value;
        int idx=finbiLanguageIndex();
        if(idx==0) return value;
        String out=value;
        ArrayList<String[]> rows=new ArrayList<>(java.util.Arrays.asList(FINBI_OUTPUT_TRANSLATIONS));
        Collections.sort(rows,(a,b)->Integer.compare(b[0].length(),a[0].length()));
        for(String[] row:rows){
            if(row[0].length()==0)continue;
            if(out.contains(row[0])) out=out.replace(row[0],row[idx]);
        }
        return out;
    }

    private String legacyTranslate(String value){
        if(value==null || "tr".equals(language)) return value;
        int idx="en".equals(language)?1:
                "fr".equals(language)?2:
                "ru".equals(language)?3:
                "de".equals(language)?4:
                "ja".equals(language)?5:
                "zh".equals(language)?6:
                "ar".equals(language)?7:
                "el".equals(language)?8:
                "es".equals(language)?9:
                "it".equals(language)?10:1;
        for(String[] row:LEGACY_UI_TRANSLATIONS){
            if(value.equals(row[0])) return row[idx];
            if(value.equals(row[1])) return row[idx];
        }
        // Global localization bridge: strings listed in the coverage report
        // are compiled into locale resources with a deterministic key.
        // This catches old hard-coded UI text without changing locked screens.
        try {
            java.util.zip.CRC32 crc=new java.util.zip.CRC32();
            crc.update(value.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            String name="auto_"+String.format(java.util.Locale.US,"%08x",crc.getValue());
            int id=getResources().getIdentifier(name,"string",getPackageName());
            if(id!=0) return getString(id);
        } catch(Exception ignored) {}
        return value;
    }

    String trUi(String tr,String en){
        if("tr".equals(language)) return tr;
        if("en".equals(language)) return en;
        String translated=legacyTranslate(tr);
        return translated.equals(tr)?en:translated;
    }
    void loadAccounts(){ accounts.clear(); String raw=getPreferences(0).getString("accounts","Genel"); for(String a:raw.split("\\|")){a=a.trim();if(!a.isEmpty()&&!accounts.contains(a))accounts.add(a);} if(accounts.isEmpty())accounts.add("Genel"); }
    void saveAccounts(){ getPreferences(0).edit().putString("accounts",android.text.TextUtils.join("|",accounts)).apply(); }
    double accountBalance(String account){ double v=0; for(Tx t:txs){if(t.archived||t.cancelled)continue; if(!account.equals(t.account==null?"Genel":t.account))continue; if(t.creditCard)continue; v+=t.isIncome?t.amount:-t.amount;} for(CardPayment cp:cardPayments)if(!cp.cancelled&&account.equals(cp.account==null?"Genel":cp.account))v-=cp.amount; return v; }
    void showAccounts(){ enterScreen("accounts"); marketsVisible=false; currentPage=3; base(trUi("Hesaplarım","My Accounts")); Colors c=C(); LinearLayout hero=card(darkMode?Color.rgb(18,45,64):Color.rgb(238,247,255),20); hero.setPadding(dp(16),dp(14),dp(16),dp(14)); TextView h=text(trUi("Paranı nerede tuttuğunu yönet","Manage where you keep your money"),18,c.text); h.setTypeface(null,Typeface.BOLD); hero.addView(h); TextView hs=text(trUi("Banka, nakit ve diğer hesaplarını tek yerde takip et.","Track bank, cash and other accounts in one place."),11,c.muted); margins(hs,0,4,0,0); hero.addView(hs); margins(hero,0,0,0,12); content.addView(hero); Button add=button("＋  "+trUi("Hesap Ekle","Add Account"),c.blue); margins(add,0,0,0,12); content.addView(add); add.setOnClickListener(v->accountDialog(null)); double total=0; for(String a:accounts)total+=accountBalance(a); TextView totalText=text(trUi("Toplam hesap bakiyesi","Total account balance")+"  "+money(total),17,total>=0?c.green:c.red); totalText.setTypeface(null,Typeface.BOLD); margins(totalText,2,0,2,10); content.addView(totalText); for(String a:new ArrayList<>(accounts)){ LinearLayout card=card(c.surface,18); card.setPadding(dp(14),dp(12),dp(12),dp(12)); LinearLayout r=row(); SimpleIconView ic=new SimpleIconView(this,"wallet",c.blue); r.addView(ic,new LinearLayout.LayoutParams(dp(44),dp(44))); LinearLayout cp=new LinearLayout(this);cp.setOrientation(LinearLayout.VERTICAL);cp.setPadding(dp(10),0,0,0);TextView n=text(accountDisplayName(a),15,c.text);n.setTypeface(null,Typeface.BOLD);cp.addView(n);TextView b=text(money(accountBalance(a)),14,accountBalance(a)>=0?c.green:c.red);margins(b,0,3,0,0);cp.addView(b);r.addView(cp,new LinearLayout.LayoutParams(0,-2,1));TextView ar=text("›",28,c.muted);r.addView(ar,new LinearLayout.LayoutParams(dp(28),dp(42)));card.addView(r); margins(card,0,0,0,8);content.addView(card); card.setOnClickListener(v->accountDialog(a)); } }
    void accountDialog(final String existing){ Colors c=C(); Dialog d=new Dialog(this); d.requestWindowFeature(Window.FEATURE_NO_TITLE); LinearLayout o=new LinearLayout(this);o.setOrientation(LinearLayout.VERTICAL);o.setPadding(dp(18),dp(18),dp(18),dp(12));o.setBackground(bg(c.surface,24)); TextView h=text(existing==null?trUi("Hesap Ekle","Add Account"):trUi("Hesabı Düzenle","Edit Account"),20,c.text);h.setTypeface(null,Typeface.BOLD);o.addView(h); EditText name=modernEdit(trUi("Hesap adı","Account name"),c);if(existing!=null)name.setText(existing);margins(name,0,12,0,0);o.addView(name,new LinearLayout.LayoutParams(-1,dp(54))); LinearLayout acts=row();Button cancel=dialogButton(trUi("Vazgeç","Cancel"),c.muted,c.surface);Button save=dialogButton(trUi("Kaydet","Save"),Color.WHITE,c.blue);acts.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(52),1);sp.setMargins(dp(8),0,0,0);acts.addView(save,sp);margins(acts,0,14,0,0);o.addView(acts);
        Button delete=null; if(existing!=null && !"Genel".equals(existing)){ delete=button(trUi("Hesabı Sil","Delete Account"),c.red); margins(delete,0,10,0,0); o.addView(delete,new LinearLayout.LayoutParams(-1,dp(48))); delete.setOnClickListener(v->{accounts.remove(existing);for(Tx t:txs)if(existing.equals(t.account))t.account="Genel";saveAccounts();save();d.dismiss();showAccounts();}); }
        cancel.setOnClickListener(v->d.dismiss());save.setOnClickListener(v->{String n=name.getText().toString().trim();if(n.isEmpty())return;if(existing!=null&&!existing.equals(n)){for(Tx t:txs)if(existing.equals(t.account))t.account=n;accounts.remove(existing);}if(!accounts.contains(n))accounts.add(n);saveAccounts();save();d.dismiss();showAccounts();});d.setContentView(o);d.show();Window w=d.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);}}
    void showTransactionFilterDialog(final String[] typeFilter,final String[] catFilter,final Runnable refresh){ Colors c=C();Dialog d=new Dialog(this);d.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout o=new LinearLayout(this);o.setOrientation(LinearLayout.VERTICAL);o.setPadding(dp(18),dp(18),dp(18),dp(12));o.setBackground(bg(c.surface,24));TextView h=text(trUi("İşlem Filtresi","Transaction Filter"),20,c.text);h.setTypeface(null,Typeface.BOLD);o.addView(h);TextView tt=text(trUi("Tür","Type"),12,c.muted);margins(tt,0,12,0,4);o.addView(tt);LinearLayout types=card(c.surface2,14);types.setPadding(dp(8),dp(4),dp(8),dp(4));addChoice(types,trUi("Tümü","All"),"all".equals(typeFilter[0]),()->{typeFilter[0]="all";d.dismiss();refresh.run();});addChoice(types,trUi("Gelir","Income"),"income".equals(typeFilter[0]),()->{typeFilter[0]="income";d.dismiss();refresh.run();});addChoice(types,trUi("Harcama","Expense"),"expense".equals(typeFilter[0]),()->{typeFilter[0]="expense";d.dismiss();refresh.run();});o.addView(types);TextView ct=text(trUi("Kategori","Category"),12,c.muted);margins(ct,0,12,0,4);o.addView(ct);for(Category cat:categories){if("Kredi Kartı".equals(cat.name))continue; final String n=cat.name;TextView row=text((n.equals(catFilter[0])?"●  ":"○  ")+categoryLabel(n),14,n.equals(catFilter[0])?c.blue:c.text);row.setPadding(dp(8),dp(10),dp(8),dp(10));o.addView(row);row.setOnClickListener(v->{catFilter[0]=n;d.dismiss();refresh.run();});}TextView all=text(("all".equals(catFilter[0])?"●  ":"○  ")+trUi("Tüm kategoriler","All categories"),14,"all".equals(catFilter[0])?c.blue:c.text);all.setPadding(dp(8),dp(10),dp(8),dp(10));o.addView(all,1);all.setOnClickListener(v->{catFilter[0]="all";d.dismiss();refresh.run();});d.setContentView(o);d.show();Window w=d.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);}}

    void loadCreditCards(){
        creditCards.clear();installments.clear();
        try{
            JSONArray a=new JSONArray(getPreferences(0).getString("creditCards","[]"));
            for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);creditCards.add(new CreditCard(o.optLong("id",System.currentTimeMillis()+i),o.optString("name","Kredi Kartı"),o.optString("bank",""),o.optDouble("limit",0),o.optDouble("debt",0),o.optDouble("statementDebt",0),o.optDouble("minPayment",0),o.optInt("statementDay",1),o.optInt("dueDay",10)));}
            JSONArray b=new JSONArray(getPreferences(0).getString("installments","[]"));
            for(int i=0;i<b.length();i++){JSONObject o=b.getJSONObject(i);installments.add(new Installment(o.optLong("id",System.currentTimeMillis()+i),o.optLong("cardId",0),o.optString("merchant","Taksit"),o.optDouble("total",0),o.optInt("count",1),o.optInt("paidCount",0),o.optString("firstDate",df.format(new Date())),o.optString("note",""),o.optBoolean("debtTracked",false)));}
        }catch(Exception ignored){}
    }
    void saveCreditCards(){try{JSONArray a=new JSONArray();for(CreditCard c:creditCards){JSONObject o=new JSONObject();o.put("id",c.id);o.put("name",c.name);o.put("bank",c.bank);o.put("limit",c.limit);o.put("debt",c.debt);o.put("statementDebt",c.statementDebt);o.put("minPayment",c.minPayment);o.put("statementDay",c.statementDay);o.put("dueDay",c.dueDay);a.put(o);}getPreferences(0).edit().putString("creditCards",a.toString()).apply();}catch(Exception ignored){}}
    void saveInstallments(){try{JSONArray a=new JSONArray();for(Installment in:installments){JSONObject o=new JSONObject();o.put("id",in.id);o.put("cardId",in.cardId);o.put("merchant",in.merchant);o.put("total",in.total);o.put("count",in.count);o.put("paidCount",in.paidCount);o.put("firstDate",in.firstDate);o.put("note",in.note);o.put("debtTracked",in.debtTracked);a.put(o);}getPreferences(0).edit().putString("installments",a.toString()).apply();}catch(Exception ignored){}}
    void loadCardPayments(){cardPayments.clear();try{JSONArray a=new JSONArray(getPreferences(0).getString("cardPayments","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);CardPayment cp=new CardPayment(o.optLong("id",System.currentTimeMillis()+i),o.optLong("cardId",0),o.optLong("installmentId",0),o.optDouble("amount",0),o.optString("date",df.format(new Date())),o.optString("note",""),o.optString("account","Genel"));cp.cancelled=o.optBoolean("cancelled",false);cardPayments.add(cp);}}catch(Exception ignored){}}
    void saveCardPayments(){try{JSONArray a=new JSONArray();for(CardPayment cp:cardPayments){JSONObject o=new JSONObject();o.put("id",cp.id);o.put("cardId",cp.cardId);o.put("installmentId",cp.installmentId);o.put("amount",cp.amount);o.put("date",cp.date);o.put("note",cp.note);o.put("account",cp.account==null?"Genel":cp.account);o.put("cancelled",cp.cancelled);a.put(o);}getPreferences(0).edit().putString("cardPayments",a.toString()).apply();}catch(Exception ignored){}}
    void creditCardPaymentDialog(final CreditCard cc){
        Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(18),dp(18),dp(18),dp(12));outer.setBackground(bg(c.surface,24));
        TextView h=text("₺  Kredi Kartı Ödemesi",20,c.text);h.setTypeface(null,1);outer.addView(h);TextView info=text(cc.name+"  •  Güncel borç: "+money(cc.debt),12,c.muted);margins(info,0,4,0,12);outer.addView(info);
        EditText amount=cardNumberEdit("Ödeme tutarı",c);outer.addView(amount,new LinearLayout.LayoutParams(-1,dp(54)));
        ArrayList<String> accountOptions=new ArrayList<>(accounts);if(accountOptions.isEmpty())accountOptions.add("Genel");final String[] selectedAccount={accountOptions.get(0)};TextView al=text("Ödeme hesabı",12,c.text);al.setTypeface(null,1);margins(al,0,9,0,5);outer.addView(al);LinearLayout accountSelector=accountSelectorCard(selectedAccount[0]);outer.addView(accountSelector,new LinearLayout.LayoutParams(-1,dp(64)));accountSelector.setOnClickListener(v->showAccountPicker(accountOptions,selectedAccount,accountSelector));
        EditText date=modernEdit("Ödeme tarihi",c);date.setText(df.format(new Date()));margins(date,0,8,0,0);outer.addView(date,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText note=modernEdit("Not (isteğe bağlı)",c);margins(note,0,8,0,0);outer.addView(note,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView warn=text("Bu işlem sadece kart borcunu azaltır. Taksit planları otomatik olarak değiştirilmez.",11,c.muted);margins(warn,0,8,0,0);outer.addView(warn);
        LinearLayout acts=row();Button cancel=dialogButton("Vazgeç",c.muted,c.surface);Button save=dialogButton("Ödemeyi Yap",Color.WHITE,c.green);acts.addView(cancel,new LinearLayout.LayoutParams(0,dp(54),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(54),1);sp.setMargins(dp(8),0,0,0);acts.addView(save,sp);margins(acts,0,10,0,0);outer.addView(acts);
        cancel.setOnClickListener(v->dlg.dismiss());save.setOnClickListener(v->{try{double a=parseNum(amount);if(a<=0||a>cc.debt+0.0001)throw new Exception();String dt=date.getText().toString().trim();if(dt.length()!=10)dt=df.format(new Date());String noteText=note.getText().toString().trim();long paymentId=System.currentTimeMillis();cardPayments.add(new CardPayment(paymentId,cc.id,0,a,dt,noteText,selectedAccount[0]));Tx tx=new Tx(System.currentTimeMillis(),false,a,"Kredi Kartı Ödemesi - "+cc.name,dt,"Kredi Kartı Ödemesi",true,cc.id,paymentId);tx.account=selectedAccount[0];txs.add(tx);cc.debt=Math.max(0,cc.debt-a);cc.statementDebt=Math.max(0,cc.statementDebt-a);cc.minPayment=minimumPaymentForCard(cc);save();saveCreditCards();saveCardPayments();dlg.dismiss();showCreditCards();Toast.makeText(this,"Kart borcu güncellendi. Ekstre dönem borcu da güncellendi.",Toast.LENGTH_SHORT).show();}catch(Exception e){amount.setError("Geçerli bir ödeme tutarı girin");}});
        dlg.setContentView(outer);Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}dlg.setOnShowListener(x->{Window ww=dlg.getWindow();if(ww!=null)ww.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);});dlg.show();
    }

    void installmentPaymentDialog(final Installment in){
        CreditCard cc=findCard(in.cardId);if(cc==null||in.paidCount>=in.count)return;Colors c=C();double amount=installmentMonthly(in);Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(18),dp(18),dp(18),dp(12));outer.setBackground(bg(c.surface,24));
        TextView h=text("✓ Taksiti Öde",20,c.text);h.setTypeface(null,1);outer.addView(h);TextView info=text(in.merchant+"  •  "+(in.paidCount+1)+" / "+in.count+". taksit",12,c.muted);margins(info,0,4,0,12);outer.addView(info);
        LinearLayout amountCard=card(c.bg,16);amountCard.setPadding(dp(14),dp(12),dp(14),dp(12));TextView amountTitle=text("Bu taksit",11,c.muted);amountCard.addView(amountTitle);TextView amountValue=text(money(amount),22,c.text);amountValue.setTypeface(null,1);margins(amountValue,0,2,0,0);amountCard.addView(amountValue);margins(amountCard,0,0,0,10);outer.addView(amountCard);
        ArrayList<String> accountOptions=new ArrayList<>(accounts);if(accountOptions.isEmpty())accountOptions.add("Genel");final String[] selectedAccount={accountOptions.get(0)};TextView al=text("Ödeme hesabı",12,c.text);al.setTypeface(null,1);margins(al,0,8,0,5);outer.addView(al);LinearLayout accountSelector=accountSelectorCard(selectedAccount[0]);outer.addView(accountSelector,new LinearLayout.LayoutParams(-1,dp(64)));accountSelector.setOnClickListener(v->showAccountPicker(accountOptions,selectedAccount,accountSelector));
        EditText date=modernEdit("Ödeme tarihi",c);date.setText(df.format(new Date()));margins(date,0,8,0,0);outer.addView(date,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView hint=text("Ödeme yapıldığında kart borcu azalır ve bu taksit otomatik olarak ödendi olarak işaretlenir. Genel kart ödemeleri diğer taksitleri değiştirmez.",11,c.muted);margins(hint,0,8,0,0);outer.addView(hint);
        LinearLayout acts=row();Button cancel=dialogButton("Vazgeç",c.muted,c.surface);Button save=dialogButton("Taksiti Öde",Color.WHITE,c.green);acts.addView(cancel,new LinearLayout.LayoutParams(0,dp(54),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(54),1);sp.setMargins(dp(8),0,0,0);acts.addView(save,sp);margins(acts,0,10,0,0);outer.addView(acts);
        cancel.setOnClickListener(v->dlg.dismiss());save.setOnClickListener(v->{try{String dt=date.getText().toString().trim();if(dt.length()!=10)dt=df.format(new Date());long paymentId=System.currentTimeMillis();cardPayments.add(new CardPayment(paymentId,cc.id,in.id,amount,dt,"Taksit: "+in.merchant,selectedAccount[0]));Tx tx=new Tx(System.currentTimeMillis(),false,amount,"Taksit Ödemesi - "+in.merchant,dt,"Kredi Kartı Taksiti",true,cc.id,paymentId);tx.account=selectedAccount[0];txs.add(tx);cc.debt=Math.max(0,cc.debt-amount);cc.statementDebt=Math.max(0,cc.statementDebt-amount);cc.minPayment=minimumPaymentForCard(cc);in.paidCount=Math.min(in.count,in.paidCount+1);save();saveCreditCards();saveInstallments();saveCardPayments();dlg.dismiss();showCreditCards();Toast.makeText(this,"Taksit ve ekstre borcu güncellendi.",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Taksit ödemesi kaydedilemedi.",Toast.LENGTH_SHORT).show();}});
        dlg.setContentView(outer);Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}dlg.show();w=dlg.getWindow();if(w!=null)w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);
    }

    void loadGoals(){
        goals.clear();completedGoals.clear();
        try{
            JSONArray a=new JSONArray(getPreferences(0).getString("goals","[]"));
            for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Goal g=new Goal(o.getLong("id"),o.optString("name",""),o.optString("icon","🎯"),o.optDouble("target",0),o.optDouble("saved",0),o.optString("deadline",""));if(g.saved>=g.target&&g.target>0)completedGoals.add(g);else goals.add(g);}
            JSONArray done=new JSONArray(getPreferences(0).getString("completedGoals","[]"));
            for(int i=0;i<done.length();i++){JSONObject o=done.getJSONObject(i);completedGoals.add(new Goal(o.getLong("id"),o.optString("name",""),o.optString("icon","🎯"),o.optDouble("target",0),o.optDouble("saved",0),o.optString("deadline","")));}
        }catch(Exception ignored){}
    }
    void saveGoals(){try{
        JSONArray a=new JSONArray();for(Goal g:goals){JSONObject o=new JSONObject();o.put("id",g.id);o.put("name",g.name);o.put("icon",g.icon);o.put("target",g.target);o.put("saved",g.saved);o.put("deadline",g.deadline);a.put(o);}getPreferences(0).edit().putString("goals",a.toString()).apply();
        JSONArray done=new JSONArray();for(Goal g:completedGoals){JSONObject o=new JSONObject();o.put("id",g.id);o.put("name",g.name);o.put("icon",g.icon);o.put("target",g.target);o.put("saved",g.saved);o.put("deadline",g.deadline);done.put(o);}getPreferences(0).edit().putString("completedGoals",done.toString()).apply();
    }catch(Exception ignored){}}
    void load(){try{JSONArray a=new JSONArray(getPreferences(0).getString("txs","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Tx t=new Tx(o.getLong("id"),o.getBoolean("income"),o.getDouble("amount"),o.optString("desc",""),o.optString("date",df.format(new Date())),o.optString("cat","Diğer"),o.optBoolean("creditCard",false),o.optLong("cardId",0),o.optLong("paymentId",0),o.optBoolean("archived",false));t.account=o.optString("account","Genel"); t.cancelled=o.optBoolean("cancelled",false);txs.add(t);}}catch(Exception ignored){}}
    void initFixedCategories(){
        categories.clear();
        categories.add(new Category("Market","cart"));
        categories.add(new Category("Kredi Kartı","card"));
        categories.add(new Category("Yemek","food"));
        categories.add(new Category("Fatura","bill"));
        categories.add(new Category("Eğlence","fun"));
        categories.add(new Category("Ulaşım","car"));
        categories.add(new Category("Ev","home"));
        categories.add(new Category("Sağlık","health"));
        categories.add(new Category("Eğitim","school"));
        categories.add(new Category("Giyim","shirt"));
        categories.add(new Category("Seyahat","travel"));
        categories.add(new Category("Yakıt","fuel"));
        categories.add(new Category("Diğer","other"));
    }
    String categoryLabel(String name){
        if(name==null)return s(R.string.ui_43f708ea9b);
        if(name.equals("Market"))return s(R.string.ui_4e963a8029);
        if(name.equals("Kredi Kartı"))return s(R.string.ui_b983b72fc2);
        if(name.equals("Yemek"))return s(R.string.ui_61fe53686c);
        if(name.equals("Fatura"))return s(R.string.ui_d5a688604f);
        if(name.equals("Eğlence"))return s(R.string.ui_389b28acd1);
        if(name.equals("Ulaşım"))return s(R.string.ui_c240b7a804);
        if(name.equals("Ev"))return s(R.string.ui_8e6e52146e);
        if(name.equals("Sağlık"))return s(R.string.ui_5439c0e763);
        if(name.equals("Eğitim"))return s(R.string.ui_ca2db1a287);
        if(name.equals("Giyim"))return s(R.string.ui_75b4e6444a);
        if(name.equals("Seyahat"))return s(R.string.ui_f0c16083f1);
        if(name.equals("Yakıt"))return s(R.string.ui_ac5068b436);
        return s(R.string.ui_43f708ea9b);
    }
}