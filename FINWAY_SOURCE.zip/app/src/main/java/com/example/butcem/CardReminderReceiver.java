package com.example.butcem;

import android.app.*;
import android.content.*;
import android.os.Build;
import android.net.Uri;
import androidx.core.app.NotificationCompat;
import org.json.*;
import java.util.*;

public class CardReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL="finway_card_reminders_v2";
    private static final String CHANNEL_SILENT="finway_card_reminders_silent_v2";
    private static final int REQ_BASE=41000;

    private int requestCode(long cardId, boolean custom){
        long v=Math.abs(cardId%300000);
        return REQ_BASE+(int)v+(custom?400000:0);
    }
    private boolean canScheduleExact(AlarmManager am){
        if(Build.VERSION.SDK_INT<31)return true;
        try{return am.canScheduleExactAlarms();}catch(Exception e){return false;}
    }
    private void setAlarm(AlarmManager am,long when,PendingIntent pi){
        if(Build.VERSION.SDK_INT>=23){
            if(canScheduleExact(am))am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
        }else am.setExact(AlarmManager.RTC_WAKEUP,when,pi);
    }
    private java.text.SimpleDateFormat df(){return new java.text.SimpleDateFormat("dd.MM.yyyy",new Locale("tr","TR"));}

    @Override public void onReceive(Context context, Intent intent){
        String action=intent.getAction();
        if(Intent.ACTION_BOOT_COMPLETED.equals(action) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)){
            scheduleAll(context);
            return;
        }
        String name=intent.getStringExtra("cardName");
        if(name==null||name.trim().isEmpty())name="Kredi Kartı";
        boolean custom=intent.getBooleanExtra("custom",false);
        boolean sound=intent.getBooleanExtra("sound",true);
        String language = context.getSharedPreferences("MainActivity", Context.MODE_PRIVATE).getString("lang", "tr");
        String[] message = localizedMessage(language, name, custom);
        String title = message[0];
        String text = message[1];
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        String channel= sound ? CHANNEL : CHANNEL_SILENT;
        if(Build.VERSION.SDK_INT>=26){
            Uri soundUri=Uri.parse("android.resource://"+context.getPackageName()+"/"+com.example.butcem.R.raw.finway_reminder);
            android.media.AudioAttributes attrs=new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
            String[] channelNames = localizedChannelNames(language);
            NotificationChannel soundCh=new NotificationChannel(CHANNEL,channelNames[0],NotificationManager.IMPORTANCE_HIGH);
            soundCh.setSound(soundUri,attrs);soundCh.enableVibration(true);nm.createNotificationChannel(soundCh);
            NotificationChannel silentCh=new NotificationChannel(CHANNEL_SILENT,channelNames[1],NotificationManager.IMPORTANCE_HIGH);
            silentCh.setSound(null,null);silentCh.enableVibration(true);nm.createNotificationChannel(silentCh);
        }
        Intent open=new Intent(context,MainActivity.class); open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi=PendingIntent.getActivity(context,9001,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        saveInAppNotification(context,title,text);

        NotificationCompat.Builder b=new NotificationCompat.Builder(context,channel)
            .setSmallIcon(com.example.butcem.R.mipmap.ic_launcher)
            .setContentTitle(title).setContentText(text).setStyle(new NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pi)
            .setVibrate(new long[]{0,180,100,220});
        nm.notify((int)(System.currentTimeMillis()%1000000),b.build());
        if(custom){
            context.getSharedPreferences("MainActivity",Context.MODE_PRIVATE).edit().remove("customReminder_"+intent.getLongExtra("cardId",0)).apply();
        }else{
            rearmMonthly(context,intent,name,sound);
        }
    }

    private void saveInAppNotification(Context context,String title,String text){
        try{
            android.content.SharedPreferences sp=context.getSharedPreferences("MainActivity",Context.MODE_PRIVATE);
            JSONArray a=new JSONArray(sp.getString("appNotifications","[]"));
            JSONObject o=new JSONObject();o.put("id",System.currentTimeMillis());o.put("time",System.currentTimeMillis());o.put("title",title);o.put("body",text);o.put("category","card");o.put("action","cards");o.put("priority",2);o.put("read",false);
            a.put(o);
            while(a.length()>50)a.remove(0);
            sp.edit().putString("appNotifications",a.toString()).apply();
            context.sendBroadcast(new Intent("com.example.butcem.NOTIFICATION_ADDED"));
        }catch(Exception ignored){}
    }

    private String[] localizedChannelNames(String language){
        if("en".equals(language)) return new String[]{"Finway Card Reminders", "Finway Card Reminders (Silent)"};
        if("fr".equals(language)) return new String[]{"Rappels de carte bancaire Finway", "Rappels de carte bancaire Finway (silencieux)"};
        if("ru".equals(language)) return new String[]{"Напоминания Finway о кредитных картах", "Напоминания Finway о кредитных картах (без звука)"};
        if("de".equals(language)) return new String[]{"Finway-Kreditkartenerinnerungen", "Finway-Kreditkartenerinnerungen (stumm)"};
        if("ja".equals(language)) return new String[]{"Finway クレジットカードのリマインダー", "Finway クレジットカードのリマインダー（サイレント）"};
        if("zh".equals(language)) return new String[]{"Finway 信用卡提醒", "Finway 信用卡提醒（静音）"};
        if("ar".equals(language)) return new String[]{"تذكيرات بطاقات الائتمان في Finway", "تذكيرات بطاقات الائتمان في Finway (صامتة)"};
        if("el".equals(language)) return new String[]{"Υπενθυμίσεις πιστωτικών καρτών Finway", "Υπενθυμίσεις πιστωτικών καρτών Finway (αθόρυβες)"};
        if("es".equals(language)) return new String[]{"Recordatorios de tarjetas de crédito de Finway", "Recordatorios de tarjetas de crédito de Finway (silenciosos)"};
        if("it".equals(language)) return new String[]{"Promemoria delle carte di credito Finway", "Promemoria delle carte di credito Finway (silenziosi)"};
        return new String[]{"Finway Kredi Kartı Hatırlatıcıları", "Finway Kredi Kartı Hatırlatıcıları (Sessiz)"};
    }

    /**
     * Notification copy is localized independently from the Activity so the
     * language selected in Finway is also respected when the app is closed.
     * All variants use formal/polite address and native punctuation.
     */
    private String[] localizedMessage(String language, String name, boolean custom){
        String safeName = (name == null || name.trim().isEmpty()) ? "Kredi Kartınız" : name.trim();
        if("en".equals(language)){
            return custom
                ? new String[]{"Credit card reminder", safeName+" — your reminder time has arrived. Open Finway to review your payment."}
                : new String[]{"Credit card payment reminder", safeName+" — your payment due date is approaching. Open Finway to review your payment."};
        }
        if("fr".equals(language)){
            return custom
                ? new String[]{"Rappel de carte bancaire", "Le rappel que vous avez défini pour "+safeName+" est arrivé. Ouvrez Finway pour vérifier votre paiement."}
                : new String[]{"Rappel de paiement par carte", "La date d’échéance du paiement de "+safeName+" approche. Ouvrez Finway pour vérifier votre paiement."};
        }
        if("ru".equals(language)){
            return custom
                ? new String[]{"Напоминание о кредитной карте", "Наступило время напоминания, которое вы установили для карты «"+safeName+"». Откройте Finway, чтобы проверить платеж."}
                : new String[]{"Напоминание о платеже по карте", "Приближается срок платежа по карте «"+safeName+"». Откройте Finway, чтобы проверить платеж."};
        }
        if("de".equals(language)){
            return custom
                ? new String[]{"Kreditkarten-Erinnerung", "Die von Ihnen für „"+safeName+"“ festgelegte Erinnerung ist fällig. Öffnen Sie Finway, um Ihre Zahlung zu prüfen."}
                : new String[]{"Erinnerung an die Kreditkartenzahlung", "Der Zahlungstermin für „"+safeName+"“ rückt näher. Öffnen Sie Finway, um Ihre Zahlung zu prüfen."};
        }
        if("ja".equals(language)){
            return custom
                ? new String[]{"クレジットカードのお知らせ", "「"+safeName+"」に設定したリマインダーの時刻になりました。Finwayを開いてお支払いをご確認ください。"}
                : new String[]{"クレジットカードのお支払いのお知らせ", "「"+safeName+"」のお支払い期限が近づいています。Finwayを開いてお支払いをご確認ください。"};
        }
        if("zh".equals(language)){
            return custom
                ? new String[]{"信用卡提醒", "您为“"+safeName+"”设置的提醒时间已到。请打开 Finway 查看您的付款情况。"}
                : new String[]{"信用卡还款提醒", "“"+safeName+"”的还款日期即将到来。请打开 Finway 查看您的付款情况。"};
        }
        if("ar".equals(language)){
            return custom
                ? new String[]{"تذكير ببطاقة الائتمان", "حان موعد التذكير الذي قمتم بتعيينه لبطاقة «"+safeName+"». افتحوا Finway للتحقق من عملية الدفع."}
                : new String[]{"تذكير بسداد بطاقة الائتمان", "اقترب موعد سداد بطاقة «"+safeName+"». افتحوا Finway للتحقق من عملية الدفع."};
        }
        if("el".equals(language)){
            return custom
                ? new String[]{"Υπενθύμιση πιστωτικής κάρτας", "Έφτασε η ώρα της υπενθύμισης που ορίσατε για την κάρτα «"+safeName+"». Ανοίξτε το Finway για να ελέγξετε την πληρωμή σας."}
                : new String[]{"Υπενθύμιση πληρωμής πιστωτικής κάρτας", "Η ημερομηνία πληρωμής για την κάρτα «"+safeName+"» πλησιάζει. Ανοίξτε το Finway για να ελέγξετε την πληρωμή σας."};
        }
        if("es".equals(language)){
            return custom
                ? new String[]{"Recordatorio de tarjeta de crédito", "Ha llegado el momento del recordatorio que estableció para «"+safeName+"». Abra Finway para revisar su pago."}
                : new String[]{"Recordatorio de pago de tarjeta de crédito", "Se acerca la fecha de pago de «"+safeName+"». Abra Finway para revisar su pago."};
        }
        if("it".equals(language)){
            return custom
                ? new String[]{"Promemoria della carta di credito", "È arrivato il momento del promemoria impostato per «"+safeName+"». Apra Finway per controllare il pagamento."}
                : new String[]{"Promemoria del pagamento della carta di credito", "Si avvicina la scadenza del pagamento di «"+safeName+"». Apra Finway per controllare il pagamento."};
        }
        // Turkish is the default and uses formal "siz" language.
        return custom
            ? new String[]{"Kredi kartı hatırlatıcısı", safeName+" için belirlediğiniz hatırlatma zamanı geldi. Finway'i açarak ödemenizi kontrol edebilirsiniz."}
            : new String[]{"Kredi kartı ödeme hatırlatıcısı", safeName+" için son ödeme tarihi yaklaşıyor. Finway'i açarak ödemenizi kontrol edebilirsiniz."};
    }

    private void rearmMonthly(Context context,Intent source,String name,boolean sound){
        try{
            AlarmManager am=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);if(am==null)return;
            int dueDay=source.getIntExtra("dueDay",1),offset=source.getIntExtra("offset",5);
            Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,9);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);
            c.add(Calendar.MONTH,1);int max=c.getActualMaximum(Calendar.DAY_OF_MONTH);c.set(Calendar.DAY_OF_MONTH,Math.max(1,Math.min(dueDay,max)));c.add(Calendar.DAY_OF_MONTH,-Math.max(0,offset));
            Intent i=new Intent(context,CardReminderReceiver.class);i.putExtra("cardName",name);i.putExtra("dueDay",dueDay);i.putExtra("offset",offset);i.putExtra("cardId",source.getLongExtra("cardId",0));i.putExtra("custom",false);i.putExtra("sound",sound);
            PendingIntent p=PendingIntent.getBroadcast(context,requestCode(source.getLongExtra("cardId",0),false),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            setAlarm(am,c.getTimeInMillis(),p);
        }catch(Exception ignored){}
    }

    private void scheduleAll(Context context){
        try{
            android.content.SharedPreferences p=context.getSharedPreferences("MainActivity",Context.MODE_PRIVATE);
            int days=p.getInt("cardReminderDays",5); boolean sound=p.getBoolean("cardReminderSound",true);
            JSONArray a=new JSONArray(p.getString("creditCards","[]"));
            AlarmManager am=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);if(am==null)return;
            for(int x=0;x<a.length();x++){
                JSONObject o=a.getJSONObject(x);long id=o.optLong("id",0);String name=o.optString("name","Kredi Kartı");
                long custom=p.getLong("customReminder_"+id,-1L);
                if(custom>System.currentTimeMillis()){
                    Intent i=new Intent(context,CardReminderReceiver.class);i.putExtra("cardId",id);i.putExtra("cardName",name);i.putExtra("custom",true);i.putExtra("sound",sound);
                    PendingIntent pi=PendingIntent.getBroadcast(context,requestCode(id,true),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);setAlarm(am,custom,pi);
                }else if(custom>0){p.edit().remove("customReminder_"+id).apply();}
                if(custom<=System.currentTimeMillis() && days>0){
                    int dueDay=o.optInt("dueDay",10);Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,9);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);int max=c.getActualMaximum(Calendar.DAY_OF_MONTH);c.set(Calendar.DAY_OF_MONTH,Math.max(1,Math.min(dueDay,max)));if(c.before(Calendar.getInstance())){c.add(Calendar.MONTH,1);max=c.getActualMaximum(Calendar.DAY_OF_MONTH);c.set(Calendar.DAY_OF_MONTH,Math.max(1,Math.min(dueDay,max)));}c.add(Calendar.DAY_OF_MONTH,-days);
                    Intent i=new Intent(context,CardReminderReceiver.class);i.putExtra("cardId",id);i.putExtra("cardName",name);i.putExtra("dueDay",dueDay);i.putExtra("offset",days);i.putExtra("custom",false);i.putExtra("sound",sound);
                    PendingIntent pi=PendingIntent.getBroadcast(context,requestCode(id,false),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);setAlarm(am,c.getTimeInMillis(),pi);
                }
            }
        }catch(Exception ignored){}
    }
}
