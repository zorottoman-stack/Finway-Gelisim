package com.example.butcem;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Isolated receipt OCR layer. It only extracts data; MainActivity owns saving. */
final class ReceiptScanner {
    interface Callback {
        void onSuccess(Result result);
        void onFailure(String message);
    }

    static final class Result {
        String merchant = "";
        String date = "";
        Double amount = null;
        String rawText = "";
        String suggestedCategory = "Diğer";
    }

    private ReceiptScanner() {}

    static void scan(Context context, Uri uri, String language, Callback callback) {
        try {
            InputImage image = InputImage.fromFilePath(context, uri);
            TextRecognizer recognizer = recognizerFor(language);
            recognizer.process(image)
                .addOnSuccessListener(text -> {
                    try {
                        Result result = parse(text, language);
                        recognizer.close();
                        if (result.amount == null && result.merchant.isEmpty() && result.date.isEmpty()) {
                            callback.onFailure("Fişte okunabilir bir tutar veya bilgi bulunamadı.");
                        } else {
                            callback.onSuccess(result);
                        }
                    } catch (Exception e) {
                        recognizer.close();
                        callback.onFailure("Fiş bilgileri okunamadı. Fotoğrafı daha net bir şekilde deneyin.");
                    }
                })
                .addOnFailureListener(e -> {
                    recognizer.close();
                    callback.onFailure("Fiş okunamadı. Fotoğrafın net ve aydınlık olduğundan emin olun.");
                });
        } catch (Exception e) {
            callback.onFailure("Fiş görseli açılamadı. Lütfen başka bir fotoğraf seçin.");
        }
    }

    private static TextRecognizer recognizerFor(String language) {
        if ("zh".equals(language)) return TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
        if ("ja".equals(language)) return TextRecognition.getClient(new JapaneseTextRecognizerOptions.Builder().build());
        return TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }

    private static Result parse(Text text, String language) {
        Result result = new Result();
        String raw = text == null ? "" : text.getText();
        result.rawText = raw;
        ArrayList<String> lines = new ArrayList<>();
        if (raw != null) {
            for (String line : raw.split("\\R")) {
                String clean = line == null ? "" : line.trim();
                if (!clean.isEmpty()) lines.add(clean);
            }
        }
        result.merchant = findMerchant(lines);
        result.date = findDate(lines);
        result.amount = findTotal(lines);
        result.suggestedCategory = suggestCategory(raw);
        return result;
    }

    private static String findMerchant(ArrayList<String> lines) {
        String[] ignored = {"fiş", "fatura", "receipt", "invoice", "tax", "vergi", "kasiyer", "cashier", "tarih", "date", "saat", "time", "toplam", "total", "tutar", "amount", "ödeme", "payment", "müşteri", "customer"};
        int limit = Math.min(lines.size(), 7);
        for (int i = 0; i < limit; i++) {
            String line = lines.get(i).trim();
            String low = line.toLowerCase(Locale.ROOT);
            if (line.length() < 2 || line.length() > 70) continue;
            if (low.matches(".*\\d{3,}.*")) continue;
            boolean skip = false;
            for (String word : ignored) if (low.equals(word) || low.startsWith(word + " ")) { skip = true; break; }
            if (skip) continue;
            if (line.replaceAll("[^A-Za-zÇĞİÖŞÜçğıöşüÀ-ÿ\\u4e00-\\u9fff\\u3040-\\u30ff ]", "").trim().length() < 2) continue;
            return line;
        }
        return "";
    }

    private static String findDate(ArrayList<String> lines) {
        Pattern p1 = Pattern.compile("\\b(\\d{1,2})[./-](\\d{1,2})[./-](\\d{2,4})\\b");
        Pattern p2 = Pattern.compile("\\b(\\d{4})[./-](\\d{1,2})[./-](\\d{1,2})\\b");
        for (String line : lines) {
            Matcher m = p1.matcher(line);
            if (m.find()) {
                String y = m.group(3); if (y.length() == 2) y = "20" + y;
                String candidate = String.format(Locale.US, "%02d.%02d.%s", Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2)), y);
                if (validDate(candidate)) return candidate;
            }
            m = p2.matcher(line);
            if (m.find()) {
                String candidate = String.format(Locale.US, "%02d.%02d.%04d", Integer.parseInt(m.group(3)), Integer.parseInt(m.group(2)), Integer.parseInt(m.group(1)));
                if (validDate(candidate)) return candidate;
            }
        }
        return "";
    }

    private static boolean validDate(String value) {
        try {
            SimpleDateFormat f = new SimpleDateFormat("dd.MM.yyyy", Locale.US);
            f.setLenient(false);
            return f.parse(value, new ParsePosition(0)) != null;
        } catch (Exception ignored) { return false; }
    }

    private static Double findTotal(ArrayList<String> lines) {
        Pattern number = Pattern.compile("(?<!\\d)(\\d{1,3}(?:[. ]\\d{3})*(?:,\\d{1,2})?|\\d+(?:[.,]\\d{1,2})?)(?!\\d)");
        String[] totalWords = {"toplam", "total", "grand total", "amount due", "net total", "tutar", "ödenecek", "ödenecek tutar", "payment", "sum", "итого", "合計", "総額"};
        double best = -1; int bestScore = -999;
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            String low = line.toLowerCase(Locale.ROOT);
            Matcher m = number.matcher(line);
            while (m.find()) {
                Double value = parseNumber(m.group(1));
                if (value == null || value <= 0 || value > 100000000) continue;
                int score = i * 2;
                for (String word : totalWords) if (low.contains(word)) score += 100;
                if (low.contains("kdv") || low.contains("vergi") || low.contains("tax") || low.contains("vat")) score -= 35;
                if (low.contains("kart") || low.contains("card") || low.contains("tel") || low.contains("telefon")) score -= 40;
                if (looksLikeDateNumber(line, value)) score -= 30;
                if (score > bestScore || (score == bestScore && value > best)) { bestScore = score; best = value; }
            }
        }
        return best > 0 ? best : null;
    }

    private static boolean looksLikeDateNumber(String line, double value) {
        return line.matches(".*\\d{1,2}[./-]\\d{1,2}[./-]\\d{2,4}.*") || (value >= 1900 && value <= 2100);
    }

    private static Double parseNumber(String raw) {
        try {
            String x = raw.replace(" ", "");
            int comma = x.lastIndexOf(',');
            int dot = x.lastIndexOf('.');
            if (comma >= 0 && dot >= 0) {
                if (comma > dot) x = x.replace(".", "").replace(',', '.');
                else x = x.replace(",", "");
            } else if (comma >= 0) {
                x = x.replace(',', '.');
            } else if (dot >= 0) {
                int decimals = x.length() - dot - 1;
                if (decimals != 2 && x.indexOf('.') != x.lastIndexOf('.')) x = x.replace(".", "");
            }
            return Double.parseDouble(x);
        } catch (Exception ignored) { return null; }
    }

    private static String suggestCategory(String raw) {
        String x = raw == null ? "" : raw.toLowerCase(Locale.ROOT);
        if (containsAny(x, "market", "migros", "carrefour", "a101", "bim", "şok", "tesco", "lidl", "aldi", "grocery", "supermarket")) return "Market";
        if (containsAny(x, "restaurant", "cafe", "café", "coffee", "pizza", "burger", "yemek", "döner", "kebap", "starbucks", "mcdonald")) return "Yemek";
        if (containsAny(x, "shell", "opet", "petrol", "fuel", "akaryakıt", "benzin", "motorin", "gas station")) return "Yakıt";
        if (containsAny(x, "pharmacy", "eczane", "hospital", "hastane", "medical", "sağlık", "health")) return "Sağlık";
        if (containsAny(x, "hotel", "otel", "flight", "uçuş", "airport", "havaalanı", "travel")) return "Seyahat";
        if (containsAny(x, "cinema", "sinema", "theatre", "tiyatro", "game", "oyun", "entertainment")) return "Eğlence";
        if (containsAny(x, "electric", "electricity", "elektrik", "water", "su faturası", "internet", "doğalgaz", "gas bill")) return "Fatura";
        if (containsAny(x, "clothing", "giyim", "fashion", "zara", "h&m", "lc waikiki")) return "Giyim";
        if (containsAny(x, "school", "okul", "education", "eğitim", "university", "üniversite")) return "Eğitim";
        return "Diğer";
    }

    private static boolean containsAny(String text, String... values) {
        for (String value : values) if (text.contains(value)) return true;
        return false;
    }
}
