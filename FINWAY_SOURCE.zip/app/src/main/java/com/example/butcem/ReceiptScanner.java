package com.example.butcem;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.core.content.FileProvider;
import androidx.exifinterface.media.ExifInterface;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;

import java.io.File;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Isolated receipt capture/OCR layer. It never writes transactions itself;
 * MainActivity receives the extracted values and uses its existing expense form.
 */
final class ReceiptScanner {
    interface Callback {
        void onSuccess(ReceiptData data);
        void onError(String message);
    }

    static final class ReceiptData {
        final String merchant;
        final String date;
        final double amount;
        final String category;
        ReceiptData(String merchant, String date, double amount, String category) {
            this.merchant = merchant == null ? "" : merchant.trim();
            this.date = date == null ? "" : date.trim();
            this.amount = amount;
            this.category = category == null ? "" : category.trim();
        }
    }

    static final int CAMERA_PERMISSION = 9201;
    private final MainActivity host;
    private Uri cameraUri;
    private Callback callback;
    private Dialog progress;

    ReceiptScanner(MainActivity host) { this.host = host; }

    void chooseSource(Callback cb) {
        callback = cb;
        Dialog d = new Dialog(host);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout root = new LinearLayout(host);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(host.dp(20), host.dp(20), host.dp(20), host.dp(14));
        root.setBackground(host.bg(host.C().surface, 24));

        TextView title = host.text(host.s(R.string.ui_receipt_source_title), 20, host.C().text);
        title.setTypeface(android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD));
        root.addView(title);
        TextView sub = host.text(host.s(R.string.ui_receipt_source_subtitle), 12, host.C().muted);
        host.margins(sub, 0, 4, 0, 14);
        root.addView(sub);

        LinearLayout camera = sourceCard("camera", host.s(R.string.ui_receipt_camera), host.s(R.string.ui_receipt_camera_subtitle));
        LinearLayout gallery = sourceCard("image", host.s(R.string.ui_receipt_gallery), host.s(R.string.ui_receipt_gallery_subtitle));
        root.addView(camera, new LinearLayout.LayoutParams(-1, host.dp(72)));
        host.margins(gallery, 0, 8, 0, 0);
        root.addView(gallery, new LinearLayout.LayoutParams(-1, host.dp(72)));
        android.widget.Button cancel = host.dialogButton(host.s(R.string.ui_receipt_cancel), host.C().muted, host.C().surface);
        host.margins(cancel, 0, 12, 0, 0);
        root.addView(cancel, new LinearLayout.LayoutParams(-1, host.dp(48)));

        cancel.setOnClickListener(v -> d.dismiss());
        camera.setOnClickListener(v -> { d.dismiss(); openCamera(); });
        gallery.setOnClickListener(v -> { d.dismiss(); openGallery(); });

        d.setContentView(root);
        d.show();
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            w.setLayout(Math.min(host.getResources().getDisplayMetrics().widthPixels - host.dp(28), host.dp(430)), WindowManager.LayoutParams.WRAP_CONTENT);
        }
    }

    private LinearLayout sourceCard(String icon, String titleText, String subText) {
        LinearLayout card = host.card(host.C().surface2, 16);
        card.setPadding(host.dp(12), host.dp(10), host.dp(12), host.dp(10));
        LinearLayout row = host.row();
        MainActivity.SimpleIconView iv = host.new SimpleIconView(host, icon, host.C().blue);
        iv.setBackground(host.bg(host.C().blue2, 14));
        row.addView(iv, new LinearLayout.LayoutParams(host.dp(42), host.dp(42)));
        LinearLayout copy = new LinearLayout(host);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setPadding(host.dp(10), 0, host.dp(4), 0);
        TextView title = host.text(titleText, 14, host.C().text);
        title.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        copy.addView(title);
        TextView sub = host.text(subText, 11, host.C().muted);
        host.margins(sub, 0, 2, 0, 0);
        copy.addView(sub);
        row.addView(copy, new LinearLayout.LayoutParams(0, -2, 1));
        TextView arrow = host.text("›", 28, host.C().blue);
        arrow.setGravity(Gravity.CENTER);
        row.addView(arrow, new LinearLayout.LayoutParams(host.dp(28), host.dp(42)));
        card.addView(row);
        host.attachPressFeedback(card);
        return card;
    }

    private void openCamera() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && host.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            host.requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION);
            return;
        }
        launchCamera();
    }

    void onRequestPermissionsResult(int requestCode, int[] grantResults) {
        if (requestCode != CAMERA_PERMISSION) return;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) launchCamera();
        else fail(host.s(R.string.ui_receipt_camera_permission));
    }

    private void launchCamera() {
        try {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (intent.resolveActivity(host.getPackageManager()) == null) {
                fail(host.s(R.string.ui_receipt_camera_unavailable));
                return;
            }
            File dir = new File(host.getCacheDir(), "receipts");
            if (!dir.exists() && !dir.mkdirs()) throw new Exception("cache");
            File image = File.createTempFile("receipt_", ".jpg", dir);
            cameraUri = FileProvider.getUriForFile(host, host.getPackageName() + ".fileprovider", image);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            host.startActivityForResult(intent, MainActivity.REQ_RECEIPT_CAMERA);
        } catch (Exception e) {
            fail(host.s(R.string.ui_receipt_camera_unavailable));
        }
    }

    private void openGallery() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("image/*");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            host.startActivityForResult(intent, MainActivity.REQ_RECEIPT_GALLERY);
        } catch (Exception e) {
            fail(host.s(R.string.ui_receipt_gallery_unavailable));
        }
    }

    void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == MainActivity.REQ_RECEIPT_CAMERA && resultCode != Activity.RESULT_OK) {
            fail(host.s(R.string.ui_receipt_cancelled)); return;
        }
        if (requestCode == MainActivity.REQ_RECEIPT_GALLERY && resultCode != Activity.RESULT_OK) {
            fail(host.s(R.string.ui_receipt_cancelled)); return;
        }
        if (resultCode != Activity.RESULT_OK) return;
        Uri uri = requestCode == MainActivity.REQ_RECEIPT_CAMERA ? cameraUri : (data == null ? null : data.getData());
        if (uri == null) { fail(host.s(R.string.ui_receipt_read_error)); return; }
        runOcr(uri);
    }

    private void runOcr(Uri uri) {
        showProgress();
        Bitmap source = null;
        Bitmap enhanced = null;
        try {
            source = loadReceiptBitmap(uri);
            if (source == null) throw new Exception("bitmap");
            final Bitmap first = source;
            runRecognizer(first, new OcrPassCallback() {
                @Override public void onResult(String firstText) {
                    Bitmap enhancedLocal = null;
                    try {
                        enhancedLocal = enhanceReceiptBitmap(first);
                    } catch (Exception e) {
                        enhancedLocal = null;
                    }
                    final Bitmap second = enhancedLocal;
                    if (second == null) {
                        try {
                            Extraction only = extractWithConfidence(firstText);
                            if (only.data.amount > 0 || !TextUtils.isEmpty(only.data.merchant) || !TextUtils.isEmpty(only.data.date)) {
                                hideProgress();
                                if (callback != null) callback.onSuccess(only.data);
                            } else fail(host.s(R.string.ui_receipt_ocr_error));
                        } finally {
                            releaseBitmap(first);
                        }
                        return;
                    }
                    runRecognizer(second, new OcrPassCallback() {
                        @Override public void onResult(String secondText) {
                            try {
                                Extraction best = chooseBestExtraction(firstText, secondText);
                                if (best.data.amount <= 0 && TextUtils.isEmpty(best.data.merchant) && TextUtils.isEmpty(best.data.date)) {
                                    fail(host.s(R.string.ui_receipt_no_data));
                                } else if (callback != null) {
                                    hideProgress();
                                    callback.onSuccess(best.data);
                                }
                            } catch (Exception e) {
                                fail(host.s(R.string.ui_receipt_ocr_error));
                            } finally {
                                releaseBitmap(first);
                                releaseBitmap(second);
                            }
                        }
                        @Override public void onFailure(Exception error) {
                            try {
                                Extraction only = extractWithConfidence(firstText);
                                if (only.data.amount > 0 || !TextUtils.isEmpty(only.data.merchant) || !TextUtils.isEmpty(only.data.date)) {
                                    hideProgress();
                                    if (callback != null) callback.onSuccess(only.data);
                                } else fail(host.s(R.string.ui_receipt_ocr_error));
                            } finally {
                                releaseBitmap(first);
                                releaseBitmap(second);
                            }
                        }
                    });
                }
                @Override public void onFailure(Exception error) {
                    Bitmap enhancedLocal = null;
                    try { enhancedLocal = enhanceReceiptBitmap(first); } catch (Exception ignored) {}
                    final Bitmap second = enhancedLocal;
                    if (second == null) {
                        releaseBitmap(first);
                        fail(host.s(R.string.ui_receipt_ocr_error));
                        return;
                    }
                    runRecognizer(second, new OcrPassCallback() {
                        @Override public void onResult(String secondText) {
                            try {
                                Extraction only = extractWithConfidence(secondText);
                                if (only.data.amount > 0 || !TextUtils.isEmpty(only.data.merchant) || !TextUtils.isEmpty(only.data.date)) {
                                    hideProgress();
                                    if (callback != null) callback.onSuccess(only.data);
                                } else fail(host.s(R.string.ui_receipt_no_data));
                            } finally {
                                releaseBitmap(first);
                                releaseBitmap(second);
                            }
                        }
                        @Override public void onFailure(Exception ignored) {
                            releaseBitmap(first);
                            releaseBitmap(second);
                            fail(host.s(R.string.ui_receipt_ocr_error));
                        }
                    });
                }
            });
        } catch (Exception e) {
            releaseBitmap(source);
            releaseBitmap(enhanced);
            hideProgress();
            fail(host.s(R.string.ui_receipt_read_error));
        }
    }

    private interface OcrPassCallback {
        void onResult(String text);
        void onFailure(Exception error);
    }

    private void runRecognizer(Bitmap bitmap, OcrPassCallback cb) {
        if (bitmap == null) {
            cb.onFailure(new Exception("bitmap"));
            return;
        }
        TextRecognizer recognizer = recognizerForLanguage(host.receiptLanguage());
        try {
            InputImage image = InputImage.fromBitmap(bitmap, 0);
            recognizer.process(image)
                    .addOnSuccessListener(result -> cb.onResult(result == null ? "" : result.getText()))
                    .addOnFailureListener(e -> cb.onFailure(e instanceof Exception ? (Exception)e : new Exception(e)))
                    .addOnCompleteListener(task -> {
                        try { recognizer.close(); } catch (Exception ignored) {}
                    });
        } catch (Exception e) {
            try { recognizer.close(); } catch (Exception ignored) {}
            cb.onFailure(e);
        }
    }

    private Bitmap loadReceiptBitmap(Uri uri) throws Exception {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream in = host.getContentResolver().openInputStream(uri)) {
            if (in == null) throw new Exception("stream");
            BitmapFactory.decodeStream(in, null, bounds);
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw new Exception("dimensions");

        int max = 2400;
        int sample = 1;
        while (Math.max(bounds.outWidth / sample, bounds.outHeight / sample) > max) sample *= 2;
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap bitmap;
        try (InputStream in = host.getContentResolver().openInputStream(uri)) {
            if (in == null) throw new Exception("stream");
            bitmap = BitmapFactory.decodeStream(in, null, opts);
        }
        if (bitmap == null) throw new Exception("decode");

        try (InputStream in = host.getContentResolver().openInputStream(uri)) {
            if (in != null) {
                ExifInterface exif = new ExifInterface(in);
                int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                Bitmap rotated = rotateForExif(bitmap, orientation);
                if (rotated != bitmap) {
                    releaseBitmap(bitmap);
                    bitmap = rotated;
                }
            }
        } catch (Exception ignored) {
            // Some document providers do not expose EXIF. The original bitmap remains usable.
        }
        return bitmap;
    }

    private Bitmap rotateForExif(Bitmap bitmap, int orientation) {
        Matrix m = new Matrix();
        switch (orientation) {
            case ExifInterface.ORIENTATION_FLIP_HORIZONTAL: m.setScale(-1f, 1f); break;
            case ExifInterface.ORIENTATION_ROTATE_180: m.setRotate(180f); break;
            case ExifInterface.ORIENTATION_FLIP_VERTICAL: m.setScale(1f, -1f); break;
            case ExifInterface.ORIENTATION_TRANSPOSE: m.setRotate(90f); m.postScale(-1f, 1f); break;
            case ExifInterface.ORIENTATION_ROTATE_90: m.setRotate(90f); break;
            case ExifInterface.ORIENTATION_TRANSVERSE: m.setRotate(-90f); m.postScale(-1f, 1f); break;
            case ExifInterface.ORIENTATION_ROTATE_270: m.setRotate(-90f); break;
            default: return bitmap;
        }
        try { return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), m, true); }
        catch (Exception ignored) { return bitmap; }
    }

    private Bitmap enhanceReceiptBitmap(Bitmap source) {
        int w = source.getWidth(), h = source.getHeight();
        float scale = Math.min(1.35f, 2800f / Math.max(w, h));
        if (scale < 1f) scale = 1f;
        int nw = Math.max(1, Math.round(w * scale));
        int nh = Math.max(1, Math.round(h * scale));
        Bitmap out = Bitmap.createBitmap(nw, nh, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(0f);
        float contrast = 1.38f;
        float translate = -10f;
        cm.postConcat(new ColorMatrix(new float[] {
                contrast, 0, 0, 0, translate,
                0, contrast, 0, 0, translate,
                0, 0, contrast, 0, translate,
                0, 0, 0, 1, 0
        }));
        paint.setColorFilter(new ColorMatrixColorFilter(cm));
        canvas.drawBitmap(source, null, new android.graphics.Rect(0, 0, nw, nh), paint);
        return out;
    }

    private void releaseBitmap(Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
    }

    private static final class Extraction {
        final ReceiptData data;
        final double confidence;
        Extraction(ReceiptData data, double confidence) { this.data = data; this.confidence = confidence; }
    }

    private Extraction extractWithConfidence(String raw) {
        if (raw == null) raw = "";
        String[] lines = raw.replace('\r', '\n').split("\\n+");
        double[] total = findTotalWithScore(lines);
        ReceiptData data = new ReceiptData(findMerchant(lines), findDate(raw), total[0], inferCategory(raw));
        double confidence = total[1];
        if (!TextUtils.isEmpty(data.merchant)) confidence += 5;
        if (!TextUtils.isEmpty(data.date)) confidence += 4;
        if (!TextUtils.isEmpty(data.category)) confidence += 2;
        return new Extraction(data, confidence);
    }

    private Extraction chooseBestExtraction(String firstText, String secondText) {
        Extraction a = extractWithConfidence(firstText);
        Extraction b = extractWithConfidence(secondText);
        // Prefer the pass with a stronger total-label match. If totals agree,
        // prefer the pass that also recovered more receipt metadata.
        if (a.data.amount > 0 && b.data.amount > 0 && Math.abs(a.data.amount - b.data.amount) < 0.005) {
            return a.confidence >= b.confidence ? a : b;
        }
        return a.confidence >= b.confidence ? a : b;
    }

    private TextRecognizer recognizerForLanguage(String lang) {
        if ("zh".equals(lang)) return TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
        if ("ja".equals(lang)) return TextRecognition.getClient(new JapaneseTextRecognizerOptions.Builder().build());
        return TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }

    private void showProgress() {
        if (progress != null && progress.isShowing()) return;
        progress = new Dialog(host);
        progress.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(host.dp(20), host.dp(18), host.dp(20), host.dp(18));
        box.setBackground(host.bg(host.C().surface, 20));
        ProgressBar pb = new ProgressBar(host);
        box.addView(pb, new LinearLayout.LayoutParams(host.dp(28), host.dp(28)));
        TextView t = host.text(host.s(R.string.ui_receipt_scanning), 14, host.C().text);
        host.margins(t, host.dp(12), 0, 0, 0);
        box.addView(t);
        progress.setContentView(box);
        progress.setCancelable(false);
        progress.show();
        Window w = progress.getWindow();
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            w.setLayout(Math.min(host.getResources().getDisplayMetrics().widthPixels - host.dp(50), host.dp(360)), WindowManager.LayoutParams.WRAP_CONTENT);
        }
    }

    private void hideProgress() { if (progress != null) { try { progress.dismiss(); } catch (Exception ignored) {} } }

    private static final class AmountCandidate {
        final double value;
        final double score;
        AmountCandidate(double value, double score) { this.value = value; this.score = score; }
    }

    private double[] findTotalWithScore(String[] lines) {
        /*
         * Receipt layouts vary wildly. Do not take the largest number or the
         * last number on a line. Build candidates and score them from their
         * surrounding labels instead. Negative labels are especially
         * important because receipts commonly contain paid/cash/change/VAT
         * values that are larger or visually closer to the OCR result.
         */
        final String[] strong = {
                "genel toplam", "grand total", "amount due", "total due", "balance due",
                "toplam tutar", "ödenecek tutar", "odenecek tutar", "ödenecek", "odenecek",
                "gesamtbetrag", "gesamt summe", "gesamt", "totale generale", "totale",
                "importe total", "montant total", "итого", "итого к оплате", "合計", "総額"
        };
        final String[] medium = {
                "toplam", "total", "tutar", "payable", "due", "summe", "amount",
                "montant", "importe", "итог", "合計金額"
        };
        final String[] negative = {
                "ara toplam", "subtotal", "sub total", "interim total",
                "kdv", "vat", "mwst", "tax", "vergi", "steuer",
                "indirim", "discount", "rabatt", "скидка",
                "ödenen", "odenen", "paid", "payment", "zahlung", "оплачено",
                "nakit", "cash", "bargeld", "наличные",
                "para üstü", "paraustu", "change", "wechselgeld", "сдача",
                "kart", "card", "kreditkarte", "credit card", "картой",
                "puan", "point", "points", "coupon", "kupon",
                "ürün", "urun", "qty", "adet", "quantity", "miktar"
        };

        ArrayList<AmountCandidate> candidates = new ArrayList<>();
        for (int i = 0; i < lines.length; i++) {
            String original = lines[i] == null ? "" : lines[i].trim();
            if (original.isEmpty()) continue;
            String line = normalizeOcrText(original).toLowerCase(Locale.ROOT);
            List<Double> nums = numbers(original);
            if (nums.isEmpty()) continue;

            double lineScore = 0;
            boolean strongHit = false;
            boolean mediumHit = false;
            boolean negativeHit = false;

            for (String word : strong) {
                if (line.contains(word)) { lineScore += 100; strongHit = true; }
            }
            for (String word : medium) {
                if (line.contains(word)) { lineScore += 45; mediumHit = true; }
            }
            for (String word : negative) {
                if (line.contains(word)) { lineScore -= 85; negativeHit = true; }
            }

            // A total label can be on one line and its amount on the next.
            if (i + 1 < lines.length) {
                String next = normalizeOcrText(lines[i + 1] == null ? "" : lines[i + 1]).toLowerCase(Locale.ROOT).trim();
                if ((strongHit || mediumHit) && numbers(lines[i + 1]).size() > 0) lineScore += 35;
                if (containsAny(next, negative)) lineScore -= 30;
            }
            if (i > 0) {
                String prev = normalizeOcrText(lines[i - 1] == null ? "" : lines[i - 1]).toLowerCase(Locale.ROOT).trim();
                if ((strongHit || mediumHit) && numbers(lines[i - 1]).size() > 0) lineScore += 20;
            }

            // Payment/change/tax lines are almost never the receipt total.
            if (negativeHit && !strongHit) lineScore -= 35;

            for (int n = 0; n < nums.size(); n++) {
                double value = nums.get(n);
                if (value <= 0 || value > 1000000000d) continue;
                double score = lineScore;

                // Monetary-looking decimals are more useful than integers.
                if (hasCurrencyDecimal(original, value)) score += 8;
                if (n == nums.size() - 1) score += 3;

                // A standalone amount immediately after a total label is very strong.
                if (i > 0) {
                    String prev = normalizeOcrText(lines[i - 1] == null ? "" : lines[i - 1]).toLowerCase(Locale.ROOT);
                    if (containsAny(prev, strong)) score += 75;
                    else if (containsAny(prev, medium)) score += 30;
                }
                if (i + 1 < lines.length) {
                    String next = normalizeOcrText(lines[i + 1] == null ? "" : lines[i + 1]).toLowerCase(Locale.ROOT);
                    if (containsAny(next, strong)) score += 25;
                }

                // Product quantities/prices should lose to explicit totals.
                if (looksLikeDate(original)) score -= 100;
                if (value < 0.01d) score -= 30;
                candidates.add(new AmountCandidate(value, score));
            }
        }

        AmountCandidate best = null;
        for (AmountCandidate c : candidates) {
            if (best == null || c.score > best.score ||
                    (Math.abs(c.score - best.score) < 0.001 && c.value > best.value)) best = c;
        }

        // Conservative fallback: only use a plausible monetary amount when OCR
        // found no meaningful total label at all.
        if (best == null || best.score < 12) {
            double fallback = 0;
            for (String line : lines) {
                if (looksLikeDate(line)) continue;
                String normalized = normalizeOcrText(line).toLowerCase(Locale.ROOT);
                if (containsAny(normalized, negative)) continue;
                for (double v : numbers(line)) {
                    if (v > fallback && v <= 1000000000d && hasCurrencyDecimal(line, v)) fallback = v;
                }
            }
            return new double[]{fallback, Math.max(0d, best == null ? 0d : best.score)};
        }
        return new double[]{best.value, best.score};
    }

    private boolean hasCurrencyDecimal(String line, double value) {
        String s = line == null ? "" : line;
        if (s.matches(".*(?:₺|tl|try|€|eur|\$|usd|rub|руб|¥|jpy|元).*")) return true;
        // Most receipt prices use exactly one or two decimal digits.
        return Math.abs(value - Math.rint(value)) > 0.000001d;
    }

    private boolean looksLikeDate(String line) {
        if (line == null) return false;
        return line.matches(".*\\b\\d{1,4}[./-]\\d{1,2}[./-]\\d{1,4}\\b.*");
    }

    private boolean containsAny(String text, String[] words) {
        if (text == null) return false;
        for (String word : words) if (text.contains(word)) return true;
        return false;
    }

    private String normalizeOcrText(String value) {
        if (value == null) return "";
        return value.replace('İ', 'i').replace('I', 'i').replace('ı', 'i')
                .replace('Ö', 'ö').replace('Ü', 'ü').replace('Ç', 'ç').replace('Ğ', 'ğ').replace('Ş', 'ş')
                .replace('—', '-').replace('–', '-')
                .replaceAll("\\s+", " ").trim();
    }

    private List<Double> numbers(String line) {
        ArrayList<Double> out = new ArrayList<>();
        if (line == null) return out;
        // Supports 1.249,90 / 1,249.90 / 1249,90 / 1 249,90 / currency-prefixed values.
        Matcher m = Pattern.compile("(?<!\\d)(?:\\d{1,3}(?:[ .][0-9]{3})+|\\d+)(?:[.,]\\d{1,2})?(?!\\d)").matcher(line);
        while (m.find()) {
            Double v = parseNumber(m.group());
            if (v != null && v >= 0) out.add(v);
        }
        return out;
    }

    private Double parseNumber(String value) {
        try {
            String x = value.replace(" ", "").replace("\u00A0", "");
            int comma = x.lastIndexOf(',');
            int dot = x.lastIndexOf('.');
            if (comma >= 0 && dot >= 0) {
                if (comma > dot) x = x.replace(".", "").replace(',', '.');
                else x = x.replace(",", "");
            } else if (comma >= 0) {
                int after = x.length() - comma - 1;
                if (after <= 2) x = x.replace(',', '.');
                else x = x.replace(",", "");
            } else if (dot >= 0) {
                int after = x.length() - dot - 1;
                if (after > 2) x = x.replace(".", "");
            }
            return Double.parseDouble(x);
        } catch (Exception e) { return null; }
    }

    private String findDate(String raw) {
        Pattern[] ps = { Pattern.compile("(?<!\\d)(\\d{1,2})[./-](\\d{1,2})[./-](\\d{2,4})(?!\\d)"), Pattern.compile("(?<!\\d)(\\d{4})[./-](\\d{1,2})[./-](\\d{1,2})(?!\\d)") };
        for (Pattern p : ps) {
            Matcher m=p.matcher(raw); if(!m.find()) continue;
            String a=m.group(1),b=m.group(2),c=m.group(3);
            try { Date d; if(a.length()==4) d=new SimpleDateFormat("yyyy-M-d",Locale.US).parse(a+"-"+b+"-"+c); else {if(c.length()==2)c="20"+c; d=new SimpleDateFormat("d-M-yyyy",Locale.US).parse(a+"-"+b+"-"+c);} return new SimpleDateFormat("dd.MM.yyyy",Locale.US).format(d); } catch (ParseException ignored) {}
        }
        return "";
    }

    private String findMerchant(String[] lines) {
        String[] bad={"receipt","fiş","fis","invoice","fatura","total","toplam","date","tarih","cash","nakit","card","kart","visa","mastercard","www.","tel:","telefon","vergi","tax","no:","no.","subtotal","ara toplam"};
        for(String line:lines){
            String x=line.trim().replaceAll("\\s+"," "); if(x.length()<3||x.length()>48||!x.matches(".*[A-Za-zÇĞİÖŞÜçğıöşü].*"))continue;
            String l=x.toLowerCase(Locale.ROOT); boolean skip=false; for(String b:bad)if(l.contains(b)){skip=true;break;} if(skip)continue;
            if(x.matches(".*\\d{4,}.*") && x.length()<12)continue; return x;
        }
        return "";
    }

    private String inferCategory(String raw) {
        String x=raw.toLowerCase(Locale.ROOT);
        if(has(x,"market","migros","carrefour","bim","a101","şok","sok","grocery","supermarket","kaufland","aldi","lidl"))return "Market";
        if(has(x,"restaurant","restoran","cafe","kahve","food","yemek","pizza","burger","starbucks"))return "Yemek";
        if(has(x,"fuel","petrol","gas station","benzin","motorin","opet","shell","bp","totalenergies"))return "Yakıt";
        if(has(x,"taxi","uber","bolt","transport","ulaşım","ulasim","metro","bus","otobüs","otobus"))return "Ulaşım";
        if(has(x,"electric","elektrik","water","su faturası","su faturasi","internet","telecom","telefon faturası","phone bill"))return "Fatura";
        if(has(x,"pharmacy","eczane","hospital","hastane","clinic","klinik","health"))return "Sağlık";
        if(has(x,"clothing","giyim","fashion","zara","h&m","lc waikiki","uniqlo"))return "Giyim";
        if(has(x,"school","education","eğitim","egitim","book","kitap","course","kurs"))return "Eğitim";
        if(has(x,"hotel","booking","airbnb","flight","uçuş","ucus","travel","seyahat"))return "Seyahat";
        if(has(x,"home","ev","furniture","mobilya","ikea","house"))return "Ev";
        if(has(x,"cinema","sinema","movie","concert","konser","entertainment","eğlence","eglence"))return "Eğlence";
        return "";
    }
    private boolean has(String text,String... words){for(String w:words)if(text.contains(w))return true;return false;}

    private void fail(String message) { hideProgress(); if(callback!=null) callback.onError(message==null?host.s(R.string.ui_receipt_unknown_error):message); }
}
