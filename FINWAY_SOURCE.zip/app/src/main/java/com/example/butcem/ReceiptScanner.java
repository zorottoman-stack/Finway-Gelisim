package com.example.butcem;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.core.content.FileProvider;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Isolated receipt capture/OCR layer. It never writes transactions itself;
 * MainActivity receives the extracted values and uses its existing expense form.
 */
final class ReceiptScanner {
    interface Callback {
        void onSuccess(ReceiptData data);
        void onError(String message);
    }

    static final class ReceiptData {
        final String merchant;
        final String date;
        final double amount;
        final String category;
        ReceiptData(String merchant, String date, double amount, String category) {
            this.merchant = merchant == null ? "" : merchant.trim();
            this.date = date == null ? "" : date.trim();
            this.amount = amount;
            this.category = category == null ? "" : category.trim();
        }
    }

    static final int CAMERA_PERMISSION = 9201;
    private final MainActivity host;
    private Uri cameraUri;
    private Callback callback;
    private Dialog progress;

    ReceiptScanner(MainActivity host) { this.host = host; }

    void chooseSource(Callback cb) {
        callback = cb;
        Dialog d = new Dialog(host);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout root = new LinearLayout(host);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(host.dp(20), host.dp(20), host.dp(20), host.dp(14));
        root.setBackground(host.bg(host.C().surface, 24));

        TextView title = host.text(host.s(R.string.ui_receipt_source_title), 20, host.C().text);
        title.setTypeface(android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD));
        root.addView(title);
        TextView sub = host.text(host.s(R.string.ui_receipt_source_subtitle), 12, host.C().muted);
        host.margins(sub, 0, 4, 0, 14);
        root.addView(sub);

        LinearLayout camera = sourceCard("camera", host.s(R.string.ui_receipt_camera), host.s(R.string.ui_receipt_camera_subtitle));
        LinearLayout gallery = sourceCard("image", host.s(R.string.ui_receipt_gallery), host.s(R.string.ui_receipt_gallery_subtitle));
        root.addView(camera, new LinearLayout.LayoutParams(-1, host.dp(72)));
        host.margins(gallery, 0, 8, 0, 0);
        root.addView(gallery, new LinearLayout.LayoutParams(-1, host.dp(72)));
        android.widget.Button cancel = host.dialogButton(host.s(R.string.ui_receipt_cancel), host.C().muted, host.C().surface);
        host.margins(cancel, 0, 12, 0, 0);
        root.addView(cancel, new LinearLayout.LayoutParams(-1, host.dp(48)));

        cancel.setOnClickListener(v -> d.dismiss());
        camera.setOnClickListener(v -> { d.dismiss(); openCamera(); });
        gallery.setOnClickListener(v -> { d.dismiss(); openGallery(); });

        d.setContentView(root);
        d.show();
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            w.setLayout(Math.min(host.getResources().getDisplayMetrics().widthPixels - host.dp(28), host.dp(430)), WindowManager.LayoutParams.WRAP_CONTENT);
        }
    }

    private LinearLayout sourceCard(String icon, String titleText, String subText) {
        LinearLayout card = host.card(host.C().surface2, 16);
        card.setPadding(host.dp(12), host.dp(10), host.dp(12), host.dp(10));
        LinearLayout row = host.row();
        MainActivity.SimpleIconView iv = host.new SimpleIconView(host, icon, host.C().blue);
        iv.setBackground(host.bg(host.C().blue2, 14));
        row.addView(iv, new LinearLayout.LayoutParams(host.dp(42), host.dp(42)));
        LinearLayout copy = new LinearLayout(host);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setPadding(host.dp(10), 0, host.dp(4), 0);
        TextView title = host.text(titleText, 14, host.C().text);
        title.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        copy.addView(title);
        TextView sub = host.text(subText, 11, host.C().muted);
        host.margins(sub, 0, 2, 0, 0);
        copy.addView(sub);
        row.addView(copy, new LinearLayout.LayoutParams(0, -2, 1));
        TextView arrow = host.text("›", 28, host.C().blue);
        arrow.setGravity(Gravity.CENTER);
        row.addView(arrow, new LinearLayout.LayoutParams(host.dp(28), host.dp(42)));
        card.addView(row);
        host.attachPressFeedback(card);
        return card;
    }

    private void openCamera() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && host.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            host.requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION);
            return;
        }
        launchCamera();
    }

    void onRequestPermissionsResult(int requestCode, int[] grantResults) {
        if (requestCode != CAMERA_PERMISSION) return;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) launchCamera();
        else fail(host.s(R.string.ui_receipt_camera_permission));
    }

    private void launchCamera() {
        try {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (intent.resolveActivity(host.getPackageManager()) == null) {
                fail(host.s(R.string.ui_receipt_camera_unavailable));
                return;
            }
            File dir = new File(host.getCacheDir(), "receipts");
            if (!dir.exists() && !dir.mkdirs()) throw new Exception("cache");
            File image = File.createTempFile("receipt_", ".jpg", dir);
            cameraUri = FileProvider.getUriForFile(host, host.getPackageName() + ".fileprovider", image);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            host.startActivityForResult(intent, MainActivity.REQ_RECEIPT_CAMERA);
        } catch (Exception e) {
            fail(host.s(R.string.ui_receipt_camera_unavailable));
        }
    }

    private void openGallery() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("image/*");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            host.startActivityForResult(intent, MainActivity.REQ_RECEIPT_GALLERY);
        } catch (Exception e) {
            fail(host.s(R.string.ui_receipt_gallery_unavailable));
        }
    }

    void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == MainActivity.REQ_RECEIPT_CAMERA && resultCode != Activity.RESULT_OK) {
            fail(host.s(R.string.ui_receipt_cancelled)); return;
        }
        if (requestCode == MainActivity.REQ_RECEIPT_GALLERY && resultCode != Activity.RESULT_OK) {
            fail(host.s(R.string.ui_receipt_cancelled)); return;
        }
        if (resultCode != Activity.RESULT_OK) return;
        Uri uri = requestCode == MainActivity.REQ_RECEIPT_CAMERA ? cameraUri : (data == null ? null : data.getData());
        if (uri == null) { fail(host.s(R.string.ui_receipt_read_error)); return; }
        runOcr(uri);
    }

    private void runOcr(Uri uri) {
        showProgress();
        try {
            InputImage image = InputImage.fromFilePath(host, uri);
            TextRecognizer recognizer = recognizerForLanguage(host.receiptLanguage());
            recognizer.process(image)
                    .addOnSuccessListener(result -> {
                        try {
                            ReceiptData data = extract(result == null ? "" : result.getText());
                            if (data.amount <= 0 && TextUtils.isEmpty(data.merchant) && TextUtils.isEmpty(data.date)) {
                                fail(host.s(R.string.ui_receipt_no_data));
                            } else if (callback != null) {
                                callback.onSuccess(data);
                            }
                        } catch (Exception e) {
                            fail(host.s(R.string.ui_receipt_ocr_error));
                        } finally {
                            recognizer.close();
                        }
                    })
                    .addOnFailureListener(e -> {
                        recognizer.close();
                        fail(host.s(R.string.ui_receipt_ocr_error));
                    })
                    .addOnCompleteListener(task -> hideProgress());
        } catch (Exception e) {
            hideProgress();
            fail(host.s(R.string.ui_receipt_read_error));
        }
    }

    private TextRecognizer recognizerForLanguage(String lang) {
        if ("zh".equals(lang)) return TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
        if ("ja".equals(lang)) return TextRecognition.getClient(new JapaneseTextRecognizerOptions.Builder().build());
        return TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }

    private void showProgress() {
        if (progress != null && progress.isShowing()) return;
        progress = new Dialog(host);
        progress.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(host.dp(20), host.dp(18), host.dp(20), host.dp(18));
        box.setBackground(host.bg(host.C().surface, 20));
        ProgressBar pb = new ProgressBar(host);
        box.addView(pb, new LinearLayout.LayoutParams(host.dp(28), host.dp(28)));
        TextView t = host.text(host.s(R.string.ui_receipt_scanning), 14, host.C().text);
        host.margins(t, host.dp(12), 0, 0, 0);
        box.addView(t);
        progress.setContentView(box);
        progress.setCancelable(false);
        progress.show();
        Window w = progress.getWindow();
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            w.setLayout(Math.min(host.getResources().getDisplayMetrics().widthPixels - host.dp(50), host.dp(360)), WindowManager.LayoutParams.WRAP_CONTENT);
        }
    }

    private void hideProgress() { if (progress != null) { try { progress.dismiss(); } catch (Exception ignored) {} } }

    private ReceiptData extract(String raw) {
        if (raw == null) raw = "";
        String[] lines = raw.replace('\r', '\n').split("\\n+");
        return new ReceiptData(findMerchant(lines), findDate(raw), findTotal(lines), inferCategory(raw));
    }

    private double findTotal(String[] lines) {
        String[] words = {"total", "toplam", "genel toplam", "grand total", "amount due", "tutar", "payable", "ödenecek", "net total", "summe", "gesamt", "totale", "importe", "montant", "итого", "合計", "総額"};
        double best = 0; boolean foundKeyword = false;
        for (String line : lines) {
            String lower = line.toLowerCase(Locale.ROOT); boolean keyword = false;
            for (String word : words) if (lower.contains(word)) { keyword = true; break; }
            List<Double> nums = numbers(line); if (nums.isEmpty()) continue;
            if (!keyword && line.matches(".*\\d{1,2}[./-]\\d{1,2}[./-]\\d{2,4}.*")) continue;
            double candidate = nums.get(nums.size() - 1);
            if (keyword) { if (!foundKeyword || candidate > best) best = candidate; foundKeyword = true; }
            else if (!foundKeyword && candidate > best && candidate < 1000000000d) best = candidate;
        }
        return best;
    }

    private List<Double> numbers(String line) {
        ArrayList<Double> out = new ArrayList<>();
        Matcher m = Pattern.compile("(?<!\\d)(?:\\d{1,3}(?:[.,]\\d{3})+|\\d+)(?:[.,]\\d{1,2})?(?!\\d)").matcher(line);
        while (m.find()) { Double v = parseNumber(m.group()); if (v != null && v >= 0) out.add(v); }
        return out;
    }

    private Double parseNumber(String value) {
        try {
            String x = value.replace(" ", ""); int comma=x.lastIndexOf(','); int dot=x.lastIndexOf('.');
            if (comma>=0 && dot>=0) { if (comma>dot) x=x.replace(".","").replace(',','.'); else x=x.replace(",",""); }
            else if (comma>=0) { int after=x.length()-comma-1; if(after<=2)x=x.replace(',','.'); else x=x.replace(",",""); }
            else if (dot>=0) { int after=x.length()-dot-1; if(after>2)x=x.replace(".",""); }
            return Double.parseDouble(x);
        } catch (Exception e) { return null; }
    }

    private String findDate(String raw) {
        Pattern[] ps = { Pattern.compile("(?<!\\d)(\\d{1,2})[./-](\\d{1,2})[./-](\\d{2,4})(?!\\d)"), Pattern.compile("(?<!\\d)(\\d{4})[./-](\\d{1,2})[./-](\\d{1,2})(?!\\d)") };
        for (Pattern p : ps) {
            Matcher m=p.matcher(raw); if(!m.find()) continue;
            String a=m.group(1),b=m.group(2),c=m.group(3);
            try { Date d; if(a.length()==4) d=new SimpleDateFormat("yyyy-M-d",Locale.US).parse(a+"-"+b+"-"+c); else {if(c.length()==2)c="20"+c; d=new SimpleDateFormat("d-M-yyyy",Locale.US).parse(a+"-"+b+"-"+c);} return new SimpleDateFormat("dd.MM.yyyy",Locale.US).format(d); } catch (ParseException ignored) {}
        }
        return "";
    }

    private String findMerchant(String[] lines) {
        String[] bad={"receipt","fiş","fis","invoice","fatura","total","toplam","date","tarih","cash","nakit","card","kart","visa","mastercard","www.","tel:","telefon","vergi","tax","no:","no.","subtotal","ara toplam"};
        for(String line:lines){
            String x=line.trim().replaceAll("\\s+"," "); if(x.length()<3||x.length()>48||!x.matches(".*[A-Za-zÇĞİÖŞÜçğıöşü].*"))continue;
            String l=x.toLowerCase(Locale.ROOT); boolean skip=false; for(String b:bad)if(l.contains(b)){skip=true;break;} if(skip)continue;
            if(x.matches(".*\\d{4,}.*") && x.length()<12)continue; return x;
        }
        return "";
    }

    private String inferCategory(String raw) {
        String x=raw.toLowerCase(Locale.ROOT);
        if(has(x,"market","migros","carrefour","bim","a101","şok","sok","grocery","supermarket","kaufland","aldi","lidl"))return "Market";
        if(has(x,"restaurant","restoran","cafe","kahve","food","yemek","pizza","burger","starbucks"))return "Yemek";
        if(has(x,"fuel","petrol","gas station","benzin","motorin","opet","shell","bp","totalenergies"))return "Yakıt";
        if(has(x,"taxi","uber","bolt","transport","ulaşım","ulasim","metro","bus","otobüs","otobus"))return "Ulaşım";
        if(has(x,"electric","elektrik","water","su faturası","su faturasi","internet","telecom","telefon faturası","phone bill"))return "Fatura";
        if(has(x,"pharmacy","eczane","hospital","hastane","clinic","klinik","health"))return "Sağlık";
        if(has(x,"clothing","giyim","fashion","zara","h&m","lc waikiki","uniqlo"))return "Giyim";
        if(has(x,"school","education","eğitim","egitim","book","kitap","course","kurs"))return "Eğitim";
        if(has(x,"hotel","booking","airbnb","flight","uçuş","ucus","travel","seyahat"))return "Seyahat";
        if(has(x,"home","ev","furniture","mobilya","ikea","house"))return "Ev";
        if(has(x,"cinema","sinema","movie","concert","konser","entertainment","eğlence","eglence"))return "Eğlence";
        return "";
    }
    private boolean has(String text,String... words){for(String w:words)if(text.contains(w))return true;return false;}

    private void fail(String message) { hideProgress(); if(callback!=null) callback.onError(message==null?host.s(R.string.ui_receipt_unknown_error):message); }
}
