# Finway v0.2.84 — Teknik Stabilizasyon Raporu

## Korunan tasarım
- Kaynak tabanı: `FINWAY_SOURCEreferans.zip` (mevcut referans UI).
- Ekran yerleşimi, renkler, kart görünümü, menü ve navigasyon tasarımına bilerek dokunulmadı.
- ZIP dosya adı sabit: `FINWAY_SOURCE.zip`.
- `applicationId` değişmedi: `com.example.butcem`.

## Yapılan değişiklikler
1. `app/build.gradle`: bağımlılıklar `android {}` bloğu dışına taşındı; Java 17 `compileOptions` eklendi.
2. Release imzalama yapılandırması yalnızca keystore yolu tanımlıysa atanıyor. Play Store yayını için gerçek imzalama anahtarı yine gereklidir.
3. Sürüm, daha önce üretilen 0.2.83 / versionCode 55 paketinin üzerine kurulabilmesi için 0.2.84 / versionCode 56 yapıldı.
4. `AndroidManifest.xml`: cleartext HTTP trafiği kapatıldı; kamera donanımı zorunlu olmaktan çıkarıldı.
5. Piyasa otomatik yenilemesi 2 saniyeden 60 saniyeye alındı; manuel yenileme düğmesi değiştirilmedi.
6. JSON, Excel uyumlu HTML ve Word uyumlu HTML dışa aktarma yazıcıları try-with-resources kullanıyor.

## Kontroller
- `check_localization.py`: geçti; 11 dil, 0 raporlanan sorun.
- `check_amount_consistency.py`: geçti; 14 regresyon testi.
- `AndroidManifest.xml` ve tüm kaynak XML dosyaları: geçerli XML.
- Kaynakta piyasa adresleri: HTTPS.
- ZIP bütünlüğü: oluşturma sonrası yeniden test edilecek.

## Henüz doğrulanmayanlar
- Android Gradle derlemesi henüz çalıştırılmadı.
- APK gerçek Android cihazda açılmadı.
- PIN, hesap/ekstre hesaplamaları, yedekleme geri yükleme ve piyasa yenilemesi cihaz üzerinde test edilmelidir.
- Bu ZIP, test edilmiş veya Play Store'a hazır olduğu iddia edilen bir yayın değildir; sonraki adım GitHub Actions debug APK derlemesidir.
