# Finbi v6

- Floating Finbi mascot changed from pill/rectangular form to a compact 58dp circular bubble.
- Bubble container reduced to 68dp x 68dp to minimize screen occupation.
- External close button retained and now calls the central Finbi enable/disable state method.
- Menu Finbi switch is synchronized immediately when the bubble is closed with X, including while the Menu screen is already visible.
- Saved Finbi coordinates are clamped to the new smaller bubble bounds.
- Added a subtle idle breathing/pulse animation to the Finbi mascot.
- No locked page/business logic changed.
