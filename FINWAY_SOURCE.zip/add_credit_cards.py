from pathlib import Path
p=Path('/mnt/data/finway_work/app/src/main/java/com/example/butcem/MainActivity.java')
s=p.read_text()

s=s.replace('''    static class SavingEntry { long id; double amount; String unit, date; SavingEntry(long id,double amount,String unit,String date){this.id=id;this.amount=amount;this.unit=unit;this.date=date;} }\n''','''    static class SavingEntry { long id; double amount; String unit, date; SavingEntry(long id,double amount,String unit,String date){this.id=id;this.amount=amount;this.unit=unit;this.date=date;} }\n    static class CreditCard { long id; String name, bank; double limit, debt, statementDebt, minPayment; int statementDay, dueDay; CreditCard(long id,String name,String bank,double limit,double debt,double statementDebt,double minPayment,int statementDay,int dueDay){this.id=id;this.name=name;this.bank=bank;this.limit=limit;this.debt=debt;this.statementDebt=statementDebt;this.minPayment=minPayment;this.statementDay=statementDay;this.dueDay=dueDay;} }\n    static class Installment { long id, cardId; String merchant, firstDate, note; double total; int count, paidCount; Installment(long id,long cardId,String merchant,double total,int count,int paidCount,String firstDate,String note){this.id=id;this.cardId=cardId;this.merchant=merchant;this.total=total;this.count=count;this.paidCount=paidCount;this.firstDate=firstDate;this.note=note;} }\n    private final ArrayList<CreditCard> creditCards = new ArrayList<>();\n    private final ArrayList<Installment> installments = new ArrayList<>();\n''')

marker='''    void showMenu(){\n'''
insert=r'''    void showCreditCards(){
        marketsVisible=false;
        currentPage=4;
        base(tr("Kredi Kartlarım","My Credit Cards"));
        TextView info=text(tr("Kredi kartı borçlarını ve taksitlerini burada ayrı takip edebilirsin. Bu bölüm Finway ana bakiyesini ve harcama kayıtlarını değiştirmez.","Track card debts and installments separately. This section does not change Finway's main balance or expense records."),12,C().muted);
        margins(info,0,0,0,12);content.addView(info);

        Button add=button(tr("＋ Kredi Kartı Ekle","＋ Add Credit Card"),C().blue);
        margins(add,0,0,0,12);content.addView(add);add.setOnClickListener(v->creditCardDialog(null));

        if(creditCards.isEmpty()){
            LinearLayout empty=card(C().surface,18);empty.setPadding(dp(18),dp(24),dp(18),dp(24));
            TextView icon=text("💳",30,C().blue);icon.setGravity(Gravity.CENTER);empty.addView(icon,new LinearLayout.LayoutParams(-1,dp(42)));
            TextView e=text(tr("Henüz kredi kartı eklenmedi.","No credit cards yet."),15,C().text);e.setGravity(Gravity.CENTER);e.setTypeface(null,1);margins(e,0,8,0,2);empty.addView(e);
            TextView sub=text(tr("Banka kartlarını ve taksitlerini ana bakiyeden bağımsız takip edebilirsin.","Track your cards and installments independently from the main balance."),12,C().muted);sub.setGravity(Gravity.CENTER);empty.addView(sub);
            margins(empty,0,6,0,0);content.addView(empty);
            return;
        }

        double totalDebt=0,totalLimit=0,thisMonth=0,remainingInstallments=0;
        for(CreditCard c:creditCards){totalDebt+=Math.max(0,c.debt);totalLimit+=Math.max(0,c.limit);}
        Calendar now=Calendar.getInstance();
        for(Installment in:installments){
            if(in.count>in.paidCount){remainingInstallments+=installmentMonthly(in)*(in.count-in.paidCount);}
            for(int i=in.paidCount;i<in.count;i++){
                Calendar d=installmentDate(in,i); if(sameMonth(d,now)) thisMonth+=installmentMonthly(in);
            }
        }
        LinearLayout summary=card(C().surface,18);summary.setPadding(dp(14),dp(14),dp(14),dp(14));
        summary.addView(text(tr("Kart Özeti","Card Summary"),13,C().muted));
        TextView debt=text(tr("Toplam borç  ","Total debt  ")+money(totalDebt),22,C().text);debt.setTypeface(null,1);margins(debt,0,3,0,0);summary.addView(debt);
        summary.addView(text(tr("Kullanılabilir limit: ","Available limit: ")+money(Math.max(0,totalLimit-totalDebt)),12,C().muted));
        summary.addView(text(tr("Bu ay taksit: ","Installments this month: ")+money(thisMonth),12,C().muted));
        summary.addView(text(tr("Kalan taksit borcu: ","Remaining installment debt: ")+money(remainingInstallments),12,C().muted));
        margins(summary,0,0,0,14);content.addView(summary);

        for(CreditCard cardData:new ArrayList<>(creditCards)) addCreditCardCard(cardData);
    }

    void addCreditCardCard(final CreditCard cc){
        Colors c=C();
        LinearLayout card=card(c.surface,20);card.setPadding(dp(14),dp(14),dp(14),dp(12));
        LinearLayout head=row();
        SimpleIconView icon=new SimpleIconView(this,"card",c.blue);icon.setBackground(bg(c.blue2,18));head.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout title=new LinearLayout(this);title.setOrientation(LinearLayout.VERTICAL);title.setPadding(dp(12),0,dp(8),0);
        TextView name=text(cc.name,17,c.text);name.setTypeface(null,1);title.addView(name);
        String bank=cc.bank.trim().length()>0?cc.bank:tr("Banka bilgisi yok","Bank not specified");title.addView(text(bank,11,c.muted));
        head.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        Button edit=button("✎",c.blue);edit.setTextSize(16);edit.setPadding(0,0,0,0);head.addView(edit,new LinearLayout.LayoutParams(dp(42),dp(42)));edit.setOnClickListener(v->creditCardDialog(cc));
        Button del=button("×",c.red);del.setTextSize(18);del.setPadding(0,0,0,0);LinearLayout.LayoutParams dpb=new LinearLayout.LayoutParams(dp(42),dp(42));dpb.setMargins(dp(6),0,0,0);head.addView(del,dpb);del.setOnClickListener(v->confirmDeleteCreditCard(cc));
        card.addView(head);

        double available=Math.max(0,cc.limit-cc.debt);
        TextView debt=text(tr("Güncel borç: ","Current debt: ")+money(cc.debt),15,c.text);debt.setTypeface(null,1);margins(debt,0,12,0,2);card.addView(debt);
        card.addView(text(tr("Kullanılabilir limit: ","Available limit: ")+money(available)+" / "+money(cc.limit),12,c.muted));
        card.addView(text(tr("Ekstre borcu: ","Statement debt: ")+money(cc.statementDebt)+"   •   "+tr("Asgari: ","Minimum: ")+money(cc.minPayment),12,c.muted));
        card.addView(text(tr("Ekstre günü: ","Statement day: ")+cc.statementDay+"   •   "+tr("Son ödeme: ","Due day: ")+cc.dueDay,12,c.muted));

        ArrayList<Installment> cardInst=new ArrayList<>();for(Installment in:installments)if(in.cardId==cc.id)cardInst.add(in);
        if(cardInst.isEmpty()){
            TextView no=text(tr("Henüz taksit yok.","No installments yet."),12,c.muted);margins(no,0,12,0,6);card.addView(no);
        }else{
            TextView sh=text(tr("Taksitler","Installments"),13,c.text);sh.setTypeface(null,1);margins(sh,0,12,0,6);card.addView(sh);
            for(Installment in:new ArrayList<>(cardInst)) addInstallmentRow(card,in);
        }
        Button add=button(tr("＋ Taksit Ekle","＋ Add Installment"),c.green);add.setTextSize(13);margins(add,0,10,0,0);card.addView(add);add.setOnClickListener(v->installmentDialog(cc));
        margins(card,0,0,0,10);content.addView(card);
    }

    void addInstallmentRow(LinearLayout parent,final Installment in){
        Colors c=C();
        LinearLayout r=row();r.setPadding(dp(10),dp(9),dp(8),dp(9));r.setBackground(strokeBg(c.bg,c.border,14));
        TextView badge=text("%",17,Color.WHITE);badge.setGravity(Gravity.CENTER);badge.setBackground(bg(in.paidCount>=in.count?c.green:c.blue,16));r.addView(badge,new LinearLayout.LayoutParams(dp(40),dp(40)));
        LinearLayout mid=new LinearLayout(this);mid.setOrientation(LinearLayout.VERTICAL);mid.setPadding(dp(10),0,dp(5),0);
        TextView merchant=text(in.merchant,13,c.text);merchant.setTypeface(null,1);mid.addView(merchant);
        String line=money(installmentMonthly(in))+" × "+in.count+"   •   "+tr("Kalan ","Remaining ")+Math.max(0,in.count-in.paidCount);
        mid.addView(text(line,11,c.muted));
        if(in.firstDate.length()>0)mid.addView(text(tr("Başlangıç: ","Starts: ")+in.firstDate,10,c.muted));
        r.addView(mid,new LinearLayout.LayoutParams(0,-2,1));
        Button pay=button(in.paidCount>=in.count?"✓":tr("Öde","Pay"),in.paidCount>=in.count?c.green:c.blue);pay.setTextSize(11);pay.setEnabled(in.paidCount<in.count);pay.setAlpha(in.paidCount<in.count?1f:.8f);r.addView(pay,new LinearLayout.LayoutParams(dp(62),dp(40)));pay.setOnClickListener(v->payNextInstallment(in));
        Button del=button("×",c.red);del.setTextSize(17);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(40),dp(40));lp.setMargins(dp(5),0,0,0);r.addView(del,lp);del.setOnClickListener(v->confirmDeleteInstallment(in));
        margins(r,0,3,0,3);parent.addView(r);
    }

    double installmentMonthly(Installment in){return in.count<=0?0:in.total/in.count;}
    Calendar parseCardDate(String value){
        Calendar cal=Calendar.getInstance();
        try{Date d=new SimpleDateFormat("dd.MM.yyyy",Locale.US).parse(value);if(d!=null)cal.setTime(d);}catch(Exception ignored){}
        return cal;
    }
    Calendar installmentDate(Installment in,int index){Calendar c=parseCardDate(in.firstDate);c.add(Calendar.MONTH,index);return c;}
    boolean sameMonth(Calendar a,Calendar b){return a.get(Calendar.YEAR)==b.get(Calendar.YEAR)&&a.get(Calendar.MONTH)==b.get(Calendar.MONTH);}
    String installmentDateText(Installment in,int index){return df.format(installmentDate(in,index).getTime());}

    EditText cardNumberEdit(String hint,Colors c){EditText e=modernEdit(hint,c);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);return e;}
    void creditCardDialog(final CreditCard edit){
        Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(18),dp(18),dp(18),dp(12));outer.setBackground(bg(c.surface,24));
        TextView h=text("💳  "+tr(edit==null?"Kredi Kartı Ekle":"Kredi Kartını Düzenle",edit==null?"Add Credit Card":"Edit Credit Card"),20,c.text);h.setTypeface(null,1);outer.addView(h);
        ScrollView scroll=new ScrollView(this);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        EditText name=modernEdit(tr("Kart adı (ör. Bonus)","Card name (e.g. Bonus)"),c);box.addView(name,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText bank=modernEdit(tr("Banka adı (opsiyonel)","Bank name (optional)"),c);margins(bank,0,8,0,0);box.addView(bank,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText limit=cardNumberEdit(tr("Kart limiti", "Card limit"),c);margins(limit,0,8,0,0);box.addView(limit,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText debt=cardNumberEdit(tr("Mevcut borç", "Current debt"),c);margins(debt,0,8,0,0);box.addView(debt,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText statement=cardNumberEdit(tr("Ekstre borcu (opsiyonel)","Statement debt (optional)"),c);margins(statement,0,8,0,0);box.addView(statement,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText minimum=cardNumberEdit(tr("Asgari ödeme (opsiyonel)","Minimum payment (optional)"),c);margins(minimum,0,8,0,0);box.addView(minimum,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText statementDay=cardNumberEdit(tr("Ekstre kesim günü (1-31)","Statement day (1-31)"),c);margins(statementDay,0,8,0,0);box.addView(statementDay,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText dueDay=cardNumberEdit(tr("Son ödeme günü (1-31)","Due day (1-31)"),c);margins(dueDay,0,8,0,0);box.addView(dueDay,new LinearLayout.LayoutParams(-1,dp(54)));
        if(edit!=null){name.setText(edit.name);bank.setText(edit.bank);limit.setText(num(edit.limit));debt.setText(num(edit.debt));statement.setText(num(edit.statementDebt));minimum.setText(num(edit.minPayment));statementDay.setText(String.valueOf(edit.statementDay));dueDay.setText(String.valueOf(edit.dueDay));}
        scroll.addView(box);outer.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout acts=row();Button cancel=dialogButton(tr("İptal","Cancel"),c.muted,c.surface);Button save=dialogButton(edit==null?tr("✓  Kaydet","✓  Save"):tr("✓  Güncelle","✓  Update"),Color.WHITE,c.blue);acts.addView(cancel,new LinearLayout.LayoutParams(0,dp(54),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(54),1);sp.setMargins(dp(8),0,0,0);acts.addView(save,sp);margins(acts,0,10,0,0);outer.addView(acts);
        cancel.setOnClickListener(v->dlg.dismiss());
        save.setOnClickListener(v->{try{String n=name.getText().toString().trim();if(n.length()==0)throw new Exception();double lim=parseNum(limit),deb=parseNum(debt);if(lim<0||deb<0)throw new Exception();double st=parseOptionalNum(statement),mi=parseOptionalNum(minimum);int sd=parseDay(statementDay,1),dd=parseDay(dueDay,10);if(edit==null){creditCards.add(new CreditCard(System.currentTimeMillis(),n,bank.getText().toString().trim(),lim,deb,st,mi,sd,dd));}else{edit.name=n;edit.bank=bank.getText().toString().trim();edit.limit=lim;edit.debt=deb;edit.statementDebt=st;edit.minPayment=mi;edit.statementDay=sd;edit.dueDay=dd;}saveCreditCards();dlg.dismiss();showCreditCards();}catch(Exception ex){name.setError(tr("Kart bilgilerini kontrol et","Check the card details"));}});
        dlg.setContentView(outer);Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}
        dlg.setOnShowListener(x->{Window ww=dlg.getWindow();if(ww!=null){ww.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(440)),Math.min(dp(760),(int)(getResources().getDisplayMetrics().heightPixels*0.88f)));ww.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);}});dlg.show();
    }
    String num(double v){return String.format(Locale.US,"%.2f",v);}
    double parseNum(EditText e){return Double.parseDouble(e.getText().toString().trim().replace(",","."));}
    double parseOptionalNum(EditText e){String s=e.getText().toString().trim();return s.length()==0?0:Double.parseDouble(s.replace(",","."));}
    int parseDay(EditText e,int fallback){String s=e.getText().toString().trim();if(s.length()==0)return fallback;int d=Integer.parseInt(s);if(d<1||d>31)throw new IllegalArgumentException();return d;}

    void installmentDialog(final CreditCard cc){
        Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(18),dp(18),dp(18),dp(12));outer.setBackground(bg(c.surface,24));
        TextView h=text("＋  "+tr("Taksit Ekle","Add Installment"),20,c.text);h.setTypeface(null,1);outer.addView(h);TextView sub=text(cc.name,12,c.muted);margins(sub,0,3,0,10);outer.addView(sub);
        ScrollView scroll=new ScrollView(this);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        EditText merchant=modernEdit(tr("Mağaza / işlem adı","Merchant / purchase name"),c);box.addView(merchant,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText total=cardNumberEdit(tr("Toplam alışveriş tutarı","Total purchase amount"),c);margins(total,0,8,0,0);box.addView(total,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText count=cardNumberEdit(tr("Taksit sayısı","Number of installments"),c);count.setInputType(InputType.TYPE_CLASS_NUMBER);margins(count,0,8,0,0);box.addView(count,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText first=modernEdit(tr("İlk taksit tarihi (gg.aa.yyyy)","First installment date (dd.MM.yyyy)"),c);first.setText(df.format(new Date()));margins(first,0,8,0,0);box.addView(first,new LinearLayout.LayoutParams(-1,dp(54)));
        EditText note=modernEdit(tr("Not (opsiyonel)","Note (optional)"),c);margins(note,0,8,0,0);box.addView(note,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView preview=text(tr("Aylık taksit: Toplam tutarı ve taksit sayısını gir.","Monthly installment: enter total amount and number of installments."),12,c.muted);margins(preview,0,8,0,0);box.addView(preview);
        TextWatcher tw=new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int countx){try{double t=Double.parseDouble(total.getText().toString().replace(",","."));int n=Integer.parseInt(count.getText().toString());if(n>0)preview.setText(tr("Aylık taksit: ","Monthly installment: ")+money(t/n));}catch(Exception ignored){}}public void afterTextChanged(Editable e){}};total.addTextChangedListener(tw);count.addTextChangedListener(tw);
        scroll.addView(box);outer.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout acts=row();Button cancel=dialogButton(tr("İptal","Cancel"),c.muted,c.surface);Button save=dialogButton(tr("✓  Kaydet","✓  Save"),Color.WHITE,c.green);acts.addView(cancel,new LinearLayout.LayoutParams(0,dp(54),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(54),1);sp.setMargins(dp(8),0,0,0);acts.addView(save,sp);margins(acts,0,10,0,0);outer.addView(acts);
        cancel.setOnClickListener(v->dlg.dismiss());save.setOnClickListener(v->{try{String m=merchant.getText().toString().trim();double t=parseNum(total);int n=Integer.parseInt(count.getText().toString().trim());if(m.length()==0||t<=0||n<=0)throw new Exception();String fd=first.getText().toString().trim();parseCardDateStrict(fd);Installment in=new Installment(System.currentTimeMillis(),cc.id,m,t,n,0,fd,note.getText().toString().trim());installments.add(in);cc.debt+=t;saveCreditCards();saveInstallments();dlg.dismiss();showCreditCards();}catch(Exception e){merchant.setError(tr("Taksit bilgilerini kontrol et","Check the installment details"));}});
        dlg.setContentView(outer);Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}dlg.setOnShowListener(x->{Window ww=dlg.getWindow();if(ww!=null)ww.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(440)),Math.min(dp(690),(int)(getResources().getDisplayMetrics().heightPixels*0.84f)));});dlg.show();
    }
    void parseCardDateStrict(String s)throws Exception{Date d=new SimpleDateFormat("dd.MM.yyyy",Locale.US).parse(s);if(d==null)throw new Exception();}
    void payNextInstallment(final Installment in){if(in.paidCount>=in.count)return;CreditCard cc=findCard(in.cardId);if(cc==null)return;double amount=installmentMonthly(in);in.paidCount++;cc.debt=Math.max(0,cc.debt-amount);saveCreditCards();saveInstallments();showCreditCards();Toast.makeText(this,tr("Taksit ödendi ve kart borcu güncellendi.","Installment marked paid and card debt updated."),Toast.LENGTH_SHORT).show();}
    CreditCard findCard(long id){for(CreditCard c:creditCards)if(c.id==id)return c;return null;}
    void confirmDeleteInstallment(final Installment in){Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout o=new LinearLayout(this);o.setOrientation(LinearLayout.VERTICAL);o.setPadding(dp(18),dp(18),dp(18),dp(12));o.setBackground(bg(c.surface,24));TextView h=text(tr("Taksiti sil?","Delete installment?"),20,c.text);h.setTypeface(null,1);o.addView(h);TextView sub=text(in.merchant+" • "+money(installmentMonthly(in))+" × "+in.count,c.muted==0?12:12,c.muted);margins(sub,0,5,0,0);o.addView(sub);TextView warn=text(tr("Silmek, kalan kart borcundan bu taksitin kalan kısmını da çıkarır.","Deleting it also removes its remaining amount from the tracked card debt."),12,c.muted);margins(warn,0,5,0,0);o.addView(warn);LinearLayout a=row();Button cancel=dialogButton(tr("Vazgeç","Cancel"),c.muted,c.surface);Button del=dialogButton(tr("Sil","Delete"),Color.WHITE,c.red);a.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(52),1);sp.setMargins(dp(8),0,0,0);a.addView(del,sp);margins(a,0,14,0,0);o.addView(a);cancel.setOnClickListener(v->dlg.dismiss());del.setOnClickListener(v->{CreditCard cc=findCard(in.cardId);if(cc!=null)cc.debt=Math.max(0,cc.debt-installmentMonthly(in)*Math.max(0,in.count-in.paidCount));installments.remove(in);saveCreditCards();saveInstallments();dlg.dismiss();showCreditCards();});dlg.setContentView(o);Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}dlg.show();w=dlg.getWindow();if(w!=null){WindowManager.LayoutParams lp=w.getAttributes();lp.width=Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430));w.setAttributes(lp);}}
    void confirmDeleteCreditCard(final CreditCard cc){Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout o=new LinearLayout(this);o.setOrientation(LinearLayout.VERTICAL);o.setPadding(dp(18),dp(18),dp(18),dp(12));o.setBackground(bg(c.surface,24));TextView h=text("💳  "+tr("Kartı sil?","Delete card?"),20,c.text);h.setTypeface(null,1);o.addView(h);TextView sub=text(cc.name+" "+tr("ve bu karta ait taksitler silinecek.","and its installments will be deleted."),12,c.muted);margins(sub,0,5,0,0);o.addView(sub);LinearLayout a=row();Button cancel=dialogButton(tr("Vazgeç","Cancel"),c.muted,c.surface);Button del=dialogButton(tr("Sil","Delete"),Color.WHITE,c.red);a.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(52),1);sp.setMargins(dp(8),0,0,0);a.addView(del,sp);margins(a,0,14,0,0);o.addView(a);cancel.setOnClickListener(v->dlg.dismiss());del.setOnClickListener(v->{creditCards.remove(cc);for(int i=installments.size()-1;i>=0;i--)if(installments.get(i).cardId==cc.id)installments.remove(i);saveCreditCards();saveInstallments();dlg.dismiss();showCreditCards();});dlg.setContentView(o);Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}dlg.show();w=dlg.getWindow();if(w!=null){WindowManager.LayoutParams lp=w.getAttributes();lp.width=Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430));w.setAttributes(lp);}}

'''
if marker not in s: raise SystemExit('marker missing')
s=s.replace(marker,insert+marker,1)

old='''        currentPage = 4;base(tr("Menü","Menu"));menuItem(tr("📈  Piyasalar","📈  Markets"),()->showMarkets());menuItem(tr("🔁  Düzenli Ödemeler","🔁  Recurring Payments"),()->showRecurringPayments());menuItem(tr("🎯  Hedefler","🎯  Goals"),()->showGoals());menuItem(tr("🔄  Veri Aktarımı","🔄  Data Transfer"),()->showDataTransfer());menuItem(tr("⚙️  Ayarlar","⚙️  Settings"),()->showSettings());menuItem(tr("ℹ️  Hakkında","ℹ️  About"),()->showAbout());'''
new='''        currentPage = 4;base(tr("Menü","Menu"));menuItem(tr("📈  Piyasalar","📈  Markets"),()->showMarkets());menuItem(tr("💳  Kredi Kartlarım","💳  My Credit Cards"),()->showCreditCards());menuItem(tr("🔁  Düzenli Ödemeler","🔁  Recurring Payments"),()->showRecurringPayments());menuItem(tr("🎯  Hedefler","🎯  Goals"),()->showGoals());menuItem(tr("🔄  Veri Aktarımı","🔄  Data Transfer"),()->showDataTransfer());menuItem(tr("⚙️  Ayarlar","⚙️  Settings"),()->showSettings());menuItem(tr("ℹ️  Hakkında","ℹ️  About"),()->showAbout());'''
if old not in s: raise SystemExit('menu old missing')
s=s.replace(old,new,1)

# Add credit card backup fields
s=s.replace('''            root.put("completedGoals",new JSONArray(getPreferences(0).getString("completedGoals","[]")));\n            root.put("recurring",new JSONArray(getPreferences(0).getString("recurring","[]")));\n''','''            root.put("completedGoals",new JSONArray(getPreferences(0).getString("completedGoals","[]")));\n            root.put("recurring",new JSONArray(getPreferences(0).getString("recurring","[]")));\n            root.put("creditCards",new JSONArray(getPreferences(0).getString("creditCards","[]")));\n            root.put("installments",new JSONArray(getPreferences(0).getString("installments","[]")));\n''',1)

s=s.replace('''            JSONArray txArr=r.optJSONArray("txs"), goalArr=r.optJSONArray("goals"), completedArr=r.optJSONArray("completedGoals"), recurringArr=r.optJSONArray("recurring");\n            if(txArr==null||goalArr==null||completedArr==null||recurringArr==null)throw new Exception("missing data");\n            getPreferences(0).edit()\n                .putString("txs",txArr.toString())\n                .putString("goals",goalArr.toString())\n                .putString("completedGoals",completedArr.toString())\n                .putString("recurring",recurringArr.toString())\n                .apply();\n            txs.clear();load();loadGoals();\n''','''            JSONArray txArr=r.optJSONArray("txs"), goalArr=r.optJSONArray("goals"), completedArr=r.optJSONArray("completedGoals"), recurringArr=r.optJSONArray("recurring");\n            if(txArr==null||goalArr==null||completedArr==null||recurringArr==null)throw new Exception("missing data");\n            JSONArray cardArr=r.optJSONArray("creditCards"), installmentArr=r.optJSONArray("installments");\n            if(cardArr==null)cardArr=new JSONArray(); if(installmentArr==null)installmentArr=new JSONArray();\n            getPreferences(0).edit()\n                .putString("txs",txArr.toString())\n                .putString("goals",goalArr.toString())\n                .putString("completedGoals",completedArr.toString())\n                .putString("recurring",recurringArr.toString())\n                .putString("creditCards",cardArr.toString())\n                .putString("installments",installmentArr.toString())\n                .apply();\n            txs.clear();load();loadGoals();loadCreditCards();\n''',1)

# Clear all data
s=s.replace('''del.setOnClickListener(v->{txs.clear();goals.clear();completedGoals.clear();save();saveGoals();saveSavingEntries(new ArrayList<SavingEntry>());getPreferences(0).edit().remove("savings_unit").remove("savings_amount").remove("savings_entries_json").remove("recurring").apply();dlg.dismiss();new Handler().postDelayed(()->showHome(),700);});''','''del.setOnClickListener(v->{txs.clear();goals.clear();completedGoals.clear();creditCards.clear();installments.clear();save();saveGoals();saveCreditCards();saveInstallments();saveSavingEntries(new ArrayList<SavingEntry>());getPreferences(0).edit().remove("savings_unit").remove("savings_amount").remove("savings_entries_json").remove("recurring").apply();dlg.dismiss();new Handler().postDelayed(()->showHome(),700);});''',1)

# Add load calls on create and storage methods before loadGoals
s=s.replace('''        loadPrefs(); initFixedCategories(); load(); loadGoals(); applySystemUi(); showHome();''','''        loadPrefs(); initFixedCategories(); load(); loadGoals(); loadCreditCards(); applySystemUi(); showHome();''',1)

marker2='''    void loadGoals(){\n'''
storage=r'''    void loadCreditCards(){
        creditCards.clear();installments.clear();
        try{
            JSONArray a=new JSONArray(getPreferences(0).getString("creditCards","[]"));
            for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);creditCards.add(new CreditCard(o.optLong("id",System.currentTimeMillis()+i),o.optString("name","Kredi Kartı"),o.optString("bank",""),o.optDouble("limit",0),o.optDouble("debt",0),o.optDouble("statementDebt",0),o.optDouble("minPayment",0),o.optInt("statementDay",1),o.optInt("dueDay",10)));}
            JSONArray b=new JSONArray(getPreferences(0).getString("installments","[]"));
            for(int i=0;i<b.length();i++){JSONObject o=b.getJSONObject(i);installments.add(new Installment(o.optLong("id",System.currentTimeMillis()+i),o.optLong("cardId",0),o.optString("merchant","Taksit"),o.optDouble("total",0),o.optInt("count",1),o.optInt("paidCount",0),o.optString("firstDate",df.format(new Date())),o.optString("note","")));}
        }catch(Exception ignored){}
    }
    void saveCreditCards(){try{JSONArray a=new JSONArray();for(CreditCard c:creditCards){JSONObject o=new JSONObject();o.put("id",c.id);o.put("name",c.name);o.put("bank",c.bank);o.put("limit",c.limit);o.put("debt",c.debt);o.put("statementDebt",c.statementDebt);o.put("minPayment",c.minPayment);o.put("statementDay",c.statementDay);o.put("dueDay",c.dueDay);a.put(o);}getPreferences(0).edit().putString("creditCards",a.toString()).apply();}catch(Exception ignored){}}
    void saveInstallments(){try{JSONArray a=new JSONArray();for(Installment in:installments){JSONObject o=new JSONObject();o.put("id",in.id);o.put("cardId",in.cardId);o.put("merchant",in.merchant);o.put("total",in.total);o.put("count",in.count);o.put("paidCount",in.paidCount);o.put("firstDate",in.firstDate);o.put("note",in.note);a.put(o);}getPreferences(0).edit().putString("installments",a.toString()).apply();}catch(Exception ignored){}}

'''
if marker2 not in s: raise SystemExit('storage marker missing')
s=s.replace(marker2,storage+marker2,1)

p.write_text(s)
