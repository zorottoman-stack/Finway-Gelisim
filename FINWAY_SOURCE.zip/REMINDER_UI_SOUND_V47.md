# Finway Reminder UI & Sound Polish — V0.2.77

## Changes
- Modernized backup/restore transfer actions into full-width tappable cards with icon, title, description, and navigation affordance.
- Modernized credit-card reminder selection with clear selected-state cards and visual hierarchy.
- Modernized reminder action buttons without changing reminder behavior.
- Introduced new notification channel IDs (`v2`) so Android devices do not retain an older channel's user-controlled sound setting.
- Replaced the reminder sound with a more distinctive 1.35-second Finway notification chime.
- Preserved the existing 11-language resource localization model; no new untranslated UI strings were introduced.
- Preserved reminder scheduling, exact-alarm fallback, boot/package-replaced rearming, and localized notification copy.
- Updated app version to `0.2.77` / versionCode `49` and target/compile SDK to 36 for the upcoming Play release preparation.

## Preserved
- Home and Transactions locked pages.
- Finbi UI/behavior.
- PIN/biometric lock screen.
- Credit-card/installment module behavior.
- Existing reminder timing, custom reminder, sound toggle, and monthly re-arm logic.
