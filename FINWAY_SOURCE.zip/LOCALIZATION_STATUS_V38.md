# Finway v0.2.73 — Localization Status

## Version
- versionName: **0.2.73**
- versionCode: **45**
- The About screen now reads the installed package version dynamically and also shows the build number.

## Audit result
The project contains 451 resource keys in each of the 11 supported app languages (Turkish, English, German, French, Spanish, Italian, Russian, Japanese, Chinese, Arabic, Greek).

The audit found that the non-Turkish/non-English catalogs are not yet fully translated: a large portion of their values are still identical to the English catalog. This is a real localization gap, not a missing-key problem.

Because producing guessed or malformed translations would be worse than reporting the gap, this build does **not** claim full localization readiness and should not yet be treated as the final Play Store release candidate.

## Next localization pass
Translate the remaining English fallback values language-by-language, then run `check_localization.py` until:
- English fallback = 0 for every non-English language
- Turkish leakage = 0 for every non-Turkish language
- hard-coded version literals = 0
- all 451 keys remain present in every catalog
