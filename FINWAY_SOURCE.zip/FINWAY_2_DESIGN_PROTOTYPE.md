# Finway 2.0 — Clean UI Prototype

This source is a visual prototype based on the provided FINWAY_SOURCE reference.

## Changed
- Reworked global top app bar into a simple navigation/header structure.
- Reworked bottom navigation into a lighter 4-section navigation.
- Rebuilt Home around typography, whitespace, dividers, and financial information hierarchy.
- Rebuilt Accounts around account rows rather than large cards.
- Added an Account Detail screen with balance, income/expense summary, recent transactions, edit action, and add-transaction action.
- Existing data models, persistence, localization infrastructure, dialogs, and financial calculations were preserved.

## Intentionally not changed
- No ZIP/source filename convention.
- No versionCode/versionName change.
- No deletion of existing financial features.
- No claim of release/build readiness: this environment does not contain the project's Gradle wrapper/toolchain.

## Validation
- MainActivity.java brace balance checked.
- New method signatures checked for duplicates.
- Source tree packaged as `FINWAY_SOURCE.zip`.
