# Finway V52 — Professional Matte Green UI

## Shell
- All screens use the same compact 38dp top-left menu control inside an 11dp-radius box.
- The top-left control always opens the side drawer. It never becomes an "Ana Sayfa" control.
- Android Back continues to use Finway screen history.
- Header title is 18–19sp medium weight with a single-line ellipsis.
- Header/content separator is 1dp. Content horizontal inset is 16dp.

## Navigation
- Bottom navigation is 56dp high plus 5/6dp vertical padding.
- Four destinations share equal width; the center action slot is fixed at 66dp, keeping the plus control on the true visual center line.
- Plus circle is 52dp: prominent, but intentionally smaller than the previous 58dp treatment.
- Navigation icons are 20×22dp and use 1.9dp strokes. Labels remain 9sp.

## Iconography
- Menu/drawer icons are 36dp and simplified.
- Avoid multicolor neon icon tiles.
- App launcher icon uses a matte green Finway monogram on a warm off-white ground.

## Language picker
- Light, app-native surface; no separate dark onboarding palette.
- Language rows are 48dp high with 12dp radius and restrained borders.
- Short country/language codes replace emoji flags to reduce visual noise.

## Color hierarchy
- Warm off-white / white surfaces.
- Matte dollar-green is the primary brand/action color.
- Red is reserved for expenses/debt states.
- Gold remains informational only where semantically required.
- No neon gradients or bright cyan/magenta accents in the primary application shell.
