# Finway V53 — Navigation, Finbi & Markets Polish

## UI / UX
- Removed the empty Finbi-only card from Home.
- Improved Home header contrast and typography.
- Kept the small three-line menu control as the universal upper-left navigation control.
- Drawer title is now `Menü` / `Menu`, never `Anasayfa`.
- Drawer icons are simple line icons without colored square containers.
- Added `Piyasalar / Markets` back to the main drawer.
- Simplified first-launch language selection and fixed title/helper ordering so `Dilini seç` remains visible.
- Finbi chat now uses distinct neutral surfaces for assistant/user messages.
- Added a boxed `×` close control to the Finbi chat header.
- Removed the ambiguous three-dot action from the chat header.

## Market data
- FX remains sourced from the official TCMB daily XML feed.
- Gold no longer uses the previous custom JSON endpoint.
- Gold now uses the XAUS structured XAU spot API as TRY/gram data, avoiding HTML scraping.
- Gold is presented as indicative spot data, not a dealer buy/sell quote.

## Important
- The canonical source ZIP filename remains `FINWAY_SOURCE.zip`.
- Android/GitHub Actions build must still be used as the authoritative compile check.
- Bottom navigation root destinations now clear the screen-history stack before opening, preventing accumulated/duplicate navigation layers.
