# Finway v0.2.57 — Professional App Lock / Lock Screen

This release redesigns the app-lock experience without changing the locked Home, Transactions, Finbi, or Expense surfaces.

## Lock screen
- Full-screen white banking-style presentation inspired by the supplied reference.
- Finway wordmark centered in the top bar with a safe back/exit action.
- Finway brand-F security badge instead of a personal profile image.
- “Finway'e Hoşgeldiniz” greeting and security reassurance.
- Exactly six PIN positions with live filled/empty states and wrong-PIN feedback.
- Primary “Giriş Yap” action remains visually dominant and is enabled only after all six digits are entered.
- Optional biometric entry is shown only when Finway biometric login is enabled and supported.
- Finbi is explicitly hidden while the lock is displayed and restored only after successful authentication.

## PIN security and recovery
- New PINs use a random salt and a PBKDF2-derived verifier; plaintext PINs are never stored.
- Existing v17 SHA-256 PIN verifiers are accepted once and transparently migrated to the new salted verifier after a successful unlock.
- PIN length is now exactly six digits for creation, unlock, and lock-disable flows.
- “PIN'i Unuttum” launches Android's device-credential verification when the device has a secure lock configured.
- After successful device verification, the user can create a replacement six-digit Finway PIN without any Finway account or email address.
- If the device has no secure screen lock, the reset action explains the requirement instead of offering an insecure bypass.

## Session behavior
- First install remains unlocked until the user enables App Lock in Settings.
- Returning from background does not automatically trigger the lock.
- Swiping Finway away from Recents invalidates the unlocked session; the next launch requires authentication.

## Preserved surfaces
- Home remains protected and unchanged.
- Transactions remains protected and unchanged.
- Finbi overlay and its keyboard/interaction behavior remain unchanged.
- Expense keyboard/input behavior remains unchanged.
- Global localization work remains postponed as previously planned.
