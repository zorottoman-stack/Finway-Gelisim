from pathlib import Path
p=Path('/mnt/data/v226/app/src/main/java/com/example/butcem/MainActivity.java')
s=p.read_text()
# add SavingEntry class
old='static class Goal { long id; String name, icon, deadline; double target, saved; Goal(long id,String name,String icon,double target,double saved,String deadline){this.id=id;this.name=name;this.icon=icon;this.target=target;this.saved=saved;this.deadline=deadline;} }'
new=old+'\n    static class SavingEntry { long id; double amount; String unit, date; SavingEntry(long id,double amount,String unit,String date){this.id=id;this.amount=amount;this.unit=unit;this.date=date;} }'
s=s.replace(old,new)
# Move goal button before summary: remove current block and insert after base
oldbtn='        Button add=button(tr("＋ Yeni Hedef","＋ New Goal"),C().blue);margins(add,0,0,0,14);content.addView(add);add.setOnClickListener(v->goalDialog(null));\n'
s=s.replace(oldbtn,'')
needle='        base(tr("Hedefler","Goals"));\n'
s=s.replace(needle,needle+'        Button addGoalTop=button(tr("＋ Yeni Hedef","＋ New Goal"),C().blue);margins(addGoalTop,0,0,0,14);content.addView(addGoalTop);addGoalTop.setOnClickListener(v->goalDialog(null));\n',1)
start=s.index('    void addSavingsSection(){')
end=s.index('    void addCurrencyCalculator(){', start)
replacement=r'''    ArrayList<SavingEntry> getSavingEntries(){
        ArrayList<SavingEntry> list=new ArrayList<>();
        android.content.SharedPreferences p=getPreferences(0);
        String raw=p.getString("savings_entries_json","");
        if(raw!=null && !raw.trim().isEmpty()){
            try{
                JSONArray a=new JSONArray(raw);
                for(int i=0;i<a.length();i++){
                    JSONObject o=a.getJSONObject(i);
                    list.add(new SavingEntry(o.optLong("id",System.currentTimeMillis()+i),o.optDouble("amount",0),o.optString("unit","TRY"),o.optString("date",df.format(new Date()))));
                }
            }catch(Exception ignored){}
        }
        // Migrate the previous single-savings value into the new entry list once.
        if(list.isEmpty() && p.contains("savings_amount")){
            double old=p.getFloat("savings_amount",0f);String u=p.getString("savings_unit","TRY");
            if(old>0){list.add(new SavingEntry(System.currentTimeMillis(),old,u,df.format(new Date())));saveSavingEntries(list);}
        }
        return list;
    }
    void saveSavingEntries(ArrayList<SavingEntry> list){
        JSONArray a=new JSONArray();
        try{for(SavingEntry e:list){JSONObject o=new JSONObject();o.put("id",e.id);o.put("amount",e.amount);o.put("unit",e.unit);o.put("date",e.date);a.put(o);}}catch(Exception ignored){}
        getPreferences(0).edit().putString("savings_entries_json",a.toString()).apply();
    }
    double savingsTotal(ArrayList<SavingEntry> list,String unit){double t=0;for(SavingEntry e:list)if(unit.equals(e.unit))t+=e.amount;return t;}
    void addSavingsSection(){
        final Colors c=C();
        final LinearLayout box=card(darkMode?Color.rgb(17,48,62):Color.rgb(239,249,247),20);box.setPadding(dp(16),dp(15),dp(16),dp(15));
        LinearLayout head=row();SimpleIconView ic=new SimpleIconView(this,"gold",c.gold);ic.setBackground(bg(darkMode?Color.rgb(45,52,42):Color.rgb(251,246,226),20));head.addView(ic,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout titles=new LinearLayout(this);titles.setOrientation(LinearLayout.VERTICAL);titles.setPadding(dp(12),0,0,0);
        TextView h=text(tr("Birikimim","My Savings"),18,c.text);h.setTypeface(null,Typeface.BOLD);titles.addView(h);
        TextView sub=text(tr("Birikimlerini tek tek gör, toplamlarını takip et ve istediğini sil.","See each saving separately, track totals and delete any entry."),11,c.muted);sub.setMaxLines(3);margins(sub,0,2,0,0);titles.addView(sub);head.addView(titles,new LinearLayout.LayoutParams(0,-2,1));box.addView(head);
        final ArrayList<SavingEntry> entries=getSavingEntries();
        LinearLayout totalsBox=new LinearLayout(this);totalsBox.setOrientation(LinearLayout.VERTICAL);margins(totalsBox,0,12,0,6);box.addView(totalsBox);
        String[] units={"TRY","USD","EUR","GRAMALTIN"};
        boolean any=false;
        for(String u:units){double total=savingsTotal(entries,u);if(total<=0)continue;any=true;LinearLayout r=row();r.setPadding(dp(10),dp(8),dp(10),dp(8));r.setBackground(strokeBg(c.surface,c.border,12));TextView l=text(savingsUnitLabel(u),12,c.muted);r.addView(l,new LinearLayout.LayoutParams(0,-2,1));TextView v=text(formatSavings(total,u),15,u.equals("GRAMALTIN")?c.gold:(u.equals("EUR")?c.green:c.blue));v.setTypeface(null,Typeface.BOLD);r.addView(v);margins(r,0,3,0,0);totalsBox.addView(r);}
        if(!any){TextView empty=text(tr("Henüz birikim eklenmedi.","No savings added yet."),11,c.muted);totalsBox.addView(empty);}
        TextView listTitle=text(tr("Birikimler","Savings entries"),12,c.text);listTitle.setTypeface(null,Typeface.BOLD);margins(listTitle,0,8,0,5);box.addView(listTitle);
        if(entries.isEmpty()){TextView empty=text(tr("Birikim eklediğinde burada tek tek görünecek.","Your savings entries will appear here."),10,c.muted);margins(empty,0,0,0,4);box.addView(empty);}
        else for(SavingEntry e:entries){
            LinearLayout r=row();r.setPadding(dp(10),dp(8),dp(6),dp(8));r.setBackground(strokeBg(c.surface,c.border,12));
            LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);TextView a=text(formatSavings(e.amount,e.unit)+"  "+savingsUnitLabel(e.unit),14,c.text);a.setTypeface(null,Typeface.BOLD);info.addView(a);TextView d=text(e.date,10,c.muted);margins(d,2,1,0,0);info.addView(d);r.addView(info,new LinearLayout.LayoutParams(0,-2,1));
            Button del=dialogButton("×",c.red,c.surface);del.setTextSize(18);r.addView(del,new LinearLayout.LayoutParams(dp(44),dp(42)));del.setOnClickListener(v->deleteSavingEntry(e.id));margins(r,0,3,0,0);box.addView(r);
        }
        Button add=button(tr("＋ Birikim Ekle","＋ Add Savings"),c.green);add.setTextSize(13);margins(add,0,10,0,0);box.addView(add);add.setOnClickListener(v->savingsDialog());
        // Show the current total in the selected/last-used currency when available.
        String current=getPreferences(0).getString("savings_unit","");double currentTotal=savingsTotal(entries,current);if(!current.isEmpty()&&currentTotal>0){TextView totalHint=text(tr("Toplam birikim: ","Total savings: ")+formatSavings(currentTotal,current)+"  "+savingsUnitLabel(current),11,c.muted);margins(totalHint,0,7,0,0);box.addView(totalHint,box.indexOfChild(add));}
        margins(box,0,0,0,14);content.addView(box);
    }
    void deleteSavingEntry(final long id){
        final Colors c=C();new AlertDialog.Builder(this).setTitle(tr("Birikimi sil","Delete saving")).setMessage(tr("Bu birikim kaydı silinsin mi?","Delete this saving entry?"))
            .setNegativeButton(tr("İptal","Cancel"),null).setPositiveButton(tr("Sil","Delete"),(d,w)->{ArrayList<SavingEntry> list=getSavingEntries();for(int i=list.size()-1;i>=0;i--)if(list.get(i).id==id)list.remove(i);saveSavingEntries(list);showGoals();}).show();
    }
    String savingsUnitLabel(String u){if("USD".equals(u))return "$ USD";if("EUR".equals(u))return "€ EUR";if("GRAMALTIN".equals(u))return "Au Altın";return "₺ TL";}
    String formatSavings(double v,String u){return "GRAMALTIN".equals(u)?fmtGold(v):fmtCalc(v);}
    void updateSavingsResults(LinearLayout parent,double value,String unit){
        parent.removeAllViews();MarketQuote usdq=marketQuotes.get("USDTRY"),eurq=marketQuotes.get("EURTRY"),goldq=marketQuotes.get("GRAMALTIN");
        if(usdq==null||eurq==null||goldq==null){TextView w=text(tr("Piyasa verileri bekleniyor…","Waiting for market data…"),10,C().muted);parent.addView(w);return;}
        double usd=usdq.sell,eur=eurq.sell,gold=goldq.sell;if(usd<=0||eur<=0||gold<=0)return;
        double tl,usdVal,eurVal,goldGrams;if("USD".equals(unit)){usdVal=value;tl=value*usd;eurVal=tl/eur;goldGrams=tl/gold;}else if("EUR".equals(unit)){eurVal=value;tl=value*eur;usdVal=tl/usd;goldGrams=tl/gold;}else if("GRAMALTIN".equals(unit)){goldGrams=value;tl=value*gold;usdVal=tl/usd;eurVal=tl/eur;}else{tl=value;usdVal=value/usd;eurVal=value/eur;goldGrams=value/gold;}
        TextView label=text(tr("Güncel karşılıklar","Current equivalents"),10,C().muted);margins(label,0,0,0,5);parent.addView(label);
        addCalcResult(parent,"₺ TL",fmtCalc(tl),C().blue);addCalcResult(parent,"$ USD",fmtCalc(usdVal),C().blue);addCalcResult(parent,"€ EUR",fmtCalc(eurVal),C().green);addCalcResult(parent,"Au Gram Altın",fmtGold(goldGrams),C().gold);
    }
    void savingsDialog(){
        Colors c=C();Dialog dlg=new Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(18),dp(16),dp(18),dp(12));outer.setBackground(bg(c.surface,24));
        TextView h=text("💰  "+tr("Birikim Ekle","Add Savings"),20,c.text);h.setTypeface(null,Typeface.BOLD);outer.addView(h);
        EditText amount=modernEdit(tr("Tutar girin","Enter amount"),c);amount.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);margins(amount,0,12,0,10);outer.addView(amount,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView choose=text(tr("Birikim para birimi","Savings currency"),11,c.muted);outer.addView(choose);
        Spinner unit=new Spinner(this);String[] opts={"₺ TL","$ USD","€ EUR","Au Altın"};unit.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,opts));String current=getPreferences(0).getString("savings_unit","TRY");unit.setSelection("USD".equals(current)?1:"EUR".equals(current)?2:"GRAMALTIN".equals(current)?3:0);margins(unit,0,5,0,12);outer.addView(unit);
        LinearLayout actions=row();Button cancel=dialogButton(tr("İptal","Cancel"),c.muted,c.surface);Button save=dialogButton(tr("＋ Ekle","＋ Add"),Color.WHITE,c.green);actions.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(52),1);sp.setMargins(dp(8),0,0,0);actions.addView(save,sp);outer.addView(actions);
        cancel.setOnClickListener(v->dlg.dismiss());save.setOnClickListener(v->{try{double a=Double.parseDouble(amount.getText().toString().replace(",","."));if(a<=0)throw new Exception();String u=unit.getSelectedItemPosition()==1?"USD":unit.getSelectedItemPosition()==2?"EUR":unit.getSelectedItemPosition()==3?"GRAMALTIN":"TRY";ArrayList<SavingEntry> list=getSavingEntries();list.add(new SavingEntry(System.currentTimeMillis(),a,u,df.format(new Date())));saveSavingEntries(list);getPreferences(0).edit().putString("savings_unit",u).apply();dlg.dismiss();showGoals();}catch(Exception e){amount.setError(tr("Geçerli bir tutar gir","Enter a valid amount"));}});
        dlg.setContentView(outer);dlg.show();Window w=dlg.getWindow();if(w!=null)w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(430)),WindowManager.LayoutParams.WRAP_CONTENT);
    }
'''
s=s[:start]+replacement+s[end:]
p.write_text(s)
