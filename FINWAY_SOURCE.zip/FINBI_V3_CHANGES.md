# Finbi Floating Assistant v3

- Removed the baked-in "Uygulama İkonu" label from the Finbi avatar by replacing it with a clean square mascot crop.
- Added a WhatsApp-style three-dot typing indicator before every Finbi response.
- Typing delay is approximately 2 seconds.
- Expanded Finbi's local finance Q&A intents without changing existing transaction, card, goal, or navigation logic.
- Added answers for balance, income, expenses, remaining/net amount, credit-card debt/available limit/minimum payment, savings, goals, installments, card count, budget usage, summary, financial status and advice.
- Existing draggable floating-bubble behavior is preserved.
- No changes to the locked Home or Transactions page logic.
