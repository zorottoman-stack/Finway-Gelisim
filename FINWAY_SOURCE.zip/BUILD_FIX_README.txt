Finway localization build fix v3

IMPORTANT: This package fixes the previous workflow selecting the old ZIP.
The workflow now explicitly extracts Finway_Global_ResourceLocalization_RootFix_v3.zip and verifies the extracted strings.xml before Gradle.

GitHub repo must contain BOTH:
- Finway_Global_ResourceLocalization_RootFix_v3.zip
- .github/workflows/build-apk.yml from this package

Do not leave the old RootFix ZIP as the selected package.
