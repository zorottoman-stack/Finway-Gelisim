# Finway – V40 Localization Fix

- 334 previously untranslated (English-copy) UI strings were translated for ru, de, fr, es, it, ja, zh, ar, el.
- All 9 catalogs now contain 451 keys, placeholders (%1$s, %1$d, %%) verified against English.
- 4 corrupted emoji strings repaired (📱 💡 📥 in values-*/strings.xml).
- generate_localizations.py: legit identical words allow-listed, XML writer now emits a double-quoted declaration
  so its own guards pass; with complete catalogs it makes no network calls.
- check_localization.py allow-list updated (Bank, App, Total, ...).
