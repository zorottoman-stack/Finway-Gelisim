# Finbi Dialogue v15

- Finbi visual/UI, floating bubble, overlay, keyboard behavior and existing actions are unchanged.
- Expanded dialogue engine with short-term conversational context for follow-up questions.
- Added category-specific month comparison and contextual follow-ups.
- Added financial-health narrative, month-end projection, richer summary and more natural fallback guidance.
- Existing Finway data sources remain the source of truth; no transaction/card/goal business logic was changed.
- Finbi remains locked as a UI/interaction surface; this release changes only its dialogue/analysis layer.
