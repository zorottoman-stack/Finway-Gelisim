#!/usr/bin/env python3
"""Generate complete static Android localization catalogs at build time.

The English catalog is the canonical source. Existing non-English translations
are preserved; only entries that are missing or still equal to English are sent
through Google Translate's public web endpoint. Translation is generated before
AAPT, so the app itself never performs runtime translation.
"""
import json, re, time
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen
import xml.etree.ElementTree as ET

ROOT = Path("app/src/main/res")
BASE = ROOT / "values-en" / "strings.xml"
LOCALES = {"fr":"fr", "ru":"ru", "de":"de", "ja":"ja", "zh":"zh-CN", "ar":"ar", "el":"el", "es":"es", "it":"it"}
# Words that are legitimately identical to English in some languages (Bank, App, Total, ...)
ALLOW_SAME_KEYS = set(['ui_b32c30eff5', 'ui_4e815149b5', 'ui_4e963a8029', 'ui_9dd0ab3d89', 'ui_b3da56fa8d', 'ui_7e315f309a', 'ui_ok', 'ui_4942be744c', 'ui_9352c6d3f6', 'ui_c240b7a804', 'ui_d37c8e5aa0', 'ui_f3fe91e9a4', 'ui_3f6ff23cf6', 'ui_5115cef58b', 'ui_57167f4624', 'ui_a6cc92d718', 'ui_fb713e89c1', 'ui_fe236856dd', 'ui_53a4c5a8dc', 'ui_8e6e52146e'])
BATCH_SIZE = 12


def read_strings(path):
    root = ET.parse(path).getroot()
    return root, {e.attrib["name"]: (e.text or "") for e in root.findall("string")}


def protect(text):
    protected = []
    def repl(m):
        protected.append(m.group(0))
        return f"ZZZFINWAY{len(protected)-1}ZZZ"
    # Keep product name, Android printf placeholders, and brace placeholders.
    out = re.sub(r"Finway|%\d+\$?[sdif]|\{[^{}]+\}", repl, text)
    return out, protected


def translate_batch(texts, target):
    prepared = []
    protected_all = []
    for text in texts:
        q, protected = protect(text)
        prepared.append(q)
        protected_all.append(protected)

    params = [("client", "gtx"), ("sl", "en"), ("tl", target), ("dt", "t")]
    params.extend(("q", q) for q in prepared)
    url = "https://translate.googleapis.com/translate_a/single?" + urlencode(params)
    req = Request(url, headers={"User-Agent":"Mozilla/5.0"})
    with urlopen(req, timeout=40) as r:
        data = json.loads(r.read().decode("utf-8"))

    # Google returns one result array per q when multiple q parameters are used.
    results = data[0] if isinstance(data, list) and data and isinstance(data[0], list) else []
    if len(results) != len(texts):
        raise RuntimeError(f"translation batch size mismatch: expected {len(texts)}, got {len(results)}")

    out = []
    for translated_parts, protected in zip(results, protected_all):
        value = "".join(p[0] for p in translated_parts if p and p[0])
        for i, original in enumerate(protected):
            value = value.replace(f"ZZZFINWAY{i}ZZZ", original)
        value = value.replace("\\", "").replace("'", "’")
        out.append(value)
    return out


def write_strings(path, values, order):
    root = ET.Element("resources")
    for key in order:
        e = ET.SubElement(root, "string", {"name": key})
        e.text = values[key]
    tree = ET.ElementTree(root)
    ET.indent(tree, space="    ")
    import io
    buf = io.BytesIO()
    tree.write(buf, encoding="utf-8", xml_declaration=False)
    path.write_text('<?xml version="1.0" encoding="utf-8"?>\n' + buf.getvalue().decode("utf-8") + "\n", encoding="utf-8")


_, en = read_strings(BASE)
order = list(en)
for locale, target in LOCALES.items():
    path = ROOT / f"values-{locale}" / "strings.xml"
    _, values = read_strings(path)
    pending = [k for k in order if (not values.get(k)) or (values.get(k) == en[k] and k not in ALLOW_SAME_KEYS)]
    changed = 0

    for start in range(0, len(pending), BATCH_SIZE):
        keys = pending[start:start+BATCH_SIZE]
        texts = [en[k] for k in keys]
        last = None
        for attempt in range(5):
            try:
                last = translate_batch(texts, target)
                break
            except Exception as exc:
                if attempt == 4:
                    raise RuntimeError(f"{locale} batch {start}:{start+BATCH_SIZE} failed: {exc}")
                time.sleep(2.0 * (attempt + 1))
        for key, translated in zip(keys, last):
            if not translated.strip():
                raise RuntimeError(f"empty translation for {locale}:{key}")
            values[key] = translated
            changed += 1
        time.sleep(0.15)

    write_strings(path, values, order)
    print(f"OK: {locale}: {changed} translations generated")

base_keys = set(en)
for locale in LOCALES:
    path = ROOT / f"values-{locale}" / "strings.xml"
    _, vals = read_strings(path)
    if set(vals) != base_keys:
        raise SystemExit(f"ERROR: locale key mismatch after generation: {locale}")
    same = sum(1 for k,v in vals.items() if v == en[k] and k not in ALLOW_SAME_KEYS)
    if same > 5:
        raise SystemExit(f"ERROR: {locale} still contains {same} English-equal UI strings")
    for key in base_keys:
        # Preserve all printf/brace placeholders exactly.
        src_ph = sorted(re.findall(r"%\d+\$?[sdif]|\{[^{}]+\}", en[key]))
        dst_ph = sorted(re.findall(r"%\d+\$?[sdif]|\{[^{}]+\}", vals[key]))
        if src_ph != dst_ph:
            raise SystemExit(f"ERROR: placeholder mismatch {locale}:{key}: {src_ph} != {dst_ph}")
    raw = path.read_text(encoding="utf-8")
    if "\\" in raw:
        raise SystemExit(f"ERROR: raw backslash remains in {path}")
    if "'" in raw:
        raise SystemExit(f"ERROR: ASCII apostrophe remains in {path}")
print("OK: complete localization generation and guards passed")
