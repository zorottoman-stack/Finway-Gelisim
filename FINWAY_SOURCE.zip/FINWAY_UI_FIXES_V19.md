# Finway UI & Transaction Fixes v19

Based on SecureLockScreen Professional v18.

## Changes
- Redesigned Home quick actions: Income / Expense / Savings use modern compact cards with icon, title and helper text.
- Normalized Account Edit dialog spacing:
  - consistent action-button gap
  - consistent delete-button gap and height
- Replaced the old native Account Spinner in transaction entry with a Finway-styled account selector and modern account picker.
- Income records are persisted with `cat = "Gelir"` and income rows no longer display a generic `Harcama` title.
- Removed the red cancelled badge/button from cancelled transaction rows. Cancellation status remains in the metadata line.
- Version bumped to 0.2.58 / versionCode 30.

## Protected areas
No intentional changes to:
- Homepage sections outside the requested quick-action cards
- Finbi overlay/keyboard behavior
- Expense keyboard/input behavior
- Professional app lock screen
- Transactions filtering/search structure
