#!/usr/bin/env python3
import xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path("app/src/main/res")
BASE=ROOT/"values-en"/"strings.xml"
LOCALES=["fr","ru","de","ja","zh","ar","el","es","it"]
def read(p): return {e.attrib["name"]:(e.text or "") for e in ET.parse(p).getroot().findall("string")}
en=read(BASE); auto=[k for k in en if k.startswith("auto_")]
for loc in LOCALES:
    vals=read(ROOT/f"values-{loc}"/"strings.xml")
    missing=[k for k in auto if not vals.get(k)]
    if missing: raise SystemExit(f"ERROR: {loc} missing {len(missing)} auto localization keys")
    print(f"OK: {loc}: {len(auto)} auto localization keys bundled")
print("OK: bundled localization verification passed; no network translation used")
