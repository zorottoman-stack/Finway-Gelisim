# Finway V49 — Neon Onboarding & Language Start

## Changes
- Added first-launch language selection before the visual tour.
- Selected language is persisted and the visual tour starts in that language.
- Added a premium dark/neon visual direction to the shared Finway color system.
- Refined the visual tour with:
  - neon focus border and glow
  - progress dots
  - fixed card navigation area
  - Back / Next / Skip controls
  - safer vertical positioning for small screens
  - increased text capacity and ellipsis handling
  - improved pointer glow
- Fixed the onboarding layout so the final step and bottom controls remain visible.
- Existing app features and 11-language resources are preserved.

## Development
This is a Debug-development source. Release/AAB generation is intentionally not part of this change.
