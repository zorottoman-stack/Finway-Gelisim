# Finway V48.2 — Navigation & Page Memory Fix

- Restored in-app Back navigation history.
- Android 13+ system back gesture is routed through Finway navigation history.
- Root tab navigation no longer clears the previous page history.
- If a page is opened directly with no history, Back returns to Home instead of minimizing Finway.
- Existing scroll-position restoration is preserved.
- Existing onboarding, visual tour, guide, Finbi, localization, data and security features are unchanged.

Version: 0.2.80
Version code: 52
