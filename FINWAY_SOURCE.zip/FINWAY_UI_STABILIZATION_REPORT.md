# Finway UI stabilization report — 0.2.85 (versionCode 57)

## Scope
This package is based on the previously selected Finway source ZIP. Existing screens, navigation destinations, data models, financial calculations, and the 11-language resource catalogs were preserved. Changes focus on the requested visual and dashboard issues; this is not a redesign.

## Changes made

1. **Home month switch scroll jump**
   - Month arrows now use `changeHomeMonth()` and reset the dashboard scroll position to the top for the newly selected month.
   - Scroll restoration captures the exact `ScrollView` and screen identity. Delayed callbacks from an old screen instance are ignored instead of acting on a newer page.
2. **Statement settings button in light theme**
   - Uses a muted secondary surface, theme border, and readable blue text instead of a bright flat fill. Tap action and statement settings logic are unchanged.
3. **Debt screen color consistency**
   - Replaced a one-off saturated blue on the Add Debt action with the shared theme blue.
   - Reused theme-aware muted danger surfaces for debt-related icons and delete warnings.
4. **Less vivid application accents**
   - Reduced saturation/brightness in the shared blue, green, red, and gold palette for light and dark themes. Semantic color roles remain the same.
   - Finbi's floating mascot outline now uses the shared theme accent instead of a separate bright cyan.
5. **Spacing consistency**
   - Added explicit design tokens for card gaps, item gaps, button heights, field heights, and screen side spacing.
   - Applied shared card-gap spacing to the main dashboard and shared item-gap spacing to menu rows.
   - Cards continue to use the same shared corner radius; the layout hierarchy and feature behavior were not redesigned.
6. **Version**
   - `versionName`: `0.2.85`
   - `versionCode`: `57`
   - Source archive name remains `FINWAY_SOURCE.zip`.

## Static checks run
- ZIP CRC/integrity verification: passed.
- XML parsing: 18 XML files parsed successfully.
- Localization audit: 11 languages listed; 0 reported issues.
- Amount parsing regression tests: 14/14 passed.
- Source references for month navigation and the statement/debt button handlers checked.

## Not yet verified
The Android SDK and Gradle executable are not available in this environment, so an APK was **not** built here and no real-device test has been run. GitHub Actions must compile this exact source ZIP before it can be considered build-verified. After installing the resulting APK, verify month switching from both top and scrolled positions, light/dark statement settings, debt add/edit/payment/delete, and 11-language UI.
