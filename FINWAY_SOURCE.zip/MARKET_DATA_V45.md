# Finway V45 — Market Data Stabilization

## Data sources
- **Foreign exchange:** TCMB official daily XML (`https://www.tcmb.gov.tr/kurlar/today.xml`)
- **Gram gold:** JSON API endpoint (`https://api.apinoktam.erenozdemir.com.tr/public/v1/altin`), reading the `GRA` gram-gold item.

## Reliability changes
- Removed active CanliDoviz HTML scraping from the market-data path.
- FX values are normalized by the `Unit` field in the TCMB XML.
- Last successful market values are cached locally in Android `SharedPreferences`.
- If a network request temporarily fails, the last successful values remain available instead of showing a blank market screen.
- The existing market UI, homepage market card, calculator, Finbi market responses, and watched-currency behavior remain unchanged.
- No market-data strings or UI labels were changed; the existing 11-language localization remains in place.

## Notes
TCMB publishes indicative exchange rates once per business day. Therefore TCMB FX values are official reference rates and are not intended to represent live Kapalıçarşı dealer quotes.
