# Finway 3.1 — Top Menu / Home Layout

The bottom tab navigation is removed. The home screen uses a top-left hamburger menu, a localized home title, notifications at top-right, and two equal-width summary boxes immediately below the header: My Credit Cards and My Savings. Inner screens retain back navigation in the same top-left position.
