# Finway v0.2.74 — Global Legacy Translation Bridge

This pass keeps the locked UI and business logic intact.

- The old `trUi("Turkish", "English")` path now resolves through 11 supported locales.
- TextView, Button, dialog button and EditText hint creation passes through the same legacy bridge.
- Existing resource catalogs are preserved unchanged in this pass; their remaining English-equal fallback entries still require catalog translation in a subsequent pass.
- No layout, navigation, credit-card, installment, PIN, Finbi or data rules were intentionally changed.
