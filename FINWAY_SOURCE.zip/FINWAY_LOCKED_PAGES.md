# FINWAY LOCKED PAGES

Locked reference pages in this branch:
- Anasayfa
- İşlemler
- Bankalar / Kredi Kartları
- Birikimlerim
- Menü

Do not modify these pages unless explicitly requested.
