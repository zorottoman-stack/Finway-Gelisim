# Finway 0.2.83 — selective Claude fixes merge

This merge keeps the latest Finway source as the baseline (versionCode 55 / versionName 0.2.83) and applies only low-risk improvements from `FINWAY_SOURCE_claude.zip`.

## Merged
- Market auto-refresh interval increased from 2 seconds to 60 seconds to avoid excessive requests and UI churn.
- Backup export now validates the selected URI and output stream and uses try-with-resources to close the stream reliably.
- Manifest marks camera, camera autofocus and fingerprint hardware as optional so store/device filtering does not incorrectly exclude devices; cleartext HTTP traffic is disabled.
- Gradle declares Java 17 explicitly, moves dependencies/configuration to standard top-level locations, permits an unsigned release build when no signing credentials are configured, and limits release native ABIs to ARM devices.

## Intentionally not copied from Claude
- Root-screen Back behavior: preserved the latest Finway behavior and its prior navigation requirement; it does not newly send the app to the background.
- Card radius and drawer colors: preserved the latest source's per-card radius and theme-aligned drawer.
- Localization checker: preserved the root-level 11-language audit (`check_localization.py`) because the existing GitHub Actions workflow looks for that exact path.
- Version numbers and all existing design images/assets: preserved latest source version 0.2.83 / code 55 and the full latest asset set.

## Validation
Static checks must be run after the merge. An Android build and physical-device test are not claimed until GitHub Actions produces a successful artifact and the APK is installed and exercised.
