# APK localization reference

The user-provided APK used for the regression reference identifies itself as **Finway v0.2.13**.
The current source baseline in this package is **Finway v0.2.50**.

The APK is therefore treated as a behavioral/UI reference, not as the source tree to decompile and rewrite.
No Java business logic, navigation, calculations, transaction handling, credit-card logic, or locked-page layout is changed by the localization fix.

Only these areas are changed:
- Android string-resource catalogs
- build-time translation generation
- localization validation

The build fails rather than silently shipping English text in a non-English locale.
