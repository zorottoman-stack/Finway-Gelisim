# Finway V48.1 — Visual Onboarding Tour

- Replaced text-only onboarding with a visual guided tour over real Finway screens.
- Highlighted targets use a sharp focus window with a blue glow.
- Non-target UI is covered by a soft glass-like blurred veil.
- Added pointer/hand cue and contextual next/skip controls.
- Tour navigates through Accounts, Transactions, Budget, Credit Cards, Finbi and User Guide.
- User Guide remains replayable from the menu.
- Preserves 11-language localization architecture.
- Version: 0.2.79 / versionCode 51.
