# Finway v0.2.53 — Harcama Keyboard Visibility v14

- Finbi is locked and was not modified in this change.
- Expense entry dialog remains a bottom-aligned sheet.
- Expense description field now uses both WindowInsets IME detection and the real visible display frame.
- The sheet height is synchronized with the actual keyboard-visible area.
- The description field requests a visible rectangle and the containing ScrollView reveals it after focus.
- Existing amount/category/date/card/save logic is unchanged.
