#!/usr/bin/env python3
"""Finway localization audit for all 11 supported languages.

Turkish is the source language. Android resolves values-tr first and then
falls back to values, so both catalogs are merged for the effective Turkish
catalog. The auto_* resources are a bridge used to translate legacy Turkish
UI text in non-Turkish languages; they are not required in the Turkish catalog.
"""
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parent / 'app' / 'src' / 'main' / 'res'
LANG_DIRS = {
    'tr': 'values-tr', 'en': 'values-en', 'de': 'values-de', 'fr': 'values-fr',
    'es': 'values-es', 'it': 'values-it', 'ru': 'values-ru', 'ja': 'values-ja',
    'zh': 'values-zh', 'ar': 'values-ar', 'el': 'values-el',
}
# These short/common strings may legitimately be identical across languages.
ALLOW_SAME_KEYS = {
    'ui_4e963a8029', 'ui_f3fe91e9a4', 'ui_57167f4624', 'ui_5115cef58b',
    'ui_4942be744c', 'ui_53a4c5a8dc', 'ui_4e815149b5', 'ui_3f6ff23cf6',
    'ui_ok', 'ui_a6cc92d718', 'ui_7e315f309a', 'ui_d37c8e5aa0',
    'ui_9352c6d3f6', 'ui_fb713e89c1', 'ui_8e6e52146e', 'ui_9dd0ab3d89',
    'ui_fe236856dd', 'ui_c240b7a804', 'ui_b3da56fa8d', 'ui_b32c30eff5',
    'auto_afeb846e', 'auto_40230307', 'auto_997e69da', 'auto_19a79e66',
    'auto_be57c764', 'auto_6c0080fd', 'auto_7653d48e', 'auto_58a8de05',
    'auto_c441c021', 'auto_28088bca', 'auto_75b17db6',
}
PLACEHOLDER_RE = re.compile(r'%(?:\d+\$)?(?:\.\d+)?[sdfi]|%%')
TURKISH_CHARS = re.compile(r'[çğıöşüÇĞİÖŞÜ]')


def load_catalog(folder):
    path = ROOT / folder / 'strings.xml'
    if not path.exists():
        raise FileNotFoundError(f'Missing locale catalog: {path.relative_to(ROOT)}')
    root = ET.parse(path).getroot()
    out = {}
    for item in root.findall('string'):
        name = item.attrib.get('name')
        if not name:
            continue
        if name in out:
            raise ValueError(f'Duplicate string key {name!r} in {path.relative_to(ROOT)}')
        out[name] = ''.join(item.itertext())
    return out


issues = []
catalogs = {lang: load_catalog(folder) for lang, folder in LANG_DIRS.items()}
default_tr = load_catalog('values')
base = catalogs['en']
# Runtime Turkish resolution: values-tr overrides the default values catalog.
effective_tr = dict(default_tr)
effective_tr.update(catalogs['tr'])
expected_tr = {k for k in base if not k.startswith('auto_')}
actual_tr = set(effective_tr)
for key in sorted(expected_tr - actual_tr):
    issues.append(('tr', key, 'MISSING_RUNTIME_KEY', ''))
for key in sorted(actual_tr - set(base)):
    issues.append(('tr', key, 'EXTRA_KEY', ''))

for lang in LANG_DIRS:
    if lang == 'tr':
        continue
    actual = catalogs[lang]
    missing = set(base) - set(actual)
    extra = set(actual) - set(base)
    for key in sorted(missing):
        issues.append((lang, key, 'MISSING_KEY', ''))
    for key in sorted(extra):
        issues.append((lang, key, 'EXTRA_KEY', ''))

# Validate formatting placeholders, which can cause runtime formatting crashes.
for lang in LANG_DIRS:
    actual = effective_tr if lang == 'tr' else catalogs[lang]
    expected_keys = expected_tr if lang == 'tr' else set(base)
    for key in sorted(expected_keys & set(actual) & set(base)):
        src_tokens = sorted(PLACEHOLDER_RE.findall(base[key]))
        dst_tokens = sorted(PLACEHOLDER_RE.findall(actual[key]))
        if src_tokens != dst_tokens:
            issues.append((lang, key, 'PLACEHOLDER_MISMATCH',
                           f'expected={src_tokens!r}; actual={dst_tokens!r}'))

# Detect obvious untranslated Turkish values in non-Turkish UI catalogs.
for lang in LANG_DIRS:
    if lang in ('tr', 'en'):
        continue
    for key, value in catalogs[lang].items():
        tr_value = effective_tr.get(key)
        if (tr_value is not None and value.strip() == tr_value.strip()
                and TURKISH_CHARS.search(value)
                and not (lang == 'de' and key == 'ui_a6cc92d718')):
            issues.append((lang, key, 'TR_LEAK', value))

# Check hard-coded release version labels in Java.
for path in (ROOT.parent / 'java').rglob('*.java'):
    source = path.read_text(encoding='utf-8', errors='replace')
    for match in re.finditer(r'Finway v0\.2\.\d+', source):
        issues.append(('java', str(path.relative_to(ROOT.parent.parent)),
                       'HARDCODED_VERSION', match.group(0)))

print('Finway localization audit')
print('Languages:', ', '.join(LANG_DIRS))
print('English resource keys:', len(base))
print('Turkish runtime keys (values-tr + values fallback):', len(effective_tr))
print('Legacy translation bridge keys (auto_*):', sum(k.startswith('auto_') for k in base))
for lang in LANG_DIRS:
    actual = effective_tr if lang == 'tr' else catalogs[lang]
    expected = expected_tr if lang == 'tr' else set(base)
    missing_count = len(expected - set(actual))
    fallback_count = sum(1 for k, v in catalogs.get(lang, {}).items()
                         if lang not in ('tr', 'en') and k in base
                         and v.strip() == base[k].strip() and len(v.strip()) >= 4
                         and k not in ALLOW_SAME_KEYS)
    leak_count = sum(1 for x in issues if x[0] == lang and x[2] == 'TR_LEAK')
    print(f'{lang}: keys={len(actual)}, missing={missing_count}, '
          f'English-copy candidates={fallback_count}, Turkish leakage={leak_count}')
print('Total issues:', len(issues))
if issues:
    for issue in issues[:100]:
        print(' | '.join(str(x) for x in issue))
    if len(issues) > 100:
        print(f'... {len(issues) - 100} more')
    sys.exit(2)
