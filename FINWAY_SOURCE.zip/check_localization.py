#!/usr/bin/env python3
import re, sys, xml.etree.ElementTree as ET
from pathlib import Path

ROOT=Path(__file__).resolve().parent/'app/src/main/res'
LANGS=['tr','en','de','fr','es','it','ru','ja','zh','ar','el']
DIRS={'tr':'values-tr','en':'values-en','de':'values-de','fr':'values-fr','es':'values-es','it':'values-it','ru':'values-ru','ja':'values-ja','zh':'values-zh','ar':'values-ar','el':'values-el'}

def load(lang):
    p=ROOT/DIRS[lang]/'strings.xml'
    if not p.exists(): p=ROOT/'values'/'strings.xml'
    root=ET.parse(p).getroot()
    return {x.attrib['name']: (x.text or '') for x in root.findall('string')}

D={k:load(k) for k in LANGS}
base=D['en']
issues=[]
for lang in LANGS:
    if lang in ('en','tr'): continue
    missing=set(base)-set(D[lang])
    extra=set(D[lang])-set(base)
    if missing:
        issues.append((lang,'catalog','MISSING_KEYS',str(len(missing))))
    if extra:
        issues.append((lang,'catalog','EXTRA_KEYS',str(len(extra))))
for lang in LANGS:
    if lang in ('en','tr'): continue
    for k,v in D[lang].items():
        if k in base and v.strip()==base[k].strip() and len(v.strip())>=4 and k not in {'ui_4e963a8029', 'ui_f3fe91e9a4', 'ui_57167f4624', 'ui_5115cef58b', 'ui_4942be744c', 'ui_53a4c5a8dc', 'ui_4e815149b5', 'ui_3f6ff23cf6', 'ui_ok', 'ui_a6cc92d718', 'ui_7e315f309a', 'ui_d37c8e5aa0', 'ui_9352c6d3f6', 'ui_fb713e89c1', 'ui_8e6e52146e', 'ui_9dd0ab3d89', 'ui_fe236856dd', 'ui_c240b7a804', 'ui_b3da56fa8d', 'ui_b32c30eff5', 'auto_afeb846e', 'auto_40230307', 'auto_997e69da', 'auto_19a79e66', 'auto_be57c764', 'auto_6c0080fd', 'auto_7653d48e', 'auto_58a8de05', 'auto_c441c021', 'auto_28088bca', 'auto_75b17db6'}:
            issues.append((lang,k,'EN_FALLBACK',v))

# crude Turkish leakage detector for non-TR catalogs; allow product name/technical tokens.
tr=D['tr']
for lang in LANGS:
    if lang in ('tr','en'): continue
    for k,v in D[lang].items():
        if k in tr and v.strip()==tr[k].strip() and re.search(r'[çğıöşüÇĞİÖŞÜ]', v) and not (lang=='de' and k=='ui_a6cc92d718'):
            issues.append((lang,k,'TR_LEAK',v))

# hard-coded version literals in Java
java=(ROOT.parent/'java').rglob('*.java')
for p in java:
    s=p.read_text(errors='ignore')
    for m in re.finditer(r'Finway v0\.2\.\d+',s):
        issues.append(('java',str(p.relative_to(ROOT.parent.parent)),'HARDCODED_VERSION',m.group(0)))

print('Finway localization audit')
print('Languages:', ', '.join(LANGS))
print('Keys per language:', {k:len(v) for k,v in D.items()})
for lang in LANGS:
    if lang=='en': continue
    n=sum(1 for x in issues if x[0]==lang and x[2]=='EN_FALLBACK')
    t=sum(1 for x in issues if x[0]==lang and x[2]=='TR_LEAK')
    print(f'{lang}: English fallback={n}, Turkish leakage={t}')
print('Total issues:',len(issues))
if issues:
    for x in issues[:80]: print(' | '.join(x))
    if len(issues)>80: print(f'... {len(issues)-80} more')
    sys.exit(2)
