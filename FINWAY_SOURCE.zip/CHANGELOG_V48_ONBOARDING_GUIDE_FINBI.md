# Finway V48 — Onboarding + Kullanım Kılavuzu + Finbi Guide

- İlk V48 açılışında 6 adımlı onboarding turu.
- Menüye Kullanım Kılavuzu eklendi.
- Kılavuz; hesaplar, işlemler, bütçe, kredi kartları, abonelikler, Finbi, analiz ve güvenlik/yedekleme konularını kapsıyor.
- Finbi; “Finway'i nasıl kullanırım?”, “Bütçe nasıl oluşturulur?”, “Hesap nasıl eklenir?”, “Kredi kartı nasıl eklenir?” gibi kullanım sorularını kılavuz içeriğiyle yanıtlıyor.
- Onboarding ve kılavuz metinleri 11 dil için eklendi.
- V48 sürümü: versionName 0.2.78, versionCode 50.
- Geliştirme build'i yalnızca Debug APK üretir; AAB/release bu aşamada kullanılmaz.
