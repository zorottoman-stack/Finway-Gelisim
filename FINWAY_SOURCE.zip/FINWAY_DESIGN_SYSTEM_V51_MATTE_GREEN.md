# Finway V51 — Matte Green Original Skeleton

This release changes the information architecture and screen shell rather than applying a theme-only refresh.

## Visual language
- Primary surface: warm off-white / matte white.
- Primary identity: muted dollar green.
- Semantic negative: restrained matte red.
- Neutral text: charcoal; secondary text: muted gray-green.
- No neon gradients, glow effects, purple identity colors, or decorative color overload in the main Finway shell.

## Shared shell
- Compact top bar with menu/back, Finway/screen title, notifications.
- Scrollable content area with 18dp horizontal page inset.
- Persistent bottom navigation: Home, Accounts, central Add, Planning, Finbi.
- Central Add action uses the primary matte green only.
- 4dp rhythm for spacing; 8/12/16/20dp practical spacing steps.
- Cards use restrained 18–20dp radius and thin neutral borders.
- Primary actions are short, consistent, and aligned to a common height.

## Home skeleton
1. Financial overview label.
2. Total balance hero.
3. Income / expense summary.
4. Account stack.
5. Quick access modules.
6. Recent transactions.
7. Monthly budget status.
8. Finbi summary.

## Accounts skeleton
1. Net financial position hero.
2. Add account action.
3. Bank accounts group.
4. Credit cards group.
5. Cash / other group.

## Account detail skeleton
1. Current balance hero.
2. Send / Add / Edit actions.
3. Income / expense / net metrics.
4. Balance trend chart.
5. Recent transaction list.

## Product rule
The skeleton is intentionally independent of the final theme system. Light/dark/system theme work can be changed later by updating the palette without rebuilding the information architecture.

## Compatibility
Existing Finway data models, localization, account/transaction logic, budgets, subscriptions, debts, credit cards, reminders, receipt scanning and Finbi logic remain in the same application source.
