# Finway v0.2.73 – Stabilization Test Report

## Scope
- Central money parser/formatter consistency
- Savings / Gram Altın amount entry
- Goal / expense / income / card / installment amount paths
- Navigation and scroll-position code inspection
- Structural source checks

## Regression cases
- 2500 -> 2500
- 2.500 -> 2500
- 2.500.000 -> 2500000
- 2500.0 -> 2500
- 2500.00 -> 2500
- 2.500,50 -> 2500.50
- 2500,50 -> 2500.50
- 25.000 -> 25000
- 40.000 -> 40000
- 5.500 -> 5500
- 0,50 -> 0.50
- 1.250.000,75 -> 1250000.75
- ₺2.500,00 -> 2500
- € 12.345,67 -> 12345.67

All 14 regression cases passed in the standalone parser test.

## Static checks
- Java brace balance: 0
- Java parenthesis balance: 0
- ZIP integrity: verified after packaging
- Amount fields using the shared formatter: verified across source paths
- Finbi savings summary now uses the same currency formatter as all other financial summaries

## Important limitation
A real Android/Gradle runtime is not available in this execution environment, so an APK install/UI tap-through test was not possible here. GitHub Actions remains the final compile/runtime verification step.

## Additional UI consistency fix
- Replaced the remaining raw `String.format(Locale.US,"%.2f", savings)` display in Finbi with the shared `money()` formatter.
