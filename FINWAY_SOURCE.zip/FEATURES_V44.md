# Finway V44 — Finbi 2.0 + Budgets + Subscriptions

- Finbi multilingual intent understanding for the supported 11 languages.
- Expanded Finbi financial analysis, including budget and subscription analysis.
- Overall monthly budget plus category budgets with progress tracking.
- Subscription tracking with amount, billing day, category, active/inactive state, and one-tap monthly payment recording.
- New budget/subscription data is included in backup/restore and cleared by the existing full-reset action.
- Existing locked homepage, transactions, Finbi UI, PIN screen, and credit-card/installment module are preserved.
- Localization is bundled offline; no Google Translate/network translation is used during build.
