# Finway v25 — Lock Screen Design Build Fix

Fixed Java float/double type errors in `LockBackdropView.onDraw()` introduced by the v24 full-screen lock-screen wave background. `Path.cubicTo()` requires float parameters; all calculated width/height coordinates are now explicitly cast to float. Visual geometry is unchanged.

No other feature or locked page was intentionally changed.
