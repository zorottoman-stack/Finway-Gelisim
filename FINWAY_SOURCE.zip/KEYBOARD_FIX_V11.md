# Keyboard Fix v11

Root cause identified from the current source/APK behavior:
- The app targets SDK 35 and the activity theme uses `windowFullscreen=true`.
- The Finbi and transaction-entry dialogs were forcing `WindowCompat.setDecorFitsSystemWindows(false)` while also trying to manually resize the dialog from full-screen display metrics.
- That combination prevented the intended keyboard-safe layout from taking effect reliably.

Fix in v11:
- Finbi and transaction-entry dialogs use `SOFT_INPUT_ADJUST_PAN` so Android keeps the focused EditText visible above the IME.
- Dialog windows use `WindowCompat.setDecorFitsSystemWindows(true)` instead of forcing edge-to-edge.
- The Activity explicitly declares `adjustResize|stateAlwaysHidden` in the manifest.
- The existing scroll-to-focused-field behavior remains as an additional safeguard for the transaction description field and Finbi chat.
- Unrelated dialogs retain their previous soft-input behavior.

No financial logic or locked-page layout was changed by this fix.
