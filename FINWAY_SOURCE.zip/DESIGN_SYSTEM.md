# Finway Design System

This version adds a centralized UI consistency layer without changing financial/business behavior.

## Typography
- Caption: 12sp
- Secondary: 13sp
- Body: 14sp
- Large body: 15sp
- Card title: 16sp
- Section title: 20sp
- Screen/amount: 24sp

## Spacing
The layout rhythm is normalized to a 4dp grid: 4 / 8 / 12 / 16 / 20 / 24 / 32dp.

## Components
- Cards: 18dp radius and 16dp default internal padding
- Buttons: 16dp radius
- Fields: 14dp radius
- Pills: 22dp radius

New UI work should use `FinwayDS` tokens rather than ad-hoc values. Existing business logic and feature behavior are intentionally unchanged.
