# Finbi v8 / Keyboard architecture

- Finbi chat is an Activity-level overlay, not a Dialog.
- The composer panel is positioned above the IME using Activity window insets.
- Quick-question chips remain inside the composer area and move with it.
- Expense entry uses a bottom-sheet-style Dialog anchored to the bottom, with IME-aware height and description reveal.
- Locked Home/Transactions business logic remains unchanged.
