# Finway 3.0 — Wallet-inspired UI Architecture

This release changes the visual architecture rather than only recoloring the existing UI.

## Main changes
- Home is a financial overview with strong hierarchy and compact account/transaction rows.
- Accounts is a control center grouped by bank accounts, credit cards, and cash/other.
- Account Detail focuses on current balance, income/expense/net summary, and transaction timeline.
- Large repeated navigation cards were removed from these three screens.
- Finway's neon purple/blue identity is used as an accent rather than as a full-screen surface.
- Existing account, transaction, credit-card, Finbi, budget, goal, and navigation actions remain connected to their existing logic.

## Reference
- `DESIGN_REFERENCES/Finway_3.0_Wallet_Reference.png`

The reference is an internal visual direction only; it is not intended as a pixel-for-pixel clone of another application.
