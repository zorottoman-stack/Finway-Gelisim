# Finway V52 — Professional Shell Refinement

- Unified the top-left navigation control across all screens: compact menu button in a bordered box; it never changes to a Home label.
- Preserved Android Back as the screen-history action.
- Centered the bottom navigation plus action using a fixed central slot and reduced the circle to 52dp.
- Reduced navigation icon footprint and stroke weight for a cleaner information hierarchy.
- Simplified drawer icons and reduced drawer item density while keeping all existing destinations.
- Reworked first-launch language selection to use the Finway light surface, restrained green accent, compact language-code rows, and lower visual noise.
- Replaced the launcher foreground artwork with a restrained matte-green Finway monogram for adaptive icons and regenerated legacy launcher sizes.
- Kept the application-wide primary palette matte and green; red remains semantic for expense/debt states.
- Bumped Android versionCode to 54 and versionName to 0.2.82.
