# Finway Global Localization — Resource Based

Finway static UI localization is now deterministic and resource-based.

- Android string resources are the single source of truth for static UI text.
- Supported catalogs: Turkish, English, French, Russian, German, Japanese, Chinese, Arabic, Greek, Spanish and Italian.
- All catalogs contain the same resource keys.
- The selected language is persisted and loaded in `attachBaseContext`, so the Android resource system supplies the correct locale before the UI is created.
- Changing language recreates the activity instead of asynchronously rewriting existing TextViews.
- ML Kit is no longer part of the static UI localization path.
- Dynamic values use Android string placeholders.
- User-entered transaction, category and card names remain user data and are not translated.

The catalogs are seeded from Finway's existing curated translation catalog. If a legacy entry had no translation for a locale, English is used as a deterministic fallback. This prevents the old asynchronous mixed-language behavior while keeping every resource key available in every locale.
