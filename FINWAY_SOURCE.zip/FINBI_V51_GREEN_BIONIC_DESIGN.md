# Finbi V51 — Green Bionic Assistant Design

Finbi is designed as a native part of Finway rather than a generic chat overlay.

## Visual language
- Bionic bird mascot: green, cream, metallic, friendly and analytical.
- Matte dollar-green is the primary Finbi accent.
- Cream/off-white surfaces and restrained red are used for meaning, not decoration.
- No neon gradients, glowing purple/blue effects or excessive accent colors.
- Rounded surfaces are controlled; hierarchy comes from spacing, typography and grouping.

## Screen architecture
1. Compact identity header: mascot, Finbi, online state, secondary action.
2. Welcome/identity card with mascot and short explanation.
3. Four task-oriented entry points:
   - Spending Analysis
   - Budget Advice
   - Financial Health
   - Finway Guide
4. Finbi Suggestions card for proactive insights.
5. Conversation area for contextual questions and answers.
6. Persistent input with microphone/keyboard-compatible field and green send action.
7. Horizontal contextual question shortcuts.

## Interaction principles
- A user can start from an intent, not only from an empty chat box.
- Quick actions must produce the same analysis engine used by natural-language questions.
- Finbi responses remain connected to real Finway data and existing navigation actions.
- Keyboard/insets behavior remains compatible with the existing Activity-level overlay.
- The mascot may use subtle breathing/idle motion; no distracting neon animation.

## Content rules
- Keep headings short and consistent.
- Prefer one clear action per card.
- Avoid decorative text that competes with financial values.
- Preserve existing 11-language Finbi question/answer engine.
