# Finway Wallet Reference Design — V51

This revision uses the supplied wallet-style reference image as the primary visual specification for the main Finway experience.

## Reference screens implemented
1. Home / dashboard
2. Accounts list
3. Account detail
4. Transaction detail
5. Quick add / New record

## Visual system
- Deep navy/near-black background
- Controlled purple/blue glow accents
- Green income and red expense emphasis
- Compact rounded cards with thin borders
- Large financial figures and tight hierarchy
- Rounded period/filter chips
- Floating center `+` action button
- Four-item bottom navigation with a center action gap
- Consistent account/transaction rows
- Purposeful press feedback and short transitions

## Interaction changes
- Account rows open Account Detail.
- Transaction rows open Transaction Detail; edit remains available from the row.
- Center `+` opens a full-screen New Record flow.
- Accounts header provides search and add-account actions.
- Detail headers provide back and more actions.
- Android Back continues to use Finway screen history.

## Localization
The existing 11-language localization audit was rerun after the UI changes and reported 0 issues.

## Build note
The source was structurally checked and the Java file has balanced braces/parentheses/brackets. A local Android build was not performed in this environment because Gradle/Android SDK are not installed here; GitHub Actions remains the build verification path.
