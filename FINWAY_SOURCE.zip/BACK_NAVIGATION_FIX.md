# Back Navigation Fix

- Ana sayfadayken Android Geri tuşunun `finish()` çağırarak Finway'i arka plana atması kaldırıldı.
- Bölümler arası mevcut Finway geçmişi korunuyor.
- Ana sayfada Geri artık uygulamadan çıkış yapmıyor.
