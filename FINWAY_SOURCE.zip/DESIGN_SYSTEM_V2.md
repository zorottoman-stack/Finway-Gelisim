# Finway 2.0 Design System

## Visual identity
- Deep navy foundation
- Electric purple as the primary Finway action/brand accent
- Orange as the secondary action/high-attention accent
- Pink/coral for selected alerts and secondary emphasis
- Teal/cyan for positive financial values
- White/off-white typography with cool muted text

## Information architecture
Finway 2.0 uses a drill-down finance model instead of putting every metric on the home screen:

Home → Accounts → Account detail → Transactions
Home → Credit cards → Card detail → Statement / Installments / Transactions
Home → Budgets / Goals / Reports
Home → Finbi

The home screen is intentionally a gateway. It summarizes the user's financial position and then opens deeper screens for details.

## Navigation
Bottom navigation is:
- Home
- Accounts
- Reports
- More

Credit cards remain a dedicated finance area reachable from Home and Accounts rather than being a primary bottom tab.

## Components
- Large summary card for total financial position
- List-style navigation rows with title, subtitle, value and chevron
- Grouped account sections
- Drill-down detail screens
- Contextual Finbi insight cards
- Consistent 4dp spacing rhythm
- 18–22dp card radius

## Product rule
This redesign changes presentation and navigation structure only. Existing financial calculations, stored data, localization, reminders, lock screen and other business logic are preserved.
