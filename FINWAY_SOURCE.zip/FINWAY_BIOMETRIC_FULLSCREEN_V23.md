# Finway v23 — Biometric + Fullscreen Lock Fix

- Migrated from platform android.hardware.biometrics to AndroidX BiometricPrompt.
- Uses BIOMETRIC_WEAK so enrolled fingerprint/face implementations are accepted consistently.
- Biometric errors/cancellation leave PIN unlock available.
- Lock dialog window now lays out in screen and behind system bars, preventing the underlying home screen from showing above the lock screen.
- Lock logo remains the launcher icon.
- No changes to Finbi, homepage, transactions, or expense keyboard behavior.
