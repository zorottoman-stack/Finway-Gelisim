# Finway Secure Lock Screen v21
- Full-screen lock window: covers status/navigation areas and never reveals the underlying app.
- Lock badge now uses the exact application launcher icon (`mipmap/ic_launcher`).
- Biometric sign-in uses the device BiometricPrompt and is auto-enabled on first App Lock activation when an enrolled biometric is available.
- If biometric is enabled and available, the lock screen shows a prominent quick biometric sign-in card and starts biometric authentication automatically shortly after opening.
- Security status text changes to “Biyometrik güvenli giriş aktif” when active.
- Visual hierarchy refined for a professional banking-style lock screen.
- PIN remains 6 digits and device-credential PIN reset flow is preserved.
