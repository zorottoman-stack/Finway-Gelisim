# Finway v0.2.83 – Sonlandırma Düzeltmeleri

## V55 / 0.2.83 — Sonlandırma turu 1
- Kart bileşenleri artık çağrıda belirtilen köşe yarıçapını kullanır.
- Menü çekmecesi etkin temanın yüzey ve kenarlık renklerini kullanır.
- 11 dil için yerelleştirme denetimi Türkçe varsayılan kaynak geri dönüşünü ve biçim belirteçlerini kontrol eder.
- Bu sürümün derleme ve gerçek cihaz kontrolleri ayrıca tamamlanmalıdır.

Bu sürüm v17 güvenlik tabanı üzerine kuruludur. Findeks benzeri temiz, tam ekran bir kilit deneyimi; 6 haneli PIN; cihaz doğrulamalı PIN sıfırlama ve güvenli PIN doğrulayıcısı içerir. Kilitli Anasayfa, İşlemler, Finbi ve Harcama davranışları korunur.

## v0.2.57 — Professional App Lock
- Full-screen, banking-style Finway lock screen.
- Six-digit PIN with visual dot feedback and wrong-PIN animation.
- Optional biometric sign-in.
- Device credential verification for “PIN'i Unuttum” with no Finway account dependency.
- New PINs use a random salt + PBKDF2 verifier; plaintext is never stored.
- Existing v17 SHA-256 verifier is migrated after a successful unlock.
- Background return does not lock the app; removing Finway from Recents invalidates the unlocked session.
- Finbi is hidden while locked and restored after successful authentication.


Bu sürüm, Finway v0.2.50 GitHubFix tabanı üzerine kuruludur.

- Kredi kartı taksit sayısı artık manuel girilmez; 1–150 arasında seçim yapılır.
- Taksit ödemesi yapıldığında ödeme otomatik olarak Harcamalar/İşlemler'e eklenir ve kart borcu azaltılır.
- Kredi kartı ödemesi yapıldığında ödeme otomatik olarak Harcamalar/İşlemler'e gider olarak eklenir ve kart borcu azaltılır.
- Kredi kartı ve taksit ödemeleri Kredi Kartı kategorisiyle görünür.
- Birikim ve kur hesaplayıcıdaki Gram Altın girişlerinde daha açıklayıcı “Gram miktarını girin” alan metni kullanılır.
- GitHub Actions'taki ZIP/proje kökü tespit düzeltmeleri korunmuştur.


## v0.2.50 – Hatırlatıcılar
- Kredi kartı son ödeme tarihleri için 10/5/3/1 gün önce otomatik hatırlatma.
- Kredi kartı ödeme ekranından özel hatırlatma tarihi seçimi.
- Bildirim, titreşim ve Finway özel uyarı sesi.


## v0.2.50 — UI consistency + reminder reliability pass
- Existing app layout/features intentionally preserved; no navigation or feature redesign.
- Standardized Android sans-serif typography and medium-weight action buttons.
- Unified press feedback on primary buttons and existing selectable/clickable controls.
- Reminder scheduling now handles exact-alarm permission safely with inexact fallback instead of failing.
- Added reminder disable option and cancellation of scheduled alarms.
- Custom reminder dates are stored per card, use stable alarm IDs, reject past dates, and can be cancelled.
- Reminder channels are split into sound/silent channels for Android channel immutability.
- Reminder alarms are restored after device/app update reboot.
- Due-day calculation respects the real last day of each month.


## Notification language and wording pass
- Credit-card reminder notifications now use the language selected in Finway at the time the notification is delivered.
- Turkish wording uses formal “siz” address and correct spelling/punctuation.
- English, French, Russian, German, Japanese, Chinese, Arabic, Greek, Spanish, and Italian reminder titles/bodies use localized, polite wording and native punctuation.
- Notification channel names are localized to the selected language as well.
- Reminder settings helper text now uses formal Turkish/English wording.
- No app features, navigation, financial calculations, or existing screen designs were changed.


## UI polish – logo and bank selector
- The home Finway wordmark now uses the same bright asset in both light and dark themes for consistent branding.
- The saved-bank selector in the credit-card form now has one rounded container; the selected item no longer draws a second nested rounded box.
- Dropdown rows retain their distinct selection surface, while the closed selector stays visually clean.
- No finance features, navigation, data models, or notification behavior were changed in this pass.

## Bildirim merkezi – in-app notification history
- Telefon bildirimi oluşturulduğunda aynı bildirim Finway içindeki Bildirimler bölümüne de kaydedilir.
- Ana ekrandaki zil ikonunda okunmamış bildirim sayısı kırmızı rozet olarak gösterilir; 99 üzeri `99+` gösterilir.
- Bildirimler en yeni tarihten eskiye listelenir ve başlık, metin ve tarih/saat gösterilir.
- Bildirim merkezi açıldığında bildirimler okunmuş kabul edilir ve rozet sıfırlanır.
- Son 50 bildirim saklanır.
- Bildirim metinleri mevcut seçili dil ile kaydedilir; telefon bildirimi ile uygulama içindeki kayıt aynı metni kullanır.


## v0.2.50 market / reminder / light-theme polish
- USD/EUR and gram-gold requests are fetched concurrently so gram gold no longer waits for the currency request.
- Light theme now uses a very soft blue/green gradient background.
- Finway bright wordmark uses a transparent version so it does not sit inside a dark rectangle on the light theme.
- Bottom navigation bubble spacing is standardized.
- Credit-card reminders support an exact time or a time range; range reminders fire at the midpoint of the selected window.
- Default reminder time/range is persisted and reschedules existing reminders.
- Custom-date reminders now ask for the reminder time instead of silently using 09:00.

## v0.2.50 settings/UX continuity fix
- Credit-card reminder day has no implicit first-run selection; it starts unselected until the user chooses a reminder option.
- Existing legacy reminder defaults are ignored until the new reminder preference is explicitly initialized.
- Settings screen preserves its current scroll position after language/theme/reminder/market preference changes instead of jumping to the top.
- "Clear All Data" now keeps the user in the Menu page after completion instead of navigating Home.
- Reminder settings display "Hatırlatıcı seçin" / "Choose reminder" while no reminder day is selected.


## Son düzeltmeler
- Ana sayfadaki Finway wordmarkı yaklaşık %10 küçültüldü ve kamera/üst alan çakışmasını azaltmak için çok hafif aşağı taşındı.
- Piyasa yenilemesi döviz ve gram altın isteklerini aynı anda başlatır; sonuçlar ortak güncelleme döngüsünde işlenir.
- Otomatik piyasa güncelleme aralığı 2 saniyeye indirildi.


## Kredi Kartlarım – Profesyonel UI
- Kredi Kartlarım ekranı Finway tasarım diliyle yeniden düzenlendi.
- Üstte genel borç, kullanılabilir limit, bu ay taksit ve kalan taksit özeti görselleştirildi.
- Her kart için daha profesyonel kart yüzü, borç/limit göstergesi ve düzenli aksiyon alanları eklendi.
- Kart ekleme, düzenleme, silme, ödeme ve taksit özellikleri korunmuştur.
- Anasayfa ve kilitli İşlemler ekranına dokunulmamıştır.


## Global localization — resource architecture
- Static UI text is now backed by Android `strings.xml` resources instead of runtime TextView scraping/ML translation.
- Turkish, English, French, Russian, German, Japanese, Chinese, Arabic, Greek, Spanish and Italian catalogs share the same 451 keys.
- Language selection is loaded before Activity UI creation and changing language recreates the Activity.
- Dynamic UI text uses Android format placeholders.
- A localization parity/reference check runs in CI before the APK build.
- ML Kit translation is no longer a runtime dependency for static UI localization.
- Existing Home and Transactions page layouts/functions were not redesigned in this pass; changes are limited to localization plumbing and resource lookup.


## Finway 2.0 design update
The current source includes the Finway 2.0 navy/purple/orange visual foundation and the drill-down home/accounts navigation introduced in `CHANGELOG_V50_FINWAY_2_DESIGN.md`.
