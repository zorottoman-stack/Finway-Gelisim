import re

def parse_money(value):
    if value is None: return 0.0
    x=value.strip().replace(' ','').replace('\u00a0','')
    if not x: return 0.0
    try:
        x=x.replace('₺','').replace('$','').replace('€','').replace('£','').strip()
        comma=x.rfind(','); dot=x.rfind('.')
        if comma>=0:
            integer=re.sub(r'[^0-9-]','',x[:comma])
            fraction=re.sub(r'[^0-9]','',x[comma+1:])[:2]
            x=integer+('.'+fraction if fraction else '')
        elif dot>=0:
            count=x.count('.'); digits_after=len(x)-dot-1
            if count==1 and digits_after>0 and digits_after<=2:
                x=re.sub(r'[^0-9.-]','',x)
            else:
                x=re.sub(r'[^0-9-]','',x.replace('.',''))
        else:
            x=re.sub(r'[^0-9-]','',x)
        if x in ('','-'): return 0.0
        return float(x)
    except Exception: return 0.0

cases={'2500':2500.0,'2.500':2500.0,'2.500.000':2500000.0,'2500.0':2500.0,'2500.00':2500.0,'2.500,50':2500.50,'2500,50':2500.50,'25.000':25000.0,'40.000':40000.0,'5.500':5500.0,'0,50':0.50,'1.250.000,75':1250000.75,'₺2.500,00':2500.0,'€ 12.345,67':12345.67}
for raw,expected in cases.items():
    got=parse_money(raw); assert abs(got-expected)<1e-9,(raw,got,expected)
print(f'{len(cases)} amount parsing regression tests passed.')
