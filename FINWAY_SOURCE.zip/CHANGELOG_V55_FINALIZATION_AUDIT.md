# Finway V55 — Finalization Pass 1

- Selected `FINWAY_SOURCE.zip` as the canonical source: it is versionCode 54 / 0.2.82, ahead of the two versionCode 52 / 0.2.80 archives.
- Fixed the shared card helper so each caller's requested corner radius is actually applied.
- Removed the drawer's separate purple-tinted hard-coded palette; it now uses the active theme surface and border colors.
- Updated Android versionCode to 55 and versionName to 0.2.83 for this build.
- Improved the localization audit to model Turkish runtime fallback correctly, verify all 11 supported languages, and compare format placeholders.

This is a focused consistency pass, not a claim that the full app has passed device testing. The GitHub Actions build and an Android smoke test remain required before calling Finway release-ready.
