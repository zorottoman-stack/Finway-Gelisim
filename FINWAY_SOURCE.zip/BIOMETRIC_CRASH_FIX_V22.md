# Finway v22 — Biometric Crash Fix

- Hardened biometric capability detection for Android 10+ and legacy Android versions.
- Uses one valid biometric class (`BIOMETRIC_WEAK`) on API 30+ instead of combining STRONG + WEAK.
- Uses the legacy no-argument `canAuthenticate()` on API 28–29.
- Wrapped biometric availability, settings toggle and prompt launch in crash-safe guards.
- Biometric failures/cancellation leave the PIN screen available.
- Startup auto-enable is also guarded so biometric state cannot crash app launch.
- App lock, PIN storage, full-screen lock UI, Finbi suppression and other locked areas are preserved.
