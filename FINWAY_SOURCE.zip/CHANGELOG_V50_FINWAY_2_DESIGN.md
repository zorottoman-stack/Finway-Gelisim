# Finway v50 — Finway 2.0 visual foundation

- Introduced deep navy / purple / orange / pink visual palette.
- Reworked the home screen into a drill-down finance gateway.
- Added grouped account navigation and an account-detail transaction view.
- Changed bottom navigation to Home / Accounts / Reports / More.
- Kept credit cards, budgets, goals, transactions and Finbi reachable from the new hierarchy.
- Added Finbi as a contextual home entry point.
- Preserved existing data models and financial calculations.
- Preserved the fixed source filename requirement: `FINWAY_SOURCE.zip`.
