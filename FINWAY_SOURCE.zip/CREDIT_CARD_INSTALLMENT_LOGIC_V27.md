# Finway Credit Card & Installment Logic v27

- General credit-card payment reduces card debt and the selected cash/bank account balance.
- General credit-card payments do **not** change installment `paidCount`.
- Installment payment is a separate action and pays exactly the next installment.
- Installment payment reduces card debt, reduces the selected account balance, records a linked transaction, and increments only that installment's `paidCount`.
- Cancelling an installment-payment transaction restores card debt and decrements that installment's `paidCount`.
- New installment plans have a `Bu planı kart borcuna ekle` option (default ON). This prevents double-counting when an existing plan is only being tracked.
- Installment plans have a `⋮` menu for schedule, edit, and remove. Removing a plan removes tracking only; it does not erase historical payments or change card debt.
- Account selection uses Finway's existing modern account picker.
- Existing saved data remains backward compatible: old card payments default to `Genel` and no linked installment.


## v28 düzeltmesi
- Taksit planı düzenleme ekranında mevcut toplam tutarın `String.valueOf(double)` ile yüklenmesinden kaynaklanan binlik/ondalık format hatası düzeltildi.
- Mevcut tutar artık Finway Türkçe para formatıyla (`2.000,00`) yükleniyor; böylece 2.000 TL tekrar düzenlendiğinde 20.000/20.00 gibi bozulmuyor.
