# Experimental Digital Finance Assistant
Added as a separate experimental feature from the supplied reference ZIP.
Includes financial health, snapshot, smart insights, next-month projection,
credit-card assistant, and goals overview. Existing home and transactions
pages were not intentionally redesigned.
