# Finbi Dialogue & Navigation v30

Finbi is expanded from a simple answer + navigation button into a conversational assistant.

- Adds capability explanation and broader natural-language intent handling.
- Navigation responses explain what Finbi is doing and why.
- Navigation button click gives a short progress message before opening the target screen.
- Market auto-update navigation opens Settings and focuses the market update control.
- Existing Finbi bubble, overlay, keyboard and dialogue architecture is preserved.
- No financial transaction is executed by navigation commands.
- Credit-card/installment module remains reference-locked from v28.
- Lock screen remains reference-locked from v26.
